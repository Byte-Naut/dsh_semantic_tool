# Cordis Agent Capability Boundary E4 v0.1

This package implements a frozen Native-versus-Semantic failure-curve experiment on a real Cordis/dsh runtime.

## Experimental variable

The only calibrated semantic-complexity variable is the exact dependency depth `N` from a failed root dynamic publisher to a named leaf consumer:

```text
root Plugin --service--> Plugin --service--> ... --service--> leaf
```

Each added edge contributes exactly one real dynamic Cordis Plugin, required binding, service publication, and owned `e4:` effect. The calibration ladder is `N = 1, 2, 4, 8, 16, 24, 32, 48`. Names contain no ordinal hints, lists are not returned in causal order, and there are no decoys or irrelevant files.

Both arms must identify the root Plugin, distinguish last-successful/failed-target/active-Run state, reconstruct the exact component and service paths, preserve effect ownership, inspect the failed Package source, and execute the same three root-only lifecycle actions. Hidden grading runs the actual runtime and rejects intermediate mutation.

- **Native:** raw application timeline, dynamic inventory, components, services, bindings, and tracked effects.
- **Semantic:** one generic normalized slice containing identities, edges, typed carriers, effect ownership, Package/Run truth, and coverage.

The normalized slice deliberately returns no computed root cause, causal path, or repair. The model must perform the same causal reasoning.

## Frozen two-stage rule

Calibration executes one pair at every depth. Held-out confirmation is licensed only if calibration contains all three uncensored anchors:

1. an earlier depth where both arms pass;
2. the earliest depth where Semantic passes and Native fails;
3. a later depth where both arms fail.

The selected three depths then receive six new paired families each. If any anchor is absent, confirmatory execution is blocked; the experiment does not keep extending the ladder until a preferred pattern appears.

The 120-call per-turn budget is more than twice the conservative ordinary Native path at `N=48`. Budget exhaustion is retained as censoring and never scored as capability failure.

## Reproduce

```sh
node runner/generate-seeds.mjs
node --test test/*.test.mjs
node runner/freeze.mjs
node runner/validate-parity.mjs
node runner/run-calibration.mjs --key-stdin
node runner/analyze-results.mjs
```

Only when `artifacts/calibration-decision.json` has `"licensed": true`:

```sh
node runner/run-calibration.mjs --confirmatory --key-stdin
node runner/analyze-results.mjs
```

The Gemini API key is accepted from standard input, redacted from errors, and never persisted.
