import { rootHostCode } from '../tasks/e4-depth-chain-recovery/fixture.mjs'

export async function applyReferenceSolution(seed, runtime) {
  const rootPluginId = runtime.publicState.rootPluginId
  runtime.inspectPackage({ pluginId: rootPluginId, packageId: runtime.publicState.rootFailedPackageId })
  const restore = await runtime.runPackage({
    pluginId: rootPluginId,
    packageId: runtime.publicState.rootStablePackageId,
    mode: 'run',
  })
  if (!restore.ok) throw new Error('reference root restore failed')
  const definition = await runtime.definePackage({
    pluginId: rootPluginId,
    name: seed.dynamicComponentNames[0],
    purpose: 'publish the intended repaired root service',
    hostCode: rootHostCode({
      componentName: seed.dynamicComponentNames[0],
      serviceKey: seed.serviceKeys[0],
      effectLabel: seed.effectLabels[0],
      value: seed.repairedRootValue,
    }),
  })
  const update = await runtime.runPackage({
    pluginId: rootPluginId,
    packageId: String(definition.packageId),
    mode: 'update',
  })
  if (!update.ok) throw new Error('reference root update failed')
  return { definition, restore, update, grade: await runtime.grade() }
}
