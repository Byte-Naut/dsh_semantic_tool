import { ACTION_IDS } from '../src/config.mjs'
import { parseFinalRecord } from '../src/records.mjs'

const REQUIRED_EVIDENCE = Object.freeze([
  'dynamic_state',
  'component_identity',
  'dependency_edges',
  'bindings',
  'effect_ownership',
  'failed_source',
])

export function scoreRun({ seed, runtime, turnOneText = '', turnTwoText = '', grade, telemetryTotals, telemetryEvents }) {
  const turnOne = parseFinalRecord(turnOneText)
  const turnTwo = parseFinalRecord(turnTwoText)
  const factChecks = scoreFacts(seed, runtime, turnOne)
  const planChecks = scorePlan(runtime, turnOne)
  const actionChecks = scoreActions(seed, runtime, grade, turnTwo)
  const turnOneEvidenceClosure = hasTurnOneEvidenceClosure(telemetryEvents)
  const semanticClosure = [...factChecks, ...planChecks].every(check => check.pass) && turnOneEvidenceClosure
  const runtimePass = grade?.pass === true
  const criticalErrors = detectCriticalErrors(seed, runtime, turnOne, grade)
  const burden = reconstructionBurden({ telemetryTotals, telemetryEvents, turnOne, factChecks, planChecks })
  const topology = topologyDiagnostics(seed, turnOne)
  const primaryPass = turnOne.ok
    && turnTwo.ok
    && semanticClosure
    && actionChecks.every(check => check.pass)
    && runtimePass
    && criticalErrors.length === 0
  return {
    primaryPass,
    runtimePass,
    semanticClosure,
    turnOneEvidenceClosure,
    failureClass: primaryPass ? null : classifyFailure({ turnOne, turnTwo, semanticClosure, actionChecks, runtimePass, criticalErrors }),
    terminalRecords: {
      turnOneParsed: turnOne.ok,
      turnOneError: turnOne.error,
      turnTwoParsed: turnTwo.ok,
      turnTwoError: turnTwo.error,
    },
    factChecks,
    planChecks,
    actionChecks,
    criticalErrors,
    topology,
    burden,
  }
}

function scoreFacts(seed, runtime, parsed) {
  const facts = parsed.ok ? parsed.record.facts ?? {} : {}
  return [
    check('root_plugin', facts.root_plugin_id === runtime.publicState.rootPluginId),
    check('last_successful_package', facts.last_successful_package_id === runtime.publicState.rootStablePackageId),
    check('failed_target_package', facts.failed_target_package_id === runtime.publicState.rootFailedPackageId),
    check('active_run_typed_known_absent', facts.active_run?.kind === 'KNOWN_ABSENT' && facts.active_run?.package_id === null),
    check('complete_ordered_causal_path', exactSequence(facts.causal_path_root_to_leaf, seed.componentNames)),
    check('complete_ordered_service_path', exactSequence(facts.dependency_services_root_to_leaf, seed.serviceKeys)),
    check('complete_effect_ownership', exactEffectSet(facts.incident_effects_at_risk, expectedEffects(seed))),
    check('failed_source_inspected', parsed.ok && parsed.record.source_diagnosis?.failed_package_inspected === true),
    check('failed_source_defect', parsed.ok && parsed.record.source_diagnosis?.defect_code === 'THROW_BEFORE_PUBLISH'),
  ]
}

function scorePlan(runtime, parsed) {
  const plan = parsed.ok && Array.isArray(parsed.record.plan) ? parsed.record.plan : []
  const rootPluginId = runtime.publicState.rootPluginId
  return [
    check('enumerated_action_sequence', plan.length === 3 && plan.every((row, index) => row?.action_id === ACTION_IDS[index])),
    check('restore_root_target_and_mode', plan[0]?.plugin_id === rootPluginId
      && plan[0]?.package_id === runtime.publicState.rootStablePackageId && plan[0]?.mode === 'run'),
    check('define_under_same_root', plan[1]?.plugin_id === rootPluginId
      && plan[1]?.package_id === 'NEW_PACKAGE' && plan[1]?.mode === null),
    check('update_same_root_new_package', plan[2]?.plugin_id === rootPluginId
      && plan[2]?.package_id === 'NEW_PACKAGE' && plan[2]?.mode === 'update'),
  ]
}

function scoreActions(seed, runtime, grade, parsed) {
  const rows = parsed.ok && Array.isArray(parsed.record.actions) ? parsed.record.actions : []
  const actual = (grade?.actionLog ?? []).map(row => row.actionId)
  const newPackageId = grade?.newRootPackageId ?? null
  const rootPluginId = runtime.publicState.rootPluginId
  return [
    check('actual_enumerated_sequence', exactSequence(actual, ACTION_IDS)),
    check('recorded_enumerated_sequence', rows.length === 3 && rows.every((row, index) => row?.action_id === ACTION_IDS[index])),
    check('recorded_restore', rows[0]?.plugin_id === rootPluginId
      && rows[0]?.package_id === runtime.publicState.rootStablePackageId && rows[0]?.mode === 'run'),
    check('recorded_define', rows[1]?.plugin_id === rootPluginId
      && rows[1]?.package_id === newPackageId && rows[1]?.mode === null),
    check('recorded_update', rows[2]?.plugin_id === rootPluginId
      && rows[2]?.package_id === newPackageId && rows[2]?.mode === 'update'),
    check('verification_active_root_package', parsed.ok
      && parsed.record.verification?.active_root_package_id === newPackageId),
    check('verification_leaf_value', parsed.ok
      && parsed.record.verification?.leaf_service_value === seed.finalRepairedValue),
    check('verification_active_path', parsed.ok
      && exactSequence(parsed.record.verification?.active_path_components, seed.componentNames)),
  ]
}

function detectCriticalErrors(seed, runtime, parsed, grade) {
  const errors = []
  const record = parsed.ok ? parsed.record : {}
  const facts = record.facts ?? {}
  const plan = Array.isArray(record.plan) ? record.plan : []
  const causal = Array.isArray(facts.causal_path_root_to_leaf) ? facts.causal_path_root_to_leaf : []
  if (facts.root_plugin_id !== runtime.publicState.rootPluginId) errors.push('E_WRONG_ROOT_PLUGIN')
  if (facts.active_run?.kind !== 'KNOWN_ABSENT' || facts.active_run?.package_id !== null) errors.push('E_ACTIVE_RUN_UNKNOWN_COLLAPSED')
  if (facts.last_successful_package_id === facts.active_run?.package_id && facts.active_run?.package_id != null) errors.push('E_CURRENT_IS_ACTIVE')
  if (!exactSet(causal, seed.componentNames)) errors.push('E_CAUSAL_PATH_OMISSION')
  else if (!exactSequence(causal, seed.componentNames)) errors.push('E_CAUSAL_PATH_ORDER')
  if (!exactSequence(facts.dependency_services_root_to_leaf, seed.serviceKeys)) errors.push('E_DEPENDENCY_SERVICE_OMISSION')
  if (!exactEffectSet(facts.incident_effects_at_risk, expectedEffects(seed))) errors.push('E_EFFECT_OWNERSHIP_OMISSION')
  if (record.source_diagnosis?.failed_package_inspected !== true || grade?.inspectedFailedSource !== true) errors.push('E_FAILED_SOURCE_UNINSPECTED')
  if (plan[0]?.action_id !== 'RESTORE_ROOT_LAST_SUCCESSFUL') errors.push('E_REPAIR_BEFORE_RESTORE')
  if (plan[0]?.mode !== 'run'
    || plan[0]?.plugin_id !== runtime.publicState.rootPluginId
    || plan[0]?.package_id !== runtime.publicState.rootStablePackageId) errors.push('E_WRONG_ROLLBACK_MODE')
  if (grade?.noIntermediateMutation !== true) errors.push('E_INTERMEDIATE_MUTATION')
  if ((grade?.pluginCount ?? seed.depth) !== seed.depth) errors.push('E_NEW_PLUGIN')
  const rootNewPackages = grade?.packageDiffs?.find(row => row.pluginId === runtime.publicState.rootPluginId)?.newPackages ?? []
  if (rootNewPackages.length > 1) errors.push('E_OVERWRITE_PACKAGE')
  return [...new Set(errors)]
}

function topologyDiagnostics(seed, parsed) {
  const actual = parsed.ok && Array.isArray(parsed.record.facts?.causal_path_root_to_leaf)
    ? parsed.record.facts.causal_path_root_to_leaf
    : []
  let correctPrefixLength = 0
  while (correctPrefixLength < actual.length
    && correctPrefixLength < seed.componentNames.length
    && actual[correctPrefixLength] === seed.componentNames[correctPrefixLength]) {
    correctPrefixLength += 1
  }
  return {
    dependencyDepth: seed.depth,
    expectedComponentCount: seed.componentNames.length,
    reportedComponentCount: actual.length,
    correctPrefixLength,
    exactPath: exactSequence(actual, seed.componentNames),
    wrongIntermediateComponents: actual.filter(name => !seed.componentNames.includes(name)),
  }
}

function reconstructionBurden({ telemetryTotals, telemetryEvents, turnOne, factChecks, planChecks }) {
  const observed = new Set()
  let callsSeen = 0
  let callsAtSufficiency = null
  let evidenceClosureSequence = null
  for (const event of telemetryEvents) {
    if (event.turn !== 1) continue
    if (event.kind === 'tool_called') callsSeen += 1
    if (event.kind !== 'tool_returned' || event.status !== 'ok') continue
    for (const tag of event.evidenceTags ?? []) observed.add(tag)
    if (callsAtSufficiency === null && REQUIRED_EVIDENCE.every(tag => observed.has(tag))) {
      callsAtSufficiency = callsSeen
      evidenceClosureSequence = event.sequence
    }
  }
  return {
    totalToolCalls: telemetryTotals.toolCalls,
    observationCalls: telemetryTotals.observationCalls,
    nativeObservationCalls: telemetryTotals.nativeObservationCalls,
    semanticObservationCalls: telemetryTotals.semanticObservationCalls,
    oracleObservationCalls: telemetryTotals.oracleObservationCalls,
    nativeStateDomainsTouched: telemetryTotals.nativeObservationDomainsTouched.length,
    nativeStateDomainNames: telemetryTotals.nativeObservationDomainsTouched,
    repeatedObservationCalls: telemetryTotals.repeatedObservationCalls,
    grossInputTokens: telemetryTotals.usage.input,
    grossOutputAndThinkingTokens: telemetryTotals.usage.output + telemetryTotals.usage.thoughts,
    toolResultBytes: telemetryTotals.toolResultBytes,
    callsToFirstSufficientEvidence: callsAtSufficiency,
    callsAfterEvidenceClosure: callsAtSufficiency === null ? null : telemetryTotals.toolCalls - callsAtSufficiency,
    evidenceClosureSequence,
    sufficientEvidenceReached: callsAtSufficiency !== null,
    evidenceCoverage: REQUIRED_EVIDENCE.filter(tag => observed.has(tag)).length / REQUIRED_EVIDENCE.length,
    requiredEvidenceTags: REQUIRED_EVIDENCE,
    observedEvidenceTags: [...observed].sort(),
    incorrectStructuredClaims: [...factChecks, ...planChecks].filter(item => !item.pass).length,
    unsupportedJudgments: turnOne.ok ? unsupportedJudgments(turnOne.record, observed) : 0,
  }
}

function hasTurnOneEvidenceClosure(events) {
  const observed = new Set(events
    .filter(event => event.turn === 1 && event.kind === 'tool_returned' && event.status === 'ok')
    .flatMap(event => event.evidenceTags ?? []))
  return REQUIRED_EVIDENCE.every(tag => observed.has(tag))
}

function unsupportedJudgments(record, observed) {
  let count = 0
  const facts = record.facts ?? {}
  if ((facts.root_plugin_id || facts.last_successful_package_id || facts.failed_target_package_id || facts.active_run)
    && !observed.has('dynamic_state')) count += 1
  if ((facts.causal_path_root_to_leaf?.length ?? 0)
    && !(observed.has('component_identity') && observed.has('dependency_edges') && observed.has('bindings'))) count += 1
  if ((facts.incident_effects_at_risk?.length ?? 0) && !observed.has('effect_ownership')) count += 1
  if (record.source_diagnosis?.defect_code && !observed.has('failed_source')) count += 1
  return count
}

function classifyFailure({ turnOne, turnTwo, semanticClosure, actionChecks, runtimePass, criticalErrors }) {
  if (!turnOne.ok || !turnTwo.ok) return 'terminal-record-failure'
  if (!semanticClosure) return 'wrong-semantic-conclusion'
  if (criticalErrors.includes('E_INTERMEDIATE_MUTATION')) return 'violated-hard-constraint'
  if (!runtimePass) return 'invalid-repair'
  if (actionChecks.some(check => !check.pass)) return 'incorrect-action-or-verification-record'
  if (criticalErrors.length) return 'critical-semantic-error'
  return 'unclassified'
}

function expectedEffects(seed) {
  return seed.componentNames.map((owner_component, index) => ({
    owner_component,
    label: seed.effectLabels[index],
  }))
}

function check(name, pass) {
  return { name, pass: Boolean(pass) }
}

function exactEffectSet(actual, expected) {
  if (!Array.isArray(actual)) return false
  const normalize = rows => rows.map(row => `${row?.owner_component ?? ''}\u0000${row?.label ?? ''}`).sort()
  return exactSequence(normalize(actual), normalize(expected))
}

function exactSet(actual, expected) {
  if (!Array.isArray(actual)) return false
  return exactSequence([...actual].sort(), [...expected].sort())
}

function exactSequence(actual, expected) {
  return Array.isArray(actual)
    && actual.length === expected.length
    && actual.every((value, index) => value === expected[index])
}
