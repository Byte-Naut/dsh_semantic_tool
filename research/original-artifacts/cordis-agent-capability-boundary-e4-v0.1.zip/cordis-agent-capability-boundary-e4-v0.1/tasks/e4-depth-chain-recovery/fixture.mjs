import { Context } from '@deepseek-ai/cordis'
import DynamicCordisRunnerService from '@deepseek-ai/dsh-cordis-host-runner'
import { captureCordisNative } from '../../src/native-snapshot.mjs'
import { CordisCollector, stateName } from '../../vendor/semantic-mirror-v0.3/collector.mjs'
import { DynamicPackageCollector } from '../../vendor/semantic-mirror-v0.3/dynamic-collector.mjs'
import { semanticSlice, verifyDepthChain } from '../../vendor/semantic-mirror-v0.3/depth-slice-query.mjs'

export async function createDepthChainRuntime(seed) {
  const root = new Context()
  const actionLog = []
  const observationLog = []
  let mutationStarted = false
  const nativeInspectedBefore = new Set()
  const collector = new CordisCollector(root, { runtimeId: `rt:${seed.seedId}` })
  await collector.attach()
  const disposeTools = root.provide('tools', Object.freeze({}))
  const runnerFiber = root.plugin(DynamicCordisRunnerService)
  await runnerFiber
  const runner = root.dynamicCordisRunner
  const agent = Object.freeze({ id: `session:${seed.seedId}`, steer() {}, inject() {} })
  const pluginRows = []
  const stableFibers = []

  for (let index = 0; index < seed.depth; index += 1) {
    const componentName = seed.dynamicComponentNames[index]
    const definition = runner.define({
      sessionId: agent.id,
      plugin: { kind: 'new', idPrefix: seed.pluginPrefixes[index] },
      name: componentName,
      purpose: index === 0 ? 'publish the root service' : 'transform one required upstream service',
      code: {
        host: index === 0
          ? rootHostCode({
              componentName,
              serviceKey: seed.serviceKeys[0],
              effectLabel: seed.effectLabels[0],
              value: seed.stableRootValue,
            })
          : downstreamHostCode({
              componentName,
              inputServiceKey: seed.serviceKeys[index - 1],
              outputServiceKey: seed.serviceKeys[index],
              effectLabel: seed.effectLabels[index],
            }),
      },
    })
    const receipt = await runner.run(agent, definition.pluginId, definition.packageId, 'run')
    if (!receipt.ok) throw new Error(`stable chain failed at ${componentName}: ${receipt.message}`)
    const implementation = root.reflect._getImpl(seed.serviceKeys[index], false)
    if (!implementation) throw new Error(`service ${seed.serviceKeys[index]} was not visible after ${componentName}`)
    if (implementation.fiber.name !== componentName) {
      throw new Error(`dynamic component identity mismatch: ${componentName} != ${implementation.fiber.name}`)
    }
    stableFibers.push(implementation.fiber)
    pluginRows.push(Object.freeze({
      pluginId: String(definition.pluginId),
      stablePackageId: String(definition.packageId),
      componentName,
    }))
  }

  const leaf = root.plugin({
    name: seed.leafConsumerName,
    inject: [seed.serviceKeys.at(-1)],
    apply(ctx) {
      ctx.effect(() => () => {}, seed.effectLabels.at(-1))
    },
  })
  await leaf

  const cordisBefore = collector.capture(seed.checkpointBefore)
  const nativeBefore = applicationSnapshot(seed.checkpointBefore)
  const rootPlugin = pluginRows[0]
  const failed = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'existing', pluginId: rootPlugin.pluginId },
    name: rootPlugin.componentName,
    purpose: 'publish the intended repaired root service',
    code: {
      host: failedRootHostCode({
        componentName: rootPlugin.componentName,
        serviceKey: seed.serviceKeys[0],
        effectLabel: seed.effectLabels[0],
        value: seed.repairedRootValue,
        failureMessage: seed.failureMessage,
      }),
    },
  })
  const failedPackageId = String(failed.packageId)
  const failedReceipt = await runner.run(agent, rootPlugin.pluginId, failedPackageId, 'update')
  if (failedReceipt.ok || failedReceipt.reason !== 'host-half-failed') {
    throw new Error('fixture did not produce the required root host-half failure')
  }
  await waitFor(() => stableFibers.slice(1).every(fiber => stateName(fiber.state) === 'pending')
    && stateName(leaf.state) === 'pending')

  const dynamicCollector = new DynamicPackageCollector(runner, { runtimeId: `rt:${seed.seedId}:dynamic` })
  const dynamicFailed = dynamicCollector.capture(seed.checkpointFailed)
  const cordisFailed = collector.capture(seed.checkpointFailed)
  const nativeFailed = applicationSnapshot(seed.checkpointFailed)
  const snapshots = new Map([
    [seed.checkpointBefore, nativeBefore],
    [cordisBefore.id, nativeBefore],
    [seed.checkpointFailed, nativeFailed],
    [cordisFailed.id, nativeFailed],
  ])
  const originalPackages = new Map(pluginRows.map(row => [row.pluginId, new Set([row.stablePackageId])]))
  originalPackages.get(rootPlugin.pluginId).add(failedPackageId)

  return {
    seed,
    publicState: {
      rootPluginId: rootPlugin.pluginId,
      rootStablePackageId: rootPlugin.stablePackageId,
      rootFailedPackageId: failedPackageId,
      beforeCheckpointId: cordisBefore.id,
      failedCheckpointId: cordisFailed.id,
      failedDynamicSnapshotId: dynamicFailed.id,
      pluginComponents: clone(pluginRows),
    },
    checkpoints() {
      return [
        { alias: seed.checkpointBefore, snapshotId: cordisBefore.id, phase: 'stable-before-root-update' },
        { alias: seed.checkpointFailed, snapshotId: cordisFailed.id, dynamicSnapshotId: dynamicFailed.id, phase: 'failed-root-update' },
        { alias: 'current', phase: 'live-read' },
      ]
    },
    dynamicInventory() {
      observationLog.push({ kind: 'dynamic-inventory' })
      return publicDynamicInventory(runner.inventory())
    },
    inspectPackage({ pluginId, packageId }) {
      observationLog.push({ kind: 'inspect-package', pluginId, packageId, beforeMutation: !mutationStarted })
      return clone(runner.inspectPackage(agent, pluginId, packageId))
    },
    nativeApplicationSnapshot(checkpointId) {
      if (!checkpointId || checkpointId === 'current') return applicationSnapshot('current')
      const snapshot = snapshots.get(checkpointId)
      if (!snapshot) throw new Error(`unknown checkpoint: ${checkpointId}`)
      return snapshot
    },
    noteNativeComponentInspection(component, checkpointId) {
      if ([seed.checkpointBefore, cordisBefore.id].includes(checkpointId)) {
        nativeInspectedBefore.add(component.name)
      }
    },
    semanticQuery(request) {
      if (request.subject?.targetComponentName !== seed.leafConsumerName) {
        throw new Error(`unknown target component: ${request.subject?.targetComponentName}`)
      }
      observationLog.push({ kind: 'semantic-query', query: request.query })
      if (request.query === 'semantic_slice') {
        return semanticSlice({
          targetComponentName: seed.leafConsumerName,
          dynamicSnapshot: dynamicFailed,
          cordisBefore,
          cordisFailed,
          pluginComponents: pluginRows,
          applicationComponentNames: seed.componentNames,
          serviceKeys: seed.serviceKeys,
        })
      }
      if (request.query === 'verify_depth_chain') {
        const dynamicCurrent = dynamicCollector.capture('current')
        const cordisCurrent = collector.capture('current')
        return verifyDepthChain({
          targetComponentName: seed.leafConsumerName,
          dynamicSnapshot: dynamicCurrent,
          cordisCurrent,
          pluginComponents: pluginRows,
          applicationComponentNames: seed.componentNames,
          serviceKeys: seed.serviceKeys,
          serviceValue: visibleVersion(root, seed.serviceKeys.at(-1)),
        })
      }
      throw new Error(`unsupported query: ${request.query}`)
    },
    async definePackage({ pluginId, name, purpose, hostCode }) {
      mutationStarted = true
      const actionId = pluginId === rootPlugin.pluginId
        ? 'DEFINE_ROOT_REPAIRED_PACKAGE'
        : 'INTERMEDIATE_MUTATION'
      const entry = { kind: 'define', actionId, pluginId, name, packageId: null }
      actionLog.push(entry)
      const definition = runner.define({
        sessionId: agent.id,
        plugin: { kind: 'existing', pluginId },
        name,
        purpose,
        code: { host: hostCode },
      })
      entry.packageId = String(definition.packageId)
      return clone(definition)
    },
    async runPackage({ pluginId, packageId, mode }) {
      mutationStarted = true
      const actionId = pluginId === rootPlugin.pluginId
        && packageId === rootPlugin.stablePackageId && mode === 'run'
        ? 'RESTORE_ROOT_LAST_SUCCESSFUL'
        : pluginId === rootPlugin.pluginId && mode === 'update'
          ? 'UPDATE_ROOT_TO_REPAIRED_PACKAGE'
          : 'INTERMEDIATE_MUTATION'
      const entry = { kind: 'run', actionId, pluginId, packageId, mode, receipt: null }
      actionLog.push(entry)
      const receipt = await runner.run(agent, pluginId, packageId, mode)
      entry.receipt = clone(receipt)
      await settle()
      entry.observedLeafValue = visibleVersion(root, seed.serviceKeys.at(-1))
      return { ...clone(receipt), observedLeafValue: entry.observedLeafValue }
    },
    evidenceTagsForTool(name, args) {
      if (name === 'software_semantic_query' && args.query === 'semantic_slice') {
        return ['dynamic_state', 'component_identity', 'dependency_edges', 'bindings', 'effect_ownership']
      }
      if (name === 'native_dynamic_inventory') return ['dynamic_state']
      if (name === 'native_list_components') return ['component_identity']
      if (name === 'native_inspect_component'
        && seed.componentNames.every(component => nativeInspectedBefore.has(component))) {
        return ['dependency_edges', 'bindings', 'effect_ownership']
      }
      if (name === 'native_inspect_package'
        && args.pluginId === rootPlugin.pluginId && args.packageId === failedPackageId) {
        return ['failed_source']
      }
      return []
    },
    async grade() {
      await settle()
      const inventory = clone(runner.inventory())
      const selected = inventory.find(row => String(row.pluginId) === rootPlugin.pluginId)
      const packageDiffs = inventory.map(row => {
        const pluginId = String(row.pluginId)
        const originals = originalPackages.get(pluginId) ?? new Set()
        const newPackages = row.packages.filter(pkg => !originals.has(String(pkg.packageId)))
        return { pluginId, newPackages }
      })
      const rootDiff = packageDiffs.find(row => row.pluginId === rootPlugin.pluginId)
      const newRootPackageId = rootDiff?.newPackages.length === 1
        ? String(rootDiff.newPackages[0].packageId)
        : null
      const rootPackage = newRootPackageId == null
        ? null
        : clone(runner.inspectPackage(agent, rootPlugin.pluginId, newRootPackageId))
      const current = applicationSnapshot('grade-current')
      const activePath = seed.componentNames.filter(name => current.fibers.some(row => row.name === name && row.state === 'active'))
      const activeEffects = current.fibers
        .filter(row => row.state === 'active' && seed.componentNames.includes(row.name))
        .flatMap(row => row.effects.filter(effect => effect.label?.startsWith('e4:')).map(effect => ({ owner: row.name, label: effect.label })))
      const expectedEffects = seed.componentNames.map((name, index) => ({ owner: name, label: seed.effectLabels[index] }))
      const services = seed.serviceKeys.map((serviceKey, index) => ({
        serviceKey,
        expected: propagatedAt(seed, index),
        actual: visibleVersion(root, serviceKey),
      }))
      const activePackageId = selected?.activeRun?.packageId == null ? null : String(selected.activeRun.packageId)
      const exactActions = actionLog.length === 3
        && actionLog.every((row, index) => row.actionId === [
          'RESTORE_ROOT_LAST_SUCCESSFUL',
          'DEFINE_ROOT_REPAIRED_PACKAGE',
          'UPDATE_ROOT_TO_REPAIRED_PACKAGE',
        ][index])
      const firstRestoreCorrect = actionLog[0]?.pluginId === rootPlugin.pluginId
        && actionLog[0]?.packageId === rootPlugin.stablePackageId
        && actionLog[0]?.mode === 'run'
        && actionLog[0]?.receipt?.ok === true
      const rootPackageStateCorrect = newRootPackageId != null
        && activePackageId === newRootPackageId
        && String(selected?.currentPackageId) === newRootPackageId
        && selected?.nextPackageId === undefined
      const packageIdentityPreserved = rootPackage?.name === rootPlugin.componentName
        && current.services.some(row => row.serviceKey === seed.serviceKeys[0]
          && row.providerName === rootPlugin.componentName && row.version === seed.repairedRootValue)
      const noIntermediateMutation = packageDiffs
        .filter(row => row.pluginId !== rootPlugin.pluginId)
        .every(row => row.newPackages.length === 0)
        && actionLog.every(row => row.pluginId === rootPlugin.pluginId)
      const runtimeCorrect = services.every(row => row.actual === row.expected)
        && activePath.length === seed.componentNames.length
        && exactPairSet(activeEffects, expectedEffects)
      const inspectedFailedSource = observationLog.some(entry => entry.kind === 'inspect-package'
        && entry.pluginId === rootPlugin.pluginId && entry.packageId === failedPackageId && entry.beforeMutation)
      const result = {
        actionLog: clone(actionLog),
        inspectedFailedSource,
        firstRestoreCorrect,
        exactActions,
        rootPackageStateCorrect,
        packageIdentityPreserved,
        noIntermediateMutation,
        runtimeCorrect,
        pluginCount: inventory.length,
        selected,
        packageDiffs,
        newRootPackageId,
        activePath,
        activeEffects,
        services,
        leafState: stateName(leaf.state),
        finalLeafValue: visibleVersion(root, seed.serviceKeys.at(-1)),
      }
      return {
        ...result,
        pass: inspectedFailedSource
          && firstRestoreCorrect
          && exactActions
          && rootPackageStateCorrect
          && packageIdentityPreserved
          && noIntermediateMutation
          && runtimeCorrect
          && result.pluginCount === seed.depth,
      }
    },
    async dispose() {
      await Promise.allSettled([leaf.dispose()])
      await runnerFiber.dispose()
      await collector.detach()
      await disposeTools()
    },
  }

  function applicationSnapshot(label) {
    const raw = captureCordisNative({ label, root, collector, fibers: [...stableFibers, leaf] })
    return Object.freeze({
      label,
      fibers: raw.fibers.filter(row => seed.componentNames.includes(row.name)),
      services: raw.services.filter(row => seed.serviceKeys.includes(row.serviceKey)),
    })
  }
}

export function rootHostCode({ componentName, serviceKey, effectLabel, value }) {
  return `return {\n  name: ${JSON.stringify(componentName)},\n  apply(ctx) {\n    ctx.effect(() => () => {}, ${JSON.stringify(effectLabel)})\n    ctx.provide(${JSON.stringify(serviceKey)}, Object.freeze({ version: ${JSON.stringify(value)} }))\n  }\n}`
}

export function downstreamHostCode({ componentName, inputServiceKey, outputServiceKey, effectLabel }) {
  return `return {\n  name: ${JSON.stringify(componentName)},\n  inject: [${JSON.stringify(inputServiceKey)}],\n  apply(ctx) {\n    const input = ctx.get(${JSON.stringify(inputServiceKey)})\n    ctx.effect(() => () => {}, ${JSON.stringify(effectLabel)})\n    ctx.provide(${JSON.stringify(outputServiceKey)}, Object.freeze({ version: input.version + ${JSON.stringify(`>${componentName}`)} }))\n  }\n}`
}

export function failedRootHostCode({ componentName, serviceKey, effectLabel, value, failureMessage }) {
  return `return {\n  name: ${JSON.stringify(componentName)},\n  apply(ctx) {\n    const intended = Object.freeze({ version: ${JSON.stringify(value)} })\n    ctx.effect(() => () => {}, ${JSON.stringify(effectLabel)})\n    throw new Error(${JSON.stringify(failureMessage)})\n    ctx.provide(${JSON.stringify(serviceKey)}, intended)\n  }\n}`
}

function propagatedAt(seed, serviceIndex) {
  return seed.dynamicComponentNames.slice(1, serviceIndex + 1)
    .reduce((value, name) => `${value}>${name}`, seed.repairedRootValue)
}

function publicDynamicInventory(rows) {
  return rows.map(row => ({
    pluginId: String(row.pluginId),
    agentId: String(row.agentId),
    packages: clone(row.packages),
    ...(row.currentPackageId === undefined ? {} : { currentPackageId: String(row.currentPackageId) }),
    ...(row.nextPackageId === undefined ? {} : { nextPackageId: String(row.nextPackageId) }),
    ...(row.activeRun === undefined ? {} : { activeRun: clone(row.activeRun) }),
    ...(row.latestRun === undefined ? {} : {
      latestRun: {
        ...clone(row.latestRun),
        ...(row.latestRun.error === undefined ? {} : {
          error: Object.fromEntries(Object.entries(clone(row.latestRun.error)).filter(([key]) => key !== 'stack')),
        }),
      },
    }),
  }))
}

function visibleVersion(root, serviceKey) {
  return root.reflect._getImpl(serviceKey, false)?.value?.version ?? null
}

async function waitFor(predicate, attempts = 1_000) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (predicate()) return
    await new Promise(resolve => setTimeout(resolve, 0))
  }
  throw new Error('timed out waiting for lifecycle state')
}

async function settle() {
  for (let index = 0; index < 12; index += 1) await new Promise(resolve => setTimeout(resolve, 0))
}

function exactPairSet(actual, expected) {
  const normalize = rows => rows.map(row => `${row.owner}\u0000${row.label}`).sort()
  const left = normalize(actual)
  const right = normalize(expected)
  return left.length === right.length && left.every((value, index) => value === right[index])
}

function clone(value) {
  if (value === undefined) return undefined
  return JSON.parse(JSON.stringify(value))
}
