export function publicTaskCard(seed) {
  return `Incident ${seed.incidentId}: leaf component \`${seed.leafConsumerName}\` lost its required service \`${seed.serviceKeys.at(-1)}\` after one upstream immutable Package update failed.

Before mutation, reconstruct the exact causal path from the failed root publisher to the leaf, including every dependency service and every incident effect labelled with the \`e4:\` prefix. Identify the failed root Plugin and Package state, inspect the failed Package source, and return the structured Turn-1 record. After approval, repair only that root Plugin by restoring its last successful Package, defining one corrected immutable Package under the same Plugin, and updating to it. Preserve the root component's exact name in both the Package metadata and returned Host plugin. Intermediate Plugins and the leaf must recover through Cordis dependency propagation; do not mutate or restart them.`
}

export function workspaceFiles(seed) {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module' }, null, 2) + '\n',
    'INCIDENT.md': `# ${seed.incidentId}\n\nTarget leaf: ${seed.leafConsumerName}\nTarget service: ${seed.serviceKeys.at(-1)}\nOnly runtime tools are authoritative.\n`,
  }
}

export const editableFiles = Object.freeze([])
export const criticalErrors = Object.freeze([
  'E_WRONG_ROOT_PLUGIN',
  'E_CURRENT_IS_ACTIVE',
  'E_ACTIVE_RUN_UNKNOWN_COLLAPSED',
  'E_CAUSAL_PATH_OMISSION',
  'E_CAUSAL_PATH_ORDER',
  'E_DEPENDENCY_SERVICE_OMISSION',
  'E_EFFECT_OWNERSHIP_OMISSION',
  'E_FAILED_SOURCE_UNINSPECTED',
  'E_REPAIR_BEFORE_RESTORE',
  'E_WRONG_ROLLBACK_MODE',
  'E_INTERMEDIATE_MUTATION',
  'E_NEW_PLUGIN',
  'E_OVERWRITE_PACKAGE',
])
