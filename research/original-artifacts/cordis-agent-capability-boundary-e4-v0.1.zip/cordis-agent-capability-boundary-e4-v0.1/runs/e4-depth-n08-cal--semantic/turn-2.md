The approved root lifecycle plan has been executed and verified. The root package was restored to its last known good version (`pkg-1`), a corrected immutable package (`pkg-10`) removing the pre-publication error was defined under `iris-1`, and `iris-1` was updated to `pkg-10`. All intermediate components and the leaf component `cal-maple` reactivated and re-propagated dependencies naturally.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-10",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-10",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-10",
    "leaf_service_value": "cal-root-repaired>cal-cedar>cal-willow>cal-fennel>cal-quince>cal-birch>cal-orchid>cal-hemlock",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple"
    ]
  },
  "remaining_unknowns": []
}
```
