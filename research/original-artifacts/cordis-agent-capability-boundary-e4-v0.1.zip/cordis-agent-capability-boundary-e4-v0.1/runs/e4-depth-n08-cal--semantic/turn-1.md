Reconstruction and package inspection for incident `incident-e4-cal-n08` are complete:

- Root dynamic plugin `iris-1` failed during an update to package `pkg-9`, leaving its active run in a disposed state (`KNOWN_ABSENT`).
- The last known successful package for `iris-1` is `pkg-1`.
- Inspection of package `pkg-9` reveals an explicit throw (`cal root publication failed before service commit`) placed immediately before service `calHaze` is provided (`THROW_BEFORE_PUBLISH`).
- The failure propagated downstream through the full 8-hop dependency chain down to leaf `cal-maple`.

```json
{
  "facts": {
    "root_plugin_id": "iris-1",
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-9",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "causal_path_root_to_leaf": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple"
    ],
    "dependency_services_root_to_leaf": [
      "calHaze",
      "calCoral",
      "calWheat",
      "calEmber",
      "calQuartz",
      "calBrisk",
      "calNavy",
      "calFrost"
    ],
    "incident_effects_at_risk": [
      {
        "owner_component": "cal-iris",
        "label": "e4:cal:cal-iris"
      },
      {
        "owner_component": "cal-cedar",
        "label": "e4:cal:cal-cedar"
      },
      {
        "owner_component": "cal-willow",
        "label": "e4:cal:cal-willow"
      },
      {
        "owner_component": "cal-fennel",
        "label": "e4:cal:cal-fennel"
      },
      {
        "owner_component": "cal-quince",
        "label": "e4:cal:cal-quince"
      },
      {
        "owner_component": "cal-birch",
        "label": "e4:cal:cal-birch"
      },
      {
        "owner_component": "cal-orchid",
        "label": "e4:cal:cal-orchid"
      },
      {
        "owner_component": "cal-hemlock",
        "label": "e4:cal:cal-hemlock"
      },
      {
        "owner_component": "cal-maple",
        "label": "e4:cal:cal-maple"
      }
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
