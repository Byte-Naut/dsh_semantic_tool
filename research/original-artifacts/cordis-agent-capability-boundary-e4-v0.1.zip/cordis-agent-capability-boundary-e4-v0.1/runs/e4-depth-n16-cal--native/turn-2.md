The approved root recovery plan was executed:
1. Restored the last successful package `pkg-1` under plugin `iris-1` with mode `run`.
2. Defined corrected immutable package `pkg-18` under plugin `iris-1` retaining name `cal-iris`, preserving the incident effect `e4:cal:cal-iris`, and removing the pre-publication error.
3. Updated plugin `iris-1` to `pkg-18` with mode `update`.

Verification confirmed all 17 path components transitioned to `active`, and leaf component `cal-pine` received the intended repaired service version through Cordis dependency propagation.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-18",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-18",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-18",
    "leaf_service_value": "cal-root-repaired>cal-cedar>cal-willow>cal-fennel>cal-quince>cal-birch>cal-orchid>cal-hemlock>cal-maple>cal-xenia>cal-spruce>cal-dahlia>cal-kelp>cal-violet>cal-aster>cal-nettle",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple",
      "cal-xenia",
      "cal-spruce",
      "cal-dahlia",
      "cal-kelp",
      "cal-violet",
      "cal-aster",
      "cal-nettle",
      "cal-pine"
    ]
  },
  "remaining_unknowns": []
}
```
