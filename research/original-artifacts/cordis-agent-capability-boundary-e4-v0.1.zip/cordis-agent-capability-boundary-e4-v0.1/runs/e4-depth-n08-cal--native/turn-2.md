The approved root lifecycle plan has been executed and verified:
1. Restored the last successful Package `pkg-1` on root Plugin `iris-1` with mode `run`.
2. Defined corrected Package `pkg-10` preserving the component name `cal-iris`, retaining its incident effect label `e4:cal:cal-iris`, publishing the intended repaired root service, and removing the pre-publication error.
3. Updated root Plugin `iris-1` to `pkg-10` with mode `update`.
4. Downstream intermediate components propagated the update without direct mutation or restarts. Every component along the path from root to leaf is now active and the leaf component `cal-maple` has bound the expected service value.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-10",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-10",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-10",
    "leaf_service_value": "cal-root-repaired>cal-cedar>cal-willow>cal-fennel>cal-quince>cal-birch>cal-orchid>cal-hemlock",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple"
    ]
  },
  "remaining_unknowns": []
}
```
