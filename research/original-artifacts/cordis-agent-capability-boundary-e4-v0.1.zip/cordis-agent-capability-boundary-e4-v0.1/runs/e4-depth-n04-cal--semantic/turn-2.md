The three-step root lifecycle plan has been executed and verified:

1. **RESTORE_ROOT_LAST_SUCCESSFUL**: `iris-1` was run with `pkg-1` (mode `run`), restoring baseline stability.
2. **DEFINE_ROOT_REPAIRED_PACKAGE**: Corrected package `pkg-6` was defined under `iris-1` preserving component name `cal-iris`, effect label `e4:cal:cal-iris`, and providing intended service value `{ version: "cal-root-repaired" }` without throwing.
3. **UPDATE_ROOT_TO_REPAIRED_PACKAGE**: `iris-1` was updated to `pkg-6` (mode `update`), propagating through intermediate components to restore the leaf service on `cal-quince`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-6",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-6",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-6",
    "leaf_service_value": "cal-root-repaired>cal-cedar>cal-willow>cal-fennel",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince"
    ]
  },
  "remaining_unknowns": []
}
```
