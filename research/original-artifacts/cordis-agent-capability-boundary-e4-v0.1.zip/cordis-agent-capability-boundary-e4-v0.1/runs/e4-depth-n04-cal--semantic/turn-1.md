The investigation into incident `incident-e4-cal-n04` is complete:

1. Dynamic Plugin `iris-1` (hosting root component `cal-iris`) failed during an update from `pkg-1` to `pkg-5`, leaving the plugin with no active run (`KNOWN_ABSENT`).
2. Inspection of `pkg-5` confirms that an explicit exception is thrown before publishing the root service `calHaze`, leaving downstream dependents `cal-cedar`, `cal-willow`, `cal-fennel`, and leaf `cal-quince` without their required injected services.
3. The planned recovery will restore the root plugin to `pkg-1`, define a corrected package under `iris-1` that publishes `{ version: "cal-root-repaired" }` under `calHaze` without throwing, and update `iris-1` to that repaired package.

```json
{
  "facts": {
    "root_plugin_id": "iris-1",
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-5",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "causal_path_root_to_leaf": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince"
    ],
    "dependency_services_root_to_leaf": [
      "calHaze",
      "calCoral",
      "calWheat",
      "calEmber"
    ],
    "incident_effects_at_risk": [
      {
        "owner_component": "cal-iris",
        "label": "e4:cal:cal-iris"
      },
      {
        "owner_component": "cal-cedar",
        "label": "e4:cal:cal-cedar"
      },
      {
        "owner_component": "cal-willow",
        "label": "e4:cal:cal-willow"
      },
      {
        "owner_component": "cal-fennel",
        "label": "e4:cal:cal-fennel"
      },
      {
        "owner_component": "cal-quince",
        "label": "e4:cal:cal-quince"
      }
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
