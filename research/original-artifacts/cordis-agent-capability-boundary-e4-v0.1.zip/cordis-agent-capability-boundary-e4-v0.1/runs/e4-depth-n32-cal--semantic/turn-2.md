```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-34",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-34",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-34",
    "leaf_service_value": "cal-root-repaired>cal-cedar>cal-willow>cal-fennel>cal-quince>cal-birch>cal-orchid>cal-hemlock>cal-maple>cal-xenia>cal-spruce>cal-dahlia>cal-kelp>cal-violet>cal-aster>cal-nettle>cal-pine>cal-ginkgo>cal-yarrow>cal-elm>cal-thistle>cal-juniper>cal-reed>cal-zinnia>cal-linden>cal-umber>cal-badger>cal-copper>cal-falcon>cal-harbor>cal-ivory>cal-lagoon",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple",
      "cal-xenia",
      "cal-spruce",
      "cal-dahlia",
      "cal-kelp",
      "cal-violet",
      "cal-aster",
      "cal-nettle",
      "cal-pine",
      "cal-ginkgo",
      "cal-yarrow",
      "cal-elm",
      "cal-thistle",
      "cal-juniper",
      "cal-reed",
      "cal-zinnia",
      "cal-linden",
      "cal-umber",
      "cal-badger",
      "cal-copper",
      "cal-falcon",
      "cal-harbor",
      "cal-ivory",
      "cal-lagoon",
      "cal-magnet"
    ]
  },
  "remaining_unknowns": []
}
```
