The approved root lifecycle plan has been executed and verified:

1. Restored `iris-1` to its last-successful package `pkg-1` via `run`.
2. Defined corrected immutable package `pkg-18` under `iris-1` preserving component name `cal-iris`, effect `e4:cal:cal-iris`, and publishing intended value `{ version: "cal-root-repaired" }` without throwing.
3. Updated `iris-1` to `pkg-18` via `update`.
4. Verified that all intermediate consumers and leaf component `cal-pine` recovered their bindings and transitioned to `active`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-18",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-18",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-18",
    "leaf_service_value": "cal-root-repaired>cal-cedar>cal-willow>cal-fennel>cal-quince>cal-birch>cal-orchid>cal-hemlock>cal-maple>cal-xenia>cal-spruce>cal-dahlia>cal-kelp>cal-violet>cal-aster>cal-nettle",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple",
      "cal-xenia",
      "cal-spruce",
      "cal-dahlia",
      "cal-kelp",
      "cal-violet",
      "cal-aster",
      "cal-nettle",
      "cal-pine"
    ]
  },
  "remaining_unknowns": []
}
```
