Evidence collection and semantic analysis are complete for `incident-e4-cal-n16`:

1. **Root Plugin and Package State**: Dynamic plugin `iris-1` hosting root component `cal-iris` failed when updating to immutable package `pkg-17`. Its last successful package is `pkg-1`, and its active run is currently `KNOWN_ABSENT`.
2. **Causal & Service Paths**: The failure at `cal-iris` propagated across 16 downstream hops via dependency service bindings (`calHaze` down through `calMoss`), causing the entire chain through leaf component `cal-pine` to enter pending states.
3. **Incident Effects**: Each component along the 17-node path registered an incident effect with the `e4:` prefix, all of which are currently in a disposed state.
4. **Source Classification**: Inspection of `pkg-17` reveals `throw new Error("cal root publication failed before service commit")` occurring before `ctx.provide("calHaze", intended)`, confirming `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "root_plugin_id": "iris-1",
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-17",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "causal_path_root_to_leaf": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple",
      "cal-xenia",
      "cal-spruce",
      "cal-dahlia",
      "cal-kelp",
      "cal-violet",
      "cal-aster",
      "cal-nettle",
      "cal-pine"
    ],
    "dependency_services_root_to_leaf": [
      "calHaze",
      "calCoral",
      "calWheat",
      "calEmber",
      "calQuartz",
      "calBrisk",
      "calNavy",
      "calFrost",
      "calSlate",
      "calXanthic",
      "calPearl",
      "calDune",
      "calJade",
      "calVerdant",
      "calAmber",
      "calMoss"
    ],
    "incident_effects_at_risk": [
      {
        "owner_component": "cal-iris",
        "label": "e4:cal:cal-iris"
      },
      {
        "owner_component": "cal-cedar",
        "label": "e4:cal:cal-cedar"
      },
      {
        "owner_component": "cal-willow",
        "label": "e4:cal:cal-willow"
      },
      {
        "owner_component": "cal-fennel",
        "label": "e4:cal:cal-fennel"
      },
      {
        "owner_component": "cal-quince",
        "label": "e4:cal:cal-quince"
      },
      {
        "owner_component": "cal-birch",
        "label": "e4:cal:cal-birch"
      },
      {
        "owner_component": "cal-orchid",
        "label": "e4:cal:cal-orchid"
      },
      {
        "owner_component": "cal-hemlock",
        "label": "e4:cal:cal-hemlock"
      },
      {
        "owner_component": "cal-maple",
        "label": "e4:cal:cal-maple"
      },
      {
        "owner_component": "cal-xenia",
        "label": "e4:cal:cal-xenia"
      },
      {
        "owner_component": "cal-spruce",
        "label": "e4:cal:cal-spruce"
      },
      {
        "owner_component": "cal-dahlia",
        "label": "e4:cal:cal-dahlia"
      },
      {
        "owner_component": "cal-kelp",
        "label": "e4:cal:cal-kelp"
      },
      {
        "owner_component": "cal-violet",
        "label": "e4:cal:cal-violet"
      },
      {
        "owner_component": "cal-aster",
        "label": "e4:cal:cal-aster"
      },
      {
        "owner_component": "cal-nettle",
        "label": "e4:cal:cal-nettle"
      },
      {
        "owner_component": "cal-pine",
        "label": "e4:cal:cal-pine"
      }
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
