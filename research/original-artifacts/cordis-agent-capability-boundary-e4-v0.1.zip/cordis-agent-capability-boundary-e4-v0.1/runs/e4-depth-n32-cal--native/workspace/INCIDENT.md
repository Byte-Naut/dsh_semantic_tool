# incident-e4-cal-n32

Target leaf: cal-magnet
Target service: calFjord
Only runtime tools are authoritative.
