The approved root lifecycle plan has been executed and verified:

1. Restored the last successful root Package `pkg-1` under plugin `iris-1` using `run` mode.
2. Defined corrected Package `pkg-3` under `iris-1`, preserving the name `cal-iris`, registering incident effect `e4:cal:cal-iris`, and providing `calHaze` with value `{ version: "cal-root-repaired" }` without the pre-publication error.
3. Updated plugin `iris-1` to `pkg-3` using `update` mode.

Verification via `verify_depth_chain` confirmed that both `cal-iris` and `cal-cedar` transitioned to `active`, and `calHaze` resolved to `cal-root-repaired`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-3",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-3",
    "leaf_service_value": "cal-root-repaired",
    "active_path_components": [
      "cal-iris",
      "cal-cedar"
    ]
  },
  "remaining_unknowns": []
}
```
