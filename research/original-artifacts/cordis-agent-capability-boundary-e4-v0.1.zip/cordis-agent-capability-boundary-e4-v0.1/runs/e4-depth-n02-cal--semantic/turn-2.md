The three-step root lifecycle plan has been executed and verified.

1. **RESTORE_ROOT_LAST_SUCCESSFUL**: Executed `pkg-1` under root plugin `iris-1` with mode `run`, restoring the initial operational baseline.
2. **DEFINE_ROOT_REPAIRED_PACKAGE**: Defined corrected immutable package `pkg-4` under `iris-1`, retaining component name `cal-iris`, registering effect `e4:cal:cal-iris`, and removing the pre-publication error to publish `{ version: "cal-root-repaired" }`.
3. **UPDATE_ROOT_TO_REPAIRED_PACKAGE**: Updated plugin `iris-1` to `pkg-4` with mode `update`.
4. **Verification**: Live runtime depth-chain inspection confirms that `cal-iris`, `cal-cedar`, and `cal-willow` are all `active`, both services `calHaze` and `calCoral` are visible, and leaf component `cal-willow` receives the intended service value `cal-root-repaired>cal-cedar`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-4",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-4",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-4",
    "leaf_service_value": "cal-root-repaired>cal-cedar",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow"
    ]
  },
  "remaining_unknowns": []
}
```
