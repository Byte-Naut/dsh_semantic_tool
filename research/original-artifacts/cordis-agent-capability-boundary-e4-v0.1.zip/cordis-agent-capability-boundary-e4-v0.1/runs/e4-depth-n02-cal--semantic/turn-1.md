An analysis of incident `incident-e4-cal-n02` reveals that leaf component `cal-willow` lost dependency service `calCoral` due to an upstream failure originating at root plugin `iris-1`.

### Findings
1. **Root Plugin and Outage Anchor**: Dynamic plugin `iris-1` hosting root component `cal-iris` attempted an immutable package update from `pkg-1` to `pkg-3`. The update failed, leaving no active run for `iris-1` (`KNOWN_ABSENT`), which caused `cal-iris` to enter a `disposed` state.
2. **Causal Dependency Propagation**:
   - `cal-iris` provides `calHaze` to intermediate component `cal-cedar`.
   - `cal-cedar` provides `calCoral` to leaf component `cal-willow`.
   - With `cal-iris` disposed, `cal-cedar` lost `calHaze` and transitioned to `pending`, withdrawing service `calCoral` and leaving `cal-willow` in `pending`.
3. **Source Defect**: Inspection of failed package `pkg-3` under plugin `iris-1` shows an explicit error thrown prior to calling `ctx.provide("calHaze", intended)`, classifying the defect as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "root_plugin_id": "iris-1",
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-3",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "causal_path_root_to_leaf": [
      "cal-iris",
      "cal-cedar",
      "cal-willow"
    ],
    "dependency_services_root_to_leaf": [
      "calHaze",
      "calCoral"
    ],
    "incident_effects_at_risk": [
      {
        "owner_component": "cal-iris",
        "label": "e4:cal:cal-iris"
      },
      {
        "owner_component": "cal-cedar",
        "label": "e4:cal:cal-cedar"
      },
      {
        "owner_component": "cal-willow",
        "label": "e4:cal:cal-willow"
      }
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
