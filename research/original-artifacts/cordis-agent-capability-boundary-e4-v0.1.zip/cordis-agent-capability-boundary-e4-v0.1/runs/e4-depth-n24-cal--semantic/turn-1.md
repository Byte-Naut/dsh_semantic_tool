We have completed the Turn 1 diagnostic investigation without mutating the runtime.

### Summary of Findings
1. **Root Plugin & Package State**: The root cause of the outage is dynamic plugin `iris-1` (`cal-iris`). An update to immutable package `pkg-25` failed during host loading because it throws an error before publishing the required service `calHaze`. Its last successful package was `pkg-1`, and it currently has no active run (`KNOWN_ABSENT`).
2. **Causal & Dependency Path**: The failure in `cal-iris` cascadingly unbinds the 24 downstream dependency services across 25 components, leaving leaf `cal-linden` in a pending state awaiting `calZircon`.
3. **Defect Classification**: Inspection of `pkg-25` source confirmed defect code `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "root_plugin_id": "iris-1",
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-25",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "causal_path_root_to_leaf": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple",
      "cal-xenia",
      "cal-spruce",
      "cal-dahlia",
      "cal-kelp",
      "cal-violet",
      "cal-aster",
      "cal-nettle",
      "cal-pine",
      "cal-ginkgo",
      "cal-yarrow",
      "cal-elm",
      "cal-thistle",
      "cal-juniper",
      "cal-reed",
      "cal-zinnia",
      "cal-linden"
    ],
    "dependency_services_root_to_leaf": [
      "calHaze",
      "calCoral",
      "calWheat",
      "calEmber",
      "calQuartz",
      "calBrisk",
      "calNavy",
      "calFrost",
      "calSlate",
      "calXanthic",
      "calPearl",
      "calDune",
      "calJade",
      "calVerdant",
      "calAmber",
      "calMoss",
      "calTeal",
      "calIndigo",
      "calYellow",
      "calGale",
      "calOchre",
      "calLilac",
      "calRose",
      "calZircon"
    ],
    "incident_effects_at_risk": [
      {
        "owner_component": "cal-iris",
        "label": "e4:cal:cal-iris"
      },
      {
        "owner_component": "cal-cedar",
        "label": "e4:cal:cal-cedar"
      },
      {
        "owner_component": "cal-willow",
        "label": "e4:cal:cal-willow"
      },
      {
        "owner_component": "cal-fennel",
        "label": "e4:cal:cal-fennel"
      },
      {
        "owner_component": "cal-quince",
        "label": "e4:cal:cal-quince"
      },
      {
        "owner_component": "cal-birch",
        "label": "e4:cal:cal-birch"
      },
      {
        "owner_component": "cal-orchid",
        "label": "e4:cal:cal-orchid"
      },
      {
        "owner_component": "cal-hemlock",
        "label": "e4:cal:cal-hemlock"
      },
      {
        "owner_component": "cal-maple",
        "label": "e4:cal:cal-maple"
      },
      {
        "owner_component": "cal-xenia",
        "label": "e4:cal:cal-xenia"
      },
      {
        "owner_component": "cal-spruce",
        "label": "e4:cal:cal-spruce"
      },
      {
        "owner_component": "cal-dahlia",
        "label": "e4:cal:cal-dahlia"
      },
      {
        "owner_component": "cal-kelp",
        "label": "e4:cal:cal-kelp"
      },
      {
        "owner_component": "cal-violet",
        "label": "e4:cal:cal-violet"
      },
      {
        "owner_component": "cal-aster",
        "label": "e4:cal:cal-aster"
      },
      {
        "owner_component": "cal-nettle",
        "label": "e4:cal:cal-nettle"
      },
      {
        "owner_component": "cal-pine",
        "label": "e4:cal:cal-pine"
      },
      {
        "owner_component": "cal-ginkgo",
        "label": "e4:cal:cal-ginkgo"
      },
      {
        "owner_component": "cal-yarrow",
        "label": "e4:cal:cal-yarrow"
      },
      {
        "owner_component": "cal-elm",
        "label": "e4:cal:cal-elm"
      },
      {
        "owner_component": "cal-thistle",
        "label": "e4:cal:cal-thistle"
      },
      {
        "owner_component": "cal-juniper",
        "label": "e4:cal:cal-juniper"
      },
      {
        "owner_component": "cal-reed",
        "label": "e4:cal:cal-reed"
      },
      {
        "owner_component": "cal-zinnia",
        "label": "e4:cal:cal-zinnia"
      },
      {
        "owner_component": "cal-linden",
        "label": "e4:cal:cal-linden"
      }
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
