Based on the runtime inventory, snapshot inspections, and package source oracle, here is the diagnosis of incident `incident-e4-cal-n04`:

1. **Root Plugin & Package Failure**: The root plugin `iris-1` failed during an update attempt from `pkg-1` to `pkg-5`. Component `cal-iris` was disposed and `iris-1` has no active run (`KNOWN_ABSENT`).
2. **Causal Path & Injections**:
   - `cal-iris` (root publisher) provides `calHaze`
   - `cal-cedar` injects `calHaze` and provides `calCoral`
   - `cal-willow` injects `calCoral` and provides `calWheat`
   - `cal-fennel` injects `calWheat` and provides `calEmber`
   - `cal-quince` (leaf consumer) injects `calEmber`
3. **Source Defect**: Inspection of `pkg-5` confirms an intentional error is thrown directly after registering effect `e4:cal:cal-iris` and before publishing `calHaze` (`THROW_BEFORE_PUBLISH`).

```json
{
  "facts": {
    "root_plugin_id": "iris-1",
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-5",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "causal_path_root_to_leaf": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince"
    ],
    "dependency_services_root_to_leaf": [
      "calHaze",
      "calCoral",
      "calWheat",
      "calEmber"
    ],
    "incident_effects_at_risk": [
      {
        "owner_component": "cal-iris",
        "label": "e4:cal:cal-iris"
      },
      {
        "owner_component": "cal-cedar",
        "label": "e4:cal:cal-cedar"
      },
      {
        "owner_component": "cal-willow",
        "label": "e4:cal:cal-willow"
      },
      {
        "owner_component": "cal-fennel",
        "label": "e4:cal:cal-fennel"
      },
      {
        "owner_component": "cal-quince",
        "label": "e4:cal:cal-quince"
      }
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
