The three-step root lifecycle plan has been executed and verified:

1. Restored the root plugin `iris-1` to its last successful package `pkg-1` in `run` mode.
2. Defined corrected immutable package `pkg-6` preserving the name `cal-iris`, effect label `e4:cal:cal-iris`, and intended service version `cal-root-repaired` without the pre-publication error.
3. Updated `iris-1` to `pkg-6`. Dependency propagation re-established service bindings across all downstream components (`cal-cedar`, `cal-willow`, `cal-fennel`) to leaf `cal-quince`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-6",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-6",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-6",
    "leaf_service_value": "cal-root-repaired>cal-cedar>cal-willow>cal-fennel",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince"
    ]
  },
  "remaining_unknowns": []
}
```
