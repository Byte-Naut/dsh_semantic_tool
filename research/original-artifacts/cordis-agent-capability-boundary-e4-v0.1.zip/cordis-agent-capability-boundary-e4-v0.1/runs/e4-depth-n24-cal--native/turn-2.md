The three-step root lifecycle plan has been executed and verified:

1. **RESTORE_ROOT_LAST_SUCCESSFUL**: Executed `pkg-1` under root plugin `iris-1` with mode `run`, successfully restoring the baseline root service and activating downstream components.
2. **DEFINE_ROOT_REPAIRED_PACKAGE**: Defined corrected immutable package `pkg-26` under `iris-1` preserving component name `cal-iris`, effect label `e4:cal:cal-iris`, and intended service payload `cal-root-repaired` while removing the pre-publication error.
3. **UPDATE_ROOT_TO_REPAIRED_PACKAGE**: Updated root plugin `iris-1` to `pkg-26` with mode `update`.
4. **Verification**: Confirmed dynamic inventory shows `pkg-26` active and running on `iris-1`, all 25 components in the dependency chain from `cal-iris` to `cal-linden` are in `active` state, and the leaf component `cal-linden` holds the active binding for service `calZircon` propagating the repaired version string.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-26",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "pkg-26",
      "mode": "update"
    }
  ],
  "verification": {
    "active_root_package_id": "pkg-26",
    "leaf_service_value": "cal-root-repaired>cal-cedar>cal-willow>cal-fennel>cal-quince>cal-birch>cal-orchid>cal-hemlock>cal-maple>cal-xenia>cal-spruce>cal-dahlia>cal-kelp>cal-violet>cal-aster>cal-nettle>cal-pine>cal-ginkgo>cal-yarrow>cal-elm>cal-thistle>cal-juniper>cal-reed>cal-zinnia",
    "active_path_components": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple",
      "cal-xenia",
      "cal-spruce",
      "cal-dahlia",
      "cal-kelp",
      "cal-violet",
      "cal-aster",
      "cal-nettle",
      "cal-pine",
      "cal-ginkgo",
      "cal-yarrow",
      "cal-elm",
      "cal-thistle",
      "cal-juniper",
      "cal-reed",
      "cal-zinnia",
      "cal-linden"
    ]
  },
  "remaining_unknowns": []
}
```
