Based on the inspection of the live runtime inventory, checkpoints, component bindings, and package sources, the evidence shows:

1. Dynamic plugin `iris-1` failed its update to package `pkg-49` during host-load with error `Error: cal root publication failed before service commit`.
2. The last-successful package for `iris-1` is `pkg-1`, the failed target is `pkg-49`, and there is currently no active run for `iris-1` (`KNOWN_ABSENT`).
3. Inspection of `pkg-49` confirms that an error is explicitly thrown prior to invoking `ctx.provide("calHaze", intended)`, establishing defect code `THROW_BEFORE_PUBLISH`.
4. Downstream dependency resolution failed through the 48-hop chain terminating at leaf component `cal-lotus`.

```json
{
  "facts": {
    "root_plugin_id": "iris-1",
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-49",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "causal_path_root_to_leaf": [
      "cal-iris",
      "cal-cedar",
      "cal-willow",
      "cal-fennel",
      "cal-quince",
      "cal-birch",
      "cal-orchid",
      "cal-hemlock",
      "cal-maple",
      "cal-xenia",
      "cal-spruce",
      "cal-dahlia",
      "cal-kelp",
      "cal-violet",
      "cal-aster",
      "cal-nettle",
      "cal-pine",
      "cal-ginkgo",
      "cal-yarrow",
      "cal-elm",
      "cal-thistle",
      "cal-juniper",
      "cal-reed",
      "cal-zinnia",
      "cal-linden",
      "cal-umber",
      "cal-badger",
      "cal-copper",
      "cal-falcon",
      "cal-harbor",
      "cal-ivory",
      "cal-lagoon",
      "cal-magnet",
      "cal-pebble",
      "cal-raven",
      "cal-saffron",
      "cal-tundra",
      "cal-velvet",
      "cal-warden",
      "cal-zephyr",
      "cal-canyon",
      "cal-drift",
      "cal-flint",
      "cal-grove",
      "cal-heron",
      "cal-islet",
      "cal-javelin",
      "cal-knoll",
      "cal-lotus"
    ],
    "dependency_services_root_to_leaf": [
      "calHaze",
      "calCoral",
      "calWheat",
      "calEmber",
      "calQuartz",
      "calBrisk",
      "calNavy",
      "calFrost",
      "calSlate",
      "calXanthic",
      "calPearl",
      "calDune",
      "calJade",
      "calVerdant",
      "calAmber",
      "calMoss",
      "calTeal",
      "calIndigo",
      "calYellow",
      "calGale",
      "calOchre",
      "calLilac",
      "calRose",
      "calZircon",
      "calKhaki",
      "calUltra",
      "calAcorn",
      "calBeacon",
      "calCipher",
      "calDelta",
      "calEcho",
      "calFjord",
      "calGlint",
      "calHaven",
      "calIon",
      "calJolt",
      "calKite",
      "calLumen",
      "calMirage",
      "calNorth",
      "calOrbit",
      "calPlume",
      "calQuest",
      "calRill",
      "calStone",
      "calTorch",
      "calUnity",
      "calVale"
    ],
    "incident_effects_at_risk": [
      {
        "owner_component": "cal-iris",
        "label": "e4:cal:cal-iris"
      },
      {
        "owner_component": "cal-cedar",
        "label": "e4:cal:cal-cedar"
      },
      {
        "owner_component": "cal-willow",
        "label": "e4:cal:cal-willow"
      },
      {
        "owner_component": "cal-fennel",
        "label": "e4:cal:cal-fennel"
      },
      {
        "owner_component": "cal-quince",
        "label": "e4:cal:cal-quince"
      },
      {
        "owner_component": "cal-birch",
        "label": "e4:cal:cal-birch"
      },
      {
        "owner_component": "cal-orchid",
        "label": "e4:cal:cal-orchid"
      },
      {
        "owner_component": "cal-hemlock",
        "label": "e4:cal:cal-hemlock"
      },
      {
        "owner_component": "cal-maple",
        "label": "e4:cal:cal-maple"
      },
      {
        "owner_component": "cal-xenia",
        "label": "e4:cal:cal-xenia"
      },
      {
        "owner_component": "cal-spruce",
        "label": "e4:cal:cal-spruce"
      },
      {
        "owner_component": "cal-dahlia",
        "label": "e4:cal:cal-dahlia"
      },
      {
        "owner_component": "cal-kelp",
        "label": "e4:cal:cal-kelp"
      },
      {
        "owner_component": "cal-violet",
        "label": "e4:cal:cal-violet"
      },
      {
        "owner_component": "cal-aster",
        "label": "e4:cal:cal-aster"
      },
      {
        "owner_component": "cal-nettle",
        "label": "e4:cal:cal-nettle"
      },
      {
        "owner_component": "cal-pine",
        "label": "e4:cal:cal-pine"
      },
      {
        "owner_component": "cal-ginkgo",
        "label": "e4:cal:cal-ginkgo"
      },
      {
        "owner_component": "cal-yarrow",
        "label": "e4:cal:cal-yarrow"
      },
      {
        "owner_component": "cal-elm",
        "label": "e4:cal:cal-elm"
      },
      {
        "owner_component": "cal-thistle",
        "label": "e4:cal:cal-thistle"
      },
      {
        "owner_component": "cal-juniper",
        "label": "e4:cal:cal-juniper"
      },
      {
        "owner_component": "cal-reed",
        "label": "e4:cal:cal-reed"
      },
      {
        "owner_component": "cal-zinnia",
        "label": "e4:cal:cal-zinnia"
      },
      {
        "owner_component": "cal-linden",
        "label": "e4:cal:cal-linden"
      },
      {
        "owner_component": "cal-umber",
        "label": "e4:cal:cal-umber"
      },
      {
        "owner_component": "cal-badger",
        "label": "e4:cal:cal-badger"
      },
      {
        "owner_component": "cal-copper",
        "label": "e4:cal:cal-copper"
      },
      {
        "owner_component": "cal-falcon",
        "label": "e4:cal:cal-falcon"
      },
      {
        "owner_component": "cal-harbor",
        "label": "e4:cal:cal-harbor"
      },
      {
        "owner_component": "cal-ivory",
        "label": "e4:cal:cal-ivory"
      },
      {
        "owner_component": "cal-lagoon",
        "label": "e4:cal:cal-lagoon"
      },
      {
        "owner_component": "cal-magnet",
        "label": "e4:cal:cal-magnet"
      },
      {
        "owner_component": "cal-pebble",
        "label": "e4:cal:cal-pebble"
      },
      {
        "owner_component": "cal-raven",
        "label": "e4:cal:cal-raven"
      },
      {
        "owner_component": "cal-saffron",
        "label": "e4:cal:cal-saffron"
      },
      {
        "owner_component": "cal-tundra",
        "label": "e4:cal:cal-tundra"
      },
      {
        "owner_component": "cal-velvet",
        "label": "e4:cal:cal-velvet"
      },
      {
        "owner_component": "cal-warden",
        "label": "e4:cal:cal-warden"
      },
      {
        "owner_component": "cal-zephyr",
        "label": "e4:cal:cal-zephyr"
      },
      {
        "owner_component": "cal-canyon",
        "label": "e4:cal:cal-canyon"
      },
      {
        "owner_component": "cal-drift",
        "label": "e4:cal:cal-drift"
      },
      {
        "owner_component": "cal-flint",
        "label": "e4:cal:cal-flint"
      },
      {
        "owner_component": "cal-grove",
        "label": "e4:cal:cal-grove"
      },
      {
        "owner_component": "cal-heron",
        "label": "e4:cal:cal-heron"
      },
      {
        "owner_component": "cal-islet",
        "label": "e4:cal:cal-islet"
      },
      {
        "owner_component": "cal-javelin",
        "label": "e4:cal:cal-javelin"
      },
      {
        "owner_component": "cal-knoll",
        "label": "e4:cal:cal-knoll"
      },
      {
        "owner_component": "cal-lotus",
        "label": "e4:cal:cal-lotus"
      }
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_ROOT_LAST_SUCCESSFUL",
      "plugin_id": "iris-1",
      "package_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_ROOT_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": null
    },
    {
      "action_id": "UPDATE_ROOT_TO_REPAIRED_PACKAGE",
      "plugin_id": "iris-1",
      "package_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
