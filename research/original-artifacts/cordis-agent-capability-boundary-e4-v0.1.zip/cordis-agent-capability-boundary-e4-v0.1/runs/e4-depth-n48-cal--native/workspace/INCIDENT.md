# incident-e4-cal-n48

Target leaf: cal-lotus
Target service: calVale
Only runtime tools are authoritative.
