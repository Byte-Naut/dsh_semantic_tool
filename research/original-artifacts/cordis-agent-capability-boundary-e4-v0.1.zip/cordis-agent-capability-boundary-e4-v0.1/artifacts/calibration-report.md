# E4-A dependency-depth calibration report

## Frozen question

Does normalized semantic state shift the non-censored correctness failure boundary as the exact root-to-leaf dependency depth increases?

Only dependency depth changes. The normalized query returns state, edges, typed carriers, effects, and coverage; it returns no root cause, path, or repair.

| N | Native validity | Native primary | Semantic validity | Semantic primary | Native path prefix | Semantic path prefix | Native calls | Semantic calls | Native input | Semantic input |
|---:|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | valid | yes | valid | yes | 2/2 | 2/2 | 21 | 9 | 86804 | 56538 |
| 2 | valid | yes | valid | yes | 3/3 | 3/3 | 21 | 8 | 85894 | 65666 |
| 4 | valid | yes | valid | yes | 5/5 | 5/5 | 22 | 7 | 108595 | 65647 |
| 8 | valid | yes | valid | yes | 9/9 | 9/9 | 23 | 8 | 246064 | 104759 |
| 16 | valid | yes | valid | yes | 17/17 | 17/17 | 36 | 6 | 337799 | 108061 |
| 24 | valid | yes | valid | yes | 25/25 | 25/25 | 40 | 8 | 456592 | 218394 |
| 32 | valid | no | valid | yes | 33/33 | 33/33 | 19 | 7 | 400226 | 242838 |
| 48 | valid | no | valid | yes | 49/49 | 49/49 | 36 | 7 | 528991 | 332079 |

## Frozen bracket decision

- Licensed: **no**
- Reason: no later both-fail high anchor
- Selected depths: none
- Calibration cost: $3.116497

The frozen calibration did not locate a complete, uncensored three-anchor bracket. Confirmatory execution is blocked; no failure-boundary shift is inferred.
