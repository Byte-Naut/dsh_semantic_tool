# E4-A capability-boundary experiment

Status: **NO_COMPLETE_CALIBRATION_BRACKET**

The frozen calibration did not locate a complete, uncensored three-anchor bracket. Confirmatory execution is blocked; no failure-boundary shift is inferred.

See `calibration-report.md` for the frozen depth curve. No held-out confirmatory runs were executed.
