import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { allSeeds } from './seed-catalog.mjs'
import { ARMS, EXPERIMENT } from '../src/config.mjs'
import { createRuntime, taskCard, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { parseFinalRecord } from '../src/records.mjs'
import { applyReferenceSolution } from '../evaluator-private/reference-solutions.mjs'

const validationRoot = resolve('workspaces')
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
await mkdir(validationRoot, { recursive: true })
const cases = []

for (const seed of allSeeds()) {
  const workspaceHashes = new Map()
  const schemas = new Map()
  for (const arm of ARMS) {
    const caseId = `${seed.seedId}--${arm}`
    const workspace = join(validationRoot, caseId)
    const files = taskWorkspaceFiles(seed.taskId, seed)
    await materializeWorkspace(workspace, files)
    const tree = await hashTree(workspace)
    workspaceHashes.set(arm, tree.hash)
    const runtime = await createRuntime(seed.taskId, seed, workspace)
    try {
      const card = taskCard(seed.taskId, seed, runtime)
      const telemetry = new Telemetry(`validate:${caseId}`)
      const turnOne = createToolRegistry({ arm, runtime, telemetry, turn: 1 })
      const turnTwo = createToolRegistry({ arm, runtime, telemetry, turn: 2 })
      schemas.set(arm, { turnOne: turnOne.declarations, turnTwo: turnTwo.declarations })
      validateFirewall(seed, card, files, turnOne.declarations, turnTwo.declarations)
      validateArmBoundary(caseId, arm, turnOne.declarations, turnTwo.declarations)
      const witness = validateSemanticWitness(seed, runtime)
      const reference = await applyReferenceSolution(seed, runtime)
      assert(reference.grade.pass, `${caseId}: reference solution fails private runtime grade`)
      cases.push({
        caseId,
        seedId: seed.seedId,
        stage: seed.stage,
        depth: seed.depth,
        family: seed.family,
        arm,
        workspaceHash: tree.hash,
        semanticDigest: witness.digest,
        referenceGradePass: true,
      })
    } finally {
      await runtime.dispose()
    }
  }
  assert(workspaceHashes.get('native') === workspaceHashes.get('semantic'), `${seed.seedId}: Agent-readable workspaces differ`)
  validateSharedSchemas(seed.seedId, schemas.get('native'), schemas.get('semantic'))
  process.stdout.write(`validated paired seed ${seed.seedId}\n`)
}

const parserRegressionPass = validateParserRegression()
const enumeratedScorerPass = await validateEnumeratedScorer()
const budgetHeadroomPass = Math.max(...allSeeds().map(seed => seed.depth + 6)) < EXPERIMENT.maxToolCallsPerTurn
const report = {
  schemaVersion: 4,
  generatedAt: new Date().toISOString(),
  passed: cases.length === allSeeds().length * ARMS.length
    && parserRegressionPass
    && enumeratedScorerPass
    && budgetHeadroomPass,
  caseCount: cases.length,
  pairedSeedCount: allSeeds().length,
  sourceTreeHash: preregistration.sourceTree.hash,
  parserRegressionPass,
  enumeratedScorerPass,
  budgetHeadroomPass,
  maxPreregisteredDepth: Math.max(...allSeeds().map(seed => seed.depth)),
  conservativeNativeTurnOneCallsAtMaxDepth: Math.max(...allSeeds().map(seed => seed.depth + 6)),
  toolCallBudgetPerTurn: EXPERIMENT.maxToolCallsPerTurn,
  assertions: [
    'All calibration and conditionally eligible held-out seeds passed paired offline closure.',
    'Agent-readable workspace trees are byte-identical within every pair.',
    'Only exact dependency depth changes within the prefix-consistent calibration family.',
    'Component, service, and Plugin-prefix names carry no ordinal suffix.',
    'Semantic exposes no raw runtime observation except the shared Package-source oracle.',
    'The normalized slice contains components, edges, typed carriers, effects, and coverage but no computed root cause, path, or repair.',
    'The normalized slice and independent native snapshot reconstruct the same exact chain.',
    'Reference root-only lifecycle actions pass the hidden executable grade at every depth and family.',
    'The maximum-depth ordinary Native evidence path fits below half the per-turn call budget.',
    'Task cards, workspaces, and tool descriptions pass the information-firewall scan.',
    'Terminal-record parsing and exact enumerated action scoring pass regression checks.',
  ],
  cases,
  digest: hashJson(cases),
}
await writeFile('artifacts/parity-validation.json', JSON.stringify(report, null, 2) + '\n')
console.log(`offline parity/reference closure passed for ${cases.length} arm-cases; digest ${report.digest}`)

function validateArmBoundary(caseId, arm, turnOne, turnTwo) {
  const oneNames = turnOne.map(item => item.name)
  const twoNames = turnTwo.map(item => item.name)
  if (arm === 'semantic') {
    assert(oneNames.includes('software_semantic_query'), `${caseId}: normalized query missing`)
    assert(!oneNames.some(name => name.startsWith('native_') && name !== 'native_inspect_package'), `${caseId}: raw native tool leaked`)
    assert(!oneNames.includes('list_checkpoints'), `${caseId}: raw timeline leaked`)
  } else {
    assert(!oneNames.includes('software_semantic_query'), `${caseId}: normalized query leaked into Native`)
    assert(oneNames.includes('native_dynamic_inventory'), `${caseId}: Native dynamic inventory missing`)
    assert(oneNames.includes('native_inspect_component'), `${caseId}: Native component inspection missing`)
  }
  assert(!oneNames.includes('dynamic_define_package') && !oneNames.includes('dynamic_run_package'), `${caseId}: mutation leaked into Turn 1`)
  assert(twoNames.includes('dynamic_define_package') && twoNames.includes('dynamic_run_package'), `${caseId}: Turn-2 actions missing`)
}

function validateSharedSchemas(seedId, nativeSchemas, semanticSchemas) {
  for (const turn of ['turnOne', 'turnTwo']) {
    const sharedNames = turn === 'turnOne'
      ? ['native_inspect_package']
      : ['native_inspect_package', 'dynamic_define_package', 'dynamic_run_package']
    for (const name of sharedNames) {
      const native = nativeSchemas[turn].find(item => item.name === name)
      const semantic = semanticSchemas[turn].find(item => item.name === name)
      assert(native && semantic && hashJson(native) === hashJson(semantic), `${seedId} ${turn}: shared schema mismatch for ${name}`)
    }
  }
}

function validateSemanticWitness(seed, runtime) {
  const query = runtime.semanticQuery({
    query: 'semantic_slice',
    subject: { targetComponentName: seed.leafConsumerName },
  })
  assert(query.computedRootCause === null, `${seed.seedId}: normalized query computes root cause`)
  assert(query.computedCausalPath === null, `${seed.seedId}: normalized query computes path`)
  assert(query.recommendedRepair === null, `${seed.seedId}: normalized query recommends repair`)
  assert(query.components.length === seed.depth + 1, `${seed.seedId}: component cardinality mismatch`)
  assert(query.dependencyEdges.length === seed.depth, `${seed.seedId}: edge cardinality mismatch`)
  assert(query.incidentEffectOwnership.length === seed.depth + 1, `${seed.seedId}: effect cardinality mismatch`)
  assert(query.coverage.packageSource === 'UNAVAILABLE_USE_SOURCE_ORACLE', `${seed.seedId}: source oracle boundary collapsed`)
  const semanticPath = reconstructSemanticPath(query, seed.leafConsumerName)
  assert(exactSequence(semanticPath.components, seed.componentNames), `${seed.seedId}: semantic component path mismatch`)
  assert(exactSequence(semanticPath.services, seed.serviceKeys), `${seed.seedId}: semantic service path mismatch`)
  const failedDynamic = query.dynamicPackages.filter(row => row.activeRun.kind === 'KNOWN_ABSENT' && row.nextPackage.kind === 'KNOWN_VALUE')
  assert(failedDynamic.length === 1, `${seed.seedId}: failed dynamic root is not uniquely derivable`)
  assert(failedDynamic[0].pluginId === runtime.publicState.rootPluginId, `${seed.seedId}: semantic root Plugin mismatch`)
  assert(failedDynamic[0].lastSuccessfulPackage.value === runtime.publicState.rootStablePackageId, `${seed.seedId}: semantic last-successful mismatch`)
  assert(failedDynamic[0].nextPackage.value === runtime.publicState.rootFailedPackageId, `${seed.seedId}: semantic failed-target mismatch`)

  const before = runtime.nativeApplicationSnapshot(runtime.publicState.beforeCheckpointId)
  const nativePath = reconstructNativePath(before, seed.leafConsumerName)
  assert(exactSequence(nativePath.components, seed.componentNames), `${seed.seedId}: native component path mismatch`)
  assert(exactSequence(nativePath.services, seed.serviceKeys), `${seed.seedId}: native service path mismatch`)
  assert(exactEffectSet(query.incidentEffectOwnership.map(row => ({ owner: row.owner.name, label: row.label })),
    seed.componentNames.map((owner, index) => ({ owner, label: seed.effectLabels[index] }))), `${seed.seedId}: semantic effect ownership mismatch`)
  assert(seed.componentNames.every(name => !/-\d+$/.test(name)), `${seed.seedId}: ordinal component suffix leaked`)
  assert(seed.serviceKeys.every(name => !/\d+$/.test(name)), `${seed.seedId}: ordinal service suffix leaked`)
  return { digest: hashJson({ semanticPath, effects: query.incidentEffectOwnership, dynamic: query.dynamicPackages }) }
}

function reconstructSemanticPath(query, leafName) {
  const edgeByConsumer = new Map(query.dependencyEdges.map(edge => [edge.consumer.name, edge]))
  const components = [leafName]
  const services = []
  while (edgeByConsumer.has(components.at(-1))) {
    const edge = edgeByConsumer.get(components.at(-1))
    services.push(edge.serviceKey)
    components.push(edge.provider.name)
  }
  return { components: components.reverse(), services: services.reverse() }
}

function reconstructNativePath(snapshot, leafName) {
  const rowsByName = new Map(snapshot.fibers.map(row => [row.name, row]))
  const components = [leafName]
  const services = []
  while (true) {
    const consumer = rowsByName.get(components.at(-1))
    const injected = Object.entries(consumer?.targetBindings ?? {})
    if (!injected.length) break
    assert(injected.length === 1, `${leafName}: native fixture is not a chain`)
    const [serviceKey, binding] = injected[0]
    services.push(serviceKey)
    components.push(binding.providerName)
  }
  return { components: components.reverse(), services: services.reverse() }
}

function validateFirewall(seed, card, files, ...schemas) {
  const corpus = [card, ...Object.entries(files).flat(), ...schemas.flat().map(item => JSON.stringify(item))].join('\n').toLowerCase()
  const forbidden = [
    'expected superiority', 'prior a/b', 'reference solution', 'private oracle', 'hidden oracle',
    'other-arm', 'other arm trajectory', 'semantic mirror rationale', 'concurrent-horn',
    'joint canonicity', 'p_0', 'ctr makes', 'treatment effect',
  ]
  for (const fragment of forbidden) assert(!corpus.includes(fragment), `${seed.seedId}: firewall phrase leaked: ${fragment}`)
}

function validateParserRegression() {
  const accepted = parseFinalRecord('analysis\n```js\nconst x = 1\n```\n```json\n{"ok":true}\n```')
  const rejected = parseFinalRecord('```json\n{"ok":true}\n```\ntrailing')
  assert(accepted.ok && accepted.record.ok === true, 'parser rejected terminal JSON after an earlier fence')
  assert(!rejected.ok, 'parser accepted trailing content after terminal JSON')
  return true
}

async function validateEnumeratedScorer() {
  const scorer = await readFile('evaluator-private/score-run.mjs', 'utf8')
  const forbidden = ['run_old_version', 'normalizePlanAction', 'normalizeActualAction', 'planned_lifecycle_actions']
  for (const fragment of forbidden) assert(!scorer.includes(fragment), `lexical alias scorer fragment remains: ${fragment}`)
  for (const actionId of ['RESTORE_ROOT_LAST_SUCCESSFUL', 'DEFINE_ROOT_REPAIRED_PACKAGE', 'UPDATE_ROOT_TO_REPAIRED_PACKAGE']) {
    assert(scorer.includes(actionId) || scorer.includes('ACTION_IDS'), `enumerated action scorer missing ${actionId}`)
  }
  return true
}

function exactEffectSet(actual, expected) {
  const normalize = rows => rows.map(row => `${row.owner}\u0000${row.label}`).sort()
  return exactSequence(normalize(actual), normalize(expected))
}

function exactSequence(actual, expected) {
  return Array.isArray(actual) && actual.length === expected.length
    && actual.every((value, index) => value === expected[index])
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}
