import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { ACTION_IDS, ARMS, CALIBRATION_DEPTHS, EXPERIMENT, TASK_ID, TURN_TWO_APPROVAL } from '../src/config.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { commonSystemPrompt } from '../src/common-prompt.mjs'
import { allSeeds, calibrationSeeds } from './seed-catalog.mjs'
import { calibrationRunOrder } from './run-order.mjs'

const sourceTree = await hashTree('.', { exclude: excludedFromFreeze })
const packageLockHash = hashJson(JSON.parse(await readFile('package-lock.json', 'utf8')))
const seeds = allSeeds()
const calibration = calibrationSeeds()
const preregistration = {
  schemaVersion: 4,
  frozenAt: new Date().toISOString(),
  experiment: EXPERIMENT,
  researchQuestion: 'Does normalized semantic state shift the non-censored correctness failure boundary of a strong software agent as exact dependency depth increases?',
  phase: 'exploratory dependency-depth calibration followed only conditionally by a frozen held-out paired boundary replication',
  task: {
    taskId: TASK_ID,
    complexityVariable: 'exact dependency-edge distance N from failed root dynamic publisher to named leaf consumer',
    calibrationDepths: CALIBRATION_DEPTHS,
    prefixConsistentFamily: true,
    invariantPerAddedLevel: 'one dynamic Cordis Plugin, one required service binding, one service publication, and one owned e4 effect',
    unchangedIncident: 'failed immutable root Package update with last-successful retained, failed target retained, and active root Run known absent',
    requiredRepair: 'restore root last-successful; define one repaired immutable root Package; update root; no intermediate mutation',
    deliberatelyExcluded: [
      'irrelevant files or log noise',
      'decoy components or services',
      'direct root-cause or repair query',
      'concurrent replacement',
      'partial-observation UNKNOWN transformation',
      'multiple independent lifecycle fronts',
    ],
  },
  arms: ARMS,
  treatmentContrast: {
    native: 'raw application timeline, dynamic inventory, component, service, binding, and tracked-effect observations plus Package-source oracle',
    semantic: 'one generic normalized slice containing the same identities, dependency edges, typed states/bindings, effect ownership, Package/Run truth, and coverage plus the same Package-source oracle',
    semanticQueryReturns: 'normalized state only',
    semanticQueryForbiddenAnswers: ['computed root cause', 'computed causal path', 'recommended repair'],
    sameSemanticActionDiscipline: true,
  },
  actionIds: ACTION_IDS,
  calibration: {
    seedIds: calibration.map(seed => seed.seedId),
    pairedSeeds: calibration.length,
    slotCount: calibration.length * ARMS.length,
    runOrder: calibrationRunOrder().map(({ seed, arm }) => ({ seedId: seed.seedId, depth: seed.depth, arm })),
    stoppingRule: 'execute every frozen calibration slot exactly once; never replace, rerun, add, or remove a depth after outcomes are visible',
  },
  conditionalConfirmatory: {
    heldOutFamiliesPerDepth: EXPERIMENT.heldOutReplicatesPerDepth,
    heldOutSeedUniverseHash: hashJson(seeds.filter(seed => seed.stage === 'confirmatory')),
    bracketSelection: [
      'Divergence is the earliest fully valid depth where Semantic primary passes and Native primary fails for a scored non-censor outcome.',
      'Low anchor is the greatest earlier fully valid depth where both arms primary pass.',
      'High anchor is the earliest later fully valid depth where both arms primary fail.',
      'The selected interval is [low, divergence, high]; if any anchor is absent, no confirmatory run is licensed.',
      'Any infrastructure-invalid or agent-budget-exhausted calibration slot blocks confirmatory execution.',
    ],
    runCountIfLicensed: 3 * EXPERIMENT.heldOutReplicatesPerDepth * ARMS.length,
    successRule: [
      'no infrastructure-invalid or agent-budget-exhausted held-out slot',
      'low anchor: each arm primary-passes at least 5 of 6',
      'divergence anchor: Semantic passes at least 4 of 6, at least 3 pairs are Semantic-pass/Native-fail, and at most 1 pair reverses',
      'high anchor: each arm primary-passes at most 2 of 6',
    ],
  },
  invariantControls: [
    'same requested model and one reported model version per run',
    'same thinking level, temperature, model seed within pair, tool budget, timeout, task card, workspace, runtime semantics, and action tools',
    'fresh conversation and fresh runtime for every run',
    'no fallback and one HTTP attempt per model request',
    'same Package-source oracle and exact enumerated lifecycle action schemas',
    'same three-valued carrier vocabulary and exact terminal-record obligations',
  ],
  informationFirewall: [
    'no theory paper or companion',
    'no experiment motivation, expected direction, prior A/B result, or arm label in the task card',
    'no hidden oracle, scorer, reference solution, grader, other-arm trajectory, or prior trajectory',
  ],
  outcomes: {
    primary: 'terminal records parse AND exact semantic closure AND exact action/verification records AND hidden executable runtime pass AND zero critical semantic errors',
    capabilityFailures: ['wrong semantic conclusion', 'violated hard constraint', 'invalid repair', 'critical semantic error'],
    excludedFromCapabilityFailure: ['agent-budget-exhausted', 'invalid-infrastructure'],
    topologyDiagnostics: ['exact path', 'correct root-to-leaf prefix length', 'wrong intermediate components', 'intermediate mutation'],
    burdenSecondary: ['calls to evidence closure', 'tool calls', 'gross input tokens', 'native domains touched', 'repeated observations'],
  },
  budgetJustification: {
    maximumDepth: Math.max(...CALIBRATION_DEPTHS),
    conservativeNativeTurnOneOrdinaryCalls: Math.max(...CALIBRATION_DEPTHS) + 6,
    maximumToolCallsPerTurn: EXPERIMENT.maxToolCallsPerTurn,
    headroomRatio: EXPERIMENT.maxToolCallsPerTurn / (Math.max(...CALIBRATION_DEPTHS) + 6),
    rule: 'budget exhaustion is retained as a censored agent outcome and never counted as a correctness failure',
  },
  parserPolicy: 'select the last fenced JSON object and require it to be terminal; earlier prose and code fences are allowed',
  scorerPolicy: 'exact structured identities, exact ordered paths, exact effect-owner pairs, enumerated actions, and hidden runtime behavior; no lexical action aliases',
  interpretationLimit: 'Calibration locates a candidate bracket only. A single winning depth is never evidence of a shifted boundary; the frozen held-out curve must satisfy all three anchor rules.',
  turnTwoApproval: TURN_TWO_APPROVAL,
  commonPromptHash: hashJson(commonSystemPrompt()),
  seedUniverseHash: hashJson(seeds),
  sourceTree,
  packageLockHash,
}
await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/preregistration.json', JSON.stringify(preregistration, null, 2) + '\n')
console.log(`frozen ${sourceTree.entries.length} files as ${sourceTree.hash}`)

function excludedFromFreeze(name, entry) {
  return name === 'node_modules' || name.startsWith('node_modules/')
    || name === 'artifacts' || name.startsWith('artifacts/')
    || name === 'runs' || name.startsWith('runs/')
    || name === 'confirmatory-runs' || name.startsWith('confirmatory-runs/')
    || name === 'workspaces' || name.startsWith('workspaces/')
    || (entry.isFile() && name === 'package-lock.json')
}
