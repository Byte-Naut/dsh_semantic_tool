import { CALIBRATION_DEPTHS, HELDOUT_REPLICATES_PER_DEPTH, TASK_ID } from '../src/config.mjs'

const COMPONENT_WORDS = Object.freeze([
  'iris', 'cedar', 'willow', 'fennel', 'quince', 'birch', 'orchid', 'hemlock', 'maple',
  'xenia', 'spruce', 'dahlia', 'kelp', 'violet', 'aster', 'nettle', 'pine', 'ginkgo',
  'yarrow', 'elm', 'thistle', 'juniper', 'reed', 'zinnia', 'linden', 'umber',
  'badger', 'copper', 'falcon', 'harbor', 'ivory', 'lagoon', 'magnet', 'pebble', 'raven',
  'saffron', 'tundra', 'velvet', 'warden', 'zephyr', 'canyon', 'drift', 'flint', 'grove',
  'heron', 'islet', 'javelin', 'knoll', 'lotus', 'meteor', 'opal', 'prism', 'ripple',
])
const SERVICE_WORDS = Object.freeze([
  'haze', 'coral', 'wheat', 'ember', 'quartz', 'brisk', 'navy', 'frost', 'slate',
  'xanthic', 'pearl', 'dune', 'jade', 'verdant', 'amber', 'moss', 'teal', 'indigo',
  'yellow', 'gale', 'ochre', 'lilac', 'rose', 'zircon', 'khaki', 'ultra',
  'acorn', 'beacon', 'cipher', 'delta', 'echo', 'fjord', 'glint', 'haven', 'ion',
  'jolt', 'kite', 'lumen', 'mirage', 'north', 'orbit', 'plume', 'quest', 'rill',
  'stone', 'torch', 'unity', 'vale', 'whirl', 'xenon', 'yield', 'zenith',
])
const FAMILY_CODES = Object.freeze(['cal', 'harbor', 'orchard', 'quarry', 'marina', 'foundry', 'granary'])

export function calibrationSeeds() {
  return CALIBRATION_DEPTHS.map(depth => makeSeed({ stage: 'calibration', depth, family: 0 }))
}

export function heldOutSeeds(depth) {
  return Array.from({ length: HELDOUT_REPLICATES_PER_DEPTH }, (_, index) => (
    makeSeed({ stage: 'confirmatory', depth, family: index + 1 })
  ))
}

export function allSeeds() {
  return [
    ...calibrationSeeds(),
    ...CALIBRATION_DEPTHS.flatMap(depth => heldOutSeeds(depth)),
  ]
}

export function makeSeed({ stage, depth, family }) {
  if (!Number.isInteger(depth) || depth < 1 || depth > 48) throw new Error(`depth must be 1..48: ${depth}`)
  if (!['calibration', 'confirmatory'].includes(stage)) throw new Error(`unknown stage: ${stage}`)
  if (!Number.isInteger(family) || family < 0 || family >= FAMILY_CODES.length) throw new Error(`unknown family: ${family}`)
  const code = FAMILY_CODES[family]
  const rotation = family * 3
  const componentTokens = rotated(COMPONENT_WORDS, rotation).slice(0, depth + 1)
  const serviceTokens = rotated(SERVICE_WORDS, rotation * 2).slice(0, depth)
  const componentNames = componentTokens.map(token => `${code}-${token}`)
  const dynamicComponentNames = componentNames.slice(0, depth)
  const leafConsumerName = componentNames.at(-1)
  const serviceKeys = serviceTokens.map(token => `${code}${token[0].toUpperCase()}${token.slice(1)}`)
  const pluginPrefixes = componentTokens.slice(0, depth).map(token => token.slice(0, 6))
  const fixtureNumber = stage === 'calibration'
    ? CALIBRATION_DEPTHS.indexOf(depth) + 1
    : 1_000 + depth * 10 + family
  return Object.freeze({
    taskId: TASK_ID,
    stage,
    level: `depth-${depth}`,
    depth,
    family,
    number: fixtureNumber,
    seedId: `e4-depth-n${String(depth).padStart(2, '0')}-${code}`,
    incidentId: `incident-e4-${code}-n${String(depth).padStart(2, '0')}`,
    componentNames: Object.freeze(componentNames),
    dynamicComponentNames: Object.freeze(dynamicComponentNames),
    leafConsumerName,
    serviceKeys: Object.freeze(serviceKeys),
    pluginPrefixes: Object.freeze(pluginPrefixes),
    effectLabels: Object.freeze(componentNames.map(name => `e4:${code}:${name}`)),
    stableRootValue: `${code}-root-stable`,
    repairedRootValue: `${code}-root-repaired`,
    finalStableValue: propagatedValue(`${code}-root-stable`, dynamicComponentNames.slice(1)),
    finalRepairedValue: propagatedValue(`${code}-root-repaired`, dynamicComponentNames.slice(1)),
    failureMessage: `${code} root publication failed before service commit`,
    checkpointBefore: `D0-${code}-n${depth}-stable`,
    checkpointFailed: `D1-${code}-n${depth}-failed-root-update`,
  })
}

export function pairedOrder(seeds) {
  return seeds.flatMap((seed, index) => {
    const arms = index % 2 === 0 ? ['semantic', 'native'] : ['native', 'semantic']
    return arms.map(arm => ({ seed, arm, taskId: TASK_ID }))
  })
}

function propagatedValue(root, downstreamNames) {
  return downstreamNames.reduce((value, name) => `${value}>${name}`, root)
}

function rotated(values, offset) {
  const normalized = offset % values.length
  return [...values.slice(normalized), ...values.slice(0, normalized)]
}
