import { access, mkdir, readFile, writeFile } from 'node:fs/promises'
import { hashJson } from '../src/hash.mjs'

const calibrationResults = await readJsonLines('runs/results.jsonl')
const parity = JSON.parse(await readFile('artifacts/parity-validation.json', 'utf8'))
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
validateCalibrationManifest(calibrationResults, preregistration)
const calibrationPairs = pairRows(calibrationResults)
const calibrationCurve = calibrationPairs.map(summarizeCalibrationPair).sort((a, b) => a.depth - b.depth)
const selection = selectBracket(calibrationCurve)
const calibrationHash = hashJson(calibrationResults)
const decision = {
  schemaVersion: 4,
  generatedAt: new Date().toISOString(),
  experimentId: preregistration.experiment.id,
  calibrationResultsHash: calibrationHash,
  allSlotsValid: calibrationResults.every(row => row.validity === 'valid'),
  licensed: selection.licensed,
  reason: selection.reason,
  selectedDepths: selection.selectedDepths,
  anchors: selection.anchors,
  immutableRule: preregistration.conditionalConfirmatory.bracketSelection,
}

const calibrationAnalysis = {
  schemaVersion: 4,
  generatedAt: new Date().toISOString(),
  experimentId: preregistration.experiment.id,
  stage: 'calibration',
  requestedModel: preregistration.experiment.model,
  slotCount: calibrationResults.length,
  totalCostUsd: totalCost(calibrationResults),
  validity: countBy(calibrationResults, row => row.validity),
  curve: calibrationCurve,
  bracketDecision: decision,
  burdenByArm: summarizeBurdenByArm(calibrationResults),
  failureClasses: countBy(calibrationResults.filter(row => !row.score?.primaryPass), row => row.score?.failureClass ?? row.validity),
  parityPassed: parity.passed,
  interpretation: decision.licensed
    ? 'The frozen calibration located all three candidate anchors. This licenses only the preregistered held-out paired replication.'
    : 'The frozen calibration did not locate a complete, uncensored three-anchor bracket. Confirmatory execution is blocked; no failure-boundary shift is inferred.',
}

await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/calibration-decision.json', JSON.stringify(decision, null, 2) + '\n')
await writeFile('artifacts/calibration-analysis.json', JSON.stringify(calibrationAnalysis, null, 2) + '\n')
await writeFile('artifacts/calibration-report.md', renderCalibrationReport(calibrationAnalysis))

let finalAnalysis = {
  ...calibrationAnalysis,
  stage: 'calibration-only',
  boundaryReplicationPass: null,
  inferentialStatus: decision.licensed
    ? 'HELDOUT_REPLICATION_LICENSED_NOT_YET_RUN'
    : 'NO_COMPLETE_CALIBRATION_BRACKET',
}

if (await exists('confirmatory-runs/results.jsonl')) {
  const heldOutResults = await readJsonLines('confirmatory-runs/results.jsonl')
  validateConfirmatoryManifest(heldOutResults, preregistration, decision)
  const heldOut = analyzeHeldOut(heldOutResults, decision)
  finalAnalysis = {
    schemaVersion: 4,
    generatedAt: new Date().toISOString(),
    experimentId: preregistration.experiment.id,
    stage: 'calibration-and-heldout-confirmatory',
    requestedModel: preregistration.experiment.model,
    calibration: calibrationAnalysis,
    heldOut,
    totalCostUsd: round(totalCost(calibrationResults) + totalCost(heldOutResults), 6),
    boundaryReplicationPass: heldOut.allRulesPass,
    inferentialStatus: heldOut.allRulesPass
      ? 'HELDOUT_THREE_ANCHOR_FAILURE_CURVE_REPLICATED'
      : 'HELDOUT_BOUNDARY_REPLICATION_NOT_ESTABLISHED',
    interpretation: heldOut.allRulesPass
      ? 'Within this frozen task family and model, the held-out three-anchor curve supports a non-censored Semantic failure boundary later than Native.'
      : 'The held-out curve did not satisfy every frozen boundary rule. No capability-boundary shift is established.',
    limits: [
      'The result is task-family and model specific.',
      'It does not establish cross-task, cross-model, or real-issue generalization.',
      'It does not imply runtime authority for the semantic shadow.',
    ],
  }
}

await writeFile('artifacts/final-analysis.json', JSON.stringify(finalAnalysis, null, 2) + '\n')
await writeFile('artifacts/final-report.md', renderFinalReport(finalAnalysis))
console.log(`analysis complete: bracket=${decision.licensed}; status=${finalAnalysis.inferentialStatus}; cost=$${finalAnalysis.totalCostUsd.toFixed(6)}`)

function selectBracket(curve) {
  const invalid = curve.filter(row => row.native.validity !== 'valid' || row.semantic.validity !== 'valid')
  if (invalid.length) {
    return { licensed: false, reason: 'at least one calibration slot is censored or infrastructure-invalid', selectedDepths: [], anchors: null }
  }
  const divergence = curve.find(row => !row.native.primaryPass && row.semantic.primaryPass)
  if (!divergence) return { licensed: false, reason: 'no Semantic-pass/Native-fail calibration depth', selectedDepths: [], anchors: null }
  const lowCandidates = curve.filter(row => row.depth < divergence.depth && row.native.primaryPass && row.semantic.primaryPass)
  const low = lowCandidates.at(-1)
  if (!low) return { licensed: false, reason: 'no earlier both-pass low anchor', selectedDepths: [], anchors: null }
  const high = curve.find(row => row.depth > divergence.depth && !row.native.primaryPass && !row.semantic.primaryPass)
  if (!high) return { licensed: false, reason: 'no later both-fail high anchor', selectedDepths: [], anchors: null }
  return {
    licensed: true,
    reason: 'all preregistered bracket anchors located without censoring',
    selectedDepths: [low.depth, divergence.depth, high.depth],
    anchors: { low: low.depth, divergence: divergence.depth, high: high.depth },
  }
}

function analyzeHeldOut(results, decision) {
  const groups = Object.fromEntries(decision.selectedDepths.map(depth => [depth, results.filter(row => row.difficulty === `depth-${depth}`)]))
  const curve = decision.selectedDepths.map(depth => {
    const rows = groups[depth]
    const native = rows.filter(row => row.arm === 'native')
    const semantic = rows.filter(row => row.arm === 'semantic')
    const pairs = pairRows(rows)
    return {
      depth,
      native: summarizeConfirmatoryArm(native),
      semantic: summarizeConfirmatoryArm(semantic),
      discordant: {
        semanticPassNativeFail: pairs.filter(pair => pair.semantic?.score?.primaryPass && !pair.native?.score?.primaryPass).length,
        nativePassSemanticFail: pairs.filter(pair => pair.native?.score?.primaryPass && !pair.semantic?.score?.primaryPass).length,
      },
    }
  })
  const low = curve.find(row => row.depth === decision.anchors.low)
  const divergence = curve.find(row => row.depth === decision.anchors.divergence)
  const high = curve.find(row => row.depth === decision.anchors.high)
  const rules = {
    noCensorOrInfrastructureFailure: results.every(row => row.validity === 'valid'),
    lowNativeAtLeastFiveOfSix: low.native.primaryPass >= 5,
    lowSemanticAtLeastFiveOfSix: low.semantic.primaryPass >= 5,
    divergenceSemanticAtLeastFourOfSix: divergence.semantic.primaryPass >= 4,
    divergenceAtLeastThreeSemanticOnlyPairs: divergence.discordant.semanticPassNativeFail >= 3,
    divergenceAtMostOneNativeOnlyPair: divergence.discordant.nativePassSemanticFail <= 1,
    highNativeAtMostTwoOfSix: high.native.primaryPass <= 2,
    highSemanticAtMostTwoOfSix: high.semantic.primaryPass <= 2,
  }
  return {
    slotCount: results.length,
    totalCostUsd: totalCost(results),
    validity: countBy(results, row => row.validity),
    curve,
    burdenByArm: summarizeBurdenByArm(results),
    failureClasses: countBy(results.filter(row => !row.score?.primaryPass), row => row.score?.failureClass ?? row.validity),
    rules,
    allRulesPass: Object.values(rules).every(Boolean),
  }
}

function summarizeCalibrationPair(pair) {
  return {
    seedId: pair.seedId,
    depth: depthOf(pair.native ?? pair.semantic),
    native: summarizeSlot(pair.native),
    semantic: summarizeSlot(pair.semantic),
    primaryPattern: `${pair.native?.score?.primaryPass ? 'N+' : 'N-'} / ${pair.semantic?.score?.primaryPass ? 'S+' : 'S-'}`,
    semanticMinusNativeToolCalls: delta(burden(pair.semantic)?.totalToolCalls, burden(pair.native)?.totalToolCalls),
    semanticMinusNativeInputTokens: delta(burden(pair.semantic)?.grossInputTokens, burden(pair.native)?.grossInputTokens),
  }
}

function summarizeSlot(row) {
  return {
    validity: row?.validity ?? 'missing',
    primaryPass: row?.score?.primaryPass ?? false,
    runtimePass: row?.score?.runtimePass ?? false,
    semanticClosure: row?.score?.semanticClosure ?? false,
    failureClass: row?.score?.failureClass ?? null,
    criticalErrors: row?.score?.criticalErrors ?? [],
    correctPathPrefix: row?.score?.topology?.correctPrefixLength ?? null,
    expectedComponents: row?.score?.topology?.expectedComponentCount ?? null,
    totalToolCalls: burden(row)?.totalToolCalls ?? null,
    callsToEvidenceClosure: burden(row)?.callsToFirstSufficientEvidence ?? null,
    grossInputTokens: burden(row)?.grossInputTokens ?? null,
    costUsd: row?.costUsd ?? 0,
  }
}

function summarizeConfirmatoryArm(rows) {
  const pass = rows.filter(row => row.score?.primaryPass).length
  return {
    slots: rows.length,
    valid: rows.filter(row => row.validity === 'valid').length,
    primaryPass: pass,
    primaryRate: rows.length ? pass / rows.length : null,
    wilson95: wilson(pass, rows.length),
    runtimePass: rows.filter(row => row.score?.runtimePass).length,
    meanBurden: meanBurden(rows),
  }
}

function summarizeBurdenByArm(rows) {
  return Object.fromEntries(['native', 'semantic'].map(arm => {
    const armRows = rows.filter(row => row.arm === arm)
    return [arm, meanBurden(armRows)]
  }))
}

function meanBurden(rows) {
  return {
    totalToolCalls: mean(rows.map(row => burden(row)?.totalToolCalls)),
    callsToEvidenceClosure: mean(rows.map(row => burden(row)?.callsToFirstSufficientEvidence)),
    grossInputTokens: mean(rows.map(row => burden(row)?.grossInputTokens)),
    nativeDomainsTouched: mean(rows.map(row => burden(row)?.nativeStateDomainsTouched)),
  }
}

function validateCalibrationManifest(results, preregistration) {
  const expected = preregistration.calibration.runOrder.map(row => `${row.seedId}--${row.arm}`).sort()
  const actual = results.map(row => row.runId).sort()
  if (!exactSequence(actual, expected)) throw new Error('calibration results do not match the frozen slot manifest')
}

function validateConfirmatoryManifest(results, preregistration, decision) {
  if (!decision.licensed || decision.selectedDepths.length !== 3) throw new Error('confirmatory results exist without a licensed bracket')
  const expected = preregistration.conditionalConfirmatory.runCountIfLicensed
  if (results.length !== expected) throw new Error(`confirmatory results have ${results.length} slots; expected ${expected}`)
  const seen = new Set()
  for (const row of results) {
    if (seen.has(row.runId)) throw new Error(`duplicate confirmatory run: ${row.runId}`)
    seen.add(row.runId)
    if (!decision.selectedDepths.includes(depthOf(row))) throw new Error(`unselected confirmatory depth: ${row.difficulty}`)
  }
}

function pairRows(rows) {
  const map = new Map()
  for (const row of rows) {
    const pair = map.get(row.seedId) ?? { seedId: row.seedId, native: null, semantic: null }
    pair[row.arm] = row
    map.set(row.seedId, pair)
  }
  return [...map.values()].sort((left, right) => depthOf(left.native ?? left.semantic) - depthOf(right.native ?? right.semantic)
    || left.seedId.localeCompare(right.seedId))
}

function renderCalibrationReport(analysis) {
  const rows = analysis.curve.map(row => `| ${row.depth} | ${row.native.validity} | ${yes(row.native.primaryPass)} | ${row.semantic.validity} | ${yes(row.semantic.primaryPass)} | ${row.native.correctPathPrefix}/${row.native.expectedComponents} | ${row.semantic.correctPathPrefix}/${row.semantic.expectedComponents} | ${cell(row.native.totalToolCalls)} | ${cell(row.semantic.totalToolCalls)} | ${cell(row.native.grossInputTokens)} | ${cell(row.semantic.grossInputTokens)} |`).join('\n')
  return `# E4-A dependency-depth calibration report

## Frozen question

Does normalized semantic state shift the non-censored correctness failure boundary as the exact root-to-leaf dependency depth increases?

Only dependency depth changes. The normalized query returns state, edges, typed carriers, effects, and coverage; it returns no root cause, path, or repair.

| N | Native validity | Native primary | Semantic validity | Semantic primary | Native path prefix | Semantic path prefix | Native calls | Semantic calls | Native input | Semantic input |
|---:|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
${rows}

## Frozen bracket decision

- Licensed: **${analysis.bracketDecision.licensed ? 'yes' : 'no'}**
- Reason: ${analysis.bracketDecision.reason}
- Selected depths: ${analysis.bracketDecision.selectedDepths.length ? analysis.bracketDecision.selectedDepths.join(', ') : 'none'}
- Calibration cost: $${analysis.totalCostUsd.toFixed(6)}

${analysis.interpretation}
`
}

function renderFinalReport(analysis) {
  if (!analysis.heldOut) {
    return `# E4-A capability-boundary experiment

Status: **${analysis.inferentialStatus}**

${analysis.interpretation}

See \`calibration-report.md\` for the frozen depth curve. No held-out confirmatory runs were executed.
`
  }
  const rows = analysis.heldOut.curve.map(row => `| ${row.depth} | ${row.native.primaryPass}/${row.native.slots} | ${row.semantic.primaryPass}/${row.semantic.slots} | ${row.discordant.semanticPassNativeFail} | ${row.discordant.nativePassSemanticFail} | ${row.native.meanBurden.totalToolCalls} | ${row.semantic.meanBurden.totalToolCalls} |`).join('\n')
  const rules = Object.entries(analysis.heldOut.rules).map(([name, pass]) => `| ${name} | ${pass ? 'PASS' : 'FAIL'} |`).join('\n')
  return `# E4-A held-out capability-boundary report

Status: **${analysis.inferentialStatus}**

| N | Native primary | Semantic primary | S-only pairs | N-only pairs | Native mean calls | Semantic mean calls |
|---:|---:|---:|---:|---:|---:|---:|
${rows}

## Frozen decision rules

| Rule | Result |
|---|---|
${rules}

Overall held-out boundary replication: **${analysis.boundaryReplicationPass ? 'PASS' : 'FAIL'}**.

${analysis.interpretation}

Total paid-model cost (calibration plus held-out): $${analysis.totalCostUsd.toFixed(6)}.
`
}

async function readJsonLines(path) {
  return (await readFile(path, 'utf8')).trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
}

async function exists(path) {
  try {
    await access(path)
    return true
  } catch {
    return false
  }
}

function burden(row) {
  return row?.score?.burden ?? null
}

function depthOf(row) {
  return Number(String(row?.difficulty ?? '').replace('depth-', ''))
}

function delta(left, right) {
  return Number.isFinite(left) && Number.isFinite(right) ? left - right : null
}

function mean(values) {
  const numeric = values.filter(Number.isFinite)
  return numeric.length ? round(numeric.reduce((sum, value) => sum + value, 0) / numeric.length, 3) : null
}

function wilson(successes, total) {
  if (!total) return null
  const z = 1.959963984540054
  const p = successes / total
  const denominator = 1 + z * z / total
  const centre = (p + z * z / (2 * total)) / denominator
  const half = z * Math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
  return [round(Math.max(0, centre - half), 4), round(Math.min(1, centre + half), 4)]
}

function totalCost(rows) {
  return round(rows.reduce((sum, row) => sum + (row.costUsd ?? 0), 0), 6)
}

function countBy(rows, key) {
  const output = {}
  for (const row of rows) output[key(row)] = (output[key(row)] ?? 0) + 1
  return output
}

function round(value, digits) {
  return Number(value.toFixed(digits))
}

function exactSequence(actual, expected) {
  return actual.length === expected.length && actual.every((value, index) => value === expected[index])
}

function yes(value) {
  return value ? 'yes' : 'no'
}

function cell(value) {
  return value === null || value === undefined ? 'NA' : String(value)
}
