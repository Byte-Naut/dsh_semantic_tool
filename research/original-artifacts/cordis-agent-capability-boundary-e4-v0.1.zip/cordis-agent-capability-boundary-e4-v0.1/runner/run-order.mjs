import { ARMS } from '../src/config.mjs'
import { calibrationSeeds, heldOutSeeds } from './seed-catalog.mjs'

export function calibrationRunOrder() {
  return calibrationSeeds().flatMap(seed => {
    const first = seed.number % 2 === 1 ? 'semantic' : 'native'
    return [first, ARMS.find(arm => arm !== first)].map(arm => ({ taskId: seed.taskId, seed, arm }))
  })
}

export function confirmatoryRunOrder(selectedDepths) {
  if (!Array.isArray(selectedDepths) || selectedDepths.length !== 3) {
    throw new Error('confirmatory run order requires exactly three selected depths')
  }
  const perDepth = new Map(selectedDepths.map(depth => [depth, heldOutSeeds(depth)]))
  const output = []
  for (let familyIndex = 0; familyIndex < heldOutSeeds(selectedDepths[0]).length; familyIndex += 1) {
    for (const [depthIndex, depth] of selectedDepths.entries()) {
      const seed = perDepth.get(depth)[familyIndex]
      const first = (familyIndex + depthIndex) % 2 === 0 ? 'semantic' : 'native'
      output.push(...[first, ARMS.find(arm => arm !== first)].map(arm => ({ taskId: seed.taskId, seed, arm })))
    }
  }
  return output
}
