import { stateName } from '../vendor/semantic-mirror-v0.3/collector.mjs'

export function captureCordisNative({ label, root, collector, fibers = [] }) {
  const allFibers = new Set([root.fiber, ...fibers])
  for (const runtime of root.registry.values()) {
    for (const fiber of runtime.fibers) allFibers.add(fiber)
  }

  const describedFibers = [...allFibers].map(fiber => ({
    fiberId: collector.fiberId(fiber),
    name: fiber.name,
    state: stateName(fiber.state),
    parentFiberId: fiber.parent?.fiber && fiber.parent.fiber !== fiber
      ? collector.fiberId(fiber.parent.fiber)
      : null,
    declaredInjections: Object.keys(fiber.inject ?? {}).sort(),
    targetBindings: describeBindings(fiber._store, collector),
    committedBindings: describeBindings(fiber.store, collector),
    effects: flattenEffects(fiber.getEffects()),
  }))
  const fiberRows = [...new Map(describedFibers.map(row => [row.fiberId, row])).values()]
    .sort((left, right) => left.name.localeCompare(right.name) || left.fiberId.localeCompare(right.fiberId))

  const services = []
  for (const key of Reflect.ownKeys(root.reflect.store)) {
    const implementation = root.reflect.store[key]
    if (!implementation) continue
    services.push(describeImplementation(implementation, collector))
  }
  services.sort((left, right) => left.serviceKey.localeCompare(right.serviceKey)
    || left.providerName.localeCompare(right.providerName))

  return Object.freeze({ label, fibers: fiberRows, services })
}

function describeBindings(store, collector) {
  return Object.fromEntries(Object.entries(store ?? {}).map(([serviceKey, implementation]) => [
    serviceKey,
    describeImplementation(implementation, collector),
  ]))
}

function describeImplementation(implementation, collector) {
  return {
    serviceImplId: collector.serviceImplId(implementation),
    serviceKey: implementation.name,
    providerFiberId: collector.fiberId(implementation.fiber),
    providerName: implementation.fiber.name,
    version: primitive(implementation.value?.version),
  }
}

function primitive(value) {
  return ['string', 'number', 'boolean'].includes(typeof value) ? value : null
}

function flattenEffects(roots) {
  const output = []
  const visit = (effect, path) => {
    output.push({ path, label: effect.label })
    effect.children.forEach((child, index) => visit(child, `${path}.${index}`))
  }
  roots.forEach((root, index) => visit(root, String(index)))
  return output
}
