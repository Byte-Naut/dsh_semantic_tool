import { hashJson } from './hash.mjs'

const OBJECT = 'object'

export function createToolRegistry({ arm, runtime, telemetry, turn }) {
  const tools = []
  const transcript = []
  const add = (name, description, parametersJsonSchema, category, domain, handler) => {
    tools.push({ declaration: { name, description, ...(parametersJsonSchema ? { parametersJsonSchema } : {}) }, category, domain, handler })
  }

  if (arm === 'native') {
    add('list_checkpoints', 'List immutable incident checkpoints plus the live current view.', null,
      'OBSERVE_NATIVE', 'timeline', () => runtime.checkpoints())
    add('native_dynamic_inventory', 'Read raw Plugin, immutable Package, latest-attempt, and active-Run fields for every dynamic Plugin.', null,
      'OBSERVE_NATIVE', 'dynamic_package', () => runtime.dynamicInventory())
    add('native_list_components', 'List application component instances, lifecycle states, parents, and declared injections at one checkpoint. Bindings and effects require per-component inspection.', checkpointSchema(),
      'OBSERVE_NATIVE', 'components', ({ checkpointId }) => runtime.nativeApplicationSnapshot(checkpointId).fibers
        .map(({ targetBindings, committedBindings, effects, ...component }) => component))
    add('native_list_service_implementations', 'List raw visible application service implementations at one checkpoint.', checkpointSchema(),
      'OBSERVE_NATIVE', 'services', ({ checkpointId }) => runtime.nativeApplicationSnapshot(checkpointId).services)
    add('native_inspect_component', 'Read raw target bindings, committed bindings, and tracked effects for exactly one application component instance.', objectSchema({
      componentId: { type: 'string' }, checkpointId: { type: 'string' },
    }, ['componentId', 'checkpointId']), 'OBSERVE_NATIVE', 'component_bindings_effects', ({ componentId, checkpointId }) => {
      const component = runtime.nativeApplicationSnapshot(checkpointId).fibers
        .find(row => row.fiberId === componentId)
      if (!component) throw new Error(`unknown component instance: ${componentId}`)
      runtime.noteNativeComponentInspection?.(component, checkpointId)
      return component
    })
  } else if (arm === 'semantic') {
    add('software_semantic_query', 'Read a pre-specified normalized semantic slice. It returns identities, dependency edges, typed lifecycle and binding carriers, effect ownership, Package/Run truth, and coverage; it does not compute a root cause, causal path, or repair.', objectSchema({
      query: { type: 'string', enum: ['semantic_slice', 'verify_depth_chain'] },
      subject: {
        type: OBJECT,
        additionalProperties: false,
        properties: { targetComponentName: { type: 'string' } },
        required: ['targetComponentName'],
      },
    }, ['query', 'subject']), 'OBSERVE_SEMANTIC', 'semantic_query', request => runtime.semanticQuery(request))
  } else {
    throw new Error(`unknown arm: ${arm}`)
  }

  add('native_inspect_package', 'Authorized source oracle: read one exact immutable Package, including stored source. This is the only raw observation available through the normalized interface.', objectSchema({
    pluginId: { type: 'string' }, packageId: { type: 'string' },
  }, ['pluginId', 'packageId']), 'OBSERVE_ORACLE', 'package_source', args => runtime.inspectPackage(args))

  if (turn === 2) {
    add('dynamic_define_package', 'Define one fresh immutable Package under an existing Plugin.', objectSchema({
      pluginId: { type: 'string' }, name: { type: 'string' }, purpose: { type: 'string' }, hostCode: { type: 'string' },
    }, ['pluginId', 'name', 'purpose', 'hostCode']), 'MUTATE_FIXTURE', 'dynamic_package', args => runtime.definePackage(args))
    add('dynamic_run_package', 'Run or update one exact immutable Package.', objectSchema({
      pluginId: { type: 'string' }, packageId: { type: 'string' }, mode: { type: 'string', enum: ['run', 'update'] },
    }, ['pluginId', 'packageId', 'mode']), 'MUTATE_FIXTURE', 'dynamic_package', args => runtime.runPackage(args))
  }

  const byName = new Map(tools.map(tool => [tool.declaration.name, tool]))
  return {
    declarations: tools.map(tool => tool.declaration),
    metadata: tools.map(({ declaration, category, domain }) => ({ name: declaration.name, category, domain })),
    transcript,
    async call(name, args = {}) {
      const tool = byName.get(name)
      if (!tool) throw new Error(`tool is unavailable in this arm/turn: ${name}`)
      const argsHash = hashJson(args)
      telemetry.record('tool_called', {
        name, category: tool.category, domain: tool.domain,
        inputBytes: Buffer.byteLength(JSON.stringify(args)), argsHash, turn,
      })
      const started = performance.now()
      try {
        const output = await tool.handler(args)
        const evidenceTags = runtime.evidenceTagsForTool?.(name, args, output) ?? []
        transcript.push({ sequence: transcript.length + 1, turn, name, args, status: 'ok', output: jsonSafe(output), evidenceTags })
        telemetry.record('tool_returned', {
          name, category: tool.category, domain: tool.domain, argsHash, evidenceTags,
          outputBytes: Buffer.byteLength(JSON.stringify(output)), durationMs: Math.round(performance.now() - started),
          status: 'ok', turn,
        })
        return output
      } catch (error) {
        const output = { error: error instanceof Error ? error.message : String(error) }
        transcript.push({ sequence: transcript.length + 1, turn, name, args, status: 'error', output, evidenceTags: [] })
        telemetry.record('tool_returned', {
          name, category: tool.category, domain: tool.domain, argsHash, evidenceTags: [],
          outputBytes: Buffer.byteLength(JSON.stringify(output)), durationMs: Math.round(performance.now() - started),
          status: 'error', turn,
        })
        return output
      }
    },
  }
}

function checkpointSchema() {
  return objectSchema({ checkpointId: { type: 'string' } }, ['checkpointId'])
}

function objectSchema(properties, required = []) {
  return { type: OBJECT, additionalProperties: false, properties, ...(required.length ? { required } : {}) }
}

function jsonSafe(value) {
  return value === undefined ? null : JSON.parse(JSON.stringify(value))
}
