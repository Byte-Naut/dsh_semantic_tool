export const CALIBRATION_DEPTHS = Object.freeze([1, 2, 4, 8, 16, 24, 32, 48])
export const HELDOUT_REPLICATES_PER_DEPTH = 6

export const EXPERIMENT = Object.freeze({
  id: 'cordis-agent-capability-boundary-e4-v01',
  phase: 'dependency-depth failure-curve calibration with conditional confirmatory replication',
  estimand: 'semantic normalization shifts the non-censored correctness failure boundary as dependency depth increases',
  model: 'gemini-3.8-flash',
  thinkingLevel: 'medium',
  temperature: 1,
  candidateCount: 1,
  maxOutputTokensPerRequest: 32_768,
  maxToolCallsPerTurn: 120,
  maxRequestsPerTurn: 126,
  maxGrossInputTokensPerRun: 10_000_000,
  maxGrossOutputTokensPerRun: 150_000,
  requestTimeoutMs: 180_000,
  runTimeoutMs: 1_800_000,
  httpAttempts: 1,
  modelSeedBase: 300_000,
  fallback: false,
  calibrationDepths: CALIBRATION_DEPTHS,
  heldOutReplicatesPerDepth: HELDOUT_REPLICATES_PER_DEPTH,
  pricingUsdPerMillion: Object.freeze({ input: 0.75, outputIncludingThinking: 3.75 }),
})

export const TASK_ID = 'e4-depth-chain-recovery'
export const ARMS = Object.freeze(['native', 'semantic'])

export const ACTION_IDS = Object.freeze([
  'RESTORE_ROOT_LAST_SUCCESSFUL',
  'DEFINE_ROOT_REPAIRED_PACKAGE',
  'UPDATE_ROOT_TO_REPAIRED_PACKAGE',
])

export function modelSeed(fixtureNumber) {
  return EXPERIMENT.modelSeedBase + fixtureNumber
}

export const TURN_TWO_APPROVAL = `Execute exactly the approved three-step root lifecycle plan. Do not mutate or restart any intermediate Plugin or consumer. Verify the leaf service and every path component using the available observation interface. Finish with one terminal JSON fence:
{
  "status":"PASS|FAIL",
  "actions":[
    {"action_id":"RESTORE_ROOT_LAST_SUCCESSFUL","plugin_id":"exact root plugin id","package_id":"exact package id","mode":"run"},
    {"action_id":"DEFINE_ROOT_REPAIRED_PACKAGE","plugin_id":"exact root plugin id","package_id":"new package id","mode":null},
    {"action_id":"UPDATE_ROOT_TO_REPAIRED_PACKAGE","plugin_id":"exact root plugin id","package_id":"new package id","mode":"update"}
  ],
  "verification":{
    "active_root_package_id":"string|null",
    "leaf_service_value":"string|null",
    "active_path_components":["component names in root-to-leaf order"]
  },
  "remaining_unknowns":[]
}`
