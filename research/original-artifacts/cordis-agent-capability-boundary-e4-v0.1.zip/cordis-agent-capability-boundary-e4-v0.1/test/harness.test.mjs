import test from 'node:test'
import assert from 'node:assert/strict'
import { ACTION_IDS, CALIBRATION_DEPTHS, TASK_ID } from '../src/config.mjs'
import { parseFinalRecord } from '../src/records.mjs'
import { classifyRunError } from '../src/outcome-classification.mjs'
import { createRuntime } from '../src/runtime-controller.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { scoreRun } from '../evaluator-private/score-run.mjs'
import { applyReferenceSolution } from '../evaluator-private/reference-solutions.mjs'
import { allSeeds, calibrationSeeds, heldOutSeeds } from '../runner/seed-catalog.mjs'
import { calibrationRunOrder } from '../runner/run-order.mjs'

test('depth ladder, held-out families, and paired order are deterministic', () => {
  assert.equal(allSeeds().length, CALIBRATION_DEPTHS.length * 7)
  assert.deepEqual(calibrationSeeds().map(seed => seed.depth), CALIBRATION_DEPTHS)
  assert.equal(heldOutSeeds(4).length, 6)
  assert.deepEqual(heldOutSeeds(4), heldOutSeeds(4))
  const order = calibrationRunOrder()
  assert.equal(order.length, CALIBRATION_DEPTHS.length * 2)
  for (let index = 0; index < order.length; index += 2) {
    assert.equal(order[index].seed.seedId, order[index + 1].seed.seedId)
    assert.notEqual(order[index].arm, order[index + 1].arm)
  }
  const shallow = calibrationSeeds().find(seed => seed.depth === 4)
  const deep = calibrationSeeds().find(seed => seed.depth === 8)
  assert.deepEqual(deep.componentNames.slice(0, shallow.componentNames.length), shallow.componentNames)
  assert(shallow.componentNames.every(name => !/-\d+$/.test(name)))
  assert(shallow.serviceKeys.every(name => !/\d+$/.test(name)))
})

test('terminal parser permits earlier fences but rejects a suffix', () => {
  const parsed = parseFinalRecord('```js\nconst x = 1\n```\ntext\n```json\n{"status":"ok"}\n```')
  assert.equal(parsed.ok, true)
  assert.equal(parsed.record.status, 'ok')
  assert.equal(parseFinalRecord('```json\n{"status":"ok"}\n```\nextra').ok, false)
})

test('agent budget limits are censored outcomes, not infrastructure failures', () => {
  assert.equal(classifyRunError({ code: 'AGENT_TOOL_BUDGET_EXHAUSTED' }), 'agent-budget-exhausted')
  assert.equal(classifyRunError({ code: 'ECONNRESET' }), 'invalid-infrastructure')
})

test('normalized slice exposes the same real chain without a root-cause answer', async () => {
  const seed = calibrationSeeds().find(row => row.depth === 4)
  const runtime = await createRuntime(TASK_ID, seed)
  try {
    const telemetry = new Telemetry('test-boundary')
    const native = createToolRegistry({ arm: 'native', runtime, telemetry, turn: 1 })
    const semantic = createToolRegistry({ arm: 'semantic', runtime, telemetry, turn: 1 })
    const nativeNames = native.declarations.map(row => row.name)
    const semanticNames = semantic.declarations.map(row => row.name)
    assert(nativeNames.includes('native_dynamic_inventory'))
    assert(nativeNames.includes('native_inspect_component'))
    assert(!nativeNames.includes('software_semantic_query'))
    assert.deepEqual(semanticNames, ['software_semantic_query', 'native_inspect_package'])

    const query = runtime.semanticQuery({
      query: 'semantic_slice', subject: { targetComponentName: seed.leafConsumerName },
    })
    assert.equal(query.computedRootCause, null)
    assert.equal(query.computedCausalPath, null)
    assert.equal(query.recommendedRepair, null)
    assert.equal(query.dependencyEdges.length, seed.depth)
    assert.equal(query.incidentEffectOwnership.length, seed.depth + 1)
    const failedRoot = query.dynamicPackages.find(row => row.activeRun.kind === 'KNOWN_ABSENT')
    assert.equal(failedRoot.pluginId, runtime.publicState.rootPluginId)
    assert.equal(failedRoot.nextPackage.value, runtime.publicState.rootFailedPackageId)
    assert.deepEqual(reconstructPath(query, seed.leafConsumerName), seed.componentNames)
  } finally {
    await runtime.dispose()
  }
})

test('reference root-only recovery closes at the high calibration anchor', async () => {
  const seed = calibrationSeeds().at(-1)
  const runtime = await createRuntime(TASK_ID, seed)
  try {
    const reference = await applyReferenceSolution(seed, runtime)
    assert.equal(reference.grade.pass, true)
    assert.equal(reference.grade.pluginCount, seed.depth)
    assert.equal(reference.grade.noIntermediateMutation, true)
    assert.deepEqual(reference.grade.activePath, seed.componentNames)
    assert.equal(reference.grade.finalLeafValue, seed.finalRepairedValue)
  } finally {
    await runtime.dispose()
  }
})

test('exact enumerated scorer accepts the executable reference record', async () => {
  const seed = calibrationSeeds().find(row => row.depth === 2)
  const runtime = await createRuntime(TASK_ID, seed)
  try {
    const reference = await applyReferenceSolution(seed, runtime)
    const newPackageId = String(reference.definition.packageId)
    const turnOne = fence({
      facts: {
        root_plugin_id: runtime.publicState.rootPluginId,
        last_successful_package_id: runtime.publicState.rootStablePackageId,
        failed_target_package_id: runtime.publicState.rootFailedPackageId,
        active_run: { kind: 'KNOWN_ABSENT', package_id: null },
        causal_path_root_to_leaf: seed.componentNames,
        dependency_services_root_to_leaf: seed.serviceKeys,
        incident_effects_at_risk: seed.componentNames.map((owner_component, index) => ({ owner_component, label: seed.effectLabels[index] })),
      },
      source_diagnosis: { failed_package_inspected: true, defect_code: 'THROW_BEFORE_PUBLISH' },
      plan: [
        { action_id: ACTION_IDS[0], plugin_id: runtime.publicState.rootPluginId, package_id: runtime.publicState.rootStablePackageId, mode: 'run' },
        { action_id: ACTION_IDS[1], plugin_id: runtime.publicState.rootPluginId, package_id: 'NEW_PACKAGE', mode: null },
        { action_id: ACTION_IDS[2], plugin_id: runtime.publicState.rootPluginId, package_id: 'NEW_PACKAGE', mode: 'update' },
      ],
      unknowns: [],
    })
    const turnTwo = fence({
      status: 'PASS',
      actions: [
        { action_id: ACTION_IDS[0], plugin_id: runtime.publicState.rootPluginId, package_id: runtime.publicState.rootStablePackageId, mode: 'run' },
        { action_id: ACTION_IDS[1], plugin_id: runtime.publicState.rootPluginId, package_id: newPackageId, mode: null },
        { action_id: ACTION_IDS[2], plugin_id: runtime.publicState.rootPluginId, package_id: newPackageId, mode: 'update' },
      ],
      verification: {
        active_root_package_id: newPackageId,
        leaf_service_value: seed.finalRepairedValue,
        active_path_components: seed.componentNames,
      },
      remaining_unknowns: [],
    })
    const score = scoreRun({
      seed, runtime, turnOneText: turnOne, turnTwoText: turnTwo, grade: reference.grade,
      telemetryTotals: {
        toolCalls: 9, observationCalls: 6, nativeObservationCalls: 5, semanticObservationCalls: 0,
        oracleObservationCalls: 1, nativeObservationDomainsTouched: ['dynamic_package', 'component_bindings_effects'],
        repeatedObservationCalls: 0, toolResultBytes: 100,
        usage: { input: 1000, output: 100, thoughts: 100 },
      },
      telemetryEvents: evidenceEvents(),
    })
    assert.equal(score.primaryPass, true)
    assert.equal(score.topology.exactPath, true)
  } finally {
    await runtime.dispose()
  }
})

function reconstructPath(query, leafName) {
  const providerByConsumer = new Map(query.dependencyEdges.map(edge => [edge.consumer.name, edge.provider.name]))
  const reverse = [leafName]
  while (providerByConsumer.has(reverse.at(-1))) reverse.push(providerByConsumer.get(reverse.at(-1)))
  return reverse.reverse()
}

function fence(value) {
  return `\`\`\`json\n${JSON.stringify(value)}\n\`\`\``
}

function evidenceEvents() {
  const tags = [
    ['dynamic_state'],
    ['component_identity'],
    ['dependency_edges', 'bindings', 'effect_ownership'],
    ['failed_source'],
  ]
  return tags.flatMap((evidenceTags, index) => [
    { sequence: index * 2 + 1, turn: 1, kind: 'tool_called' },
    { sequence: index * 2 + 2, turn: 1, kind: 'tool_returned', status: 'ok', evidenceTags },
  ])
}
