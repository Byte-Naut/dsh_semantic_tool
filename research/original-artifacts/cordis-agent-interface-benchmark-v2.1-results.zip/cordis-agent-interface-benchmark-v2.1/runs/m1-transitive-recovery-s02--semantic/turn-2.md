The recovery plan has been executed and verified.

1. **Service Restored**: `RESTORE_LAST_SUCCESSFUL` executed on `pkg-1` in `run` mode, bringing the plugin back online with stable service value `cobalt-stable`.
2. **Repaired Package Defined**: `DEFINE_REPAIRED_PACKAGE` defined `pkg-3` on `orchac-1` with the premature error throw removed.
3. **Updated to Repaired Package**: `UPDATE_TO_REPAIRED_PACKAGE` updated `orchac-1` to `pkg-3` in `update` mode, publishing service value `cobalt-repaired`.
4. **Verification**: Both the direct consumer (`orchard-ledger-adapter`) and transitive consumer (`orchard-index-client`) are verified active.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "orchac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "cobalt-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
