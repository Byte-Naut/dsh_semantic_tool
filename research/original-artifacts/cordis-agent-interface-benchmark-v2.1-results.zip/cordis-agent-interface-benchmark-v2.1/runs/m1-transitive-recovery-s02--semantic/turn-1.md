I have completed the Turn-1 evidence collection and inspection obligations for incident `incident-orchard-02`.

### Evidence Summary
1. **Last successful immutable Package**: `pkg-1`
2. **Failed target Package**: `pkg-2`
3. **Active Run status**: `KNOWN_ABSENT` (`package_id`: `null`)
4. **Direct consumer**: `orchard-ledger-adapter` (consumes `ledgerEndpoint`)
5. **Transitive consumer**: `orchard-index-client` (consumes `indexView` derived from `ledgerEndpoint`)
6. **Tracked effects at risk**:
   - `ctx.provide("ledgerEndpoint")`
   - `tracked:direct:cobalt-stable`
   - `ctx.provide("indexView")`
   - `tracked:transitive:derived:cobalt-stable`
7. **Failed Package inspection**: Package `pkg-2` throws `Error: cobalt bootstrap failed before publication` synchronously during `apply(ctx)` prior to `ctx.provide("ledgerEndpoint", ...)`. Classified as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "orchard-ledger-adapter"
    ],
    "transitive_consumers": [
      "orchard-index-client"
    ],
    "tracked_effects_at_risk": [
      "ctx.provide(\"ledgerEndpoint\")",
      "tracked:transitive:derived:cobalt-stable",
      "ctx.provide(\"indexView\")",
      "tracked:direct:cobalt-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "orchac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
