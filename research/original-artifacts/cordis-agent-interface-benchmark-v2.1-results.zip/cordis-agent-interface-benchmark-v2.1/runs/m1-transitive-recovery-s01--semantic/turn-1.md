I have established all seven evidence obligations for incident `incident-harbor-01`:

1. **Last successful package**: `pkg-1`
2. **Failed target package**: `pkg-2`
3. **Active run**: `KNOWN_ABSENT` (no active run currently executing)
4. **Direct consumers**: `harbor-beacon-adapter`
5. **Transitive consumers**: `harbor-pulse-client`
6. **Tracked effects at risk**:
   - `ctx.provide("beaconEndpoint")`
   - `ctx.provide("pulseView")`
   - `tracked:direct:amber-stable`
   - `tracked:transitive:derived:amber-stable`
7. **Failed package inspection**: Inspected `pkg-2` source under `harboc-1`, identifying defect `THROW_BEFORE_PUBLISH` (`throw new Error("amber bootstrap failed before publication")` prior to `ctx.provide("beaconEndpoint", ...)`).

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "harbor-beacon-adapter"
    ],
    "transitive_consumers": [
      "harbor-pulse-client"
    ],
    "tracked_effects_at_risk": [
      "ctx.provide(\"beaconEndpoint\")",
      "ctx.provide(\"pulseView\")",
      "tracked:direct:amber-stable",
      "tracked:transitive:derived:amber-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "harboc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
