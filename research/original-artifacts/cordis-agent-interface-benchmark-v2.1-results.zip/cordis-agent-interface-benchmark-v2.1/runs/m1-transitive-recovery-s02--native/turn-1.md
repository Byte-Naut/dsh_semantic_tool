All seven evidence obligations have been verified against runtime state and immutable package source:

1. **Last successful immutable Package**: `pkg-1` (providing `ledgerEndpoint` version `cobalt-stable`).
2. **Failed target Package**: `pkg-2` (latest run failed during host bootstrap phase).
3. **Active Run status**: `KNOWN_ABSENT` (host status is `failed`, client status is `absent`, no active execution fiber exists).
4. **Direct consumer**: `orchard-ledger-adapter` (declared dependency on `ledgerEndpoint`).
5. **Transitive consumer**: `orchard-index-client` (declared dependency on `indexView`, provided by `orchard-ledger-adapter`).
6. **Tracked effects at risk**: `tracked:direct:cobalt-stable` on `orchard-ledger-adapter` and `tracked:transitive:derived:cobalt-stable` on `orchard-index-client`.
7. **Source diagnosis**: `pkg-2` unconditionally throws `Error("cobalt bootstrap failed before publication")` prior to calling `ctx.provide("ledgerEndpoint", intended)`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "orchard-ledger-adapter"
    ],
    "transitive_consumers": [
      "orchard-index-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:cobalt-stable",
      "tracked:transitive:derived:cobalt-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "orchac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
