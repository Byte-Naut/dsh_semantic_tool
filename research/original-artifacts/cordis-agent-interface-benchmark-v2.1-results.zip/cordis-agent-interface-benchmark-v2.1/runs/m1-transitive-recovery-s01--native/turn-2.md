The lifecycle recovery plan has been executed in the exact approved order and verified against the live runtime:

1. **RESTORE_LAST_SUCCESSFUL**: Ran `pkg-1` under plugin `harboc-1` with mode `run`, successfully restoring `beaconEndpoint` (`amber-stable`).
2. **DEFINE_REPAIRED_PACKAGE**: Defined package `pkg-3` under plugin `harboc-1` with the throw statement removed.
3. **UPDATE_TO_REPAIRED_PACKAGE**: Updated plugin `harboc-1` to `pkg-3` with mode `update`, successfully activating `amber-repaired`.
4. **Verification**:
   - `beaconEndpoint` is active with value `amber-repaired`.
   - Direct consumer `harbor-beacon-adapter` transitioned to `active`, publishing `pulseView` (`derived:amber-repaired`) with tracked effect `tracked:direct:amber-repaired`.
   - Transitive consumer `harbor-pulse-client` transitioned to `active` with tracked effect `tracked:transitive:derived:amber-repaired`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "harboc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "amber-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
