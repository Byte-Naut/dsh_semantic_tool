All seven evidence obligations have been investigated and verified against the authoritative runtime interface:

1. **Last successful immutable Package**: `pkg-1` (serving `beaconEndpoint`, version `amber-stable`).
2. **Failed target Package**: `pkg-2` (`harboc failed target`).
3. **Active Run status**: `KNOWN_ABSENT` (the latest run failed during host load, host is failed, client is absent, and no provider fiber is running).
4. **Direct consumer**: `harbor-beacon-adapter` (injected `beaconEndpoint`, currently in pending state).
5. **Transitive consumer**: `harbor-pulse-client` (injected derived service `pulseView`, currently in pending state).
6. **Tracked effects at risk**: `tracked:direct:amber-stable` on `harbor-beacon-adapter` and `tracked:transitive:derived:amber-stable` on `harbor-pulse-client`.
7. **Failed Package source diagnosis**: Inspected `pkg-2`, which throws an exception during bootstrap prior to service publication (`THROW_BEFORE_PUBLISH`).

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "harbor-beacon-adapter"
    ],
    "transitive_consumers": [
      "harbor-pulse-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:amber-stable",
      "tracked:transitive:derived:amber-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "harboc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
