export function publicTaskCard(seed, state) {
  return `Incident ${seed.incidentId}: session-owned dynamic Plugin \`${state.pluginId}\` stopped serving \`${seed.serviceKey}\` after an immutable Package update failed. This withdrew a direct consumer that publishes \`${seed.derivedServiceKey}\`, so a second consumer may be affected transitively.

Before mutation, establish all seven evidence obligations from the common instructions, including inspection of the failed Package source. Then stop and return the Turn-1 record. After approval, restore service first, define exactly one corrected immutable Package under the same Plugin, update to it, and verify both consumers. Preserve Plugin identity; never overwrite a Package or create another Plugin.`
}

export function workspaceFiles(seed) {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module' }, null, 2) + '\n',
    'INCIDENT.md': `# ${seed.incidentId}\n\nRuntime operations and observation tools are authoritative.\n`,
  }
}

export const editableFiles = Object.freeze([])
export const criticalErrors = Object.freeze([
  'E_CURRENT_IS_ACTIVE',
  'E_ACTIVE_RUN_UNKNOWN_COLLAPSED',
  'E_REPAIR_BEFORE_RESTORE',
  'E_WRONG_ROLLBACK_MODE',
  'E_NEW_PLUGIN',
  'E_OVERWRITE_PACKAGE',
  'E_DIRECT_IMPACT_OMITTED',
  'E_TRANSITIVE_IMPACT_OMITTED',
  'E_FAILED_SOURCE_UNINSPECTED',
])
