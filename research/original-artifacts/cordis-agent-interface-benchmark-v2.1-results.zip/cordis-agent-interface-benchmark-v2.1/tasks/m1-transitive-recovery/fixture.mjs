import { Context } from '@deepseek-ai/cordis'
import DynamicCordisRunnerService from '@deepseek-ai/dsh-cordis-host-runner'
import { captureCordisNative } from '../../src/native-snapshot.mjs'
import { CordisCollector, stateName } from '../../vendor/semantic-mirror-v0.3/collector.mjs'
import { DynamicPackageCollector } from '../../vendor/semantic-mirror-v0.3/dynamic-collector.mjs'
import { explainTransitiveRecoveryIncident, verifyTransitiveRecovery } from '../../vendor/semantic-mirror-v0.3/transitive-recovery-query.mjs'

export async function createTransitiveRecoveryRuntime(seed) {
  const root = new Context()
  const actionLog = []
  const observationLog = []
  const activity = { directDisposed: [], transitiveDisposed: [] }
  const collector = new CordisCollector(root, { runtimeId: `rt:${seed.seedId}` })
  await collector.attach()
  const disposeTools = root.provide('tools', Object.freeze({}))
  const runnerFiber = root.plugin(DynamicCordisRunnerService)
  await runnerFiber
  const runner = root.dynamicCordisRunner
  const agent = Object.freeze({ id: `session:${seed.seedId}`, steer() {}, inject() {} })

  const v1 = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'new', idPrefix: seed.pluginPrefix },
    name: `${seed.pluginPrefix} stable package`,
    purpose: 'serve the primary endpoint',
    code: { host: validHostCode(seed.serviceKey, seed.stableValue) },
  })
  const v1Receipt = await runner.run(agent, v1.pluginId, v1.packageId, 'run')
  if (!v1Receipt.ok) throw new Error(v1Receipt.message)

  const direct = root.plugin({
    name: seed.directConsumerName,
    inject: [seed.serviceKey],
    apply(ctx) {
      const value = ctx[seed.serviceKey].version
      ctx.effect(() => () => activity.directDisposed.push(value), `tracked:direct:${value}`)
      ctx.provide(seed.derivedServiceKey, Object.freeze({ version: `derived:${value}` }))
    },
  })
  await direct
  const transitive = root.plugin({
    name: seed.transitiveConsumerName,
    inject: [seed.derivedServiceKey],
    apply(ctx) {
      const value = ctx[seed.derivedServiceKey].version
      ctx.effect(() => () => activity.transitiveDisposed.push(value), `tracked:transitive:${value}`)
    },
  })
  await transitive

  const primaryImpl = root.reflect._getImpl(seed.serviceKey, false)
  if (!primaryImpl) throw new Error('primary service was not visible before the incident')
  const selectedServiceImplId = collector.serviceImplId(primaryImpl)
  const cordisBefore = collector.capture(seed.checkpointBefore)
  const nativeBefore = captureCordisNative({ label: seed.checkpointBefore, root, collector, fibers: [direct, transitive] })

  const v2 = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'existing', pluginId: v1.pluginId },
    name: `${seed.pluginPrefix} failed target`,
    purpose: 'publish repaired endpoint behavior',
    code: { host: brokenHostCode(seed) },
  })
  const failedReceipt = await runner.run(agent, v1.pluginId, v2.packageId, 'update')
  if (failedReceipt.ok || failedReceipt.reason !== 'host-half-failed') {
    throw new Error('fixture did not produce the required failed update')
  }
  await waitFor(() => stateName(direct.state) === 'pending' && stateName(transitive.state) === 'pending')

  const dynamicCollector = new DynamicPackageCollector(runner, { runtimeId: `rt:${seed.seedId}:dynamic` })
  const dynamicFailed = dynamicCollector.capture(seed.checkpointFailed)
  const cordisFailed = collector.capture(seed.checkpointFailed)
  const nativeFailed = captureCordisNative({ label: seed.checkpointFailed, root, collector, fibers: [direct, transitive] })
  const snapshots = new Map([
    [seed.checkpointBefore, nativeBefore], [cordisBefore.id, nativeBefore],
    [seed.checkpointFailed, nativeFailed], [cordisFailed.id, nativeFailed],
  ])
  const pluginId = String(v1.pluginId)
  const v1PackageId = String(v1.packageId)
  const v2PackageId = String(v2.packageId)

  return {
    seed,
    publicState: {
      pluginId,
      v1PackageId,
      v2PackageId,
      beforeCheckpointId: cordisBefore.id,
      failedCheckpointId: cordisFailed.id,
      failedDynamicSnapshotId: dynamicFailed.id,
    },
    checkpoints() {
      return [
        { alias: seed.checkpointBefore, snapshotId: cordisBefore.id, phase: 'stable-before-update' },
        { alias: seed.checkpointFailed, snapshotId: cordisFailed.id, dynamicSnapshotId: dynamicFailed.id, phase: 'failed-update' },
        { alias: 'current', phase: 'live-read' },
      ]
    },
    dynamicInventory() {
      observationLog.push({ kind: 'dynamic-inventory' })
      return clone(runner.inventory())
    },
    inspectPackage({ pluginId: requestedPlugin, packageId }) {
      observationLog.push({ kind: 'inspect-package', pluginId: requestedPlugin, packageId })
      return clone(runner.inspectPackage(agent, requestedPlugin, packageId))
    },
    nativeSnapshot(checkpointId) {
      if (!checkpointId || checkpointId === 'current') {
        return captureCordisNative({ label: 'current', root, collector, fibers: [direct, transitive] })
      }
      const snapshot = snapshots.get(checkpointId)
      if (!snapshot) throw new Error(`unknown checkpoint: ${checkpointId}`)
      return snapshot
    },
    semanticQuery(request) {
      if (request.subject?.pluginId !== pluginId) throw new Error(`unknown selected plugin: ${request.subject?.pluginId}`)
      observationLog.push({ kind: 'semantic-query', query: request.query })
      if (request.query === 'explain_transitive_recovery_incident') {
        return explainTransitiveRecoveryIncident({ pluginId, dynamicFailed, cordisBefore, selectedServiceImplId })
      }
      if (request.query === 'verify_transitive_recovery') {
        const dynamicCurrent = dynamicCollector.capture('current')
        const cordisCurrent = collector.capture('current')
        return verifyTransitiveRecovery({
          pluginId, dynamicCurrent, cordisCurrent, serviceKey: seed.serviceKey,
          directConsumerName: seed.directConsumerName,
          transitiveConsumerName: seed.transitiveConsumerName,
        })
      }
      throw new Error(`unsupported query: ${request.query}`)
    },
    async definePackage({ pluginId: requestedPlugin, name, purpose, hostCode }) {
      if (requestedPlugin !== pluginId) throw new Error('only the existing selected Plugin may receive a new Package')
      const definition = runner.define({
        sessionId: agent.id,
        plugin: { kind: 'existing', pluginId: requestedPlugin },
        name,
        purpose,
        code: { host: hostCode },
      })
      actionLog.push({ kind: 'define', actionId: 'DEFINE_REPAIRED_PACKAGE', pluginId, packageId: String(definition.packageId) })
      return clone(definition)
    },
    async runPackage({ pluginId: requestedPlugin, packageId, mode }) {
      const receipt = await runner.run(agent, requestedPlugin, packageId, mode)
      await settle()
      const actionId = mode === 'run' && packageId === v1PackageId
        ? 'RESTORE_LAST_SUCCESSFUL'
        : mode === 'update' ? 'UPDATE_TO_REPAIRED_PACKAGE' : 'UNRECOGNIZED'
      const entry = {
        kind: 'run', actionId, pluginId: requestedPlugin, packageId, mode,
        receipt: clone(receipt), observedServiceValue: visibleVersion(root, seed.serviceKey),
      }
      actionLog.push(entry)
      return { ...clone(receipt), observedServiceValue: entry.observedServiceValue }
    },
    evidenceTagsForTool(name, args) {
      if (name === 'software_semantic_query' && args.query === 'explain_transitive_recovery_incident') {
        return ['dynamic_state', 'direct_path', 'transitive_path', 'tracked_effects']
      }
      if (name === 'native_dynamic_inventory') return ['dynamic_state']
      if (name === 'native_inspect_package' && String(args.packageId) === v2PackageId) return ['failed_source']
      if (name === 'native_inspect_fiber') {
        if ([seed.directConsumerName, collector.fiberId(direct)].includes(args.fiberId)) return ['direct_path', 'tracked_effects']
        if ([seed.transitiveConsumerName, collector.fiberId(transitive)].includes(args.fiberId)) return ['transitive_path', 'tracked_effects']
      }
      return []
    },
    async grade() {
      const selected = clone(runner.inspectPlugin(agent, pluginId))
      const originalPackages = new Set([v1PackageId, v2PackageId])
      const newPackages = selected.packages.filter(pkg => !originalPackages.has(String(pkg.packageId)))
      const firstLifecycle = actionLog.find(action => action.kind === 'run' || action.kind === 'define')
      const restoredFirst = firstLifecycle?.actionId === 'RESTORE_LAST_SUCCESSFUL'
        && firstLifecycle.pluginId === pluginId
        && firstLifecycle.packageId === v1PackageId
        && firstLifecycle.mode === 'run'
        && firstLifecycle.receipt.ok === true
      const activePackageId = selected.activeRun?.packageId == null ? null : String(selected.activeRun.packageId)
      const packageStateCorrect = newPackages.length === 1
        && activePackageId === String(newPackages[0].packageId)
        && String(selected.currentPackageId) === activePackageId
        && selected.nextPackageId === undefined
      const inspectedFailedSource = observationLog.some(entry => entry.kind === 'inspect-package'
        && entry.pluginId === pluginId && entry.packageId === v2PackageId)
      const runtimeCorrect = visibleVersion(root, seed.serviceKey) === seed.repairedValue
        && stateName(direct.state) === 'active'
        && stateName(transitive.state) === 'active'
      const result = {
        actionLog: clone(actionLog), selected, inspectedFailedSource, restoredFirst, packageStateCorrect,
        runtimeCorrect, directState: stateName(direct.state), transitiveState: stateName(transitive.state),
        finalServiceValue: visibleVersion(root, seed.serviceKey), pluginCount: runner.listPlugins(agent).length,
        activity: clone(activity), newPackageIds: newPackages.map(pkg => String(pkg.packageId)),
      }
      return { ...result, pass: inspectedFailedSource && restoredFirst && packageStateCorrect && runtimeCorrect && result.pluginCount === 1 }
    },
    async dispose() {
      await Promise.allSettled([transitive.dispose(), direct.dispose()])
      await runnerFiber.dispose()
      await collector.detach()
      await disposeTools()
    },
  }
}

function validHostCode(serviceKey, value) {
  return `return { apply(ctx) { ctx.provide(${JSON.stringify(serviceKey)}, Object.freeze({ version: ${JSON.stringify(value)} })) } }`
}

function brokenHostCode(seed) {
  return `return { apply(ctx) {\n  const intended = Object.freeze({ version: ${JSON.stringify(seed.repairedValue)} })\n  throw new Error(${JSON.stringify(seed.failureMessage)})\n  ctx.provide(${JSON.stringify(seed.serviceKey)}, intended)\n} }`
}

function visibleVersion(root, serviceKey) {
  return root.reflect._getImpl(serviceKey, false)?.value?.version ?? null
}

async function waitFor(predicate, attempts = 500) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (predicate()) return
    await new Promise(resolve => setTimeout(resolve, 0))
  }
  throw new Error('timed out waiting for lifecycle state')
}

async function settle() {
  for (let index = 0; index < 5; index += 1) await new Promise(resolve => setTimeout(resolve, 0))
}

function clone(value) {
  if (value === undefined) return undefined
  return JSON.parse(JSON.stringify(value))
}
