import { ACTION_IDS } from '../src/config.mjs'
import { parseFinalRecord } from '../src/records.mjs'

const REQUIRED_EVIDENCE = Object.freeze([
  'dynamic_state', 'direct_path', 'transitive_path', 'tracked_effects', 'failed_source',
])

export function scoreRun({ seed, runtime, turnOneText = '', turnTwoText = '', grade, telemetryTotals, telemetryEvents }) {
  const turnOne = parseFinalRecord(turnOneText)
  const turnTwo = parseFinalRecord(turnTwoText)
  const factChecks = scoreFacts(seed, runtime, turnOne)
  const planChecks = scorePlan(runtime, turnOne)
  const actionChecks = scoreActions(runtime, grade, turnTwo)
  const semanticClosure = [...factChecks, ...planChecks].every(check => check.pass)
  const runtimePass = grade?.pass === true
  const criticalErrors = detectCriticalErrors(seed, runtime, turnOne, grade)
  const burden = reconstructionBurden({ telemetryTotals, telemetryEvents, turnOne, factChecks, planChecks })
  return {
    primaryPass: turnOne.ok && turnTwo.ok && semanticClosure && runtimePass && criticalErrors.length === 0,
    runtimePass,
    semanticClosure,
    terminalRecords: {
      turnOneParsed: turnOne.ok,
      turnOneError: turnOne.error,
      turnTwoParsed: turnTwo.ok,
      turnTwoError: turnTwo.error,
    },
    factChecks,
    planChecks,
    actionChecks,
    criticalErrors,
    burden,
  }
}

function scoreFacts(seed, runtime, parsed) {
  const facts = parsed.ok ? parsed.record.facts ?? {} : {}
  const labels = Array.isArray(facts.tracked_effects_at_risk) ? facts.tracked_effects_at_risk.map(String) : []
  return [
    check('last_successful_package', facts.last_successful_package_id === runtime.publicState.v1PackageId),
    check('failed_target_package', facts.failed_target_package_id === runtime.publicState.v2PackageId),
    check('active_run_typed_known_absent', facts.active_run?.kind === 'KNOWN_ABSENT' && facts.active_run?.package_id === null),
    check('direct_consumer', exactSet(facts.direct_consumers, [seed.directConsumerName])),
    check('transitive_consumer', exactSet(facts.transitive_consumers, [seed.transitiveConsumerName])),
    check('direct_tracked_effect', labels.some(label => label.includes('tracked:direct:'))),
    check('transitive_tracked_effect', labels.some(label => label.includes('tracked:transitive:'))),
    check('failed_source_inspected', parsed.ok && parsed.record.source_diagnosis?.failed_package_inspected === true),
    check('failed_source_defect', parsed.ok && parsed.record.source_diagnosis?.defect_code === 'THROW_BEFORE_PUBLISH'),
  ]
}

function scorePlan(runtime, parsed) {
  const plan = parsed.ok && Array.isArray(parsed.record.plan) ? parsed.record.plan : []
  return [
    check('enumerated_action_sequence', plan.length === 3 && plan.every((row, index) => row?.action_id === ACTION_IDS[index])),
    check('restore_target_and_mode', plan[0]?.target_id === runtime.publicState.v1PackageId && plan[0]?.mode === 'run'),
    check('define_under_existing_plugin', plan[1]?.target_id === runtime.publicState.pluginId && plan[1]?.mode === null),
    check('update_new_package_mode', plan[2]?.target_id === 'NEW_PACKAGE' && plan[2]?.mode === 'update'),
  ]
}

function scoreActions(runtime, grade, parsed) {
  const rows = parsed.ok && Array.isArray(parsed.record.actions) ? parsed.record.actions : []
  const actual = (grade?.actionLog ?? []).map(row => row.actionId)
  const newPackageId = grade?.newPackageIds?.length === 1 ? grade.newPackageIds[0] : null
  return [
    check('actual_enumerated_sequence', exactSequence(actual, ACTION_IDS)),
    check('recorded_enumerated_sequence', rows.length === 3 && rows.every((row, index) => row?.action_id === ACTION_IDS[index])),
    check('recorded_restore', rows[0]?.target_id === runtime.publicState.v1PackageId && rows[0]?.mode === 'run'),
    check('recorded_define', rows[1]?.target_id === runtime.publicState.pluginId && rows[1]?.mode === null),
    check('recorded_update', rows[2]?.target_id === newPackageId && rows[2]?.mode === 'update'),
    check('verification_active_package', parsed.ok && parsed.record.verification?.active_package_id === newPackageId),
    check('verification_service_value', parsed.ok && parsed.record.verification?.service_value === seedValue(runtime, 'repairedValue')),
    check('verification_direct_active', parsed.ok && parsed.record.verification?.direct_consumer_state === 'active'),
    check('verification_transitive_active', parsed.ok && parsed.record.verification?.transitive_consumer_state === 'active'),
  ]
}

function detectCriticalErrors(seed, runtime, parsed, grade) {
  const errors = []
  const record = parsed.ok ? parsed.record : {}
  const facts = record.facts ?? {}
  const plan = Array.isArray(record.plan) ? record.plan : []
  if (facts.active_run?.kind !== 'KNOWN_ABSENT' || facts.active_run?.package_id !== null) errors.push('E_ACTIVE_RUN_UNKNOWN_COLLAPSED')
  if (facts.last_successful_package_id === facts.active_run?.package_id && facts.active_run?.package_id != null) errors.push('E_CURRENT_IS_ACTIVE')
  if (!exactSet(facts.direct_consumers, [seed.directConsumerName])) errors.push('E_DIRECT_IMPACT_OMITTED')
  if (!exactSet(facts.transitive_consumers, [seed.transitiveConsumerName])) errors.push('E_TRANSITIVE_IMPACT_OMITTED')
  if (record.source_diagnosis?.failed_package_inspected !== true || grade?.inspectedFailedSource !== true) errors.push('E_FAILED_SOURCE_UNINSPECTED')
  if (plan[0]?.action_id !== 'RESTORE_LAST_SUCCESSFUL') errors.push('E_REPAIR_BEFORE_RESTORE')
  if (plan[0]?.mode !== 'run' || plan[0]?.target_id !== runtime.publicState.v1PackageId) errors.push('E_WRONG_ROLLBACK_MODE')
  if ((grade?.pluginCount ?? 1) !== 1) errors.push('E_NEW_PLUGIN')
  if ((grade?.newPackageIds?.length ?? 0) > 1) errors.push('E_OVERWRITE_PACKAGE')
  return [...new Set(errors)]
}

function reconstructionBurden({ telemetryTotals, telemetryEvents, turnOne, factChecks, planChecks }) {
  const observed = new Set()
  let callsSeen = 0
  let callsAtSufficiency = null
  let evidenceClosureSequence = null
  for (const event of telemetryEvents) {
    if (event.kind === 'tool_called') callsSeen += 1
    if (event.kind !== 'tool_returned' || event.status !== 'ok') continue
    for (const tag of event.evidenceTags ?? []) observed.add(tag)
    if (callsAtSufficiency === null && REQUIRED_EVIDENCE.every(tag => observed.has(tag))) {
      callsAtSufficiency = callsSeen
      evidenceClosureSequence = event.sequence
    }
  }
  const callsAfterEvidenceClosure = callsAtSufficiency === null ? null : telemetryTotals.toolCalls - callsAtSufficiency
  return {
    totalToolCalls: telemetryTotals.toolCalls,
    observationCalls: telemetryTotals.observationCalls,
    nativeObservationCalls: telemetryTotals.nativeObservationCalls,
    semanticObservationCalls: telemetryTotals.semanticObservationCalls,
    oracleObservationCalls: telemetryTotals.oracleObservationCalls,
    nativeStateDomainsTouched: telemetryTotals.nativeObservationDomainsTouched.length,
    nativeStateDomainNames: telemetryTotals.nativeObservationDomainsTouched,
    repeatedObservationCalls: telemetryTotals.repeatedObservationCalls,
    grossInputTokens: telemetryTotals.usage.input,
    grossOutputAndThinkingTokens: telemetryTotals.usage.output + telemetryTotals.usage.thoughts,
    toolResultBytes: telemetryTotals.toolResultBytes,
    callsToFirstSufficientEvidence: callsAtSufficiency,
    callsAfterEvidenceClosure,
    evidenceClosureSequence,
    sufficientEvidenceReached: callsAtSufficiency !== null,
    evidenceCoverage: REQUIRED_EVIDENCE.filter(tag => observed.has(tag)).length / REQUIRED_EVIDENCE.length,
    requiredEvidenceTags: REQUIRED_EVIDENCE,
    observedEvidenceTags: [...observed].sort(),
    incorrectStructuredClaims: [...factChecks, ...planChecks].filter(item => !item.pass).length,
    unsupportedJudgments: turnOne.ok ? unsupportedJudgments(turnOne.record, observed) : 0,
  }
}

function unsupportedJudgments(record, observed) {
  let count = 0
  const facts = record.facts ?? {}
  if ((facts.last_successful_package_id || facts.failed_target_package_id || facts.active_run) && !observed.has('dynamic_state')) count += 1
  if ((facts.direct_consumers?.length ?? 0) && !observed.has('direct_path')) count += 1
  if ((facts.transitive_consumers?.length ?? 0) && !observed.has('transitive_path')) count += 1
  if ((facts.tracked_effects_at_risk?.length ?? 0) && !observed.has('tracked_effects')) count += 1
  if (record.source_diagnosis?.defect_code && !observed.has('failed_source')) count += 1
  return count
}

function seedValue(runtime, key) {
  return runtime.seed?.[key] ?? null
}

function check(name, pass) {
  return { name, pass: Boolean(pass) }
}

function exactSet(actual, expected) {
  if (!Array.isArray(actual)) return false
  return actual.length === expected.length && [...actual].sort().every((value, index) => value === [...expected].sort()[index])
}

function exactSequence(actual, expected) {
  return actual.length === expected.length && actual.every((value, index) => value === expected[index])
}
