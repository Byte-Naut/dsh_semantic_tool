export async function applyReferenceSolution(seed, runtime) {
  runtime.inspectPackage({ pluginId: runtime.publicState.pluginId, packageId: runtime.publicState.v2PackageId })
  const restore = await runtime.runPackage({
    pluginId: runtime.publicState.pluginId,
    packageId: runtime.publicState.v1PackageId,
    mode: 'run',
  })
  if (!restore.ok) throw new Error('reference restore failed')
  const definition = await runtime.definePackage({
    pluginId: runtime.publicState.pluginId,
    name: `${seed.pluginPrefix} corrected package`,
    purpose: 'publish the intended repaired endpoint behavior',
    hostCode: validHostCode(seed.serviceKey, seed.repairedValue),
  })
  const update = await runtime.runPackage({
    pluginId: runtime.publicState.pluginId,
    packageId: String(definition.packageId),
    mode: 'update',
  })
  if (!update.ok) throw new Error('reference update failed')
  return { definition, restore, update, grade: await runtime.grade() }
}

function validHostCode(serviceKey, value) {
  return `return { apply(ctx) { ctx.provide(${JSON.stringify(serviceKey)}, Object.freeze({ version: ${JSON.stringify(value)} })) } }`
}
