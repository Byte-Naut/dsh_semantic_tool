# Four-slot interface-first calibration report

## Frozen question

Does a composed semantic interface reach critical evidence earlier, and does an interface-first boundary convert that access advantage into fewer calls and tokens at one intermediate task point?

This is a two-pair harness calibration, not a confirmatory treatment-effect estimate.

## Slot outcomes

| Seed | Arm | Validity | Primary | Runtime | Calls to evidence | Total calls | Raw native domains | Gross input tokens | Cost |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| m1-transitive-recovery-s01 | semantic | valid | yes | yes | 2 | 6 | 0 | 50489 | $0.063633 |
| m1-transitive-recovery-s01 | native | valid | yes | yes | 10 | 17 | 5 | 152933 | $0.148259 |
| m1-transitive-recovery-s02 | native | valid | yes | yes | 11 | 22 | 5 | 196247 | $0.176683 |
| m1-transitive-recovery-s02 | semantic | valid | yes | yes | 2 | 6 | 0 | 43507 | $0.053086 |

## Paired deltas

Evidence lead is Native minus Semantic, so positive is earlier Semantic closure. Other deltas are Semantic minus Native, so negative is lower Semantic burden.

| Seed | Evidence lead calls | Tool-call delta | Input-token delta | Post-closure call delta |
|---|---:|---:|---:|---:|
| m1-transitive-recovery-s01 | 8 | -11 | -102444 | -3 |
| m1-transitive-recovery-s02 | 9 | -16 | -152740 | -7 |

## Preregistered calibration gates

| Gate | Result |
|---|---|
| G1_completionObservable | PASS |
| G2_semanticClosureEarlier | PASS |
| G3_interfaceFirstNoRawNativeDomains | PASS |
| G4_earlierClosureTransmitsToCost | PASS |
| G5_aliasIndependentScorer | PASS |
| G6_harnessValidity | PASS |

Overall gate result: **PASS**.

## Aggregate readout

- Completed within budget: 4/4 (Native 2/2; Semantic 2/2).
- Primary pass: Native 2/2; Semantic 2/2.
- Hidden runtime pass: Native 2/2; Semantic 2/2.
- Comparable evidence-closure pairs: 2/2.
- Fully completed pairs: 2/2.
- Semantic raw native domains touched: 0 mean.
- Total paid-model cost: $0.441661.

## Interpretation

All harness-calibration gates passed. This licenses a larger preregistered replication, not a general efficacy claim.

The readout can diagnose E1 (access), E2 (trajectory conversion), and a narrow E3 typed-absence probe. It cannot establish E4 capability-boundary shift or general lifecycle coverage. Two paired seeds provide a local mechanism check only; no population treatment effect is estimated.
