# Cordis Agent-interface benchmark v2.1

This package runs a frozen four-slot calibration of an interface-first Native-versus-Semantic agent experiment.

The single intermediate task combines a failed immutable dynamic-Package update, direct service impact, transitive derived-service impact, and tracked-effect ownership. It intentionally omits external effects and concurrent LOADING replacement so it lies between the prior easy and medium tasks.

Each of two deterministic fixture seeds is run once in each arm:

- Native: raw runtime timeline/dynamic/service/Fiber observations plus a Package-source oracle.
- Semantic: one composed read-only semantic interface for covered runtime domains plus the same Package-source oracle.

Both arms use the same model, task card, runtime, workspace, budgets, action tools, and model seed within each pair. The task card contains no experiment rationale or expected direction. Lifecycle plans are scored with enumerated semantic action IDs, not tool-name wording.

This is a harness calibration with two pairs, not a confirmatory efficacy study.

## Reproduce

```sh
npm run generate
npm test
npm run freeze
npm run validate
npm run calibrate -- --key-stdin
npm run analyze
```

The API key is accepted from standard input and is never persisted.
