export function parseFinalRecord(value) {
  if (typeof value !== 'string') return failure('response is not text')
  const matches = [...value.matchAll(/^```json[\t ]*\r?\n([\s\S]*?)^```[\t ]*$/gm)]
  const terminal = matches.at(-1)
  if (!terminal) return failure('no json fence')
  const suffix = value.slice((terminal.index ?? 0) + terminal[0].length).trim()
  if (suffix) return failure('json fence is not terminal')
  try {
    const record = JSON.parse(terminal[1])
    if (!record || Array.isArray(record) || typeof record !== 'object') return failure('terminal JSON is not an object')
    return { ok: true, record, error: null }
  } catch (error) {
    return failure(error instanceof Error ? error.message : String(error))
  }
}

export function recordText(parsed) {
  return parsed?.ok ? JSON.stringify(parsed.record) : ''
}

function failure(error) {
  return { ok: false, record: null, error }
}
