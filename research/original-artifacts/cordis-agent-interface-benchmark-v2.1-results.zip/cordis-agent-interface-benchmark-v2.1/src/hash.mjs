import { createHash } from 'node:crypto'
import { readdir, readFile, stat } from 'node:fs/promises'
import { join, relative } from 'node:path'

export function sha256(value) {
  return createHash('sha256').update(value).digest('hex')
}

export function stableStringify(value) {
  return JSON.stringify(sortValue(value))
}

export function hashJson(value) {
  return sha256(stableStringify(value))
}

export async function hashFile(path) {
  return sha256(await readFile(path))
}

export async function hashTree(root, { exclude = () => false } = {}) {
  const files = []
  await walk(root, root, files, exclude)
  const entries = []
  for (const path of files.sort()) {
    entries.push([relative(root, path), await hashFile(path)])
  }
  return { hash: hashJson(entries), entries }
}

async function walk(root, directory, files, exclude) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    const name = relative(root, path)
    if (exclude(name, entry)) continue
    if (entry.isDirectory()) await walk(root, path, files, exclude)
    else if (entry.isFile() && (await stat(path)).size >= 0) files.push(path)
  }
}

function sortValue(value) {
  if (Array.isArray(value)) return value.map(sortValue)
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value)
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([key, item]) => [key, sortValue(item)]),
    )
  }
  return value
}
