import { hashJson } from './hash.mjs'

const OBJECT = 'object'

export function createToolRegistry({ arm, runtime, telemetry, turn }) {
  const tools = []
  const transcript = []
  const add = (name, description, parametersJsonSchema, category, domain, handler) => {
    tools.push({ declaration: { name, description, ...(parametersJsonSchema ? { parametersJsonSchema } : {}) }, category, domain, handler })
  }

  if (arm === 'native') {
    add('list_checkpoints', 'List immutable incident checkpoints plus the live current view.', null,
      'OBSERVE_NATIVE', 'timeline', () => runtime.checkpoints())
    add('native_dynamic_inventory', 'Read raw Plugin, immutable Package, latest-attempt, and active-Run fields.', null,
      'OBSERVE_NATIVE', 'dynamic_package', () => runtime.dynamicInventory())
    add('native_list_services', 'List raw visible service implementations at a checkpoint.', checkpointSchema(),
      'OBSERVE_NATIVE', 'services', ({ checkpointId }) => runtime.nativeSnapshot(checkpointId).services)
    add('native_list_fibers', 'List raw Fiber identities, states, parents, and declared injections without binding joins.', checkpointSchema(),
      'OBSERVE_NATIVE', 'fibers', ({ checkpointId }) => runtime.nativeSnapshot(checkpointId).fibers.map(({ targetBindings, committedBindings, effects, ...fiber }) => fiber))
    add('native_inspect_fiber', 'Read raw target bindings, committed bindings, and tracked effects for one Fiber.', objectSchema({
      fiberId: { type: 'string' }, checkpointId: { type: 'string' },
    }, ['fiberId']), 'OBSERVE_NATIVE', 'fiber_bindings_effects', ({ fiberId, checkpointId }) => {
      const fiber = runtime.nativeSnapshot(checkpointId).fibers.find(row => row.fiberId === fiberId || row.name === fiberId)
      if (!fiber) throw new Error(`unknown fiber: ${fiberId}`)
      return fiber
    })
  } else if (arm === 'semantic') {
    add('software_semantic_query', 'Run a read-only pre-specified semantic query. Complete covered domains must not be re-inspected natively; UNKNOWN identifies an oracle escape.', objectSchema({
      query: { type: 'string', enum: ['explain_transitive_recovery_incident', 'verify_transitive_recovery'] },
      subject: { type: OBJECT, additionalProperties: false, properties: { pluginId: { type: 'string' } }, required: ['pluginId'] },
    }, ['query', 'subject']), 'OBSERVE_SEMANTIC', 'semantic_query', request => runtime.semanticQuery(request))
  } else {
    throw new Error(`unknown arm: ${arm}`)
  }

  add('native_inspect_package', 'Authorized source oracle: read one exact immutable Package, including stored source. This is the only native observation available through the semantic interface.', objectSchema({
    pluginId: { type: 'string' }, packageId: { type: 'string' },
  }, ['pluginId', 'packageId']), 'OBSERVE_ORACLE', 'package_source', args => runtime.inspectPackage(args))

  if (turn === 2) {
    add('dynamic_define_package', 'Define one fresh immutable Package under the existing selected Plugin.', objectSchema({
      pluginId: { type: 'string' }, name: { type: 'string' }, purpose: { type: 'string' }, hostCode: { type: 'string' },
    }, ['pluginId', 'name', 'purpose', 'hostCode']), 'MUTATE_FIXTURE', 'dynamic_package', args => runtime.definePackage(args))
    add('dynamic_run_package', 'Run or update one exact immutable Package. Use run to restore the last successful version and update to switch to the repaired version.', objectSchema({
      pluginId: { type: 'string' }, packageId: { type: 'string' }, mode: { type: 'string', enum: ['run', 'update'] },
    }, ['pluginId', 'packageId', 'mode']), 'MUTATE_FIXTURE', 'dynamic_package', args => runtime.runPackage(args))
  }

  const byName = new Map(tools.map(tool => [tool.declaration.name, tool]))
  return {
    declarations: tools.map(tool => tool.declaration),
    metadata: tools.map(({ declaration, category, domain }) => ({ name: declaration.name, category, domain })),
    transcript,
    async call(name, args = {}) {
      const tool = byName.get(name)
      if (!tool) throw new Error(`tool is unavailable in this arm/turn: ${name}`)
      const argsHash = hashJson(args)
      telemetry.record('tool_called', {
        name, category: tool.category, domain: tool.domain,
        inputBytes: Buffer.byteLength(JSON.stringify(args)), argsHash, turn,
      })
      const started = performance.now()
      try {
        const output = await tool.handler(args)
        const evidenceTags = runtime.evidenceTagsForTool?.(name, args, output) ?? []
        transcript.push({ sequence: transcript.length + 1, turn, name, args, status: 'ok', output: jsonSafe(output), evidenceTags })
        telemetry.record('tool_returned', {
          name, category: tool.category, domain: tool.domain, argsHash, evidenceTags,
          outputBytes: Buffer.byteLength(JSON.stringify(output)), durationMs: Math.round(performance.now() - started),
          status: 'ok', turn,
        })
        return output
      } catch (error) {
        const output = { error: error instanceof Error ? error.message : String(error) }
        transcript.push({ sequence: transcript.length + 1, turn, name, args, status: 'error', output, evidenceTags: [] })
        telemetry.record('tool_returned', {
          name, category: tool.category, domain: tool.domain, argsHash, evidenceTags: [],
          outputBytes: Buffer.byteLength(JSON.stringify(output)), durationMs: Math.round(performance.now() - started),
          status: 'error', turn,
        })
        return output
      }
    },
  }
}

function checkpointSchema() {
  return objectSchema({ checkpointId: { type: 'string' } })
}

function objectSchema(properties, required = []) {
  return { type: OBJECT, additionalProperties: false, properties, ...(required.length ? { required } : {}) }
}

function jsonSafe(value) {
  return value === undefined ? null : JSON.parse(JSON.stringify(value))
}
