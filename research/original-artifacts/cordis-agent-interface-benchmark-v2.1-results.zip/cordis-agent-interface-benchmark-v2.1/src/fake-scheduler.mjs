export class FakeExternalScheduler {
  #nextId = 1
  #jobs = new Map()
  #events = []

  schedule(label, payload = null) {
    const id = `external-job:${this.#nextId++}`
    const job = { id, label, payload, active: true, cancelCount: 0 }
    this.#jobs.set(id, job)
    this.#events.push({ kind: 'scheduled', id, label })
    return Object.freeze({
      id,
      cancel: () => {
        if (!job.active) return false
        job.active = false
        job.cancelCount += 1
        this.#events.push({ kind: 'cancelled', id, label })
        return true
      },
    })
  }

  activeJobs() {
    return [...this.#jobs.values()].filter(job => job.active).map(clone)
  }

  cancel(id) {
    const job = this.#jobs.get(id)
    if (!job || !job.active) return false
    job.active = false
    job.cancelCount += 1
    this.#events.push({ kind: 'cancelled', id, label: job.label })
    return true
  }

  jobs() {
    return [...this.#jobs.values()].map(clone)
  }

  events() {
    return this.#events.map(clone)
  }
}

function clone(value) {
  return JSON.parse(JSON.stringify(value))
}
