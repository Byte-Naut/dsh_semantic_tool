import * as task from '../tasks/m1-transitive-recovery/spec.mjs'
import { createTransitiveRecoveryRuntime } from '../tasks/m1-transitive-recovery/fixture.mjs'
import { TASK_ID } from './config.mjs'

export async function createRuntime(taskId, seed) {
  requireTask(taskId)
  return createTransitiveRecoveryRuntime(seed)
}

export function taskCard(taskId, seed, runtime) {
  requireTask(taskId)
  return task.publicTaskCard(seed, runtime.publicState)
}

export function taskWorkspaceFiles(taskId, seed) {
  requireTask(taskId)
  return task.workspaceFiles(seed)
}

export function taskEditableFiles(taskId) {
  requireTask(taskId)
  return task.editableFiles
}

export function taskCriticalErrors(taskId) {
  requireTask(taskId)
  return task.criticalErrors
}

function requireTask(taskId) {
  if (taskId !== TASK_ID) throw new Error(`unknown task: ${taskId}`)
}
