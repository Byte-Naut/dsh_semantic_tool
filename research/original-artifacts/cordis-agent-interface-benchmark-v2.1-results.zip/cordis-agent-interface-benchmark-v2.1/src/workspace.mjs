import { execFile } from 'node:child_process'
import { mkdir, readFile, readdir, stat, writeFile } from 'node:fs/promises'
import { dirname, join, relative, resolve, sep } from 'node:path'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)

export async function materializeWorkspace(root, files) {
  await mkdir(root, { recursive: true })
  for (const [name, content] of Object.entries(files)) {
    const path = safePath(root, name)
    await mkdir(dirname(path), { recursive: true })
    await writeFile(path, content)
  }
}

export class WorkspaceAccess {
  constructor(root, { editableFiles, telemetry, turn }) {
    this.root = root
    this.editableFiles = new Set(editableFiles)
    this.telemetry = telemetry
    this.turn = turn
  }

  async listFiles() {
    const files = []
    await walk(this.root, this.root, files)
    return files.sort()
  }

  async readFile(name) {
    const path = safePath(this.root, name)
    const content = await readFile(path, 'utf8')
    this.telemetry.record('file_read', { path: name, bytes: Buffer.byteLength(content) })
    return { path: name, content }
  }

  async writeFile(name, content) {
    if (this.turn !== 2) throw new Error('artifact editing is not authorized before Turn 2')
    if (!this.editableFiles.has(name)) throw new Error(`file is outside the approved edit scope: ${name}`)
    const path = safePath(this.root, name)
    const before = await readFile(path, 'utf8')
    await writeFile(path, normalizeNewline(content))
    const after = await readFile(path, 'utf8')
    this.telemetry.record('file_changed', {
      path: name,
      beforeLines: lineCount(before),
      afterLines: lineCount(after),
    })
    return { path: name, bytes: Buffer.byteLength(after) }
  }

  async runVisibleTests() {
    const started = performance.now()
    try {
      const { stdout, stderr } = await execFileAsync(process.execPath, ['--test'], {
        cwd: this.root,
        timeout: 60_000,
        maxBuffer: 512_000,
        env: { PATH: process.env.PATH },
      })
      const durationMs = Math.round(performance.now() - started)
      this.telemetry.record('test_executed', { commandId: 'node--test', status: 'pass', durationMs })
      return { status: 'pass', stdout, stderr, durationMs }
    } catch (error) {
      const durationMs = Math.round(performance.now() - started)
      this.telemetry.record('test_executed', { commandId: 'node--test', status: 'fail', durationMs })
      return {
        status: 'fail',
        stdout: error.stdout ?? '',
        stderr: error.stderr ?? String(error.message),
        durationMs,
      }
    }
  }
}

export function safePath(root, name) {
  if (typeof name !== 'string' || !name || name.includes('\0')) throw new Error('invalid path')
  const absoluteRoot = resolve(root)
  const path = resolve(absoluteRoot, name)
  if (path !== absoluteRoot && !path.startsWith(absoluteRoot + sep)) {
    throw new Error(`path escapes Agent workspace: ${name}`)
  }
  return path
}

async function walk(root, directory, output) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isDirectory()) await walk(root, path, output)
    else if (entry.isFile() && (await stat(path)).size >= 0) output.push(relative(root, path))
  }
}

function normalizeNewline(value) {
  return String(value).replace(/\s*$/, '') + '\n'
}

function lineCount(value) {
  return value === '' ? 0 : value.replace(/\n$/, '').split('\n').length
}
