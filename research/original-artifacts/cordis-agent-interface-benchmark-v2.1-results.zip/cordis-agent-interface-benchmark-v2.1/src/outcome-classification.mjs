const AGENT_LIMIT_CODES = new Set([
  'AGENT_TOOL_BUDGET_EXHAUSTED',
  'AGENT_REQUEST_BUDGET_EXHAUSTED',
  'AGENT_INPUT_TOKEN_CAP_EXHAUSTED',
  'AGENT_OUTPUT_TOKEN_CAP_EXHAUSTED',
])

export function classifyRunError(error) {
  return AGENT_LIMIT_CODES.has(error?.code) ? 'agent-budget-exhausted' : 'invalid-infrastructure'
}

export function isAgentLimitCode(code) {
  return AGENT_LIMIT_CODES.has(code)
}
