export const EXPERIMENT = Object.freeze({
  id: 'cordis-agent-interface-gemini38-v21-four-slot',
  phase: 'four-slot interface-first calibration',
  estimands: Object.freeze({
    E1: 'semantic normalization reduces calls to critical-evidence closure',
    E2: 'interface-first access converts earlier closure into lower trajectory cost',
    E3Probe: 'typed active-run absence is preserved in diagnosis and recovery planning',
  }),
  model: 'gemini-3.8-flash',
  thinkingLevel: 'medium',
  temperature: 1,
  candidateCount: 1,
  maxOutputTokensPerRequest: 32_768,
  maxToolCallsPerTurn: 40,
  maxRequestsPerTurn: 44,
  maxGrossInputTokensPerRun: 2_000_000,
  maxGrossOutputTokensPerRun: 100_000,
  requestTimeoutMs: 180_000,
  runTimeoutMs: 1_200_000,
  httpAttempts: 1,
  modelSeedBase: 61_000,
  fallback: false,
  calibrationSeeds: Object.freeze([1, 2]),
  pricingUsdPerMillion: Object.freeze({ input: 0.75, outputIncludingThinking: 3.75 }),
})

export const TASK_ID = 'm1-transitive-recovery'
export const ARMS = Object.freeze(['native', 'semantic'])

export function modelSeed(fixtureNumber) {
  return EXPERIMENT.modelSeedBase + fixtureNumber
}

export const ACTION_IDS = Object.freeze([
  'RESTORE_LAST_SUCCESSFUL',
  'DEFINE_REPAIRED_PACKAGE',
  'UPDATE_TO_REPAIRED_PACKAGE',
])

export const TURN_TWO_APPROVAL = `Execute exactly the approved three-step lifecycle plan. Use the tool mapping already stated in the common instructions. Verify the repaired service and both consumers through the available observation interface. Finish with one terminal JSON fence:
{
  "status": "PASS|FAIL",
  "actions": [
    {"action_id":"RESTORE_LAST_SUCCESSFUL","target_id":"exact package id","mode":"run"},
    {"action_id":"DEFINE_REPAIRED_PACKAGE","target_id":"exact plugin id","mode":null},
    {"action_id":"UPDATE_TO_REPAIRED_PACKAGE","target_id":"new package id","mode":"update"}
  ],
  "verification": {
    "active_package_id":"string|null",
    "service_value":"string|null",
    "direct_consumer_state":"active|other|unknown",
    "transitive_consumer_state":"active|other|unknown"
  },
  "remaining_unknowns":[]
}`
