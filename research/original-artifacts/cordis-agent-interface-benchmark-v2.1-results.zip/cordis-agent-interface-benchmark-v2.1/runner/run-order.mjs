import { ARMS } from '../src/config.mjs'
import { calibrationSeeds } from './seed-catalog.mjs'

export function calibrationRunOrder() {
  return calibrationSeeds().flatMap(seed => {
    const first = seed.number % 2 === 1 ? 'semantic' : 'native'
    return [first, ARMS.find(arm => arm !== first)].map(arm => ({ taskId: seed.taskId, seed, arm }))
  })
}
