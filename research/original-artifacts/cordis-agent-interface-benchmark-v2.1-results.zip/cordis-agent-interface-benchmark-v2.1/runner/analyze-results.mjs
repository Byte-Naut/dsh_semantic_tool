import { mkdir, readFile, writeFile } from 'node:fs/promises'

const results = (await readFile('runs/results.jsonl', 'utf8'))
  .trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
const parity = JSON.parse(await readFile('artifacts/parity-validation.json', 'utf8'))
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
const arms = Object.fromEntries(['native', 'semantic'].map(arm => [arm, summarizeArm(results.filter(row => row.arm === arm))]))
const pairs = pairRows(results)
const closurePairs = pairs.filter(pair => burden(pair.native)?.sufficientEvidenceReached && burden(pair.semantic)?.sufficientEvidenceReached)
const completedPairs = pairs.filter(pair => pair.native?.validity === 'valid' && pair.semantic?.validity === 'valid')
const paired = pairs.map(pair => ({
  seedId: pair.seedId,
  nativeValidity: pair.native?.validity ?? null,
  semanticValidity: pair.semantic?.validity ?? null,
  evidenceClosureLeadCalls: bothNumbers(burden(pair.native)?.callsToFirstSufficientEvidence, burden(pair.semantic)?.callsToFirstSufficientEvidence)
    ? burden(pair.native).callsToFirstSufficientEvidence - burden(pair.semantic).callsToFirstSufficientEvidence : null,
  semanticMinusNativeToolCalls: bothNumbers(burden(pair.native)?.totalToolCalls, burden(pair.semantic)?.totalToolCalls)
    ? burden(pair.semantic).totalToolCalls - burden(pair.native).totalToolCalls : null,
  semanticMinusNativeInputTokens: bothNumbers(burden(pair.native)?.grossInputTokens, burden(pair.semantic)?.grossInputTokens)
    ? burden(pair.semantic).grossInputTokens - burden(pair.native).grossInputTokens : null,
  semanticMinusNativeCallsAfterClosure: bothNumbers(burden(pair.native)?.callsAfterEvidenceClosure, burden(pair.semantic)?.callsAfterEvidenceClosure)
    ? burden(pair.semantic).callsAfterEvidenceClosure - burden(pair.native).callsAfterEvidenceClosure : null,
  nativePrimaryPass: pair.native?.score?.primaryPass ?? false,
  semanticPrimaryPass: pair.semantic?.score?.primaryPass ?? false,
  nativeRuntimePass: pair.native?.score?.runtimePass ?? false,
  semanticRuntimePass: pair.semantic?.score?.runtimePass ?? false,
}))

const completed = results.filter(row => row.validity === 'valid')
const invalidInfrastructure = results.filter(row => row.validity === 'invalid-infrastructure')
const completedByArm = Object.fromEntries(['native', 'semantic'].map(arm => [arm, completed.filter(row => row.arm === arm).length]))
const completedPairRows = completedPairs.flatMap(pair => [pair.native, pair.semantic])
const completedNative = completedPairRows.filter(row => row.arm === 'native')
const completedSemantic = completedPairRows.filter(row => row.arm === 'semantic')
const semanticRows = results.filter(row => row.arm === 'semantic' && row.score)
const gates = {
  G1_completionObservable: completed.length >= 3 && completedByArm.native >= 1 && completedByArm.semantic >= 1,
  G2_semanticClosureEarlier: closurePairs.length >= 1 && closurePairs.every(pair => burden(pair.semantic).callsToFirstSufficientEvidence < burden(pair.native).callsToFirstSufficientEvidence),
  G3_interfaceFirstNoRawNativeDomains: semanticRows.length === 2 && semanticRows.every(row => burden(row).nativeStateDomainsTouched === 0),
  G4_earlierClosureTransmitsToCost: completedPairs.length >= 1
    && mean(completedSemantic.map(row => burden(row).totalToolCalls)) < mean(completedNative.map(row => burden(row).totalToolCalls))
    && mean(completedSemantic.map(row => burden(row).grossInputTokens)) < mean(completedNative.map(row => burden(row).grossInputTokens)),
  G5_aliasIndependentScorer: parity.aliasIndependencePass === true,
  G6_harnessValidity: invalidInfrastructure.length === 0 && parity.parserRegressionPass === true,
}
const allGatesPass = Object.values(gates).every(Boolean)
const analysis = {
  schemaVersion: 3,
  generatedAt: new Date().toISOString(),
  experimentId: preregistration.experiment.id,
  requestedModel: preregistration.experiment.model,
  slotCount: results.length,
  totalCostUsd: round(results.reduce((sum, row) => sum + (row.costUsd ?? 0), 0), 6),
  validity: countBy(results, row => row.validity),
  completedByArm,
  primaryPassByArm: Object.fromEntries(['native', 'semantic'].map(arm => [arm, results.filter(row => row.arm === arm && row.score?.primaryPass).length])),
  runtimePassByArm: Object.fromEntries(['native', 'semantic'].map(arm => [arm, results.filter(row => row.arm === arm && row.score?.runtimePass).length])),
  arms,
  comparableEvidenceClosurePairs: closurePairs.length,
  completedPairs: completedPairs.length,
  paired,
  pairedCompletedMeans: {
    native: meanBurden(completedNative),
    semantic: meanBurden(completedSemantic),
  },
  gates,
  allGatesPass,
  interpretation: allGatesPass
    ? 'All harness-calibration gates passed. This licenses a larger preregistered replication, not a general efficacy claim.'
    : 'At least one harness-calibration gate failed. Diagnose the failed mechanism or observability gate before scaling.',
  inferentialLimit: 'Two paired seeds provide a local mechanism check only; no population treatment effect is estimated.',
}

await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/calibration-analysis.json', JSON.stringify(analysis, null, 2) + '\n')
await writeFile('artifacts/calibration-report.md', renderReport(analysis, results))
console.log(`analysis complete: ${completed.length}/4 completed; all gates pass=${allGatesPass}; cost=$${analysis.totalCostUsd.toFixed(6)}`)

function summarizeArm(rows) {
  const scored = rows.filter(row => row.score)
  return {
    slots: rows.length,
    completed: rows.filter(row => row.validity === 'valid').length,
    primaryPass: rows.filter(row => row.score?.primaryPass).length,
    runtimePass: rows.filter(row => row.score?.runtimePass).length,
    evidenceClosureReached: scored.filter(row => burden(row).sufficientEvidenceReached).length,
    meanBurden: meanBurden(scored),
    costUsd: round(rows.reduce((sum, row) => sum + (row.costUsd ?? 0), 0), 6),
  }
}

function meanBurden(rows) {
  return {
    totalToolCalls: mean(rows.map(row => burden(row)?.totalToolCalls)),
    callsToEvidenceClosure: mean(rows.map(row => burden(row)?.callsToFirstSufficientEvidence)),
    callsAfterEvidenceClosure: mean(rows.map(row => burden(row)?.callsAfterEvidenceClosure)),
    nativeDomainsTouched: mean(rows.map(row => burden(row)?.nativeStateDomainsTouched)),
    grossInputTokens: mean(rows.map(row => burden(row)?.grossInputTokens)),
    grossOutputAndThinkingTokens: mean(rows.map(row => burden(row)?.grossOutputAndThinkingTokens)),
  }
}

function pairRows(rows) {
  const map = new Map()
  for (const row of rows) {
    const pair = map.get(row.seedId) ?? { seedId: row.seedId, native: null, semantic: null }
    pair[row.arm] = row
    map.set(row.seedId, pair)
  }
  return [...map.values()].sort((a, b) => a.seedId.localeCompare(b.seedId))
}

function burden(row) {
  return row?.score?.burden ?? null
}

function bothNumbers(...values) {
  return values.every(Number.isFinite)
}

function mean(values) {
  const numeric = values.filter(Number.isFinite)
  return numeric.length ? round(numeric.reduce((sum, value) => sum + value, 0) / numeric.length, 3) : null
}

function round(value, digits) {
  return Number(value.toFixed(digits))
}

function countBy(rows, key) {
  const output = {}
  for (const row of rows) output[key(row)] = (output[key(row)] ?? 0) + 1
  return output
}

function renderReport(analysis, rows) {
  const slotRows = rows.map(row => {
    const b = burden(row) ?? {}
    return `| ${row.seedId} | ${row.arm} | ${row.validity} | ${yes(row.score?.primaryPass)} | ${yes(row.score?.runtimePass)} | ${cell(b.callsToFirstSufficientEvidence)} | ${cell(b.totalToolCalls)} | ${cell(b.nativeStateDomainsTouched)} | ${cell(b.grossInputTokens)} | $${(row.costUsd ?? 0).toFixed(6)} |`
  }).join('\n')
  const pairRows = analysis.paired.map(pair => `| ${pair.seedId} | ${cell(pair.evidenceClosureLeadCalls)} | ${cell(pair.semanticMinusNativeToolCalls)} | ${cell(pair.semanticMinusNativeInputTokens)} | ${cell(pair.semanticMinusNativeCallsAfterClosure)} |`).join('\n')
  const gateRows = Object.entries(analysis.gates).map(([name, pass]) => `| ${name} | ${pass ? 'PASS' : 'FAIL'} |`).join('\n')
  return `# Four-slot interface-first calibration report

## Frozen question

Does a composed semantic interface reach critical evidence earlier, and does an interface-first boundary convert that access advantage into fewer calls and tokens at one intermediate task point?

This is a two-pair harness calibration, not a confirmatory treatment-effect estimate.

## Slot outcomes

| Seed | Arm | Validity | Primary | Runtime | Calls to evidence | Total calls | Raw native domains | Gross input tokens | Cost |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
${slotRows}

## Paired deltas

Evidence lead is Native minus Semantic, so positive is earlier Semantic closure. Other deltas are Semantic minus Native, so negative is lower Semantic burden.

| Seed | Evidence lead calls | Tool-call delta | Input-token delta | Post-closure call delta |
|---|---:|---:|---:|---:|
${pairRows}

## Preregistered calibration gates

| Gate | Result |
|---|---|
${gateRows}

Overall gate result: **${analysis.allGatesPass ? 'PASS' : 'FAIL'}**.

## Aggregate readout

- Completed within budget: ${analysis.validity.valid ?? 0}/4 (Native ${analysis.completedByArm.native}/2; Semantic ${analysis.completedByArm.semantic}/2).
- Primary pass: Native ${analysis.primaryPassByArm.native}/2; Semantic ${analysis.primaryPassByArm.semantic}/2.
- Hidden runtime pass: Native ${analysis.runtimePassByArm.native}/2; Semantic ${analysis.runtimePassByArm.semantic}/2.
- Comparable evidence-closure pairs: ${analysis.comparableEvidenceClosurePairs}/2.
- Fully completed pairs: ${analysis.completedPairs}/2.
- Semantic raw native domains touched: ${analysis.arms.semantic.meanBurden.nativeDomainsTouched ?? 'NA'} mean.
- Total paid-model cost: $${analysis.totalCostUsd.toFixed(6)}.

## Interpretation

${analysis.interpretation}

The readout can diagnose E1 (access), E2 (trajectory conversion), and a narrow E3 typed-absence probe. It cannot establish E4 capability-boundary shift or general lifecycle coverage. ${analysis.inferentialLimit}
`
}

function yes(value) {
  return value ? 'yes' : 'no'
}

function cell(value) {
  return value === null || value === undefined ? 'NA' : String(value)
}
