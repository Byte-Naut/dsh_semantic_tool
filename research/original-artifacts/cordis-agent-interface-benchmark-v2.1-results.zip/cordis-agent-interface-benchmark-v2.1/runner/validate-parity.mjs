import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { allSeeds } from './seed-catalog.mjs'
import { ARMS } from '../src/config.mjs'
import { createRuntime, taskCard, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { parseFinalRecord } from '../src/records.mjs'
import { applyReferenceSolution } from '../evaluator-private/reference-solutions.mjs'

const validationRoot = resolve('workspaces')
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
await mkdir(validationRoot, { recursive: true })
const cases = []

for (const seed of allSeeds()) {
  const workspaceHashes = new Map()
  const schemas = new Map()
  for (const arm of ARMS) {
    const caseId = `${seed.seedId}--${arm}`
    const workspace = join(validationRoot, caseId)
    const files = taskWorkspaceFiles(seed.taskId, seed)
    await materializeWorkspace(workspace, files)
    const tree = await hashTree(workspace)
    workspaceHashes.set(arm, tree.hash)
    const runtime = await createRuntime(seed.taskId, seed, workspace)
    try {
      const card = taskCard(seed.taskId, seed, runtime)
      const telemetry = new Telemetry(`validate:${caseId}`)
      const turnOne = createToolRegistry({ arm, runtime, telemetry, turn: 1 })
      const turnTwo = createToolRegistry({ arm, runtime, telemetry, turn: 2 })
      schemas.set(arm, { turnOne: turnOne.declarations, turnTwo: turnTwo.declarations })
      validateFirewall(seed, card, files, turnOne.declarations, turnTwo.declarations)
      validateArmBoundary(caseId, arm, turnOne.declarations, turnTwo.declarations)
      const witness = validateSemanticWitness(seed, runtime)
      const reference = await applyReferenceSolution(seed, runtime)
      assert(reference.grade.pass, `${caseId}: reference solution fails private runtime grade`)
      cases.push({
        caseId, seedId: seed.seedId, arm, workspaceHash: tree.hash, witness,
        referenceGradePass: true,
      })
      process.stdout.write(`validated ${caseId}\n`)
    } finally {
      await runtime.dispose()
    }
  }
  assert(workspaceHashes.get('native') === workspaceHashes.get('semantic'), `${seed.seedId}: Agent-readable workspaces differ`)
  validateSharedSchemas(seed.seedId, schemas.get('native'), schemas.get('semantic'))
}

const parserRegressionPass = validateParserRegression()
const aliasIndependencePass = await validateAliasIndependence()
const report = {
  schemaVersion: 3,
  generatedAt: new Date().toISOString(),
  passed: cases.length === allSeeds().length * ARMS.length && parserRegressionPass && aliasIndependencePass,
  caseCount: cases.length,
  sourceTreeHash: preregistration.sourceTree.hash,
  parserRegressionPass,
  aliasIndependencePass,
  assertions: [
    'Twenty-four offline arm-cases passed: twelve seeds times two interfaces.',
    'Agent-readable workspace trees are byte-identical within every pair.',
    'Semantic exposes no raw runtime observation except the explicitly shared Package-source oracle.',
    'Package-source oracle and mutation declarations are byte-identical across arms.',
    'The composed semantic query agrees with independently read native runtime state.',
    'Reference lifecycle actions pass the hidden executable grade in all arm-cases.',
    'Task cards, workspaces, and tool descriptions pass the information-firewall scan.',
    'Terminal-record parser accepts earlier fences and rejects trailing content.',
    'Action scoring is enumerated and contains no prior lexical alias machinery.',
  ],
  cases,
  digest: hashJson(cases),
}
await writeFile('artifacts/parity-validation.json', JSON.stringify(report, null, 2) + '\n')
console.log(`offline parity/reference closure passed for ${cases.length} arm-cases; digest ${report.digest}`)

function validateArmBoundary(caseId, arm, turnOne, turnTwo) {
  const oneNames = turnOne.map(item => item.name)
  const twoNames = turnTwo.map(item => item.name)
  if (arm === 'semantic') {
    assert(oneNames.includes('software_semantic_query'), `${caseId}: semantic query missing`)
    assert(!oneNames.some(name => name.startsWith('native_') && name !== 'native_inspect_package'), `${caseId}: raw native tool leaked`)
    assert(!oneNames.includes('list_checkpoints'), `${caseId}: raw timeline leaked`)
  } else {
    assert(!oneNames.includes('software_semantic_query'), `${caseId}: semantic query leaked into Native`)
    assert(oneNames.includes('native_dynamic_inventory') && oneNames.includes('native_inspect_fiber'), `${caseId}: Native observations incomplete`)
  }
  assert(!oneNames.includes('dynamic_define_package') && !oneNames.includes('dynamic_run_package'), `${caseId}: mutation leaked into Turn 1`)
  assert(twoNames.includes('dynamic_define_package') && twoNames.includes('dynamic_run_package'), `${caseId}: Turn-2 actions missing`)
}

function validateSharedSchemas(seedId, nativeSchemas, semanticSchemas) {
  for (const turn of ['turnOne', 'turnTwo']) {
    const sharedNames = turn === 'turnOne'
      ? ['native_inspect_package']
      : ['native_inspect_package', 'dynamic_define_package', 'dynamic_run_package']
    for (const name of sharedNames) {
      const native = nativeSchemas[turn].find(item => item.name === name)
      const semantic = semanticSchemas[turn].find(item => item.name === name)
      assert(native && semantic && hashJson(native) === hashJson(semantic), `${seedId} ${turn}: shared schema mismatch for ${name}`)
    }
  }
}

function validateSemanticWitness(seed, runtime) {
  const query = runtime.semanticQuery({
    query: 'explain_transitive_recovery_incident',
    subject: { pluginId: runtime.publicState.pluginId },
  })
  const inventory = runtime.dynamicInventory().find(row => String(row.pluginId) === runtime.publicState.pluginId)
  assert(String(inventory.currentPackageId) === runtime.publicState.v1PackageId, `${seed.seedId}: native last-successful mismatch`)
  assert(String(inventory.nextPackageId) === runtime.publicState.v2PackageId, `${seed.seedId}: native failed-target mismatch`)
  assert(inventory.activeRun === undefined, `${seed.seedId}: native active run should be absent`)
  assert(query.obligations.lastSuccessfulPackageId === runtime.publicState.v1PackageId, `${seed.seedId}: semantic last-successful mismatch`)
  assert(query.obligations.failedTargetPackageId === runtime.publicState.v2PackageId, `${seed.seedId}: semantic failed-target mismatch`)
  assert(query.obligations.activeRun.kind === 'KNOWN_ABSENT', `${seed.seedId}: semantic absence typing mismatch`)
  assert(exactSet(query.obligations.directConsumers, [seed.directConsumerName]), `${seed.seedId}: direct path mismatch`)
  assert(exactSet(query.obligations.transitiveConsumers, [seed.transitiveConsumerName]), `${seed.seedId}: transitive path mismatch`)
  const before = runtime.nativeSnapshot(runtime.publicState.beforeCheckpointId)
  const direct = before.fibers.find(row => row.name === seed.directConsumerName)
  const transitive = before.fibers.find(row => row.name === seed.transitiveConsumerName)
  assert(direct?.targetBindings?.[seed.serviceKey], `${seed.seedId}: native direct binding absent`)
  assert(transitive?.targetBindings?.[seed.derivedServiceKey], `${seed.seedId}: native transitive binding absent`)
  assert(query.coverage.packageSource === 'unavailable_use_authorized_oracle', `${seed.seedId}: source oracle boundary collapsed`)
  return {
    lastSuccessful: query.obligations.lastSuccessfulPackageId,
    failedTarget: query.obligations.failedTargetPackageId,
    activeRun: query.obligations.activeRun,
    direct: query.obligations.directConsumers,
    transitive: query.obligations.transitiveConsumers,
    effectCount: query.obligations.trackedEffectsAtRisk.length,
  }
}

function validateFirewall(seed, card, files, ...schemas) {
  const corpus = [card, ...Object.entries(files).flat(), ...schemas.flat().map(item => JSON.stringify(item))].join('\n').toLowerCase()
  const forbidden = [
    'expected superiority', 'prior a/b', 'reference solution', 'private oracle', 'hidden oracle',
    'other-arm', 'other arm trajectory', 'semantic mirror rationale', 'concurrent-horn',
    'joint canonicity', 'p_0', 'ctr makes', 'treatment effect',
  ]
  for (const fragment of forbidden) assert(!corpus.includes(fragment), `${seed.seedId}: firewall phrase leaked: ${fragment}`)
}

function validateParserRegression() {
  const accepted = parseFinalRecord('analysis\n```js\nconst x = 1\n```\n```json\n{"ok":true}\n```')
  const rejected = parseFinalRecord('```json\n{"ok":true}\n```\ntrailing')
  assert(accepted.ok && accepted.record.ok === true, 'parser rejected terminal JSON after an earlier fence')
  assert(!rejected.ok, 'parser accepted trailing content after terminal JSON')
  return true
}

async function validateAliasIndependence() {
  const scorer = await readFile('evaluator-private/score-run.mjs', 'utf8')
  const forbidden = ['run_old_version', 'normalizePlanAction', 'normalizeActualAction', 'planned_lifecycle_actions']
  for (const fragment of forbidden) assert(!scorer.includes(fragment), `alias scorer fragment remains: ${fragment}`)
  for (const actionId of ['RESTORE_LAST_SUCCESSFUL', 'DEFINE_REPAIRED_PACKAGE', 'UPDATE_TO_REPAIRED_PACKAGE']) {
    assert(scorer.includes(actionId) || scorer.includes('ACTION_IDS'), `enumerated action scorer missing ${actionId}`)
  }
  return true
}

function exactSet(actual, expected) {
  return Array.isArray(actual) && actual.length === expected.length
    && [...actual].sort().every((value, index) => value === [...expected].sort()[index])
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}
