import { EXPERIMENT, TASK_ID } from '../src/config.mjs'

const WORDS = Object.freeze([
  ['harbor', 'beacon', 'pulse', 'amber'],
  ['orchard', 'ledger', 'index', 'cobalt'],
  ['quarry', 'signal', 'view', 'crimson'],
  ['marina', 'quota', 'panel', 'delta'],
  ['foundry', 'metric', 'screen', 'ember'],
  ['granary', 'route', 'digest', 'frost'],
  ['terrace', 'catalog', 'summary', 'garnet'],
  ['aviary', 'notice', 'feed', 'hazel'],
  ['citadel', 'status', 'report', 'indigo'],
  ['meadow', 'sample', 'projection', 'jade'],
  ['tundra', 'record', 'display', 'kelp'],
  ['estuary', 'channel', 'snapshot', 'lilac'],
])

export function allSeeds() {
  return WORDS.map((_, index) => seedFor(index + 1))
}

export function calibrationSeeds() {
  return EXPERIMENT.calibrationSeeds.map(seedFor)
}

export function seedFor(number) {
  if (!Number.isInteger(number) || number < 1 || number > WORDS.length) {
    throw new Error(`seed number must be 1..${WORDS.length}: ${number}`)
  }
  const [place, service, derived, color] = WORDS[number - 1]
  return Object.freeze({
    taskId: TASK_ID,
    level: 'intermediate-1.5',
    number,
    seedId: `${TASK_ID}-s${String(number).padStart(2, '0')}`,
    incidentId: `incident-${place}-${String(number).padStart(2, '0')}`,
    pluginPrefix: `${place.slice(0, 5)}c`,
    serviceKey: `${service}Endpoint`,
    derivedServiceKey: `${derived}View`,
    stableValue: `${color}-stable`,
    repairedValue: `${color}-repaired`,
    directConsumerName: `${place}-${service}-adapter`,
    transitiveConsumerName: `${place}-${derived}-client`,
    failureMessage: `${color} bootstrap failed before publication`,
    checkpointBefore: `D0-${place}-stable`,
    checkpointFailed: `D2-${place}-failed-update`,
  })
}
