import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { ACTION_IDS, ARMS, EXPERIMENT, TASK_ID, TURN_TWO_APPROVAL } from '../src/config.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { commonSystemPrompt } from '../src/common-prompt.mjs'
import { calibrationSeeds } from './seed-catalog.mjs'
import { calibrationRunOrder } from './run-order.mjs'

const sourceTree = await hashTree('.', { exclude: excludedFromFreeze })
const packageLockHash = hashJson(JSON.parse(await readFile('package-lock.json', 'utf8')))
const preregistration = {
  schemaVersion: 3,
  frozenAt: new Date().toISOString(),
  experiment: EXPERIMENT,
  researchQuestion: 'Does an interface-first semantic treatment reproduce earlier evidence closure and convert it into trajectory efficiency at one intermediate semantic-complexity point?',
  estimands: EXPERIMENT.estimands,
  phase: 'four-slot paired harness calibration; mechanism and observability check, not confirmatory efficacy testing',
  task: {
    taskId: TASK_ID,
    level: 'intermediate-1.5',
    addedDimension: 'transitive dependency impact added to the prior direct failed-update recovery task',
    deliberatelyExcluded: ['external effect ownership', 'concurrent LOADING replacement', 'full UNKNOWN implementation repair'],
  },
  arms: ARMS,
  treatmentContrast: {
    native: 'raw timeline, dynamic inventory, service, Fiber, binding, and tracked-effect observations plus Package-source oracle',
    semantic: 'one composed semantic interface for covered runtime domains plus the same Package-source oracle escape',
    treatmentIsReplacementNotAddition: true,
  },
  actionIds: ACTION_IDS,
  calibrationSeeds: calibrationSeeds().map(seed => seed.seedId),
  runCount: calibrationSeeds().length * ARMS.length,
  runOrder: calibrationRunOrder().map(({ seed, arm }) => ({ seedId: seed.seedId, arm })),
  invariantControls: [
    'same requested model and one reported model version per run',
    'same thinking level, temperature, model seed within pair, tool budget, timeout, task card, workspace, and runtime semantics',
    'fresh conversation and fresh runtime for every run',
    'no fallback and one HTTP attempt per model request',
    'same Package-source oracle and lifecycle action schemas',
  ],
  informationFirewall: [
    'no theory paper or companion',
    'no experiment motivation, expected direction, prior A/B result, or interface label in the task card',
    'no hidden oracle, scorer, reference solution, grader, other-arm trajectory, or prior trajectory',
  ],
  outcomes: {
    E1: 'paired calls to first closure of five preregistered evidence tags',
    E2: 'native-domain access, total calls, gross input tokens, and calls after evidence closure',
    E3Probe: 'structured KNOWN_ABSENT active-run classification and enumerated semantic action sequence',
    correctness: 'structured semantic closure AND hidden executable runtime grade AND zero critical semantic errors',
  },
  calibrationGates: [
    'at least three of four slots finish within budget, with at least one finished slot in each arm',
    'Semantic reaches evidence closure earlier in every pair where both arms reach closure',
    'Semantic touches zero raw native state domains',
    'among pairs completed in both arms, Semantic mean total calls and gross input tokens are both lower',
    'enumerated action scorer passes alias-independence audit',
    'no infrastructure-invalid slots and parser regression suite passes',
  ],
  parserPolicy: 'select the last fenced JSON object and require it to be terminal; earlier prose and code fences are allowed',
  censoringPolicy: 'agent tool/request/token limits are agent-budget-exhausted outcomes with full partial trajectories, never infrastructure-invalid',
  stoppingRule: 'execute exactly four frozen slots once; do not replace, rerun, or tune after seeing outcomes',
  interpretationLimit: 'n=2 pairs calibrates the harness and local complexity point; it cannot estimate a general treatment effect',
  turnTwoApproval: TURN_TWO_APPROVAL,
  commonPromptHash: hashJson(commonSystemPrompt()),
  sourceTree,
  packageLockHash,
}
await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/preregistration.json', JSON.stringify(preregistration, null, 2) + '\n')
console.log(`frozen ${sourceTree.entries.length} files as ${sourceTree.hash}`)

function excludedFromFreeze(name, entry) {
  return name === 'node_modules' || name.startsWith('node_modules/')
    || name === 'artifacts' || name.startsWith('artifacts/')
    || name === 'runs' || name.startsWith('runs/')
    || name === 'workspaces' || name.startsWith('workspaces/')
    || (entry.isFile() && name === 'package-lock.json')
}
