import test from 'node:test'
import assert from 'node:assert/strict'
import { ACTION_IDS, TASK_ID } from '../src/config.mjs'
import { parseFinalRecord } from '../src/records.mjs'
import { classifyRunError } from '../src/outcome-classification.mjs'
import { createRuntime } from '../src/runtime-controller.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { scoreRun } from '../evaluator-private/score-run.mjs'
import { applyReferenceSolution } from '../evaluator-private/reference-solutions.mjs'
import { allSeeds, calibrationSeeds, seedFor } from '../runner/seed-catalog.mjs'
import { calibrationRunOrder } from '../runner/run-order.mjs'

test('seed catalog and four-slot order are deterministic and paired', () => {
  assert.equal(allSeeds().length, 12)
  assert.deepEqual(calibrationSeeds().map(seed => seed.number), [1, 2])
  const order = calibrationRunOrder()
  assert.equal(order.length, 4)
  assert.deepEqual(order.map(row => `${row.seed.number}:${row.arm}`), ['1:semantic', '1:native', '2:native', '2:semantic'])
  assert.deepEqual(seedFor(1), seedFor(1))
})

test('terminal parser permits earlier fences but rejects a suffix', () => {
  const parsed = parseFinalRecord('```js\nconst x = 1\n```\ntext\n```json\n{"status":"ok"}\n```')
  assert.equal(parsed.ok, true)
  assert.equal(parsed.record.status, 'ok')
  assert.equal(parseFinalRecord('```json\n{"status":"ok"}\n```\nextra').ok, false)
})

test('agent budget limits are censored outcomes, not infrastructure failures', () => {
  assert.equal(classifyRunError({ code: 'AGENT_TOOL_BUDGET_EXHAUSTED' }), 'agent-budget-exhausted')
  assert.equal(classifyRunError({ code: 'ECONNRESET' }), 'invalid-infrastructure')
})

test('interface-first boundary and semantic witness hold on a real fixture', async () => {
  const seed = seedFor(1)
  const runtime = await createRuntime(TASK_ID, seed)
  try {
    const telemetry = new Telemetry('test-boundary')
    const native = createToolRegistry({ arm: 'native', runtime, telemetry, turn: 1 })
    const semantic = createToolRegistry({ arm: 'semantic', runtime, telemetry, turn: 1 })
    const nativeNames = native.declarations.map(row => row.name)
    const semanticNames = semantic.declarations.map(row => row.name)
    assert(nativeNames.includes('native_dynamic_inventory'))
    assert(!nativeNames.includes('software_semantic_query'))
    assert.deepEqual(semanticNames, ['software_semantic_query', 'native_inspect_package'])

    const query = runtime.semanticQuery({
      query: 'explain_transitive_recovery_incident', subject: { pluginId: runtime.publicState.pluginId },
    })
    assert.equal(query.obligations.activeRun.kind, 'KNOWN_ABSENT')
    assert.deepEqual(query.obligations.directConsumers, [seed.directConsumerName])
    assert.deepEqual(query.obligations.transitiveConsumers, [seed.transitiveConsumerName])
    assert(query.obligations.trackedEffectsAtRisk.some(row => row.label.startsWith('tracked:direct:')))
    assert(query.obligations.trackedEffectsAtRisk.some(row => row.label.startsWith('tracked:transitive:')))
  } finally {
    await runtime.dispose()
  }
})

test('reference recovery and enumerated scorer close on the executable runtime', async () => {
  const seed = seedFor(2)
  const runtime = await createRuntime(TASK_ID, seed)
  try {
    const reference = await applyReferenceSolution(seed, runtime)
    assert.equal(reference.grade.pass, true)
    const newPackageId = String(reference.definition.packageId)
    const turnOne = fence({
      facts: {
        last_successful_package_id: runtime.publicState.v1PackageId,
        failed_target_package_id: runtime.publicState.v2PackageId,
        active_run: { kind: 'KNOWN_ABSENT', package_id: null },
        direct_consumers: [seed.directConsumerName],
        transitive_consumers: [seed.transitiveConsumerName],
        tracked_effects_at_risk: [`tracked:direct:${seed.stableValue}`, `tracked:transitive:derived:${seed.stableValue}`],
      },
      source_diagnosis: { failed_package_inspected: true, defect_code: 'THROW_BEFORE_PUBLISH' },
      plan: [
        { action_id: ACTION_IDS[0], target_id: runtime.publicState.v1PackageId, mode: 'run' },
        { action_id: ACTION_IDS[1], target_id: runtime.publicState.pluginId, mode: null },
        { action_id: ACTION_IDS[2], target_id: 'NEW_PACKAGE', mode: 'update' },
      ],
      unknowns: [],
    })
    const turnTwo = fence({
      status: 'PASS',
      actions: [
        { action_id: ACTION_IDS[0], target_id: runtime.publicState.v1PackageId, mode: 'run' },
        { action_id: ACTION_IDS[1], target_id: runtime.publicState.pluginId, mode: null },
        { action_id: ACTION_IDS[2], target_id: newPackageId, mode: 'update' },
      ],
      verification: {
        active_package_id: newPackageId,
        service_value: seed.repairedValue,
        direct_consumer_state: 'active',
        transitive_consumer_state: 'active',
      },
      remaining_unknowns: [],
    })
    const score = scoreRun({
      seed, runtime, turnOneText: turnOne, turnTwoText: turnTwo, grade: reference.grade,
      telemetryTotals: {
        toolCalls: 5, observationCalls: 5, nativeObservationCalls: 4, semanticObservationCalls: 0,
        oracleObservationCalls: 1, nativeObservationDomainsTouched: ['dynamic_package', 'fiber_bindings_effects'],
        repeatedObservationCalls: 0, toolResultBytes: 100,
        usage: { input: 1000, output: 100, thoughts: 100 },
      },
      telemetryEvents: evidenceEvents(),
    })
    assert.equal(score.primaryPass, true)
    assert.equal(score.actionChecks.find(row => row.name === 'actual_enumerated_sequence').pass, true)
  } finally {
    await runtime.dispose()
  }
})

function fence(value) {
  return `\`\`\`json\n${JSON.stringify(value)}\n\`\`\``
}

function evidenceEvents() {
  const tags = [['dynamic_state'], ['direct_path', 'tracked_effects'], ['transitive_path', 'tracked_effects'], ['failed_source']]
  return tags.flatMap((evidenceTags, index) => [
    { sequence: index * 2 + 1, kind: 'tool_called' },
    { sequence: index * 2 + 2, kind: 'tool_returned', status: 'ok', evidenceTags },
  ])
}
