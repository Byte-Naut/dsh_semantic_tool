import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { EXPERIMENT, TASK_ID, TURN_TWO_APPROVAL, modelSeed } from '../src/config.mjs'
import { createRuntime, taskCard, taskCriticalErrors, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { GeminiAgent } from '../src/gemini-agent.mjs'
import { Telemetry, appendJsonLine } from '../src/telemetry.mjs'
import { hashFile, hashJson, hashTree } from '../src/hash.mjs'
import { classifyRunError } from '../src/outcome-classification.mjs'
import { scoreRun } from '../evaluator-private/score-run.mjs'
import { REPLICATION } from './replication-config.mjs'
import { replicationRunOrder } from './replication-run-order.mjs'

const apiKey = await acquireKey()
const preregistration = JSON.parse(await readFile('artifacts/replication-preregistration.json', 'utf8'))
const parity = JSON.parse(await readFile('artifacts/replication-parity-validation.json', 'utf8'))
if (!parity.passed) throw new Error('replication offline validation did not pass')
await verifyFrozenInputs(preregistration)
if (parity.protocolManifestHash !== preregistration.protocolLock.manifestHash) throw new Error('validation did not use the frozen protocol')
verifyRunOrder(preregistration)

await mkdir('runs-replication', { recursive: false })
const preflight = new GeminiAgent({
  apiKey,
  taskId: TASK_ID,
  fixtureNumber: REPLICATION.seedNumbers[0],
  telemetry: new Telemetry('replication-preflight'),
})
const modelMetadata = await preflight.modelMetadata()
await writeFile('runs-replication/model-metadata.json', JSON.stringify({
  requestedModel: EXPERIMENT.model,
  retrievedAt: new Date().toISOString(),
  metadata: modelMetadata,
}, null, 2) + '\n')
process.stdout.write(`model preflight passed for ${EXPERIMENT.model}\n`)

const order = replicationRunOrder()
for (const [index, item] of order.entries()) {
  const runId = `${item.seed.seedId}--${item.arm}`
  process.stdout.write(`[${index + 1}/${order.length}] starting ${runId}\n`)
  const result = await runSingle({ ...item, runId, apiKey, modelMetadata })
  await appendJsonLine('runs-replication/results.jsonl', result)
  process.stdout.write(`[${index + 1}/${order.length}] ${runId}: ${result.validity} / primary=${result.score?.primaryPass ?? false} / runtime=${result.score?.runtimePass ?? false}\n`)
}
process.stdout.write('held-out 20-slot paired replication completed\n')

async function runSingle({ seed, taskId, arm, runId, apiKey: secret, modelMetadata: metadata }) {
  const runRoot = resolve('runs-replication', runId)
  const workspace = join(runRoot, 'workspace')
  await mkdir(runRoot, { recursive: false })
  const telemetry = new Telemetry(runId)
  const startedAt = new Date().toISOString()
  const started = performance.now()
  let runtime = null
  let agent = null
  let card = null
  let initialTree = null
  let finalTree = null
  let turnOne = null
  let turnTwo = null
  let turnOneRegistry = null
  let turnTwoRegistry = null
  let grade = null
  let caught = null

  try {
    await materializeWorkspace(workspace, taskWorkspaceFiles(taskId, seed))
    initialTree = await hashTree(workspace)
    runtime = await createRuntime(taskId, seed, workspace)
    card = taskCard(taskId, seed, runtime)
    agent = new GeminiAgent({ apiKey: secret, taskId, fixtureNumber: seed.number, telemetry })
    turnOneRegistry = createToolRegistry({ arm, runtime, telemetry, turn: 1 })
    turnTwoRegistry = createToolRegistry({ arm, runtime, telemetry, turn: 2 })
    turnOne = await agent.runTurn({ turn: 1, message: card, registry: turnOneRegistry })
    turnTwo = await agent.runTurn({ turn: 2, message: TURN_TWO_APPROVAL, registry: turnTwoRegistry })
  } catch (error) {
    caught = error
    telemetry.record('run_interrupted', {
      classification: classifyRunError(error),
      errorCode: error?.code ?? null,
      turn: error?.turn ?? null,
      error: sanitizeError(error, secret),
    })
  }

  try {
    if (runtime) grade = await runtime.grade()
  } catch (error) {
    caught ??= error
    telemetry.record('grade_failed', { error: sanitizeError(error, secret) })
  }
  if (initialTree) finalTree = await hashTree(workspace)

  const totals = telemetry.totals()
  const turnOneText = turnOne?.text ?? latestTurnText(agent, 1)
  const turnTwoText = turnTwo?.text ?? latestTurnText(agent, 2)
  const score = runtime ? scoreRun({
    seed, runtime, turnOneText, turnTwoText, grade,
    telemetryTotals: totals, telemetryEvents: telemetry.events(),
  }) : null
  const versions = [...new Set((agent?.responses ?? []).map(response => response.modelVersion).filter(Boolean))]
  const validity = caught
    ? classifyRunError(caught)
    : versions.length === 1 ? 'valid' : 'invalid-model-version'
  const result = {
    schemaVersion: 4,
    experimentId: REPLICATION.id,
    phase: REPLICATION.phase,
    runId, taskId, difficulty: seed.level, seedId: seed.seedId, fixtureNumber: seed.number, arm,
    requestedModel: EXPERIMENT.model,
    reportedModelVersions: versions,
    modelMetadataName: metadata.name ?? null,
    thinkingLevel: EXPERIMENT.thinkingLevel,
    temperature: EXPERIMENT.temperature,
    modelSeed: modelSeed(seed.number),
    validity,
    completedWithinBudget: validity === 'valid',
    startedAt,
    completedAt: new Date().toISOString(),
    durationMs: Math.round(performance.now() - started),
    initialWorkspaceHash: initialTree?.hash ?? null,
    finalWorkspaceHash: finalTree?.hash ?? null,
    filesChanged: initialTree && finalTree ? changedFiles(initialTree.entries, finalTree.entries) : [],
    taskCriticalErrorVocabulary: taskCriticalErrors(taskId),
    errorCode: caught?.code ?? null,
    error: caught ? sanitizeError(caught, secret) : null,
    score,
    costUsd: calculateCost(totals.usage),
  }
  await writeRunArtifacts({
    runRoot, seed, card, arm, turnOneText, turnTwoText, telemetry, result,
    exchanges: agent?.responses ?? [],
    registries: { turnOne: turnOneRegistry, turnTwo: turnTwoRegistry },
  })
  if (runtime) await runtime.dispose().catch(() => {})
  return result
}

async function writeRunArtifacts({ runRoot, seed, card, arm, turnOneText, turnTwoText, telemetry, result, exchanges, registries }) {
  await telemetry.write(join(runRoot, 'telemetry.jsonl'))
  await writeFile(join(runRoot, 'task.json'), JSON.stringify({ seed, arm, taskCard: card }, null, 2) + '\n')
  await writeFile(join(runRoot, 'tool-schema.json'), JSON.stringify({
    turnOne: registries.turnOne ? { declarations: registries.turnOne.declarations, metadata: registries.turnOne.metadata } : null,
    turnTwo: registries.turnTwo ? { declarations: registries.turnTwo.declarations, metadata: registries.turnTwo.metadata } : null,
  }, null, 2) + '\n')
  await writeFile(join(runRoot, 'tool-transcript.json'), JSON.stringify({
    turnOne: registries.turnOne?.transcript ?? [],
    turnTwo: registries.turnTwo?.transcript ?? [],
  }, null, 2) + '\n')
  await writeFile(join(runRoot, 'turn-1.md'), (turnOneText || '').trimEnd() + '\n')
  await writeFile(join(runRoot, 'turn-2.md'), (turnTwoText || '').trimEnd() + '\n')
  await writeFile(join(runRoot, 'model-exchanges.json'), JSON.stringify(exchanges, null, 2) + '\n')
  await writeFile(join(runRoot, 'result.json'), JSON.stringify(result, null, 2) + '\n')
}

function latestTurnText(agent, turn) {
  return (agent?.responses ?? []).filter(response => response.turn === turn && response.text).at(-1)?.text ?? ''
}

function changedFiles(beforeEntries, afterEntries) {
  const before = new Map(beforeEntries)
  const after = new Map(afterEntries)
  return [...new Set([...before.keys(), ...after.keys()])].filter(path => before.get(path) !== after.get(path)).sort()
}

function calculateCost(usage) {
  const input = usage.input * EXPERIMENT.pricingUsdPerMillion.input / 1_000_000
  const output = (usage.output + usage.thoughts) * EXPERIMENT.pricingUsdPerMillion.outputIncludingThinking / 1_000_000
  return Number((input + output).toFixed(6))
}

function verifyRunOrder(preregistration) {
  const actual = replicationRunOrder().map(({ seed, arm }) => ({ seedId: seed.seedId, arm }))
  if (hashJson(actual) !== hashJson(preregistration.runOrder)) throw new Error('run order differs from preregistration')
  if (preregistration.frozenProtocol.model !== EXPERIMENT.model || preregistration.frozenProtocol.fallback !== false) {
    throw new Error('model configuration differs from frozen protocol')
  }
}

async function verifyFrozenInputs(preregistration) {
  const sourceTree = await hashTree('.', { exclude: excludedFromFreeze })
  if (sourceTree.hash !== preregistration.replicationSourceTree.hash) throw new Error('replication source tree differs from freeze')
  for (const frozen of preregistration.protocolLock.files) {
    if (await hashFile(frozen.path) !== frozen.sha256) throw new Error(`protocol file differs from freeze: ${frozen.path}`)
  }
}

function excludedFromFreeze(name, entry) {
  return name === 'node_modules' || name.startsWith('node_modules/')
    || name === 'artifacts' || name.startsWith('artifacts/')
    || name === 'runs-replication' || name.startsWith('runs-replication/')
    || name === 'workspaces-replication' || name.startsWith('workspaces-replication/')
    || (entry.isFile() && name === 'package-lock.json')
}

async function acquireKey() {
  if (process.argv.includes('--key-stdin')) {
    let value = ''
    for await (const chunk of process.stdin) {
      value += chunk
      if (value.includes('\n')) break
    }
    const key = value.split(/\r?\n/, 1)[0].trim()
    if (!key) throw new Error('empty Gemini API key on stdin')
    return key
  }
  const key = process.env.GEMINI_API_KEY
  if (!key) throw new Error('GEMINI_API_KEY is unset; pass --key-stdin or set process environment')
  return key
}

function sanitizeError(error, secret) {
  const source = error instanceof Error ? `${error.name}: ${error.message}` : String(error)
  return source.split(secret).join('[REDACTED]')
}
