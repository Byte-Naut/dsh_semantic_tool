import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { ACTION_IDS, ARMS, EXPERIMENT, TASK_ID, TURN_TWO_APPROVAL } from '../src/config.mjs'
import { hashFile, hashJson, hashTree } from '../src/hash.mjs'
import { commonSystemPrompt } from '../src/common-prompt.mjs'
import { PROTOCOL_FILES, REPLICATION } from './replication-config.mjs'
import { replicationRunOrder, replicationSeeds } from './replication-run-order.mjs'

const calibrationRoot = resolve('../cordis-agent-interface-benchmark-v2.1')
const calibrationPrereg = JSON.parse(await readFile(`${calibrationRoot}/artifacts/preregistration.json`, 'utf8'))
const calibrationAnalysis = JSON.parse(await readFile(`${calibrationRoot}/artifacts/calibration-analysis.json`, 'utf8'))
const calibrationResultsText = await readFile(`${calibrationRoot}/runs/results.jsonl`, 'utf8')
const calibrationResults = calibrationResultsText.trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
assert(calibrationPrereg.sourceTree.hash === REPLICATION.expectedCalibrationSourceHash, 'unexpected calibration source hash')

const heldOutIds = new Set(replicationSeeds().map(seed => seed.seedId))
const priorHeldOutRuns = calibrationResults.filter(row => heldOutIds.has(row.seedId))
assert(priorHeldOutRuns.length === 0, 'a held-out replication seed was already executed')
assert(new Set(calibrationResults.map(row => row.seedId)).size === 2, 'calibration result set is not restricted to S01-S02')

const protocolFiles = []
for (const path of PROTOCOL_FILES) {
  const [calibrationSha256, replicationSha256] = await Promise.all([
    hashFile(`${calibrationRoot}/${path}`),
    hashFile(path),
  ])
  assert(calibrationSha256 === replicationSha256, `protocol drift before freeze: ${path}`)
  protocolFiles.push({ path, sha256: replicationSha256, calibrationSha256, identical: true })
}

const sourceTree = await hashTree('.', { exclude: excludedFromFreeze })
const preregistration = {
  schemaVersion: 4,
  frozenAt: new Date().toISOString(),
  experimentId: REPLICATION.id,
  phase: REPLICATION.phase,
  calibrationSourceTreeHash: calibrationPrereg.sourceTree.hash,
  replicationSourceTree: sourceTree,
  protocolLock: {
    files: protocolFiles,
    manifestHash: hashJson(protocolFiles),
    statement: 'task, task card, runtime fixture, interface schemas, common prompt, scorer, budget, model configuration, and seed generator are byte-identical to v2.1 calibration',
  },
  heldOutAudit: {
    calibrationRunCount: calibrationResults.length,
    calibrationSeedIds: [...new Set(calibrationResults.map(row => row.seedId))].sort(),
    heldOutSeedIds: [...heldOutIds],
    priorHeldOutRunCount: priorHeldOutRuns.length,
  },
  calibrationReference: {
    analysisHash: hashJson(calibrationAnalysis),
    pairCount: calibrationAnalysis.completedPairs,
    nativeMean: calibrationAnalysis.arms.native.meanBurden,
    semanticMean: calibrationAnalysis.arms.semantic.meanBurden,
  },
  costPlanning: {
    calibrationObservedCostUsd: calibrationAnalysis.totalCostUsd,
    calibrationObservedPairs: calibrationAnalysis.completedPairs,
    projectedReplicationCostUsdAtCalibrationMean: Number((calibrationAnalysis.totalCostUsd / calibrationAnalysis.completedPairs * REPLICATION.pairCount).toFixed(6)),
    policy: 'projection only; no cost-based early stopping or selective slot omission',
  },
  frozenProtocol: {
    taskId: TASK_ID,
    model: EXPERIMENT.model,
    thinkingLevel: EXPERIMENT.thinkingLevel,
    temperature: EXPERIMENT.temperature,
    maxToolCallsPerTurn: EXPERIMENT.maxToolCallsPerTurn,
    maxRequestsPerTurn: EXPERIMENT.maxRequestsPerTurn,
    maxGrossInputTokensPerRun: EXPERIMENT.maxGrossInputTokensPerRun,
    maxGrossOutputTokensPerRun: EXPERIMENT.maxGrossOutputTokensPerRun,
    requestTimeoutMs: EXPERIMENT.requestTimeoutMs,
    fallback: EXPERIMENT.fallback,
    arms: ARMS,
    actionIds: ACTION_IDS,
    commonPromptHash: hashJson(commonSystemPrompt()),
    turnTwoApprovalHash: hashJson(TURN_TWO_APPROVAL),
  },
  seeds: replicationSeeds().map(seed => ({ seedId: seed.seedId, number: seed.number, hash: hashJson(seed) })),
  excludedCalibrationSeedNumbers: REPLICATION.excludedCalibrationSeedNumbers,
  runCount: REPLICATION.slotCount,
  pairCount: REPLICATION.pairCount,
  runOrder: replicationRunOrder().map(({ seed, arm }) => ({ seedId: seed.seedId, arm })),
  invariantControls: [
    'same requested model, thinking level, temperature, pair seed, tool budget, request budget, timeout, task card, workspace, and runtime semantics as calibration',
    'same interface-first Native versus Semantic-plus-source-oracle boundary',
    'same terminal schemas, typed KNOWN_ABSENT obligation, enumerated action IDs, scorer, evidence tags, and hidden runtime grade',
    'fresh conversation, workspace, and runtime for every slot; no fallback and one HTTP attempt per request',
  ],
  endpoints: {
    correctnessRetention: 'Semantic primary-pass and hidden-runtime-pass counts must not be lower than Native; both Semantic counts must be at least 8/10',
    efficiencyFamily: [
      'Native minus Semantic calls to first sufficient evidence',
      'Native minus Semantic total tool calls',
      'Native minus Semantic gross input tokens',
    ],
    direction: 'positive means lower Semantic burden',
    test: 'one-sided exact paired sign test for each endpoint; zero differences are excluded',
    multiplicity: 'Holm adjustment across the three efficiency endpoints at family-wise alpha 0.05; all three adjusted tests must pass in the expected direction',
    magnitude: 'report pair deltas, arithmetic arm means, mean relative reduction, and median paired delta without imputing missing pairs',
  },
  analysisPopulation: {
    confirmatory: 'S03-S12 only',
    completePair: 'both slots validity=valid; evidence endpoint additionally requires both evidence closures',
    minimumCompletePairs: REPLICATION.minimumCompletePairs,
    minimumValidPerArm: REPLICATION.minimumValidPerArm,
    missingness: 'no imputation; censored and infrastructure-invalid slots remain in completion accounting and are excluded only from paired burden tests that require both values',
  },
  replicationSuccessRule: [
    'all protocol component hashes remain identical to calibration',
    'at least 8/10 complete pairs and at least 9/10 valid slots per arm',
    'correctness-retention gate passes',
    'all three Holm-adjusted paired efficiency tests pass in the expected direction',
    'every scored Semantic slot touches zero raw native domains',
    'no scorer-alias or parser regression defect',
  ],
  stoppingRule: 'execute the twenty frozen slots exactly once in the frozen order; no early stopping, slot replacement, rerun, or post-outcome protocol change',
  interpretationLimit: 'held-out procedural seeds replicate the mechanism within one task family and one model; they are not independent real-world incident families and do not establish E3 hard-UNKNOWN or E4 capability-boundary claims',
}
await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/replication-preregistration.json', JSON.stringify(preregistration, null, 2) + '\n')
console.log(`replication frozen: ${protocolFiles.length} protocol files unchanged; ${heldOutIds.size} held-out pairs; source ${sourceTree.hash}`)

function excludedFromFreeze(name, entry) {
  return name === 'node_modules' || name.startsWith('node_modules/')
    || name === 'artifacts' || name.startsWith('artifacts/')
    || name === 'runs-replication' || name.startsWith('runs-replication/')
    || name === 'workspaces-replication' || name.startsWith('workspaces-replication/')
    || (entry.isFile() && name === 'package-lock.json')
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}
