import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { ARMS } from '../src/config.mjs'
import { createRuntime, taskCard, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { hashFile, hashJson, hashTree } from '../src/hash.mjs'
import { parseFinalRecord } from '../src/records.mjs'
import { applyReferenceSolution } from '../evaluator-private/reference-solutions.mjs'
import { PROTOCOL_FILES, REPLICATION } from './replication-config.mjs'
import { replicationSeeds } from './replication-run-order.mjs'

const preregistration = JSON.parse(await readFile('artifacts/replication-preregistration.json', 'utf8'))
const validationRoot = resolve('workspaces-replication')
await mkdir(validationRoot, { recursive: true })
const protocolChecks = []
for (const frozen of preregistration.protocolLock.files) {
  const actual = await hashFile(frozen.path)
  assert(actual === frozen.sha256, `frozen protocol drift: ${frozen.path}`)
  protocolChecks.push({ path: frozen.path, sha256: actual, pass: true })
}
assert(PROTOCOL_FILES.length === protocolChecks.length, 'protocol file count drift')

const cases = []
for (const seed of replicationSeeds()) {
  const workspaceHashes = new Map()
  const schemas = new Map()
  let cardHash = null
  for (const arm of ARMS) {
    const caseId = `${seed.seedId}--${arm}`
    const workspace = join(validationRoot, caseId)
    const files = taskWorkspaceFiles(seed.taskId, seed)
    await materializeWorkspace(workspace, files)
    const tree = await hashTree(workspace)
    workspaceHashes.set(arm, tree.hash)
    const runtime = await createRuntime(seed.taskId, seed, workspace)
    try {
      const card = taskCard(seed.taskId, seed, runtime)
      const currentCardHash = hashJson(card)
      cardHash ??= currentCardHash
      assert(cardHash === currentCardHash, `${seed.seedId}: task card differs by arm`)
      validateFirewall(seed, card, files)
      const telemetry = new Telemetry(`replication-validate:${caseId}`)
      const turnOne = createToolRegistry({ arm, runtime, telemetry, turn: 1 })
      const turnTwo = createToolRegistry({ arm, runtime, telemetry, turn: 2 })
      schemas.set(arm, { turnOne: turnOne.declarations, turnTwo: turnTwo.declarations })
      validateArmBoundary(caseId, arm, turnOne.declarations, turnTwo.declarations)
      const witness = validateSemanticWitness(seed, runtime)
      const reference = await applyReferenceSolution(seed, runtime)
      assert(reference.grade.pass, `${caseId}: unchanged reference recovery failed`)
      cases.push({ caseId, seedId: seed.seedId, arm, workspaceHash: tree.hash, cardHash, witness, referenceGradePass: true })
      process.stdout.write(`validated ${caseId}\n`)
    } finally {
      await runtime.dispose()
    }
  }
  assert(workspaceHashes.get('native') === workspaceHashes.get('semantic'), `${seed.seedId}: workspace mismatch`)
  validateSharedSchemas(seed.seedId, schemas.get('native'), schemas.get('semantic'))
}

const parserRegressionPass = validateParserRegression()
const aliasIndependencePass = await validateAliasIndependence()
const report = {
  schemaVersion: 4,
  generatedAt: new Date().toISOString(),
  passed: cases.length === REPLICATION.slotCount && parserRegressionPass && aliasIndependencePass,
  caseCount: cases.length,
  pairCount: replicationSeeds().length,
  protocolManifestHash: preregistration.protocolLock.manifestHash,
  protocolChecks,
  parserRegressionPass,
  aliasIndependencePass,
  assertions: [
    'All frozen protocol files retain their calibration hashes.',
    'All twenty held-out offline arm-cases pass reference recovery and semantic/native witness agreement.',
    'Task cards and workspaces are arm-identical within each seed.',
    'Semantic exposes no raw runtime observation beyond the shared Package-source oracle.',
    'Shared oracle and lifecycle-action schemas are byte-identical across arms.',
    'Information firewall, terminal parser, and enumerated-action scorer audits pass.',
  ],
  cases,
  digest: hashJson(cases),
}
await writeFile('artifacts/replication-parity-validation.json', JSON.stringify(report, null, 2) + '\n')
console.log(`replication offline closure passed for ${cases.length} held-out arm-cases; digest ${report.digest}`)

function validateArmBoundary(caseId, arm, turnOne, turnTwo) {
  const one = turnOne.map(item => item.name)
  const two = turnTwo.map(item => item.name)
  if (arm === 'semantic') {
    assert(one.includes('software_semantic_query'), `${caseId}: semantic query missing`)
    assert(!one.some(name => name.startsWith('native_') && name !== 'native_inspect_package'), `${caseId}: raw native tool leaked`)
    assert(!one.includes('list_checkpoints'), `${caseId}: raw timeline leaked`)
  } else {
    assert(!one.includes('software_semantic_query'), `${caseId}: semantic query leaked into Native`)
    assert(one.includes('native_dynamic_inventory') && one.includes('native_inspect_fiber'), `${caseId}: Native interface incomplete`)
  }
  assert(!one.includes('dynamic_define_package') && !one.includes('dynamic_run_package'), `${caseId}: Turn-1 mutation leaked`)
  assert(two.includes('dynamic_define_package') && two.includes('dynamic_run_package'), `${caseId}: Turn-2 actions missing`)
}

function validateSharedSchemas(seedId, native, semantic) {
  for (const [turn, names] of [
    ['turnOne', ['native_inspect_package']],
    ['turnTwo', ['native_inspect_package', 'dynamic_define_package', 'dynamic_run_package']],
  ]) {
    for (const name of names) {
      const left = native[turn].find(item => item.name === name)
      const right = semantic[turn].find(item => item.name === name)
      assert(left && right && hashJson(left) === hashJson(right), `${seedId}: shared schema drift for ${name}`)
    }
  }
}

function validateSemanticWitness(seed, runtime) {
  const query = runtime.semanticQuery({ query: 'explain_transitive_recovery_incident', subject: { pluginId: runtime.publicState.pluginId } })
  const inventory = runtime.dynamicInventory().find(row => String(row.pluginId) === runtime.publicState.pluginId)
  assert(String(inventory.currentPackageId) === runtime.publicState.v1PackageId, `${seed.seedId}: native last-successful mismatch`)
  assert(String(inventory.nextPackageId) === runtime.publicState.v2PackageId, `${seed.seedId}: native failed-target mismatch`)
  assert(inventory.activeRun === undefined, `${seed.seedId}: native active run should be absent`)
  assert(query.obligations.lastSuccessfulPackageId === runtime.publicState.v1PackageId, `${seed.seedId}: semantic last-successful mismatch`)
  assert(query.obligations.failedTargetPackageId === runtime.publicState.v2PackageId, `${seed.seedId}: semantic failed-target mismatch`)
  assert(query.obligations.activeRun.kind === 'KNOWN_ABSENT', `${seed.seedId}: typed absence mismatch`)
  assert(exactSet(query.obligations.directConsumers, [seed.directConsumerName]), `${seed.seedId}: direct mismatch`)
  assert(exactSet(query.obligations.transitiveConsumers, [seed.transitiveConsumerName]), `${seed.seedId}: transitive mismatch`)
  return {
    lastSuccessful: query.obligations.lastSuccessfulPackageId,
    failedTarget: query.obligations.failedTargetPackageId,
    activeRun: query.obligations.activeRun,
    direct: query.obligations.directConsumers,
    transitive: query.obligations.transitiveConsumers,
    effectCount: query.obligations.trackedEffectsAtRisk.length,
  }
}

function validateFirewall(seed, card, files) {
  const corpus = [card, ...Object.entries(files).flat()].join('\n').toLowerCase()
  const forbidden = [
    'expected superiority', 'prior a/b', 'reference solution', 'private oracle', 'hidden oracle',
    'other-arm', 'other arm trajectory', 'semantic mirror rationale', 'concurrent-horn',
    'joint canonicity', 'p_0', 'ctr makes', 'treatment effect', 'replication',
  ]
  for (const fragment of forbidden) assert(!corpus.includes(fragment), `${seed.seedId}: firewall leak: ${fragment}`)
}

function validateParserRegression() {
  const accepted = parseFinalRecord('analysis\n```js\nconst x = 1\n```\n```json\n{"ok":true}\n```')
  const rejected = parseFinalRecord('```json\n{"ok":true}\n```\ntrailing')
  assert(accepted.ok && accepted.record.ok === true, 'parser rejected valid terminal JSON')
  assert(!rejected.ok, 'parser accepted trailing content')
  return true
}

async function validateAliasIndependence() {
  const scorer = await readFile('evaluator-private/score-run.mjs', 'utf8')
  for (const fragment of ['run_old_version', 'normalizePlanAction', 'normalizeActualAction', 'planned_lifecycle_actions']) {
    assert(!scorer.includes(fragment), `alias scorer fragment remains: ${fragment}`)
  }
  return true
}

function exactSet(actual, expected) {
  return Array.isArray(actual) && actual.length === expected.length
    && [...actual].sort().every((value, index) => value === [...expected].sort()[index])
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}
