import { ARMS } from '../src/config.mjs'
import { seedFor } from './seed-catalog.mjs'
import { REPLICATION } from './replication-config.mjs'

export function replicationSeeds() {
  return REPLICATION.seedNumbers.map(seedFor)
}

export function replicationRunOrder() {
  return replicationSeeds().flatMap(seed => {
    const first = seed.number % 2 === 1 ? 'semantic' : 'native'
    return [first, ARMS.find(arm => arm !== first)].map(arm => ({ taskId: seed.taskId, seed, arm }))
  })
}
