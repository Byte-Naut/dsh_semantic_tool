import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { REPLICATION } from './replication-config.mjs'

const results = (await readFile('runs-replication/results.jsonl', 'utf8'))
  .trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
const preregistration = JSON.parse(await readFile('artifacts/replication-preregistration.json', 'utf8'))
const parity = JSON.parse(await readFile('artifacts/replication-parity-validation.json', 'utf8'))
const pairs = pairRows(results)
const completePairs = pairs.filter(pair => pair.native?.validity === 'valid' && pair.semantic?.validity === 'valid')

const endpoints = [
  endpoint('evidence_closure_calls', pairs, row => burden(row)?.callsToFirstSufficientEvidence, true),
  endpoint('total_tool_calls', pairs, row => burden(row)?.totalToolCalls),
  endpoint('gross_input_tokens', pairs, row => burden(row)?.grossInputTokens),
]
applyHolm(endpoints, REPLICATION.alpha)

const byArm = Object.fromEntries(['native', 'semantic'].map(arm => {
  const rows = results.filter(row => row.arm === arm)
  return [arm, summarizeArm(rows)]
}))
const correctness = {
  nativePrimaryPass: results.filter(row => row.arm === 'native' && row.score?.primaryPass).length,
  semanticPrimaryPass: results.filter(row => row.arm === 'semantic' && row.score?.primaryPass).length,
  nativeRuntimePass: results.filter(row => row.arm === 'native' && row.score?.runtimePass).length,
  semanticRuntimePass: results.filter(row => row.arm === 'semantic' && row.score?.runtimePass).length,
  nativeOnlyPrimaryPass: completePairs.filter(pair => pair.native.score?.primaryPass && !pair.semantic.score?.primaryPass).length,
  semanticOnlyPrimaryPass: completePairs.filter(pair => !pair.native.score?.primaryPass && pair.semantic.score?.primaryPass).length,
}
const validByArm = Object.fromEntries(['native', 'semantic'].map(arm => [arm, results.filter(row => row.arm === arm && row.validity === 'valid').length]))
const infrastructureInvalid = results.filter(row => row.validity === 'invalid-infrastructure').length
const gates = {
  protocolByteIdentity: parity.passed === true && parity.protocolChecks.every(row => row.pass),
  analyzablePopulation: completePairs.length >= REPLICATION.minimumCompletePairs
    && validByArm.native >= REPLICATION.minimumValidPerArm
    && validByArm.semantic >= REPLICATION.minimumValidPerArm,
  correctnessRetention: correctness.semanticPrimaryPass >= correctness.nativePrimaryPass
    && correctness.semanticRuntimePass >= correctness.nativeRuntimePass
    && correctness.semanticPrimaryPass >= 8
    && correctness.semanticRuntimePass >= 8,
  efficiencyFamilyHolm: endpoints.every(item => item.adjustedPValue <= REPLICATION.alpha && item.medianNativeMinusSemantic > 0),
  semanticInterfaceFirstFidelity: results.filter(row => row.arm === 'semantic' && row.score).length === REPLICATION.pairCount
    && results.filter(row => row.arm === 'semantic' && row.score).every(row => burden(row).nativeStateDomainsTouched === 0),
  scorerAndParserIntegrity: parity.aliasIndependencePass === true && parity.parserRegressionPass === true,
  noInfrastructureInvalid: infrastructureInvalid === 0,
}
const replicationSuccess = Object.values(gates).every(Boolean)
const paired = pairs.map(pair => ({
  seedId: pair.seedId,
  nativeValidity: pair.native?.validity ?? null,
  semanticValidity: pair.semantic?.validity ?? null,
  nativePrimaryPass: pair.native?.score?.primaryPass ?? false,
  semanticPrimaryPass: pair.semantic?.score?.primaryPass ?? false,
  nativeRuntimePass: pair.native?.score?.runtimePass ?? false,
  semanticRuntimePass: pair.semantic?.score?.runtimePass ?? false,
  nativeMinusSemanticEvidenceCalls: difference(pair, row => burden(row)?.callsToFirstSufficientEvidence),
  nativeMinusSemanticTotalCalls: difference(pair, row => burden(row)?.totalToolCalls),
  nativeMinusSemanticGrossInputTokens: difference(pair, row => burden(row)?.grossInputTokens),
  nativeMinusSemanticPostClosureCalls: difference(pair, row => burden(row)?.callsAfterEvidenceClosure),
}))

const analysis = {
  schemaVersion: 4,
  generatedAt: new Date().toISOString(),
  experimentId: REPLICATION.id,
  requestedModel: preregistration.frozenProtocol.model,
  heldOutSeeds: preregistration.seeds.map(seed => seed.seedId),
  slotCount: results.length,
  pairCount: pairs.length,
  completePairs: completePairs.length,
  totalCostUsd: round(results.reduce((sum, row) => sum + (row.costUsd ?? 0), 0), 6),
  validity: countBy(results, row => row.validity),
  validByArm,
  correctness,
  byArm,
  endpoints,
  paired,
  gates,
  replicationSuccess,
  calibrationComparison: calibrationComparison(preregistration.calibrationReference, byArm),
  interpretation: replicationSuccess
    ? 'The held-out replication met every preregistered gate: correctness was retained and all three paired efficiency endpoints replicated under Holm control.'
    : 'At least one preregistered replication gate failed; inspect the failed gate before claiming mechanism replication.',
  inferentialLimit: preregistration.interpretationLimit,
}

await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/replication-analysis.json', JSON.stringify(analysis, null, 2) + '\n')
await writeFile('artifacts/replication-report.md', renderReport(analysis, results))
console.log(`replication analysis: complete pairs=${completePairs.length}/10; success=${replicationSuccess}; cost=$${analysis.totalCostUsd.toFixed(6)}`)

function endpoint(name, allPairs, getter, requiresEvidence = false) {
  const values = []
  for (const pair of allPairs) {
    if (pair.native?.validity !== 'valid' || pair.semantic?.validity !== 'valid') continue
    const native = getter(pair.native)
    const semantic = getter(pair.semantic)
    if (!Number.isFinite(native) || !Number.isFinite(semantic)) continue
    if (requiresEvidence && (!burden(pair.native)?.sufficientEvidenceReached || !burden(pair.semantic)?.sufficientEvidenceReached)) continue
    values.push({ seedId: pair.seedId, native, semantic, nativeMinusSemantic: native - semantic })
  }
  const positive = values.filter(row => row.nativeMinusSemantic > 0).length
  const negative = values.filter(row => row.nativeMinusSemantic < 0).length
  const ties = values.length - positive - negative
  const rawPValue = exactOneSidedSignP(positive, negative)
  const nativeMean = mean(values.map(row => row.native))
  const semanticMean = mean(values.map(row => row.semantic))
  return {
    name,
    analyzablePairs: values.length,
    positiveDirectionPairs: positive,
    ties,
    negativeDirectionPairs: negative,
    rawPValue,
    adjustedPValue: null,
    holmReject: false,
    nativeMean,
    semanticMean,
    meanRelativeReduction: nativeMean === 0 ? null : round((nativeMean - semanticMean) / nativeMean, 6),
    medianNativeMinusSemantic: median(values.map(row => row.nativeMinusSemantic)),
    meanNativeMinusSemantic: mean(values.map(row => row.nativeMinusSemantic)),
    values,
  }
}

function applyHolm(items, alpha) {
  const ordered = [...items].sort((left, right) => left.rawPValue - right.rawPValue)
  let priorAdjusted = 0
  let priorRejected = true
  for (let index = 0; index < ordered.length; index += 1) {
    const adjusted = Math.min(1, Math.max(priorAdjusted, ordered[index].rawPValue * (ordered.length - index)))
    ordered[index].adjustedPValue = adjusted
    ordered[index].holmReject = priorRejected && ordered[index].rawPValue <= alpha / (ordered.length - index)
    priorRejected = ordered[index].holmReject
    priorAdjusted = adjusted
  }
}

function exactOneSidedSignP(positive, negative) {
  const n = positive + negative
  if (!n) return 1
  let numerator = 0
  for (let successes = positive; successes <= n; successes += 1) numerator += choose(n, successes)
  return numerator / (2 ** n)
}

function choose(n, k) {
  const m = Math.min(k, n - k)
  let value = 1
  for (let index = 1; index <= m; index += 1) value = value * (n - m + index) / index
  return value
}

function summarizeArm(rows) {
  const scored = rows.filter(row => row.score)
  return {
    slots: rows.length,
    valid: rows.filter(row => row.validity === 'valid').length,
    primaryPass: rows.filter(row => row.score?.primaryPass).length,
    runtimePass: rows.filter(row => row.score?.runtimePass).length,
    evidenceClosureReached: scored.filter(row => burden(row).sufficientEvidenceReached).length,
    meanBurden: {
      totalToolCalls: mean(scored.map(row => burden(row)?.totalToolCalls)),
      callsToEvidenceClosure: mean(scored.map(row => burden(row)?.callsToFirstSufficientEvidence)),
      callsAfterEvidenceClosure: mean(scored.map(row => burden(row)?.callsAfterEvidenceClosure)),
      observationCalls: mean(scored.map(row => burden(row)?.observationCalls)),
      nativeDomainsTouched: mean(scored.map(row => burden(row)?.nativeStateDomainsTouched)),
      repeatedObservationCalls: mean(scored.map(row => burden(row)?.repeatedObservationCalls)),
      grossInputTokens: mean(scored.map(row => burden(row)?.grossInputTokens)),
      grossOutputAndThinkingTokens: mean(scored.map(row => burden(row)?.grossOutputAndThinkingTokens)),
      toolResultBytes: mean(scored.map(row => burden(row)?.toolResultBytes)),
    },
    costUsd: round(rows.reduce((sum, row) => sum + (row.costUsd ?? 0), 0), 6),
  }
}

function calibrationComparison(reference, replication) {
  return {
    calibrationPairs: reference.pairCount,
    calibration: { native: reference.nativeMean, semantic: reference.semanticMean },
    heldOutReplication: { native: replication.native.meanBurden, semantic: replication.semantic.meanBurden },
    note: 'Calibration seeds are excluded from confirmatory tests; this table is a descriptive stability comparison only.',
  }
}

function pairRows(rows) {
  const map = new Map()
  for (const row of rows) {
    const pair = map.get(row.seedId) ?? { seedId: row.seedId, native: null, semantic: null }
    pair[row.arm] = row
    map.set(row.seedId, pair)
  }
  return [...map.values()].sort((left, right) => left.seedId.localeCompare(right.seedId))
}

function difference(pair, getter) {
  const native = getter(pair.native)
  const semantic = getter(pair.semantic)
  return Number.isFinite(native) && Number.isFinite(semantic) ? native - semantic : null
}

function burden(row) {
  return row?.score?.burden ?? null
}

function mean(values) {
  const numeric = values.filter(Number.isFinite)
  return numeric.length ? round(numeric.reduce((sum, value) => sum + value, 0) / numeric.length, 3) : null
}

function median(values) {
  const numeric = values.filter(Number.isFinite).sort((a, b) => a - b)
  if (!numeric.length) return null
  const middle = Math.floor(numeric.length / 2)
  return numeric.length % 2 ? numeric[middle] : round((numeric[middle - 1] + numeric[middle]) / 2, 3)
}

function countBy(rows, key) {
  const output = {}
  for (const row of rows) output[key(row)] = (output[key(row)] ?? 0) + 1
  return output
}

function round(value, digits) {
  return Number(value.toFixed(digits))
}

function renderReport(analysis, rows) {
  const pairTable = analysis.paired.map(pair => `| ${shortSeed(pair.seedId)} | ${yes(pair.nativePrimaryPass)}/${yes(pair.semanticPrimaryPass)} | ${yes(pair.nativeRuntimePass)}/${yes(pair.semanticRuntimePass)} | ${cell(pair.nativeMinusSemanticEvidenceCalls)} | ${cell(pair.nativeMinusSemanticTotalCalls)} | ${cell(pair.nativeMinusSemanticGrossInputTokens)} |`).join('\n')
  const endpointTable = analysis.endpoints.map(item => `| ${item.name} | ${item.positiveDirectionPairs}/${item.ties}/${item.negativeDirectionPairs} | ${formatP(item.rawPValue)} | ${formatP(item.adjustedPValue)} | ${item.nativeMean} | ${item.semanticMean} | ${percent(item.meanRelativeReduction)} |`).join('\n')
  const gateTable = Object.entries(analysis.gates).map(([name, pass]) => `| ${name} | ${pass ? 'PASS' : 'FAIL'} |`).join('\n')
  return `# Held-out paired replication report

## Frozen protocol

The v2.1 task, task card, runtime fixture, Native/Semantic interface schemas, common prompt, scorer, evidence tags, model controls, and 40-call budget were copied byte-for-byte from calibration. Only held-out seed selection (S03-S12), run order, replication preregistration, and analysis orchestration were added.

Calibration seeds S01-S02 are excluded from every confirmatory test. The replication executed ten held-out pairs / twenty slots exactly once with no replacement or early stopping.

## Correctness and validity

- Valid slots: ${analysis.validity.valid ?? 0}/20; complete pairs: ${analysis.completePairs}/10.
- Primary pass, Native/Semantic: ${analysis.correctness.nativePrimaryPass}/10 vs ${analysis.correctness.semanticPrimaryPass}/10.
- Hidden runtime pass, Native/Semantic: ${analysis.correctness.nativeRuntimePass}/10 vs ${analysis.correctness.semanticRuntimePass}/10.
- Native-only/Semantic-only primary discordance: ${analysis.correctness.nativeOnlyPrimaryPass}/${analysis.correctness.semanticOnlyPrimaryPass}.
- Infrastructure-invalid slots: ${analysis.validity['invalid-infrastructure'] ?? 0}.

## Confirmatory paired efficiency family

Differences are Native minus Semantic; positive values favor lower Semantic burden. The direction counts are positive/tie/negative. Tests are one-sided exact paired sign tests with Holm adjustment across the three preregistered endpoints.

| Endpoint | Direction pairs | Raw p | Holm p | Native mean | Semantic mean | Mean reduction |
|---|---:|---:|---:|---:|---:|---:|
${endpointTable}

## Per-pair closure

Primary and runtime columns are Native/Semantic.

| Seed | Primary | Runtime | Evidence-call delta | Total-call delta | Gross-input delta |
|---|---:|---:|---:|---:|---:|
${pairTable}

## Preregistered gates

| Gate | Result |
|---|---|
${gateTable}

Overall replication result: **${analysis.replicationSuccess ? 'PASS' : 'FAIL'}**.

## Aggregate burden

| Metric | Native | Semantic |
|---|---:|---:|
| Calls to evidence closure | ${analysis.byArm.native.meanBurden.callsToEvidenceClosure} | ${analysis.byArm.semantic.meanBurden.callsToEvidenceClosure} |
| Total tool calls | ${analysis.byArm.native.meanBurden.totalToolCalls} | ${analysis.byArm.semantic.meanBurden.totalToolCalls} |
| Calls after closure | ${analysis.byArm.native.meanBurden.callsAfterEvidenceClosure} | ${analysis.byArm.semantic.meanBurden.callsAfterEvidenceClosure} |
| Raw native domains | ${analysis.byArm.native.meanBurden.nativeDomainsTouched} | ${analysis.byArm.semantic.meanBurden.nativeDomainsTouched} |
| Gross input tokens | ${analysis.byArm.native.meanBurden.grossInputTokens} | ${analysis.byArm.semantic.meanBurden.grossInputTokens} |
| Output + thinking tokens | ${analysis.byArm.native.meanBurden.grossOutputAndThinkingTokens} | ${analysis.byArm.semantic.meanBurden.grossOutputAndThinkingTokens} |
| Repeated observations | ${analysis.byArm.native.meanBurden.repeatedObservationCalls} | ${analysis.byArm.semantic.meanBurden.repeatedObservationCalls} |
| Arm cost | $${analysis.byArm.native.costUsd.toFixed(6)} | $${analysis.byArm.semantic.costUsd.toFixed(6)} |

Total paid-model cost: $${analysis.totalCostUsd.toFixed(6)}.

## Interpretation boundary

${analysis.interpretation}

${analysis.inferentialLimit}
`
}

function shortSeed(seedId) {
  return seedId.match(/s\d+$/)?.[0]?.toUpperCase() ?? seedId
}

function yes(value) {
  return value ? 'yes' : 'no'
}

function cell(value) {
  return value === null || value === undefined ? 'NA' : String(value)
}

function formatP(value) {
  return value === null ? 'NA' : value < 0.0001 ? value.toExponential(2) : value.toFixed(6)
}

function percent(value) {
  return value === null ? 'NA' : `${(value * 100).toFixed(1)}%`
}
