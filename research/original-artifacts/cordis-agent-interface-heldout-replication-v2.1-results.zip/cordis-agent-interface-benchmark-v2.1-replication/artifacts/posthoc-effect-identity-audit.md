# Post-hoc effect identity scorer audit

The frozen replication result remains **FAIL** and is not overwritten.

Four Semantic runs (S05, S07, S10, S12) passed the hidden runtime grade, terminal parser, every plan check, every action check, every non-effect fact check, and all critical-error checks. Their only frozen failures were `direct_tracked_effect` and `transitive_tracked_effect`.

The written Turn-1 contract permits either an exact effect label or an exact effect ID. In all four runs, the model returned exact `effectId` values present in the composed query result. The scorer, however, accepted only strings containing the effect-label fragments `tracked:direct:` and `tracked:transitive:`.

This mismatch is arm-sensitive: the Semantic query exposes both IDs and labels, whereas Native Fiber inspection exposes labels without effect IDs.

| Readout | Native | Semantic |
|---|---:|---:|
| Frozen primary | 10/10 | 6/10 |
| Contract-adjudicated primary | 10/10 | 10/10 |
| Hidden runtime | 10/10 | 10/10 |

The contract-adjudicated readout is a transparent post-hoc audit, not a new confirmatory score. Efficiency endpoints are unaffected because they use frozen telemetry and all three passed their preregistered Holm-adjusted tests.
