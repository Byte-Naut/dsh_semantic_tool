# Held-out paired replication report

## Frozen protocol

The v2.1 task, task card, runtime fixture, Native/Semantic interface schemas, common prompt, scorer, evidence tags, model controls, and 40-call budget were copied byte-for-byte from calibration. Only held-out seed selection (S03-S12), run order, replication preregistration, and analysis orchestration were added.

Calibration seeds S01-S02 are excluded from every confirmatory test. The replication executed ten held-out pairs / twenty slots exactly once with no replacement or early stopping.

## Correctness and validity

- Valid slots: 20/20; complete pairs: 10/10.
- Primary pass, Native/Semantic: 10/10 vs 6/10.
- Hidden runtime pass, Native/Semantic: 10/10 vs 10/10.
- Native-only/Semantic-only primary discordance: 4/0.
- Infrastructure-invalid slots: 0.

## Confirmatory paired efficiency family

Differences are Native minus Semantic; positive values favor lower Semantic burden. The direction counts are positive/tie/negative. Tests are one-sided exact paired sign tests with Holm adjustment across the three preregistered endpoints.

| Endpoint | Direction pairs | Raw p | Holm p | Native mean | Semantic mean | Mean reduction |
|---|---:|---:|---:|---:|---:|---:|
| evidence_closure_calls | 10/0/0 | 0.000977 | 0.002930 | 10.5 | 2 | 81.0% |
| total_tool_calls | 10/0/0 | 0.000977 | 0.002930 | 20.1 | 6 | 70.1% |
| gross_input_tokens | 10/0/0 | 0.000977 | 0.002930 | 176540.1 | 44216.3 | 75.0% |

## Per-pair closure

Primary and runtime columns are Native/Semantic.

| Seed | Primary | Runtime | Evidence-call delta | Total-call delta | Gross-input delta |
|---|---:|---:|---:|---:|---:|
| S03 | yes/yes | yes/yes | 9 | 14 | 117615 |
| S04 | yes/yes | yes/yes | 10 | 14 | 148539 |
| S05 | yes/no | yes/yes | 10 | 15 | 103254 |
| S06 | yes/yes | yes/yes | 8 | 15 | 130789 |
| S07 | yes/no | yes/yes | 8 | 14 | 147962 |
| S08 | yes/yes | yes/yes | 8 | 15 | 211841 |
| S09 | yes/yes | yes/yes | 7 | 11 | 107397 |
| S10 | yes/no | yes/yes | 9 | 14 | 173176 |
| S11 | yes/yes | yes/yes | 9 | 16 | 109832 |
| S12 | yes/no | yes/yes | 7 | 13 | 72833 |

## Preregistered gates

| Gate | Result |
|---|---|
| protocolByteIdentity | PASS |
| analyzablePopulation | PASS |
| correctnessRetention | FAIL |
| efficiencyFamilyHolm | PASS |
| semanticInterfaceFirstFidelity | PASS |
| scorerAndParserIntegrity | PASS |
| noInfrastructureInvalid | PASS |

Overall replication result: **FAIL**.

## Aggregate burden

| Metric | Native | Semantic |
|---|---:|---:|
| Calls to evidence closure | 10.5 | 2 |
| Total tool calls | 20.1 | 6 |
| Calls after closure | 9.6 | 4 |
| Raw native domains | 5 | 0 |
| Gross input tokens | 176540.1 | 44216.3 |
| Output + thinking tokens | 11514.1 | 5682.7 |
| Repeated observations | 4 | 0 |
| Arm cost | $1.755830 | $0.544724 |

Total paid-model cost: $2.300554.

## Interpretation boundary

At least one preregistered replication gate failed; inspect the failed gate before claiming mechanism replication.

held-out procedural seeds replicate the mechanism within one task family and one model; they are not independent real-world incident families and do not establish E3 hard-UNKNOWN or E4 capability-boundary claims
