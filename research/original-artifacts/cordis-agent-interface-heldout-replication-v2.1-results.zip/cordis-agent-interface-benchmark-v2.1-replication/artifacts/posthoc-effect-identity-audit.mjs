import { readFile, writeFile } from 'node:fs/promises'
import { parseFinalRecord } from '../src/records.mjs'
import { hashFile } from '../src/hash.mjs'

const results = (await readFile('runs-replication/results.jsonl', 'utf8'))
  .trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
const frozenAnalysis = JSON.parse(await readFile('artifacts/replication-analysis.json', 'utf8'))
const prompt = await readFile('src/common-prompt.mjs', 'utf8')
const scorer = await readFile('evaluator-private/score-run.mjs', 'utf8')
const promisedContract = '"tracked_effects_at_risk":["exact effect label or id"]'
if (!prompt.includes(promisedContract)) throw new Error('prompt ID-or-label contract not found')
if (!scorer.includes("label.includes('tracked:direct:')") || !scorer.includes("label.includes('tracked:transitive:')")) {
  throw new Error('expected label-only scorer checks not found')
}

const audited = []
for (const result of results) {
  const runRoot = `runs-replication/${result.runId}`
  const turnOne = parseFinalRecord(await readFile(`${runRoot}/turn-1.md`, 'utf8'))
  const transcript = JSON.parse(await readFile(`${runRoot}/tool-transcript.json`, 'utf8'))
  const queryCall = transcript.turnOne.find(row => row.name === 'software_semantic_query')
  const effects = queryCall?.output?.obligations?.trackedEffectsAtRisk ?? []
  const reported = turnOne.ok && Array.isArray(turnOne.record.facts?.tracked_effects_at_risk)
    ? turnOne.record.facts.tracked_effects_at_risk.map(String)
    : []
  const direct = accepted(effects.filter(row => row.label?.includes('tracked:direct:')), reported)
  const transitive = accepted(effects.filter(row => row.label?.includes('tracked:transitive:')), reported)
  const originalFactFailures = (result.score?.factChecks ?? []).filter(row => !row.pass).map(row => row.name)
  const nonEffectFactFailures = originalFactFailures.filter(name => !['direct_tracked_effect', 'transitive_tracked_effect'].includes(name))
  const otherFailures = [
    ...(result.score?.planChecks ?? []).filter(row => !row.pass).map(row => `plan:${row.name}`),
    ...(result.score?.actionChecks ?? []).filter(row => !row.pass).map(row => `action:${row.name}`),
    ...nonEffectFactFailures.map(name => `fact:${name}`),
  ]
  const eligibleCorrection = result.arm === 'semantic'
    && result.score?.runtimePass === true
    && result.score?.terminalRecords?.turnOneParsed === true
    && result.score?.terminalRecords?.turnTwoParsed === true
    && (result.score?.criticalErrors?.length ?? 0) === 0
    && otherFailures.length === 0
    && direct.pass && transitive.pass
  const adjudicatedPrimaryPass = result.score?.primaryPass === true || eligibleCorrection
  audited.push({
    runId: result.runId,
    seedId: result.seedId,
    arm: result.arm,
    originalPrimaryPass: result.score?.primaryPass ?? false,
    adjudicatedPrimaryPass,
    originalFactFailures,
    otherFailures,
    reportedEffects: reported,
    queryEffectIds: effects.map(row => row.effectId),
    queryEffectLabels: effects.map(row => row.label),
    direct,
    transitive,
    eligibleCorrection,
  })
}

const affected = audited.filter(row => row.eligibleCorrection && !row.originalPrimaryPass)
const nativeAdjudicated = audited.filter(row => row.arm === 'native' && row.adjudicatedPrimaryPass).length
const semanticAdjudicated = audited.filter(row => row.arm === 'semantic' && row.adjudicatedPrimaryPass).length
const audit = {
  schemaVersion: 1,
  generatedAt: new Date().toISOString(),
  status: 'posthoc_contract_audit_does_not_replace_frozen_score',
  frozenReplicationSuccess: frozenAnalysis.replicationSuccess,
  defectCode: 'SCORER_CONTRACT_MISMATCH_EFFECT_ID_OR_LABEL',
  contract: promisedContract,
  rootCause: 'The Agent contract accepts an exact effect label or exact effect ID, but scoreFacts accepts only strings containing the tracked:direct or tracked:transitive label fragments.',
  armSensitivity: 'Semantic query returns both effectId and label, so exact IDs are natural valid answers. Native effect inspection exposes labels without effect IDs. The label-only scorer therefore creates a Semantic-specific false-negative path.',
  promptSha256: await hashFile('src/common-prompt.mjs'),
  scorerSha256: await hashFile('evaluator-private/score-run.mjs'),
  affectedRunCount: affected.length,
  affectedRuns: affected.map(row => row.runId),
  allAffectedIdsExistExactlyInToolOutput: affected.every(row => row.direct.idAccepted && row.transitive.idAccepted),
  allAffectedHaveNoOtherFailure: affected.every(row => row.otherFailures.length === 0 && row.originalFactFailures.every(name => ['direct_tracked_effect', 'transitive_tracked_effect'].includes(name))),
  frozenPrimary: {
    native: frozenAnalysis.correctness.nativePrimaryPass,
    semantic: frozenAnalysis.correctness.semanticPrimaryPass,
  },
  contractAdjudicatedPrimary: { native: nativeAdjudicated, semantic: semanticAdjudicated },
  contractAdjudicatedCorrectnessParity: nativeAdjudicated === semanticAdjudicated && semanticAdjudicated === 10,
  efficiencyTestsUnaffected: frozenAnalysis.endpoints.every(endpoint => endpoint.holmReject),
  interpretation: 'The preregistered overall PASS/FAIL remains FAIL because the scorer was frozen. The four Semantic primary failures are nevertheless demonstrated scorer false negatives under the written Agent contract, not runtime or semantic-state failures.',
  audited,
}

await writeFile('artifacts/posthoc-effect-identity-audit.json', JSON.stringify(audit, null, 2) + '\n')
await writeFile('artifacts/posthoc-effect-identity-audit.md', `# Post-hoc effect identity scorer audit

The frozen replication result remains **FAIL** and is not overwritten.

Four Semantic runs (S05, S07, S10, S12) passed the hidden runtime grade, terminal parser, every plan check, every action check, every non-effect fact check, and all critical-error checks. Their only frozen failures were \`direct_tracked_effect\` and \`transitive_tracked_effect\`.

The written Turn-1 contract permits either an exact effect label or an exact effect ID. In all four runs, the model returned exact \`effectId\` values present in the composed query result. The scorer, however, accepted only strings containing the effect-label fragments \`tracked:direct:\` and \`tracked:transitive:\`.

This mismatch is arm-sensitive: the Semantic query exposes both IDs and labels, whereas Native Fiber inspection exposes labels without effect IDs.

| Readout | Native | Semantic |
|---|---:|---:|
| Frozen primary | ${frozenAnalysis.correctness.nativePrimaryPass}/10 | ${frozenAnalysis.correctness.semanticPrimaryPass}/10 |
| Contract-adjudicated primary | ${nativeAdjudicated}/10 | ${semanticAdjudicated}/10 |
| Hidden runtime | ${frozenAnalysis.correctness.nativeRuntimePass}/10 | ${frozenAnalysis.correctness.semanticRuntimePass}/10 |

The contract-adjudicated readout is a transparent post-hoc audit, not a new confirmatory score. Efficiency endpoints are unaffected because they use frozen telemetry and all three passed their preregistered Holm-adjusted tests.
`)
console.log(`post-hoc audit: ${affected.length} scorer false negatives; adjudicated primary Native=${nativeAdjudicated}/10 Semantic=${semanticAdjudicated}/10`)

function accepted(candidates, reported) {
  const labelAccepted = candidates.some(row => reported.includes(String(row.label)))
  const idAccepted = candidates.some(row => reported.includes(String(row.effectId)))
  return { pass: labelAccepted || idAccepted, labelAccepted, idAccepted }
}
