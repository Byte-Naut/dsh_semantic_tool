Based on raw observations from the runtime environment, all seven Turn 1 evidence obligations have been verified:

1. **Last successful package**: `pkg-1` (`granac stable package`), serving `routeEndpoint` with version `"frost-stable"`.
2. **Failed target package**: `pkg-2` (`granac failed target`), which encountered a bootstrap error during host loading.
3. **Active run**: `KNOWN_ABSENT` (`latestRun` has status `"failed"`, host status `"failed"`, and client status `"absent"`).
4. **Direct consumer**: `granary-route-adapter` (declares injection `routeEndpoint`).
5. **Transitive consumer**: `granary-digest-client` (declares injection `digestView`, which is published by `granary-route-adapter`).
6. **Tracked effects at risk**: `tracked:direct:frost-stable` and `tracked:transitive:derived:frost-stable`.
7. **Failed package inspection**: The code in `pkg-2` throws `Error: frost bootstrap failed before publication` prior to executing `ctx.provide("routeEndpoint", intended)`, classifying the defect as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "granary-route-adapter"
    ],
    "transitive_consumers": [
      "granary-digest-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:frost-stable",
      "tracked:transitive:derived:frost-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "granac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
