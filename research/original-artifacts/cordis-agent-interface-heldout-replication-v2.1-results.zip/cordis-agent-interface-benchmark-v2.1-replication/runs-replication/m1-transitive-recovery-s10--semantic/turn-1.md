All seven evidence obligations for incident `incident-meadow-10` have been established through authoritative semantic query and direct inspection of failed package `pkg-2`:

1. **Last successful package**: `pkg-1`
2. **Failed target package**: `pkg-2`
3. **Active run**: `KNOWN_ABSENT` (no live run currently active)
4. **Direct consumer**: `meadow-sample-adapter`
5. **Transitive consumer**: `meadow-projection-client`
6. **Tracked effects at risk**: `effect:rt:m1-transitive-recovery-s10:32`, `effect:rt:m1-transitive-recovery-s10:34`, `effect:rt:m1-transitive-recovery-s10:35`, `effect:rt:m1-transitive-recovery-s10:38`
7. **Failed package source inspection**: Confirmed defect code `THROW_BEFORE_PUBLISH` (`throw new Error("jade bootstrap failed before publication")` before invoking `ctx.provide`).

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "meadow-sample-adapter"
    ],
    "transitive_consumers": [
      "meadow-projection-client"
    ],
    "tracked_effects_at_risk": [
      "effect:rt:m1-transitive-recovery-s10:32",
      "effect:rt:m1-transitive-recovery-s10:34",
      "effect:rt:m1-transitive-recovery-s10:35",
      "effect:rt:m1-transitive-recovery-s10:38"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "meadoc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
