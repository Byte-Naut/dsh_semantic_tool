Based on the semantic interface and package inspection for plugin `tundrc-1`, all seven evidence obligations have been established:

1. **Last Successful Package**: `pkg-1`
2. **Failed Target Package**: `pkg-2`
3. **Active Run**: `KNOWN_ABSENT` (no live run currently running)
4. **Direct Consumers**: `tundra-record-adapter`
5. **Transitive Consumers**: `tundra-display-client`
6. **Tracked Effects at Risk**: `ctx.provide("recordEndpoint")`, `tracked:transitive:derived:kelp-stable`, `ctx.provide("displayView")`, and `tracked:direct:kelp-stable`
7. **Failed Package Defect**: Stored source in `pkg-2` throws an explicit Error before publishing `recordEndpoint` (`THROW_BEFORE_PUBLISH`).

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "tundra-record-adapter"
    ],
    "transitive_consumers": [
      "tundra-display-client"
    ],
    "tracked_effects_at_risk": [
      "ctx.provide(\"recordEndpoint\")",
      "tracked:transitive:derived:kelp-stable",
      "ctx.provide(\"displayView\")",
      "tracked:direct:kelp-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "tundrc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
