Based on the native dynamic inventory, fiber inspection across checkpoints, and package inspection, here is the diagnosis and recovery plan:

1. **Last successful package**: `pkg-1` (`foundc stable package`), which provides `metricEndpoint` at version `ember-stable`.
2. **Failed target package**: `pkg-2` (`foundc failed target`), which failed during host startup under update mode.
3. **Active run**: `KNOWN_ABSENT` (`package_id`: `null`). The failed update aborted host startup and no active run is present.
4. **Direct consumer**: `foundry-metric-adapter`, which injects `metricEndpoint` and became pending when `foundc-1` failed.
5. **Transitive consumer**: `foundry-screen-client`, which injects derived service `screenView` published by `foundry-metric-adapter`.
6. **Tracked effects at risk**: `tracked:direct:ember-stable` on `foundry-metric-adapter` and `tracked:transitive:derived:ember-stable` on `foundry-screen-client`.
7. **Failed package inspection**: `pkg-2` throws `Error("ember bootstrap failed before publication")` prior to calling `ctx.provide("metricEndpoint", intended)`, classifying the defect code as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "foundry-metric-adapter"
    ],
    "transitive_consumers": [
      "foundry-screen-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:ember-stable",
      "tracked:transitive:derived:ember-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "foundc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
