The three-step lifecycle plan was executed in order and verified:

1. **RESTORE_LAST_SUCCESSFUL**: Ran `pkg-1` with mode `run`, successfully restoring `metricEndpoint` at version `ember-stable`.
2. **DEFINE_REPAIRED_PACKAGE**: Defined fresh immutable package `pkg-3` under plugin `foundc-1` with the pre-publication error removed.
3. **UPDATE_TO_REPAIRED_PACKAGE**: Updated runtime to `pkg-3` with mode `update`.
4. **Verification**: Checked the live dynamic inventory and fiber states:
   - `foundc-1` active run is package `pkg-3` serving `ember-repaired`.
   - Direct consumer `foundry-metric-adapter` is `active` with committed binding to `metricEndpoint` (`ember-repaired`) and tracked effect `tracked:direct:ember-repaired`.
   - Transitive consumer `foundry-screen-client` is `active` with committed binding to `screenView` (`derived:ember-repaired`) and tracked effect `tracked:transitive:derived:ember-repaired`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "foundc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "ember-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
