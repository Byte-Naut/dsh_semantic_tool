Based on the semantic interface query and the inspection of the failed package source, all seven evidence obligations have been established:

1. **Last successful Package:** `pkg-1`
2. **Failed target Package:** `pkg-2`
3. **Active Run status:** `KNOWN_ABSENT` (no active run currently executing under `marinc-1`)
4. **Direct consumer:** `marina-quota-adapter`
5. **Transitive consumer:** `marina-panel-client`
6. **Tracked effects at risk:**
   - `ctx.provide("quotaEndpoint")`
   - `tracked:direct:delta-stable`
   - `ctx.provide("panelView")`
   - `tracked:transitive:derived:delta-stable`
7. **Failed package inspection:** `pkg-2` throws an error (`"delta bootstrap failed before publication"`) prior to executing `ctx.provide("quotaEndpoint", intended)`. The defect is classified as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "marina-quota-adapter"
    ],
    "transitive_consumers": [
      "marina-panel-client"
    ],
    "tracked_effects_at_risk": [
      "ctx.provide(\"quotaEndpoint\")",
      "tracked:transitive:derived:delta-stable",
      "ctx.provide(\"panelView\")",
      "tracked:direct:delta-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "marinc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
