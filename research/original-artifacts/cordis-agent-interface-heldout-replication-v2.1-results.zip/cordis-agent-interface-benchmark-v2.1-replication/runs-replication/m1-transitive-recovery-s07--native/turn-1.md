### Turn 1 Incident Response Record

#### 1. Evidence and Findings
- **Last Successful Package**: `pkg-1` (`terrac stable package`, provides `catalogEndpoint` with version `garnet-stable`).
- **Failed Target Package**: `pkg-2` (`terrac failed target`, attempted update to `garnet-repaired`).
- **Active Run**: `KNOWN_ABSENT`. Inspection of the current runtime inventory confirms `latestRun` failed at phase `host-load` and no active dynamic runner Fiber exists.
- **Direct Consumer**: `terrace-catalog-adapter` directly consumes `catalogEndpoint` and transitioned to `pending` upon failure.
- **Transitive Consumer**: `terrace-summary-client` depends on `summaryView` published by `terrace-catalog-adapter` and transitioned to `pending`.
- **Tracked Effects at Risk**: `tracked:direct:garnet-stable` and `tracked:transitive:derived:garnet-stable`.
- **Source Inspection & Defect Classification**: Source inspection of `pkg-2` reveals an explicit throw (`throw new Error("garnet bootstrap failed before publication")`) preceding the call to `ctx.provide("catalogEndpoint", intended)`. Defect code: `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "terrace-catalog-adapter"
    ],
    "transitive_consumers": [
      "terrace-summary-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:garnet-stable",
      "tracked:transitive:derived:garnet-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "terrac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
