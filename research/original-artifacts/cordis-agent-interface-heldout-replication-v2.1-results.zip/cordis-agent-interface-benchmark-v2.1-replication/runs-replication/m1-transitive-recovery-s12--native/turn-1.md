Based on the inspection of runtime inventory, checkpoints, fiber states, and the immutable package source, all seven evidence obligations have been established:

1. **Last successful Package:** `pkg-1` (`estuac stable package`), which served `channelEndpoint` at version `lilac-stable`.
2. **Failed target Package:** `pkg-2` (`estuac failed target`), targeted during an update attempt.
3. **Active Run:** `KNOWN_ABSENT`. The latest run failed during the `host-load` phase (`status: failed`), leaving no active package run in the host.
4. **Direct consumer:** `estuary-channel-adapter`, which injects the withdrawn `channelEndpoint` service and is currently pending.
5. **Transitive consumer:** `estuary-snapshot-client`, which injects `snapshotView` (provided by `estuary-channel-adapter`) and is currently pending.
6. **Tracked effects at risk:** `tracked:direct:lilac-stable` (direct consumer effect) and `tracked:transitive:derived:lilac-stable` (transitive consumer effect).
7. **Source diagnosis:** Inspection of package `pkg-2` confirms an unconditional throw (`lilac bootstrap failed before publication`) prior to `ctx.provide("channelEndpoint", intended)`, classifying the defect as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "estuary-channel-adapter"
    ],
    "transitive_consumers": [
      "estuary-snapshot-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:lilac-stable",
      "tracked:transitive:derived:lilac-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "estuac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
