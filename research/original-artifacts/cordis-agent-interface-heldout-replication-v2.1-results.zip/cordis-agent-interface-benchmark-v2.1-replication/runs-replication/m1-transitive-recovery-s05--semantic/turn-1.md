Based on the semantic incident query and inspection of the failed immutable Package source, all seven Turn-1 evidence obligations have been verified:

1. **Last successful Package**: `pkg-1`
2. **Failed target Package**: `pkg-2`
3. **Active Run status**: `KNOWN_ABSENT` (no live run is currently active for `foundc-1`)
4. **Direct consumer**: `foundry-metric-adapter` (consumed `metricEndpoint` directly)
5. **Transitive consumer**: `foundry-screen-client` (depends on `screenView` from `foundry-metric-adapter`)
6. **Tracked effects at risk**: Identified 4 tracked effects across the dynamic plugin and both consumers
7. **Source inspection**: Package `pkg-2` throws an unhandled error (`ember bootstrap failed before publication`) prior to calling `ctx.provide("metricEndpoint", ...)`, classifying the defect as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "foundry-metric-adapter"
    ],
    "transitive_consumers": [
      "foundry-screen-client"
    ],
    "tracked_effects_at_risk": [
      "effect:rt:m1-transitive-recovery-s05:32",
      "effect:rt:m1-transitive-recovery-s05:35",
      "effect:rt:m1-transitive-recovery-s05:34",
      "effect:rt:m1-transitive-recovery-s05:38"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "foundc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
