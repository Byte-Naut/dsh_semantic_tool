### Turn 1 Incident Investigation & Diagnosis

All seven evidence obligations have been verified using the native observation interface:

1. **Last Successful Package**: `pkg-1` (`aviarc stable package`, serving `noticeEndpoint` with version `hazel-stable`).
2. **Failed Target Package**: `pkg-2` (`aviarc failed target`, intended to serve `hazel-repaired`).
3. **Active Run**: `KNOWN_ABSENT`. The latest run (`run-2`) failed during phase `host-load` with status `failed` and client status `absent`. No dynamic package fiber is currently running.
4. **Direct Consumers**: `aviary-notice-adapter` declares injection on `noticeEndpoint`.
5. **Transitive Consumers**: `aviary-feed-client` declares injection on `feedView` (provided by `aviary-notice-adapter`).
6. **Tracked Effects at Risk**: `tracked:direct:hazel-stable` and `tracked:transitive:derived:hazel-stable` were cleared when both consumer fibers transitioned to `pending`.
7. **Failed Package Inspection**: Source code of `pkg-2` contains a synchronous throw (`throw new Error("hazel bootstrap failed before publication")`) preceding `ctx.provide("noticeEndpoint", intended)`. Defect is classified as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "aviary-notice-adapter"
    ],
    "transitive_consumers": [
      "aviary-feed-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:hazel-stable",
      "tracked:transitive:derived:hazel-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "aviarc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
