All seven evidence obligations for incident `incident-aviary-08` have been investigated and verified:

1. **Last Successful Package**: `pkg-1` was the last successfully executed immutable package.
2. **Failed Target Package**: `pkg-2` failed during host bootstrap.
3. **Active Run Classification**: `KNOWN_ABSENT` (no active run is currently executing under `aviarc-1`).
4. **Direct Consumer**: `aviary-notice-adapter` consumes `noticeEndpoint`.
5. **Transitive Consumer**: `aviary-feed-client` consumes `feedView` provided by `aviary-notice-adapter`.
6. **Tracked Effects at Risk**: The effects associated with `noticeEndpoint` and the downstream `feedView` service and stability markers (`tracked:transitive:derived:hazel-stable`, `ctx.provide("feedView")`, `tracked:direct:hazel-stable`, and `ctx.provide("noticeEndpoint")`).
7. **Failed Package Defect**: Package `pkg-2` throws an unhandled error prior to publishing `noticeEndpoint` (`THROW_BEFORE_PUBLISH`).

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "aviary-notice-adapter"
    ],
    "transitive_consumers": [
      "aviary-feed-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:transitive:derived:hazel-stable",
      "ctx.provide(\"feedView\")",
      "tracked:direct:hazel-stable",
      "ctx.provide(\"noticeEndpoint\")"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "aviarc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
