The three-step lifecycle plan has been executed successfully and verified:

1. **RESTORE_LAST_SUCCESSFUL**: Executed `dynamic_run_package` with `mode: "run"` on `pkg-1`, restoring service `noticeEndpoint` (`hazel-stable`).
2. **DEFINE_REPAIRED_PACKAGE**: Defined corrected immutable package `pkg-3` under plugin `aviarc-1` without the unhandled bootstrap exception.
3. **UPDATE_TO_REPAIRED_PACKAGE**: Executed `dynamic_run_package` with `mode: "update"` on `pkg-3`, upgrading service `noticeEndpoint` to `hazel-repaired`.
4. **Verification**: Checked service visibility and confirmed that both direct consumer `aviary-notice-adapter` and transitive consumer `aviary-feed-client` are active and healthy.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "aviarc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "hazel-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
