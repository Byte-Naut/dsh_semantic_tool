All seven evidence obligations have been established from the authoritative interface:

1. **Last successful immutable Package**: `pkg-1`
2. **Failed target Package**: `pkg-2`
3. **Active Run status**: `KNOWN_ABSENT` (no active run currently present for dynamic plugin `terrac-1`)
4. **Direct consumer**: `terrace-catalog-adapter` (consumed `catalogEndpoint`)
5. **Transitive consumer**: `terrace-summary-client` (consumed `summaryView` derived from `catalogEndpoint`)
6. **Tracked effects at risk**:
   - `effect:rt:m1-transitive-recovery-s07:32` (`ctx.provide("catalogEndpoint")`)
   - `effect:rt:m1-transitive-recovery-s07:35` (`ctx.provide("summaryView")`)
   - `effect:rt:m1-transitive-recovery-s07:34` (`tracked:direct:garnet-stable`)
   - `effect:rt:m1-transitive-recovery-s07:38` (`tracked:transitive:derived:garnet-stable`)
7. **Failed Package inspection**: Package `pkg-2` source was inspected. The defect is an uncaught error thrown during host bootstrap prior to service registration (`THROW_BEFORE_PUBLISH`).

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "terrace-catalog-adapter"
    ],
    "transitive_consumers": [
      "terrace-summary-client"
    ],
    "tracked_effects_at_risk": [
      "effect:rt:m1-transitive-recovery-s07:32",
      "effect:rt:m1-transitive-recovery-s07:35",
      "effect:rt:m1-transitive-recovery-s07:34",
      "effect:rt:m1-transitive-recovery-s07:38"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "terrac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
