Based on the runtime inventory, fiber inspection, and package source inspection, here are the findings for Turn 1:

1. **Last successful immutable Package**: `pkg-1` ("quarrc stable package"), which successfully provided `signalEndpoint` (version `crimson-stable`).
2. **Failed target Package**: `pkg-2` ("quarrc failed target"), which failed during the host-load phase of run `run-2`.
3. **Active Run status**: `KNOWN_ABSENT`. The latest run failed with no active host or client running.
4. **Direct consumer**: `quarry-signal-adapter`, which directly injects `signalEndpoint`.
5. **Transitive consumer**: `quarry-view-client`, which injects `viewView` provided by the direct consumer.
6. **Tracked effects at risk**: `tracked:direct:crimson-stable` and `tracked:transitive:derived:crimson-stable`.
7. **Failed package defect**: In `pkg-2`, `apply(ctx)` throws `Error("crimson bootstrap failed before publication")` immediately before calling `ctx.provide("signalEndpoint", intended)`, classifying the defect as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "quarry-signal-adapter"
    ],
    "transitive_consumers": [
      "quarry-view-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:crimson-stable",
      "tracked:transitive:derived:crimson-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "quarrc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
