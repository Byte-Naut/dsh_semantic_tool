The three lifecycle actions have been executed and verified:

1. **RESTORE_LAST_SUCCESSFUL**: Executed `dynamic_run_package` on `pkg-1` under `quarrc-1` with mode `run`, successfully restoring `signalEndpoint` with version `crimson-stable`.
2. **DEFINE_REPAIRED_PACKAGE**: Defined a new package `pkg-3` under plugin `quarrc-1` containing the corrected host code without the preliminary exception.
3. **UPDATE_TO_REPAIRED_PACKAGE**: Executed `dynamic_run_package` on `pkg-3` under `quarrc-1` with mode `update`. The active run switched cleanly to `pkg-3` serving `crimson-repaired`.
4. **Verification**: Direct consumer `quarry-signal-adapter` is active, re-binding `signalEndpoint` and publishing `viewView` (`derived:crimson-repaired`). Transitive consumer `quarry-view-client` is active, re-binding `viewView` and generating `tracked:transitive:derived:crimson-repaired`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "quarrc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "crimson-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
