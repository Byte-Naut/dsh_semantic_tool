All seven evidence obligations have been established through native observations without mutating the runtime:

1. **Last successful Package**: `pkg-1` (`currentPackageId: "pkg-1"`).
2. **Failed target Package**: `pkg-2` (attempted update failed during `host-load`).
3. **Active Run status**: `KNOWN_ABSENT` (the previous run was torn down and the update run failed before publishing; runner fiber is absent in live state).
4. **Direct consumer**: `marina-quota-adapter` (consumes `quotaEndpoint`).
5. **Transitive consumer**: `marina-panel-client` (consumes `panelView`, published by `marina-quota-adapter`).
6. **Tracked effects at risk**: `tracked:direct:delta-stable` and `tracked:transitive:derived:delta-stable`.
7. **Failed source inspection**: Inspected `pkg-2` source code, which throws `Error("delta bootstrap failed before publication")` immediately prior to calling `ctx.provide("quotaEndpoint", intended)`. Defect classified as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "marina-quota-adapter"
    ],
    "transitive_consumers": [
      "marina-panel-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:delta-stable",
      "tracked:transitive:derived:delta-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "marinc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
