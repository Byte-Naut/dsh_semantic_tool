All seven evidence obligations have been established through the semantic query and native source oracle:

1. **Last successful immutable Package**: `pkg-1`
2. **Failed target Package**: `pkg-2`
3. **Active Run status**: `KNOWN_ABSENT` (no active run currently running)
4. **Direct consumer**: `citadel-status-adapter`
5. **Transitive consumer**: `citadel-report-client`
6. **Tracked effects at risk**:
   - `tracked:transitive:derived:indigo-stable` (`effect:rt:m1-transitive-recovery-s09:38`)
   - `ctx.provide("reportView")` (`effect:rt:m1-transitive-recovery-s09:35`)
   - `tracked:direct:indigo-stable` (`effect:rt:m1-transitive-recovery-s09:34`)
   - `ctx.provide("statusEndpoint")` (`effect:rt:m1-transitive-recovery-s09:32`)
7. **Failed package inspection & defect classification**: Inspection of `pkg-2` source reveals an intentional thrown exception (`throw new Error("indigo bootstrap failed before publication")`) prior to service publication (`ctx.provide("statusEndpoint", intended)`), classified as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "citadel-status-adapter"
    ],
    "transitive_consumers": [
      "citadel-report-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:transitive:derived:indigo-stable",
      "ctx.provide(\"reportView\")",
      "tracked:direct:indigo-stable",
      "ctx.provide(\"statusEndpoint\")"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "citadc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
