The approved three-step lifecycle plan has been executed and verified:

1. **`RESTORE_LAST_SUCCESSFUL`**: Restored `pkg-1` under `meadoc-1` in `run` mode. Service returned to `jade-stable`.
2. **`DEFINE_REPAIRED_PACKAGE`**: Defined corrected immutable package `pkg-3` under existing plugin `meadoc-1` without the pre-publish throw.
3. **`UPDATE_TO_REPAIRED_PACKAGE`**: Switched `meadoc-1` to `pkg-3` in `update` mode. Service transitioned to `jade-repaired`.
4. **Verification**:
   - `sampleEndpoint` is actively published at `jade-repaired`.
   - Direct consumer `meadow-sample-adapter` is `active` with effect `tracked:direct:jade-repaired` and derives `projectionView` (`derived:jade-repaired`).
   - Transitive consumer `meadow-projection-client` is `active` with effect `tracked:transitive:derived:jade-repaired`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "meadoc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "jade-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
