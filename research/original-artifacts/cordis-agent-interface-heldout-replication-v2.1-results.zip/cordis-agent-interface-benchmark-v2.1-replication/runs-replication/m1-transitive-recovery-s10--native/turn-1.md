All seven evidence obligations for incident `incident-meadow-10` have been established:

1. **Last successful package**: `pkg-1` ("meadoc stable package"), which successfully published `sampleEndpoint` (`jade-stable`).
2. **Failed target package**: `pkg-2` ("meadoc failed target").
3. **Active run status**: `KNOWN_ABSENT`. The latest run (`run-2`) failed during `host-load`, leaving no active dynamic run or provider fiber for `sampleEndpoint`.
4. **Direct consumer**: `meadow-sample-adapter`, which directly injects `sampleEndpoint`.
5. **Transitive consumer**: `meadow-projection-client`, which injects `projectionView` derived from `meadow-sample-adapter`.
6. **Tracked effects at risk**: `tracked:direct:jade-stable` and `tracked:transitive:derived:jade-stable`.
7. **Failed package inspection & diagnosis**: Inspected `pkg-2`; its host source unconditionally throws `Error("jade bootstrap failed before publication")` prior to calling `ctx.provide("sampleEndpoint", intended)`. Defect code: `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "meadow-sample-adapter"
    ],
    "transitive_consumers": [
      "meadow-projection-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:jade-stable",
      "tracked:transitive:derived:jade-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "meadoc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
