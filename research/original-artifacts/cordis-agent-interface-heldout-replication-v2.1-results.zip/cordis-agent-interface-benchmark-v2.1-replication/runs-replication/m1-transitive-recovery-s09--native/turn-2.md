The three-step lifecycle plan has been executed and verified:

1. **RESTORE_LAST_SUCCESSFUL**: Ran `pkg-1` in `run` mode to restore service `statusEndpoint` (`indigo-stable`).
2. **DEFINE_REPAIRED_PACKAGE**: Defined corrected immutable package `pkg-3` under plugin `citadc-1` removing the pre-publication error.
3. **UPDATE_TO_REPAIRED_PACKAGE**: Updated plugin `citadc-1` to `pkg-3` in `update` mode, successfully serving `indigo-repaired`.

Both the direct consumer (`citadel-status-adapter`) and the transitive consumer (`citadel-report-client`) transitioned back to `active` state with updated bindings and tracked effects.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "citadc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "indigo-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
