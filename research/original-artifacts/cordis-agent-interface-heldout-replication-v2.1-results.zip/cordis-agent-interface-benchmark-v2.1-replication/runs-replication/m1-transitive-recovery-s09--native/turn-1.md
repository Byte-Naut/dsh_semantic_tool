Based on the runtime observations and package source inspection, here is the evidence-backed record for Turn 1:

1. **Last Successful Package**: `pkg-1` (recorded as `currentPackageId` on Plugin `citadc-1`).
2. **Failed Target Package**: `pkg-2` (recorded as `nextPackageId` and `latestRun.packageId` with host failure).
3. **Active Run Classification**: `KNOWN_ABSENT` (`pkg-2` update failed during host-load phase before completion, leaving no live active run or published services for `citadc-1`).
4. **Direct Consumer**: `citadel-status-adapter` (declared injection on withdrawn service `statusEndpoint`).
5. **Transitive Consumer**: `citadel-report-client` (declared injection on `reportView`, which is provided by `citadel-status-adapter`).
6. **Tracked Effects at Risk**: `tracked:direct:indigo-stable` (on `citadel-status-adapter`) and `tracked:transitive:derived:indigo-stable` (on `citadel-report-client`).
7. **Source Inspection & Defect**: `pkg-2` host code throws an error immediately before `ctx.provide("statusEndpoint", intended)` (`THROW_BEFORE_PUBLISH`).

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "citadel-status-adapter"
    ],
    "transitive_consumers": [
      "citadel-report-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:indigo-stable",
      "tracked:transitive:derived:indigo-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "citadc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
