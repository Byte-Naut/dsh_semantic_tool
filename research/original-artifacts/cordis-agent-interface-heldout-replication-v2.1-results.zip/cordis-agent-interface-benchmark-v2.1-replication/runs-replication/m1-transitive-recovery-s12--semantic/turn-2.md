The three-step recovery lifecycle has been successfully executed:

1. **RESTORE_LAST_SUCCESSFUL**: Restored the known good package `pkg-1` via `dynamic_run_package` in `run` mode. Service value `lilac-stable` was restored.
2. **DEFINE_REPAIRED_PACKAGE**: Defined a new immutable package `pkg-3` under plugin `estuac-1` with the premature bootstrap throw removed.
3. **UPDATE_TO_REPAIRED_PACKAGE**: Updated runtime execution to `pkg-3` via `dynamic_run_package` in `update` mode. Service value transitioned cleanly to `lilac-repaired`.
4. **Verification**: Checked through `verify_transitive_recovery`; both the direct consumer `estuary-channel-adapter` and the transitive consumer `estuary-snapshot-client` are active and bound to the repaired service.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "estuac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "lilac-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
