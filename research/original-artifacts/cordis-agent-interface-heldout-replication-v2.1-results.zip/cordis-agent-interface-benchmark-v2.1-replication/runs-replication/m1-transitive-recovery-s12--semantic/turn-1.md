All seven evidence obligations for incident `incident-estuary-12` have been verified:

1. **Last successful immutable Package**: `pkg-1`
2. **Failed target Package**: `pkg-2`
3. **Active Run status**: `KNOWN_ABSENT` (no active run is currently executing for Plugin `estuac-1`)
4. **Direct consumers**: `estuary-channel-adapter` (consumed `channelEndpoint` directly)
5. **Transitive consumers**: `estuary-snapshot-client` (consumed `snapshotView` derived from `channelEndpoint`)
6. **Tracked effects at risk**:
   - `effect:rt:m1-transitive-recovery-s12:32` (`ctx.provide("channelEndpoint")`)
   - `effect:rt:m1-transitive-recovery-s12:34` (`tracked:direct:lilac-stable`)
   - `effect:rt:m1-transitive-recovery-s12:35` (`ctx.provide("snapshotView")`)
   - `effect:rt:m1-transitive-recovery-s12:38` (`tracked:transitive:derived:lilac-stable`)
7. **Failed Package inspection**: Package `pkg-2` throws an unhandled error during host load (`lilac bootstrap failed before publication`) prior to calling `ctx.provide("channelEndpoint", intended)`, classified as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "estuary-channel-adapter"
    ],
    "transitive_consumers": [
      "estuary-snapshot-client"
    ],
    "tracked_effects_at_risk": [
      "effect:rt:m1-transitive-recovery-s12:32",
      "effect:rt:m1-transitive-recovery-s12:34",
      "effect:rt:m1-transitive-recovery-s12:35",
      "effect:rt:m1-transitive-recovery-s12:38"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "estuac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
