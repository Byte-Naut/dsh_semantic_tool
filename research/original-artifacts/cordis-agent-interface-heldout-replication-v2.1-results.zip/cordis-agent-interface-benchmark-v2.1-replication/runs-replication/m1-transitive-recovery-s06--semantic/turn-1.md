Based on the semantic query and native package source inspection, all seven evidence obligations have been established:

1. **Last Successful Package**: `pkg-1`
2. **Failed Target Package**: `pkg-2`
3. **Active Run**: `KNOWN_ABSENT` (no active run currently present for `granac-1`)
4. **Direct Consumer**: `granary-route-adapter` (consumes `routeEndpoint` at depth 1)
5. **Transitive Consumer**: `granary-digest-client` (consumes `digestView` at depth 2)
6. **Tracked Effects at Risk**: `ctx.provide("routeEndpoint")`, `tracked:direct:frost-stable`, `ctx.provide("digestView")`, and `tracked:transitive:derived:frost-stable`
7. **Failed Package Defect**: `pkg-2` throws an error (`frost bootstrap failed before publication`) during `apply()` prior to calling `ctx.provide("routeEndpoint", intended)`. Defect code: `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "granary-route-adapter"
    ],
    "transitive_consumers": [
      "granary-digest-client"
    ],
    "tracked_effects_at_risk": [
      "ctx.provide(\"routeEndpoint\")",
      "tracked:direct:frost-stable",
      "ctx.provide(\"digestView\")",
      "tracked:transitive:derived:frost-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "granac-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
