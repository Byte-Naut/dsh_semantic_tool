The three-step recovery lifecycle plan has been executed and verified:

1. **`RESTORE_LAST_SUCCESSFUL`**: Restored `pkg-1` with mode `run` on plugin `quarrc-1`, successfully re-establishing dynamic service visibility.
2. **`DEFINE_REPAIRED_PACKAGE`**: Defined corrected package `pkg-3` under plugin `quarrc-1` removing the pre-publication defect.
3. **`UPDATE_TO_REPAIRED_PACKAGE`**: Updated plugin `quarrc-1` to `pkg-3` with mode `update`, observing service value `"crimson-repaired"`.
4. **Verification**: Checked transitive recovery via semantic query, confirming `activeRun` is present on `pkg-3`, and both `quarry-signal-adapter` (direct consumer) and `quarry-view-client` (transitive consumer) are `active`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "quarrc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "crimson-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
