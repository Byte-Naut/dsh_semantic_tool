Evidence obligations for Turn 1 have been established:

1. **Last successful immutable Package**: `pkg-1`
2. **Failed target Package**: `pkg-2`
3. **Active Run status**: `KNOWN_ABSENT` (`package_id: null`)
4. **Direct consumer(s)**: `quarry-signal-adapter`
5. **Transitive consumer(s)**: `quarry-view-client`
6. **Tracked effects at risk**:
   - `ctx.provide("signalEndpoint")` (`effect:rt:m1-transitive-recovery-s03:32`)
   - `ctx.provide("viewView")` (`effect:rt:m1-transitive-recovery-s03:35`)
   - `tracked:direct:crimson-stable` (`effect:rt:m1-transitive-recovery-s03:34`)
   - `tracked:transitive:derived:crimson-stable` (`effect:rt:m1-transitive-recovery-s03:38`)
7. **Failed Package source defect**: In `pkg-2`, `apply(ctx)` throws an error (`crimson bootstrap failed before publication`) before calling `ctx.provide("signalEndpoint", intended)`. Classified as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "quarry-signal-adapter"
    ],
    "transitive_consumers": [
      "quarry-view-client"
    ],
    "tracked_effects_at_risk": [
      "ctx.provide(\"signalEndpoint\")",
      "ctx.provide(\"viewView\")",
      "tracked:direct:crimson-stable",
      "tracked:transitive:derived:crimson-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "quarrc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
