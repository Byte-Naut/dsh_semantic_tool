We have established all seven evidence obligations based on raw observations from the runtime:

1. **Last successful Package:** `pkg-1` (`tundrc stable package`), serving `recordEndpoint` at version `kelp-stable`.
2. **Failed target Package:** `pkg-2` (`tundrc failed target`), which failed during host load on run `run-2`.
3. **Active Run status:** `KNOWN_ABSENT` (`latestRun` failed at host load phase; no live active run exists for plugin `tundrc-1`).
4. **Direct consumer:** `tundra-record-adapter`, which directly injects `recordEndpoint` and is currently in a `pending` state with bindings uncommitted.
5. **Transitive consumer:** `tundra-display-client`, which injects `displayView` derived from `tundra-record-adapter` and is also in a `pending` state.
6. **Tracked effects at risk:** `tracked:direct:kelp-stable` (registered by `tundra-record-adapter`) and `tracked:transitive:derived:kelp-stable` (registered by `tundra-display-client`).
7. **Source defect diagnosis:** Inspected package `pkg-2`. The entrypoint throws an error (`throw new Error("kelp bootstrap failed before publication")`) before `ctx.provide("recordEndpoint", intended)` is executed, classified as `THROW_BEFORE_PUBLISH`.

```json
{
  "facts": {
    "last_successful_package_id": "pkg-1",
    "failed_target_package_id": "pkg-2",
    "active_run": {
      "kind": "KNOWN_ABSENT",
      "package_id": null
    },
    "direct_consumers": [
      "tundra-record-adapter"
    ],
    "transitive_consumers": [
      "tundra-display-client"
    ],
    "tracked_effects_at_risk": [
      "tracked:direct:kelp-stable",
      "tracked:transitive:derived:kelp-stable"
    ]
  },
  "source_diagnosis": {
    "failed_package_inspected": true,
    "defect_code": "THROW_BEFORE_PUBLISH"
  },
  "plan": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "tundrc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "NEW_PACKAGE",
      "mode": "update"
    }
  ],
  "unknowns": []
}
```
