The three-step recovery lifecycle was executed in order:
1. Restored the last successful immutable package `pkg-1` with mode `run`.
2. Defined corrected immutable package `pkg-3` under existing plugin `tundrc-1`.
3. Updated to `pkg-3` with mode `update`.

Verification shows that:
- The active package is `pkg-3` with `recordEndpoint` serving version `kelp-repaired`.
- Direct consumer `tundra-record-adapter` transitioned to `active` state, committing the binding and tracking `tracked:direct:kelp-repaired`.
- Transitive consumer `tundra-display-client` transitioned to `active` state, committing `displayView` (`derived:kelp-repaired`) and tracking `tracked:transitive:derived:kelp-repaired`.

```json
{
  "status": "PASS",
  "actions": [
    {
      "action_id": "RESTORE_LAST_SUCCESSFUL",
      "target_id": "pkg-1",
      "mode": "run"
    },
    {
      "action_id": "DEFINE_REPAIRED_PACKAGE",
      "target_id": "tundrc-1",
      "mode": null
    },
    {
      "action_id": "UPDATE_TO_REPAIRED_PACKAGE",
      "target_id": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "active_package_id": "pkg-3",
    "service_value": "kelp-repaired",
    "direct_consumer_state": "active",
    "transitive_consumer_state": "active"
  },
  "remaining_unknowns": []
}
```
