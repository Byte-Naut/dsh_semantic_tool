export function deriveLifecycleView(observation) {
  const targetBinding = observation?.targetBinding
  const committedBinding = observation?.committedBinding
  const activeRun = observation?.activeRun
  const lastSuccessfulPackage = observation?.lastSuccessfulPackage
  const cleanupReceipt = observation?.cleanupReceipt

  let transitioning
  if (!targetBinding || targetBinding.kind === 'UNKNOWN' || !committedBinding || committedBinding.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (targetBinding.kind === 'KNOWN_ABSENT' && committedBinding.kind === 'KNOWN_ABSENT') {
    transitioning = 'FALSE'
  } else if (targetBinding.kind === 'KNOWN_VALUE' && committedBinding.kind === 'KNOWN_VALUE' && targetBinding.value === committedBinding.value) {
    transitioning = 'FALSE'
  } else {
    transitioning = 'TRUE'
  }

  let activeRunPresent
  if (activeRun?.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else if (activeRun?.kind === 'KNOWN_ABSENT') {
    activeRunPresent = 'FALSE'
  } else {
    activeRunPresent = 'UNKNOWN'
  }

  let cleanupComplete
  if (!cleanupReceipt || cleanupReceipt.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanupReceipt.kind === 'KNOWN_ABSENT') {
    cleanupComplete = 'FALSE'
  } else if (cleanupReceipt.kind === 'KNOWN_VALUE' && cleanupReceipt.value === 'DISPOSED') {
    cleanupComplete = 'TRUE'
  } else {
    cleanupComplete = 'FALSE'
  }

  let providerAction
  if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else if (transitioning === 'FALSE') {
    providerAction = 'NO_ACTION'
  } else {
    providerAction = 'DEFER_FOR_EVIDENCE'
  }

  let packageAction
  if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else {
    if (lastSuccessfulPackage?.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else if (lastSuccessfulPackage?.kind === 'KNOWN_ABSENT') {
      packageAction = 'NO_ACTION'
    } else {
      packageAction = 'DEFER_FOR_EVIDENCE'
    }
  }

  function strictNot(v) {
    if (v === 'TRUE') return 'FALSE'
    if (v === 'FALSE') return 'TRUE'
    return 'UNKNOWN'
  }

  function strictAnd(a, b) {
    if (a === 'UNKNOWN' || b === 'UNKNOWN') return 'UNKNOWN'
    if (a === 'TRUE' && b === 'TRUE') return 'TRUE'
    return 'FALSE'
  }

  function actionGuard(value, namedAction) {
    if (value === 'TRUE') return namedAction
    if (value === 'FALSE') return 'NO_ACTION'
    return 'DEFER_FOR_EVIDENCE'
  }

  const handoffComplete = strictAnd(strictNot(transitioning), cleanupComplete)
  const handoffAction = actionGuard(handoffComplete, 'FINALIZE_HANDOFF')

  const recoveryAllowed = strictAnd(strictNot(activeRunPresent), handoffComplete)
  const recoveryAction = actionGuard(recoveryAllowed, 'FINALIZE_RECOVERY')

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
    handoffComplete,
    handoffAction,
    recoveryAllowed,
    recoveryAction,
  }
}
