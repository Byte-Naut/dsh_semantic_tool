function STRICT_NOT(val) {
  if (val === 'TRUE') return 'FALSE'
  if (val === 'FALSE') return 'TRUE'
  return 'UNKNOWN'
}

function STRICT_AND(x, y) {
  if (x === 'UNKNOWN' || y === 'UNKNOWN') return 'UNKNOWN'
  if (x === 'TRUE' && y === 'TRUE') return 'TRUE'
  return 'FALSE'
}

function actionGuard(guardVal, namedAction) {
  if (guardVal === 'TRUE') return namedAction
  if (guardVal === 'FALSE') return 'NO_ACTION'
  return 'DEFER_FOR_EVIDENCE'
}

export function deriveLifecycleView(observation) {
  const targetBinding = observation?.targetBinding
  const committedBinding = observation?.committedBinding
  const activeRun = observation?.activeRun
  const lastSuccessfulPackage = observation?.lastSuccessfulPackage
  const cleanupReceipt = observation?.cleanupReceipt

  // transitioning
  let transitioning
  if (!targetBinding || !committedBinding || targetBinding.kind === 'UNKNOWN' || committedBinding.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (targetBinding.kind === 'KNOWN_ABSENT' && committedBinding.kind === 'KNOWN_ABSENT') {
    transitioning = 'FALSE'
  } else if (targetBinding.kind === 'KNOWN_VALUE' && committedBinding.kind === 'KNOWN_VALUE') {
    transitioning = targetBinding.value === committedBinding.value ? 'FALSE' : 'TRUE'
  } else {
    transitioning = 'TRUE'
  }

  // activeRunPresent
  let activeRunPresent
  if (!activeRun || activeRun.kind === 'UNKNOWN') {
    activeRunPresent = 'UNKNOWN'
  } else if (activeRun.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else {
    activeRunPresent = 'FALSE'
  }

  // cleanupComplete
  let cleanupComplete
  if (!cleanupReceipt || cleanupReceipt.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanupReceipt.kind === 'KNOWN_ABSENT') {
    cleanupComplete = 'FALSE'
  } else if (cleanupReceipt.kind === 'KNOWN_VALUE') {
    cleanupComplete = cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  } else {
    cleanupComplete = 'UNKNOWN'
  }

  // providerAction
  let providerAction
  if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else if (transitioning === 'FALSE') {
    providerAction = 'NO_ACTION'
  } else {
    providerAction = 'DEFER_FOR_EVIDENCE'
  }

  // packageAction
  let packageAction
  if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else {
    // activeRunPresent === 'FALSE'
    if (!lastSuccessfulPackage || lastSuccessfulPackage.kind === 'UNKNOWN') {
      packageAction = 'DEFER_FOR_EVIDENCE'
    } else if (lastSuccessfulPackage.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else {
      packageAction = 'NO_ACTION'
    }
  }

  // Tier 1
  const handoffComplete = STRICT_AND(STRICT_NOT(transitioning), cleanupComplete)
  const handoffAction = actionGuard(handoffComplete, 'FINALIZE_HANDOFF')

  // Tier 2
  const recoveryAllowed = STRICT_AND(STRICT_NOT(activeRunPresent), handoffComplete)
  const recoveryAction = actionGuard(recoveryAllowed, 'FINALIZE_RECOVERY')

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
    handoffComplete,
    handoffAction,
    recoveryAllowed,
    recoveryAction,
  }
}
