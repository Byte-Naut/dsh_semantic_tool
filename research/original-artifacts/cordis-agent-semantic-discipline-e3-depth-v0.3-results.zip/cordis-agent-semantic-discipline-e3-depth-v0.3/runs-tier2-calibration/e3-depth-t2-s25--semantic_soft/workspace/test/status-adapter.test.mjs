import assert from 'node:assert/strict'
import test from 'node:test'
import { deriveLifecycleView } from '../src/status-adapter.mjs'

const value = value => ({ kind: 'KNOWN_VALUE', value })
const absent = () => ({ kind: 'KNOWN_ABSENT' })

test('fully known replacement remains decisive', () => {
  assert.deepEqual(deriveLifecycleView({
    targetBinding: value('provider-v2'), committedBinding: value('provider-v1'),
    activeRun: value('package-v1'), lastSuccessfulPackage: value('package-v1'),
    cleanupReceipt: value('DISPOSED'),
  }), {
  "transitioning": "TRUE",
  "activeRunPresent": "TRUE",
  "cleanupComplete": "TRUE",
  "providerAction": "ALLOW_CURRENT_LOAD_TO_SETTLE",
  "packageAction": "NO_ACTION",
  "handoffComplete": "FALSE",
  "handoffAction": "NO_ACTION",
  "recoveryAllowed": "FALSE",
  "recoveryAction": "NO_ACTION"
})
})

test('fully known ready state remains decisive', () => {
  assert.deepEqual(deriveLifecycleView({
    targetBinding: value('provider-v2'), committedBinding: value('provider-v2'),
    activeRun: absent(), lastSuccessfulPackage: value('package-v1'),
    cleanupReceipt: value('DISPOSED'),
  }), {
  "transitioning": "FALSE",
  "activeRunPresent": "FALSE",
  "cleanupComplete": "TRUE",
  "providerAction": "NO_ACTION",
  "packageAction": "RUN_LAST_SUCCESSFUL",
  "handoffComplete": "TRUE",
  "handoffAction": "FINALIZE_HANDOFF",
  "recoveryAllowed": "TRUE",
  "recoveryAction": "FINALIZE_RECOVERY"
})
})
