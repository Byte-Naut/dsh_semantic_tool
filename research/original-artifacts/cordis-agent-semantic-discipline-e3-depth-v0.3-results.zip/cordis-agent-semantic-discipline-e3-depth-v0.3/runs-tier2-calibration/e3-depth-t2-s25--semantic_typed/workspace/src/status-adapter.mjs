function strictNot(val) {
  if (val === 'TRUE') return 'FALSE'
  if (val === 'FALSE') return 'TRUE'
  return 'UNKNOWN'
}

function strictAnd(a, b) {
  if (a === 'UNKNOWN' || b === 'UNKNOWN') return 'UNKNOWN'
  if (a === 'TRUE' && b === 'TRUE') return 'TRUE'
  return 'FALSE'
}

function actionGuard(val, trueAction) {
  if (val === 'TRUE') return trueAction
  if (val === 'FALSE') return 'NO_ACTION'
  return 'DEFER_FOR_EVIDENCE'
}

export function deriveLifecycleView(observation) {
  const {
    targetBinding,
    committedBinding,
    activeRun,
    lastSuccessfulPackage,
    cleanupReceipt,
  } = observation

  let transitioning
  if (targetBinding?.kind === 'UNKNOWN' || committedBinding?.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (targetBinding?.kind === 'KNOWN_ABSENT' && committedBinding?.kind === 'KNOWN_ABSENT') {
    transitioning = 'FALSE'
  } else if (targetBinding?.kind === 'KNOWN_VALUE' && committedBinding?.kind === 'KNOWN_VALUE') {
    transitioning = targetBinding.value === committedBinding.value ? 'FALSE' : 'TRUE'
  } else {
    transitioning = 'TRUE'
  }

  let activeRunPresent
  if (activeRun?.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else if (activeRun?.kind === 'KNOWN_ABSENT') {
    activeRunPresent = 'FALSE'
  } else {
    activeRunPresent = 'UNKNOWN'
  }

  let cleanupComplete
  if (cleanupReceipt?.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanupReceipt?.kind === 'KNOWN_ABSENT') {
    cleanupComplete = 'FALSE'
  } else if (cleanupReceipt?.kind === 'KNOWN_VALUE') {
    cleanupComplete = cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  } else {
    cleanupComplete = 'UNKNOWN'
  }

  const providerAction = actionGuard(transitioning, 'ALLOW_CURRENT_LOAD_TO_SETTLE')

  let packageAction
  if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else {
    if (lastSuccessfulPackage?.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else if (lastSuccessfulPackage?.kind === 'KNOWN_ABSENT') {
      packageAction = 'NO_ACTION'
    } else {
      packageAction = 'DEFER_FOR_EVIDENCE'
    }
  }

  const handoffComplete = strictAnd(strictNot(transitioning), cleanupComplete)
  const handoffAction = actionGuard(handoffComplete, 'FINALIZE_HANDOFF')

  const recoveryAllowed = strictAnd(strictNot(activeRunPresent), handoffComplete)
  const recoveryAction = actionGuard(recoveryAllowed, 'FINALIZE_RECOVERY')

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
    handoffComplete,
    handoffAction,
    recoveryAllowed,
    recoveryAction,
  }
}
