# Cordis Agent Semantic Discipline — E3 Transformation Depth v0.3

This benchmark uses one byte-identical normalized lifecycle world and increases only the depth of downstream three-valued transformation:

- Tier 1 derives `handoffComplete`.
- Tier 2 additionally derives `recoveryAllowed`.
- Tier 3 additionally derives `serviceAdvertisable`.

Both arms receive the same public contract, task, workspace, model configuration, seed, and semantic observation. `semantic_typed` alone receives a checker that mechanically evaluates the public contract without observing new world facts.

The ladder is finite and preregistered. Each tier starts with two new paired calibration seeds. A clean Soft-vs-Typed contrast selects that tier for six untouched held-out pairs. A clean tie advances one tier. Invalidity stops the ladder. A tie through Tier 3 establishes a bounded Soft ceiling and ends E3; no deeper task is synthesized post hoc.

Commands:

```bash
npm test
npm run freeze
npm run validate
node runner/run-experiment.mjs --key-stdin
npm run analyze
```
