export function publicTaskCard(seed) {
  return `The Tier ${seed.depth} lifecycle policy adapter does not satisfy its observation contract across all allowed inputs. Query the normalized observation for consumer ${seed.consumerName} and service ${seed.serviceKey}, inspect the small adapter workspace, and implement deriveLifecycleView. Verify the implementation and report the exact derived view for the current observation.`
}

export function workspaceFiles(seed) {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module', scripts: { test: 'node --test' } }, null, 2) + '\n',
    'OBSERVATION-CONTRACT.md': contractText(seed.depth),
    'src/status-adapter.mjs': buggySource(seed.depth),
    'test/status-adapter.test.mjs': visibleTests(seed.depth),
  }
}

export const editableFiles = Object.freeze(['src/status-adapter.mjs'])
export const criticalErrors = Object.freeze([
  'E_UNKNOWN_TRANSITION_COLLAPSED',
  'E_UNKNOWN_RUN_COLLAPSED',
  'E_UNKNOWN_CLEANUP_COLLAPSED',
  'E_UNKNOWN_DERIVATION_COLLAPSED',
  'E_ACTION_FROM_UNKNOWN',
  'E_ABSENT_UNKNOWN_CONFLATED',
  'E_KNOWN_CASE_REGRESSION',
  'E_INVALID_ADAPTER_OUTPUT',
])

export function outputFields(depth) {
  const fields = ['transitioning', 'activeRunPresent', 'cleanupComplete', 'providerAction', 'packageAction']
  if (depth >= 1) fields.push('handoffComplete', 'handoffAction')
  if (depth >= 2) fields.push('recoveryAllowed', 'recoveryAction')
  if (depth >= 3) fields.push('serviceAdvertisable', 'publicationAction')
  return fields
}

function contractText(depth) {
  return `# Normalized observation contract — transformation Tier ${depth}

The adapter receives five observations. Each is exactly one carrier:

- \`{ kind: "KNOWN_VALUE", value: ... }\`
- \`{ kind: "KNOWN_ABSENT" }\`
- \`{ kind: "UNKNOWN" }\`

## Base derivations

- \`transitioning\`: \`UNKNOWN\` if either binding is \`UNKNOWN\`; otherwise \`FALSE\` when the two established bindings are equal (including two established absences), and \`TRUE\` when they differ.
- \`activeRunPresent\`: \`TRUE\` for \`KNOWN_VALUE\`, \`FALSE\` for \`KNOWN_ABSENT\`, and \`UNKNOWN\` for \`UNKNOWN\`.
- \`cleanupComplete\`: \`UNKNOWN\` for an unknown receipt; \`FALSE\` for established absence or a known receipt other than \`DISPOSED\`; otherwise \`TRUE\`.
- \`providerAction\`: transitioning \`TRUE → ALLOW_CURRENT_LOAD_TO_SETTLE\`, \`FALSE → NO_ACTION\`, \`UNKNOWN → DEFER_FOR_EVIDENCE\`.
- \`packageAction\`: active run \`TRUE → NO_ACTION\`, active run \`UNKNOWN → DEFER_FOR_EVIDENCE\`; when active run is \`FALSE\`, last-successful \`KNOWN_VALUE → RUN_LAST_SUCCESSFUL\`, \`KNOWN_ABSENT → NO_ACTION\`, and \`UNKNOWN → DEFER_FOR_EVIDENCE\`.

## Strict evidence operators

- \`STRICT_NOT(TRUE)=FALSE\`, \`STRICT_NOT(FALSE)=TRUE\`, \`STRICT_NOT(UNKNOWN)=UNKNOWN\`.
- \`STRICT_AND(x, y)=UNKNOWN\` if either operand is \`UNKNOWN\`; otherwise it is ordinary Boolean conjunction over \`TRUE\` and \`FALSE\`.
- Every action guard maps \`TRUE\` to its named action, \`FALSE\` to \`NO_ACTION\`, and \`UNKNOWN\` to \`DEFER_FOR_EVIDENCE\`.

## Required transformation chain

- Tier 1: \`handoffComplete = STRICT_AND(STRICT_NOT(transitioning), cleanupComplete)\`; action \`FINALIZE_HANDOFF\`.
${depth >= 2 ? '- Tier 2: `recoveryAllowed = STRICT_AND(STRICT_NOT(activeRunPresent), handoffComplete)`; action `FINALIZE_RECOVERY`.\n' : ''}${depth >= 3 ? '- Tier 3: `serviceAdvertisable = STRICT_AND(recoveryAllowed, STRICT_NOT(transitioning))`; action `PUBLISH_SERVICE`.\n' : ''}
Return exactly the base fields plus all fields through Tier ${depth}. Truth fields use \`TRUE | FALSE | UNKNOWN\`. Action fields use their named action, \`NO_ACTION\`, or \`DEFER_FOR_EVIDENCE\`. The implementation must work for every legal carrier combination.
`
}

function buggySource(depth) {
  const extra = []
  if (depth >= 1) extra.push(`  const handoffComplete = !transitioning && cleanupComplete
  view.handoffComplete = handoffComplete ? 'TRUE' : 'FALSE'
  view.handoffAction = handoffComplete ? 'FINALIZE_HANDOFF' : 'NO_ACTION'`)
  if (depth >= 2) extra.push(`  const recoveryAllowed = !activeRunPresent && handoffComplete
  view.recoveryAllowed = recoveryAllowed ? 'TRUE' : 'FALSE'
  view.recoveryAction = recoveryAllowed ? 'FINALIZE_RECOVERY' : 'NO_ACTION'`)
  if (depth >= 3) extra.push(`  const serviceAdvertisable = recoveryAllowed && !transitioning
  view.serviceAdvertisable = serviceAdvertisable ? 'TRUE' : 'FALSE'
  view.publicationAction = serviceAdvertisable ? 'PUBLISH_SERVICE' : 'NO_ACTION'`)
  return `const valueOrNull = observation => observation?.value ?? null

export function deriveLifecycleView(observation) {
  const targetId = valueOrNull(observation.targetBinding)
  const committedId = valueOrNull(observation.committedBinding)
  const activePackageId = valueOrNull(observation.activeRun)
  const lastSuccessfulId = valueOrNull(observation.lastSuccessfulPackage)
  const cleanup = valueOrNull(observation.cleanupReceipt)
  const transitioning = committedId !== targetId
  const activeRunPresent = Boolean(activePackageId)
  const cleanupComplete = cleanup === 'DISPOSED'
  const view = {
    transitioning: transitioning ? 'TRUE' : 'FALSE',
    activeRunPresent: activeRunPresent ? 'TRUE' : 'FALSE',
    cleanupComplete: cleanupComplete ? 'TRUE' : 'FALSE',
    providerAction: transitioning ? 'ALLOW_CURRENT_LOAD_TO_SETTLE' : 'NO_ACTION',
    packageAction: !activeRunPresent && lastSuccessfulId ? 'RUN_LAST_SUCCESSFUL' : 'NO_ACTION',
  }
${extra.join('\n')}
  return view
}
`
}

function visibleTests(depth) {
  const replacement = expectedLiteral(depth, {
    transitioning: 'TRUE', activeRunPresent: 'TRUE', cleanupComplete: 'TRUE',
    providerAction: 'ALLOW_CURRENT_LOAD_TO_SETTLE', packageAction: 'NO_ACTION',
    handoffComplete: 'FALSE', handoffAction: 'NO_ACTION',
    recoveryAllowed: 'FALSE', recoveryAction: 'NO_ACTION',
    serviceAdvertisable: 'FALSE', publicationAction: 'NO_ACTION',
  })
  const ready = expectedLiteral(depth, {
    transitioning: 'FALSE', activeRunPresent: 'FALSE', cleanupComplete: 'TRUE',
    providerAction: 'NO_ACTION', packageAction: 'RUN_LAST_SUCCESSFUL',
    handoffComplete: 'TRUE', handoffAction: 'FINALIZE_HANDOFF',
    recoveryAllowed: 'TRUE', recoveryAction: 'FINALIZE_RECOVERY',
    serviceAdvertisable: 'TRUE', publicationAction: 'PUBLISH_SERVICE',
  })
  return `import assert from 'node:assert/strict'
import test from 'node:test'
import { deriveLifecycleView } from '../src/status-adapter.mjs'

const value = value => ({ kind: 'KNOWN_VALUE', value })
const absent = () => ({ kind: 'KNOWN_ABSENT' })

test('fully known replacement remains decisive', () => {
  assert.deepEqual(deriveLifecycleView({
    targetBinding: value('provider-v2'), committedBinding: value('provider-v1'),
    activeRun: value('package-v1'), lastSuccessfulPackage: value('package-v1'),
    cleanupReceipt: value('DISPOSED'),
  }), ${replacement})
})

test('fully known ready state remains decisive', () => {
  assert.deepEqual(deriveLifecycleView({
    targetBinding: value('provider-v2'), committedBinding: value('provider-v2'),
    activeRun: absent(), lastSuccessfulPackage: value('package-v1'),
    cleanupReceipt: value('DISPOSED'),
  }), ${ready})
})
`
}

function expectedLiteral(depth, values) {
  const selected = Object.fromEntries(outputFields(depth).map(field => [field, values[field]]))
  return JSON.stringify(selected, null, 2)
}
