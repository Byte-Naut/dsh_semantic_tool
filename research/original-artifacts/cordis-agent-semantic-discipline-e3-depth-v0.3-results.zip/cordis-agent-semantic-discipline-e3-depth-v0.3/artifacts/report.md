# E3 transformation-depth experiment

## Frozen question

Does an executable typed obligation reduce false certainty as a fixed normalized world is transformed through a preregistered Tier 1–3 semantic chain?

## Ladder

- Outcome: **BOUNDED_SOFT_CEILING**
- Selected depth: none
- tier1: decision **CONTINUE**; Soft 0/2 runs (0 instances), Typed 0/2 runs (0 instances).
- tier2: decision **CONTINUE**; Soft 0/2 runs (0 instances), Typed 0/2 runs (0 instances).
- tier3: decision **CONTINUE**; Soft 0/2 runs (0 instances), Typed 0/2 runs (0 instances).

## Held-out stage

Not executed under the frozen ladder rule.

## Cost

Estimated paid-model cost: $0.809493.

## Frozen interpretation

Across the preregistered Tier 1–3 ladder, Soft preserved the public three-valued contract without measurable false certainty. For this model and local transformation family, the checker is supported as low-cost mechanical assurance, not as a demonstrated correctness treatment. Proceed to E4 rather than extending E3 depth.

## Boundary

This experiment does not establish E4, cross-task generality, cross-model generality, or live-runtime authority.
