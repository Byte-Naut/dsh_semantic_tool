The lifecycle policy adapter in `src/status-adapter.mjs` has been updated to fully comply with the transformation Tier 1 specification from `OBSERVATION-CONTRACT.md`. The implementation properly handles all legal carrier combinations (`KNOWN_VALUE`, `KNOWN_ABSENT`, `UNKNOWN`) and strict logic operations. All visible tests pass.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL",
    "handoffComplete": "UNKNOWN",
    "handoffAction": "DEFER_FOR_EVIDENCE"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "NOT_AVAILABLE"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
