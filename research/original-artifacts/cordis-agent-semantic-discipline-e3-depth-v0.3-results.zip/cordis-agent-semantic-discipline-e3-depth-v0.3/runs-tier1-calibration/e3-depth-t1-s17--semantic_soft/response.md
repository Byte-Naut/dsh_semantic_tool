The lifecycle policy adapter in `src/status-adapter.mjs` has been implemented to handle all carrier variants (`KNOWN_VALUE`, `KNOWN_ABSENT`, `UNKNOWN`) and strict operators as defined in `OBSERVATION-CONTRACT.md`. The visible test suite passes.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL",
    "handoffComplete": "UNKNOWN",
    "handoffAction": "DEFER_FOR_EVIDENCE"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "NOT_AVAILABLE"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
