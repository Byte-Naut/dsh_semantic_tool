function getTransitioning(target, committed) {
  if (!target || !committed || target.kind === 'UNKNOWN' || committed.kind === 'UNKNOWN') {
    return 'UNKNOWN'
  }
  if (target.kind === 'KNOWN_ABSENT' && committed.kind === 'KNOWN_ABSENT') {
    return 'FALSE'
  }
  if (target.kind === 'KNOWN_VALUE' && committed.kind === 'KNOWN_VALUE') {
    return target.value === committed.value ? 'FALSE' : 'TRUE'
  }
  return 'TRUE'
}

function getActiveRunPresent(activeRun) {
  if (!activeRun || activeRun.kind === 'UNKNOWN') {
    return 'UNKNOWN'
  }
  if (activeRun.kind === 'KNOWN_VALUE') {
    return 'TRUE'
  }
  return 'FALSE'
}

function getCleanupComplete(cleanupReceipt) {
  if (!cleanupReceipt || cleanupReceipt.kind === 'UNKNOWN') {
    return 'UNKNOWN'
  }
  if (cleanupReceipt.kind === 'KNOWN_ABSENT') {
    return 'FALSE'
  }
  if (cleanupReceipt.kind === 'KNOWN_VALUE') {
    return cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  }
  return 'FALSE'
}

function getProviderAction(transitioning) {
  if (transitioning === 'TRUE') {
    return 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  }
  if (transitioning === 'FALSE') {
    return 'NO_ACTION'
  }
  return 'DEFER_FOR_EVIDENCE'
}

function getPackageAction(activeRunPresent, lastSuccessfulPackage) {
  if (activeRunPresent === 'TRUE') {
    return 'NO_ACTION'
  }
  if (activeRunPresent === 'UNKNOWN') {
    return 'DEFER_FOR_EVIDENCE'
  }
  if (!lastSuccessfulPackage || lastSuccessfulPackage.kind === 'UNKNOWN') {
    return 'DEFER_FOR_EVIDENCE'
  }
  if (lastSuccessfulPackage.kind === 'KNOWN_VALUE') {
    return 'RUN_LAST_SUCCESSFUL'
  }
  if (lastSuccessfulPackage.kind === 'KNOWN_ABSENT') {
    return 'NO_ACTION'
  }
  return 'DEFER_FOR_EVIDENCE'
}

function strictNot(val) {
  if (val === 'TRUE') return 'FALSE'
  if (val === 'FALSE') return 'TRUE'
  return 'UNKNOWN'
}

function strictAnd(a, b) {
  if (a === 'UNKNOWN' || b === 'UNKNOWN') return 'UNKNOWN'
  if (a === 'TRUE' && b === 'TRUE') return 'TRUE'
  return 'FALSE'
}

function getHandoffAction(handoffComplete) {
  if (handoffComplete === 'TRUE') return 'FINALIZE_HANDOFF'
  if (handoffComplete === 'FALSE') return 'NO_ACTION'
  return 'DEFER_FOR_EVIDENCE'
}

export function deriveLifecycleView(observation) {
  const transitioning = getTransitioning(observation?.targetBinding, observation?.committedBinding)
  const activeRunPresent = getActiveRunPresent(observation?.activeRun)
  const cleanupComplete = getCleanupComplete(observation?.cleanupReceipt)
  const providerAction = getProviderAction(transitioning)
  const packageAction = getPackageAction(activeRunPresent, observation?.lastSuccessfulPackage)
  const handoffComplete = strictAnd(strictNot(transitioning), cleanupComplete)
  const handoffAction = getHandoffAction(handoffComplete)

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
    handoffComplete,
    handoffAction,
  }
}
