# Normalized observation contract — transformation Tier 1

The adapter receives five observations. Each is exactly one carrier:

- `{ kind: "KNOWN_VALUE", value: ... }`
- `{ kind: "KNOWN_ABSENT" }`
- `{ kind: "UNKNOWN" }`

## Base derivations

- `transitioning`: `UNKNOWN` if either binding is `UNKNOWN`; otherwise `FALSE` when the two established bindings are equal (including two established absences), and `TRUE` when they differ.
- `activeRunPresent`: `TRUE` for `KNOWN_VALUE`, `FALSE` for `KNOWN_ABSENT`, and `UNKNOWN` for `UNKNOWN`.
- `cleanupComplete`: `UNKNOWN` for an unknown receipt; `FALSE` for established absence or a known receipt other than `DISPOSED`; otherwise `TRUE`.
- `providerAction`: transitioning `TRUE → ALLOW_CURRENT_LOAD_TO_SETTLE`, `FALSE → NO_ACTION`, `UNKNOWN → DEFER_FOR_EVIDENCE`.
- `packageAction`: active run `TRUE → NO_ACTION`, active run `UNKNOWN → DEFER_FOR_EVIDENCE`; when active run is `FALSE`, last-successful `KNOWN_VALUE → RUN_LAST_SUCCESSFUL`, `KNOWN_ABSENT → NO_ACTION`, and `UNKNOWN → DEFER_FOR_EVIDENCE`.

## Strict evidence operators

- `STRICT_NOT(TRUE)=FALSE`, `STRICT_NOT(FALSE)=TRUE`, `STRICT_NOT(UNKNOWN)=UNKNOWN`.
- `STRICT_AND(x, y)=UNKNOWN` if either operand is `UNKNOWN`; otherwise it is ordinary Boolean conjunction over `TRUE` and `FALSE`.
- Every action guard maps `TRUE` to its named action, `FALSE` to `NO_ACTION`, and `UNKNOWN` to `DEFER_FOR_EVIDENCE`.

## Required transformation chain

- Tier 1: `handoffComplete = STRICT_AND(STRICT_NOT(transitioning), cleanupComplete)`; action `FINALIZE_HANDOFF`.

Return exactly the base fields plus all fields through Tier 1. Truth fields use `TRUE | FALSE | UNKNOWN`. Action fields use their named action, `NO_ACTION`, or `DEFER_FOR_EVIDENCE`. The implementation must work for every legal carrier combination.
