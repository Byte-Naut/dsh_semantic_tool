function strictNot(v) {
  if (v === 'TRUE') return 'FALSE'
  if (v === 'FALSE') return 'TRUE'
  return 'UNKNOWN'
}

function strictAnd(a, b) {
  if (a === 'UNKNOWN' || b === 'UNKNOWN') return 'UNKNOWN'
  if (a === 'TRUE' && b === 'TRUE') return 'TRUE'
  return 'FALSE'
}

function actionGuard(v, namedAction) {
  if (v === 'TRUE') return namedAction
  if (v === 'FALSE') return 'NO_ACTION'
  return 'DEFER_FOR_EVIDENCE'
}

function deriveTransitioning(target, committed) {
  if (!target || !committed || target.kind === 'UNKNOWN' || committed.kind === 'UNKNOWN') {
    return 'UNKNOWN'
  }
  if (target.kind === 'KNOWN_ABSENT' && committed.kind === 'KNOWN_ABSENT') {
    return 'FALSE'
  }
  if (target.kind === 'KNOWN_VALUE' && committed.kind === 'KNOWN_VALUE') {
    return target.value === committed.value ? 'FALSE' : 'TRUE'
  }
  return 'TRUE'
}

function deriveActiveRunPresent(activeRun) {
  if (!activeRun || activeRun.kind === 'UNKNOWN') {
    return 'UNKNOWN'
  }
  if (activeRun.kind === 'KNOWN_VALUE') {
    return 'TRUE'
  }
  if (activeRun.kind === 'KNOWN_ABSENT') {
    return 'FALSE'
  }
  return 'UNKNOWN'
}

function deriveCleanupComplete(cleanupReceipt) {
  if (!cleanupReceipt || cleanupReceipt.kind === 'UNKNOWN') {
    return 'UNKNOWN'
  }
  if (cleanupReceipt.kind === 'KNOWN_ABSENT') {
    return 'FALSE'
  }
  if (cleanupReceipt.kind === 'KNOWN_VALUE') {
    return cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  }
  return 'UNKNOWN'
}

function derivePackageAction(activeRunPresent, lastSuccessfulPackage) {
  if (activeRunPresent === 'TRUE') {
    return 'NO_ACTION'
  }
  if (activeRunPresent === 'UNKNOWN') {
    return 'DEFER_FOR_EVIDENCE'
  }
  if (!lastSuccessfulPackage || lastSuccessfulPackage.kind === 'UNKNOWN') {
    return 'DEFER_FOR_EVIDENCE'
  }
  if (lastSuccessfulPackage.kind === 'KNOWN_VALUE') {
    return 'RUN_LAST_SUCCESSFUL'
  }
  if (lastSuccessfulPackage.kind === 'KNOWN_ABSENT') {
    return 'NO_ACTION'
  }
  return 'DEFER_FOR_EVIDENCE'
}

export function deriveLifecycleView(observation) {
  const transitioning = deriveTransitioning(observation?.targetBinding, observation?.committedBinding)
  const activeRunPresent = deriveActiveRunPresent(observation?.activeRun)
  const cleanupComplete = deriveCleanupComplete(observation?.cleanupReceipt)
  const providerAction = actionGuard(transitioning, 'ALLOW_CURRENT_LOAD_TO_SETTLE')
  const packageAction = derivePackageAction(activeRunPresent, observation?.lastSuccessfulPackage)

  const handoffComplete = strictAnd(strictNot(transitioning), cleanupComplete)
  const handoffAction = actionGuard(handoffComplete, 'FINALIZE_HANDOFF')

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
    handoffComplete,
    handoffAction,
  }
}
