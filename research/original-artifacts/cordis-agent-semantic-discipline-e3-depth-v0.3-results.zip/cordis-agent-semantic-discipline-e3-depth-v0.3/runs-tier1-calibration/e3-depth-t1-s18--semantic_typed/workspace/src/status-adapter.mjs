function strictNot(val) {
  if (val === 'TRUE') return 'FALSE'
  if (val === 'FALSE') return 'TRUE'
  return 'UNKNOWN'
}

function strictAnd(a, b) {
  if (a === 'UNKNOWN' || b === 'UNKNOWN') return 'UNKNOWN'
  if (a === 'TRUE' && b === 'TRUE') return 'TRUE'
  return 'FALSE'
}

function areBindingsEqual(b1, b2) {
  if (b1.kind === 'KNOWN_ABSENT' && b2.kind === 'KNOWN_ABSENT') return true
  if (b1.kind === 'KNOWN_VALUE' && b2.kind === 'KNOWN_VALUE') {
    return b1.value === b2.value
  }
  return false
}

export function deriveLifecycleView(observation) {
  const targetBinding = observation?.targetBinding ?? { kind: 'UNKNOWN' }
  const committedBinding = observation?.committedBinding ?? { kind: 'UNKNOWN' }
  const activeRun = observation?.activeRun ?? { kind: 'UNKNOWN' }
  const lastSuccessfulPackage = observation?.lastSuccessfulPackage ?? { kind: 'UNKNOWN' }
  const cleanupReceipt = observation?.cleanupReceipt ?? { kind: 'UNKNOWN' }

  let transitioning
  if (targetBinding.kind === 'UNKNOWN' || committedBinding.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (areBindingsEqual(targetBinding, committedBinding)) {
    transitioning = 'FALSE'
  } else {
    transitioning = 'TRUE'
  }

  let activeRunPresent
  if (activeRun.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else if (activeRun.kind === 'KNOWN_ABSENT') {
    activeRunPresent = 'FALSE'
  } else {
    activeRunPresent = 'UNKNOWN'
  }

  let cleanupComplete
  if (cleanupReceipt.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanupReceipt.kind === 'KNOWN_VALUE' && cleanupReceipt.value === 'DISPOSED') {
    cleanupComplete = 'TRUE'
  } else {
    cleanupComplete = 'FALSE'
  }

  let providerAction
  if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else if (transitioning === 'FALSE') {
    providerAction = 'NO_ACTION'
  } else {
    providerAction = 'DEFER_FOR_EVIDENCE'
  }

  let packageAction
  if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else {
    if (lastSuccessfulPackage.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else if (lastSuccessfulPackage.kind === 'KNOWN_ABSENT') {
      packageAction = 'NO_ACTION'
    } else {
      packageAction = 'DEFER_FOR_EVIDENCE'
    }
  }

  const handoffComplete = strictAnd(strictNot(transitioning), cleanupComplete)

  let handoffAction
  if (handoffComplete === 'TRUE') {
    handoffAction = 'FINALIZE_HANDOFF'
  } else if (handoffComplete === 'FALSE') {
    handoffAction = 'NO_ACTION'
  } else {
    handoffAction = 'DEFER_FOR_EVIDENCE'
  }

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
    handoffComplete,
    handoffAction,
  }
}
