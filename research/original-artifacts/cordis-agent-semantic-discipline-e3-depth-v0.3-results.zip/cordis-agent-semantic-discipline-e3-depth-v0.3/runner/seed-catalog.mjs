import { allSeedNumbers, depthForSeedNumber } from '../src/config.mjs'

const WORLD = Object.freeze({
  serviceKey: 'depthEndpoint',
  consumerName: 'depth-consumer',
  providerV1: 'provider-v1',
  providerV2: 'provider-v2',
  packageV1: 'package-v1',
})

export function seedByNumber(number) {
  if (!allSeedNumbers().includes(number)) throw new Error(`unknown seed number: ${number}`)
  const depth = depthForSeedNumber(number)
  return Object.freeze({
    number,
    depth,
    seedId: `e3-depth-t${depth}-s${String(number).padStart(2, '0')}`,
    ...WORLD,
  })
}

export function seeds(numbers) {
  return numbers.map(seedByNumber)
}

export function pairedOrder(numbers) {
  return numbers.flatMap(number => {
    const seed = seedByNumber(number)
    const arms = number % 2 ? ['semantic_typed', 'semantic_soft'] : ['semantic_soft', 'semantic_typed']
    return arms.map(arm => ({ seed, arm }))
  })
}
