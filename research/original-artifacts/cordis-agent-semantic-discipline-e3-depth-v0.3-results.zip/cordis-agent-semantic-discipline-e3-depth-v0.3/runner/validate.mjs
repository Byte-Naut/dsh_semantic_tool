import { mkdir, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { allSeedNumbers, EXPERIMENT, modelSeed, TASK_ID, TIER_PLANS } from '../src/config.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { commonSystemPrompt } from '../src/common-prompt.mjs'
import { createRuntime, taskCard, taskEditableFiles, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { normalizedSnapshot, referenceSource } from '../tasks/e3-transformation-depth-adapter/fixture.mjs'
import { seedByNumber, seeds } from './seed-catalog.mjs'

const preregistration = JSON.parse(await import('node:fs/promises').then(fs => fs.readFile('artifacts/preregistration.json', 'utf8')))
const sourceTree = await hashTree('.', { exclude: excludedFromFreeze })
assert(sourceTree.hash === preregistration.sourceTree.hash, 'source changed after freeze')
assert(hashJson(normalizedSnapshot()) === preregistration.fixedWorldFactHash, 'fixed normalized world differs from preregistration')
assert(new Set(allSeedNumbers().map(modelSeed)).size === allSeedNumbers().length, 'model seeds are not unique')

const validations = []
const observedWorldHashes = new Set()
await mkdir('validation-workspaces', { recursive: false })
for (const plan of TIER_PLANS) {
  const tierSeeds = seeds([...plan.calibrationSeedNumbers, ...plan.heldOutSeedNumbers])
  const first = tierSeeds[0]
  const tierCardHash = hashJson(taskCard(TASK_ID, first))
  const tierWorkspaceHash = hashJson(taskWorkspaceFiles(TASK_ID, first))
  assert(hashJson(commonSystemPrompt(plan.depth)) === preregistration.tiers[`tier${plan.depth}`].commonPromptHash, `Tier ${plan.depth}: common prompt drift`)
  for (const seed of tierSeeds) {
    assert(hashJson(taskCard(TASK_ID, seed)) === tierCardHash, `${seed.seedId}: task card changes within tier`)
    assert(hashJson(taskWorkspaceFiles(TASK_ID, seed)) === tierWorkspaceHash, `${seed.seedId}: workspace changes within tier`)
    const workspace = resolve('validation-workspaces', seed.seedId)
    await materializeWorkspace(workspace, taskWorkspaceFiles(TASK_ID, seed))
    const runtime = await createRuntime(TASK_ID, seed, workspace)
    const initial = await runtime.grade()
    assert(initial.falseCertaintyCount > 0, `${seed.seedId}: scaffold does not expose false certainty`)
    assert(initial.knownCaseErrorCount === 0, `${seed.seedId}: scaffold confounds known-case correctness`)
    assert(initial.invalidOutputCount === 0, `${seed.seedId}: scaffold has invalid output shape`)
    const caught = await runtime.typedObligationCheck()
    assert(caught.status === 'FAIL' && caught.falseCertaintyCount > 0, `${seed.seedId}: checker did not catch scaffold`)

    await writeFile(join(workspace, 'src/status-adapter.mjs'), referenceSource(seed.depth))
    const reference = await runtime.grade()
    const checked = await runtime.typedObligationCheck()
    assert(reference.fullPass, `${seed.seedId}: reference solution failed`)
    assert(checked.status === 'PASS', `${seed.seedId}: checker rejected reference`)

    const softRuntime = await createRuntime(TASK_ID, seed, workspace)
    const typedRuntime = await createRuntime(TASK_ID, seed, workspace)
    const softRegistry = createToolRegistry({ arm: 'semantic_soft', runtime: softRuntime, workspace, editableFiles: taskEditableFiles(TASK_ID), telemetry: new Telemetry(`validate:${seed.seedId}:soft`) })
    const typedRegistry = createToolRegistry({ arm: 'semantic_typed', runtime: typedRuntime, workspace, editableFiles: taskEditableFiles(TASK_ID), telemetry: new Telemetry(`validate:${seed.seedId}:typed`) })
    const softCommon = softRegistry.declarations.filter(row => row.name !== 'typed_obligation_check')
    const typedCommon = typedRegistry.declarations.filter(row => row.name !== 'typed_obligation_check')
    assert(hashJson(softCommon) === hashJson(typedCommon), `${seed.seedId}: non-treatment tool drift`)
    assert(!softRegistry.declarations.some(row => row.name === 'typed_obligation_check'), `${seed.seedId}: checker leaked to Soft`)
    const checker = typedRegistry.declarations.find(row => row.name === 'typed_obligation_check')
    assert(Boolean(checker), `${seed.seedId}: Typed checker missing`)
    assert(!/UNKNOWN|KNOWN_ABSENT|STRICT_AND|DEFER_FOR_EVIDENCE/.test(checker.description), `${seed.seedId}: checker tool description leaks contract rules`)
    const query = { query: 'current_lifecycle_observation', subject: { consumer: seed.consumerName, service: seed.serviceKey } }
    const softWorld = softRuntime.semanticQuery(query)
    const typedWorld = typedRuntime.semanticQuery(query)
    const worldHash = hashJson(softWorld)
    observedWorldHashes.add(worldHash)
    assert(worldHash === hashJson(typedWorld), `${seed.seedId}: normalized facts differ by arm`)
    assert(worldHash === preregistration.fixedWorldFactHash, `${seed.seedId}: normalized facts differ by seed or tier`)
    validations.push({
      seedId: seed.seedId,
      depth: seed.depth,
      modelSeed: modelSeed(seed.number),
      normalizedWorldHash: worldHash,
      scaffoldFalseCertaintyCount: initial.falseCertaintyCount,
      scaffoldKnownCaseErrors: initial.knownCaseErrorCount,
      referencePass: reference.fullPass,
      checkerCatchesScaffold: caught.status === 'FAIL',
      checkerAcceptsReference: checked.status === 'PASS',
      commonToolsIdentical: true,
    })
  }
}
assert(observedWorldHashes.size === 1, 'more than one normalized world observed across ladder')

const result = {
  schemaVersion: 1,
  passed: true,
  sourceTreeHash: sourceTree.hash,
  fixedWorldFactHash: preregistration.fixedWorldFactHash,
  uniqueNormalizedWorldHashes: observedWorldHashes.size,
  seedCount: validations.length,
  validations,
}
await writeFile('artifacts/parity-validation.json', JSON.stringify(result, null, 2) + '\n')
console.log(`offline E3 depth validation passed for ${validations.length} seeds; one fixed normalized world`) 

function excludedFromFreeze(name, entry) {
  return name === 'node_modules' || name.startsWith('node_modules/')
    || name === 'artifacts' || name.startsWith('artifacts/')
    || name.startsWith('runs-tier')
    || name === 'validation-workspaces' || name.startsWith('validation-workspaces/')
    || name === 'test-workspaces' || name.startsWith('test-workspaces/')
    || (entry.isFile() && name === 'package-lock.json')
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}
