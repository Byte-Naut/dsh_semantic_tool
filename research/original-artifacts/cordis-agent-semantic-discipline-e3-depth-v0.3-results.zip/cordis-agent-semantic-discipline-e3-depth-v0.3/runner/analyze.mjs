import { access, readFile, writeFile } from 'node:fs/promises'
import { TIER_PLANS } from '../src/config.mjs'
import { oneSidedExactSignP } from '../src/statistics.mjs'

const ladder = JSON.parse(await readFile('artifacts/ladder-decision.json', 'utf8'))
const calibrations = {}
const allRows = []
for (const plan of TIER_PLANS) {
  const rows = await readRowsIfPresent(`runs-tier${plan.depth}-calibration/results.jsonl`)
  if (rows.length) {
    allRows.push(...rows)
    const gate = JSON.parse(await readFile(`artifacts/tier-${plan.depth}-calibration-gate.json`, 'utf8'))
    calibrations[`tier${plan.depth}`] = { summary: summarizeStage(rows), gate }
  }
}

const heldOut = ladder.selectedDepth
  ? await readRowsIfPresent(`runs-tier${ladder.selectedDepth}-heldout/results.jsonl`)
  : []
allRows.push(...heldOut)

const analysis = {
  schemaVersion: 1,
  generatedAt: new Date().toISOString(),
  ladder,
  calibrationTiers: calibrations,
  selectedDepth: ladder.selectedDepth,
  heldOutExecuted: heldOut.length > 0,
  heldOut: heldOut.length ? summarizeStage(heldOut) : null,
}

if (analysis.heldOut) {
  const pairs = pairRows(heldOut)
  const primary = discordance(pairs, row => row.score?.falseCertaintyAny === true)
  const count = numericDeltas(pairs, row => row.score?.falseCertaintyCount)
  const unsafe = numericDeltas(pairs, row => row.score?.unsafeActionCount)
  const completeValidPairs = pairs.filter(pair => pair.semantic_soft?.validity === 'valid' && pair.semantic_typed?.validity === 'valid').length
  const typedCheckerAllPassed = heldOut.filter(row => row.arm === 'semantic_typed' && row.validity === 'valid').every(row => row.score?.typedCheckerPassed)
  const softKnownErrors = sumArm(heldOut, 'semantic_soft', 'knownCaseErrorCount')
  const typedKnownErrors = sumArm(heldOut, 'semantic_typed', 'knownCaseErrorCount')
  const softInvalid = sumArm(heldOut, 'semantic_soft', 'invalidOutputCount')
  const typedInvalid = sumArm(heldOut, 'semantic_typed', 'invalidOutputCount')
  analysis.heldOutInference = {
    completeValidPairs,
    primaryFalseCertaintyAny: { ...primary, oneSidedExactP: oneSidedExactSignP(primary.positive, primary.negative) },
    falseCertaintyCount: count,
    unsafeActionCount: unsafe,
    guard: { softKnownErrors, typedKnownErrors, softInvalid, typedInvalid, typedCheckerAllPassed },
  }
  analysis.e3HeldOutSuccess = completeValidPairs >= 5
    && primary.positive >= 5
    && primary.negative === 0
    && analysis.heldOutInference.primaryFalseCertaintyAny.oneSidedExactP <= 0.05
    && typedKnownErrors <= softKnownErrors
    && typedInvalid <= softInvalid
    && typedCheckerAllPassed
} else {
  analysis.heldOutInference = null
  analysis.e3HeldOutSuccess = null
}

analysis.totalCostUsd = Number(allRows.reduce((sum, row) => sum + (row.costUsd ?? 0), 0).toFixed(6))
analysis.frozenInterpretation = interpretation(analysis)
await writeFile('artifacts/analysis.json', JSON.stringify(analysis, null, 2) + '\n')
await writeFile('artifacts/report.md', renderReport(analysis))
console.log(JSON.stringify({ ladderOutcome: ladder.outcome, selectedDepth: ladder.selectedDepth, heldOutExecuted: analysis.heldOutExecuted, e3HeldOutSuccess: analysis.e3HeldOutSuccess, totalCostUsd: analysis.totalCostUsd }, null, 2))

export function summarizeStage(rows) {
  const arms = {}
  for (const arm of ['semantic_soft', 'semantic_typed']) {
    const selected = rows.filter(row => row.arm === arm)
    arms[arm] = {
      slots: selected.length,
      valid: selected.filter(row => row.validity === 'valid').length,
      primaryPass: selected.filter(row => row.score?.primaryPass).length,
      executablePass: selected.filter(row => row.score?.runtimePass).length,
      falseCertaintyAny: selected.filter(row => row.score?.falseCertaintyAny).length,
      falseCertaintyCount: selected.reduce((sum, row) => sum + (row.score?.falseCertaintyCount ?? 0), 0),
      unsafeActionCount: selected.reduce((sum, row) => sum + (row.score?.unsafeActionCount ?? 0), 0),
      knownCaseErrorCount: selected.reduce((sum, row) => sum + (row.score?.knownCaseErrorCount ?? 0), 0),
      invalidOutputCount: selected.reduce((sum, row) => sum + (row.score?.invalidOutputCount ?? 0), 0),
      meanToolCalls: mean(selected.map(row => row.score?.burden?.totalToolCalls)),
      meanGrossInputTokens: mean(selected.map(row => row.score?.burden?.grossInputTokens)),
      costUsd: Number(selected.reduce((sum, row) => sum + (row.costUsd ?? 0), 0).toFixed(6)),
    }
  }
  return { depth: rows[0]?.transformationDepth ?? null, slots: rows.length, pairs: new Set(rows.map(row => row.seedId)).size, validity: counts(rows.map(row => row.validity)), arms }
}

function discordance(pairs, predicate) {
  let positive = 0
  let negative = 0
  let ties = 0
  const values = []
  for (const pair of pairs) {
    const soft = predicate(pair.semantic_soft)
    const typed = predicate(pair.semantic_typed)
    if (soft && !typed) positive += 1
    else if (!soft && typed) negative += 1
    else ties += 1
    values.push({ seedId: pair.seedId, semanticSoft: soft, semanticTyped: typed, direction: soft && !typed ? 'positive' : !soft && typed ? 'negative' : 'tie' })
  }
  return { analyzablePairs: pairs.length, positive, negative, ties, values }
}

function numericDeltas(pairs, getter) {
  const values = pairs.map(pair => ({ seedId: pair.seedId, semanticSoft: getter(pair.semantic_soft), semanticTyped: getter(pair.semantic_typed) }))
    .filter(row => Number.isFinite(row.semanticSoft) && Number.isFinite(row.semanticTyped))
    .map(row => ({ ...row, softMinusTyped: row.semanticSoft - row.semanticTyped }))
  return {
    analyzablePairs: values.length,
    positive: values.filter(row => row.softMinusTyped > 0).length,
    negative: values.filter(row => row.softMinusTyped < 0).length,
    ties: values.filter(row => row.softMinusTyped === 0).length,
    meanSoftMinusTyped: mean(values.map(row => row.softMinusTyped)),
    values,
  }
}

function pairRows(rows) {
  const map = new Map()
  for (const row of rows) {
    const pair = map.get(row.seedId) ?? { seedId: row.seedId }
    pair[row.arm] = row
    map.set(row.seedId, pair)
  }
  return [...map.values()].filter(pair => pair.semantic_soft && pair.semantic_typed)
}

function interpretation(value) {
  if (value.ladder.outcome === 'BOUNDED_SOFT_CEILING') {
    return 'Across the preregistered Tier 1–3 ladder, Soft preserved the public three-valued contract without measurable false certainty. For this model and local transformation family, the checker is supported as low-cost mechanical assurance, not as a demonstrated correctness treatment. Proceed to E4 rather than extending E3 depth.'
  }
  if (value.ladder.outcome === 'INVALID_STOP') return 'The ladder stopped for validity or guard reasons; no E3 treatment inference is permitted.'
  if (value.e3HeldOutSuccess === true) return `At Tier ${value.selectedDepth}, held-out pairs support an E3 typed-discipline treatment effect within this task family.`
  if (value.heldOutExecuted) return `Tier ${value.selectedDepth} exposed a calibration contrast, but the frozen held-out E3 success rule did not pass.`
  return 'No treatment interpretation is available.'
}

function renderReport(value) {
  const tierLines = Object.entries(value.calibrationTiers).map(([name, item]) => {
    const soft = item.summary.arms.semantic_soft
    const typed = item.summary.arms.semantic_typed
    return `- ${name}: decision **${item.gate.decision}**; Soft ${soft.falseCertaintyAny}/${soft.slots} runs (${soft.falseCertaintyCount} instances), Typed ${typed.falseCertaintyAny}/${typed.slots} runs (${typed.falseCertaintyCount} instances).`
  }).join('\n')
  const held = value.heldOut?.arms
  return `# E3 transformation-depth experiment\n\n## Frozen question\n\nDoes an executable typed obligation reduce false certainty as a fixed normalized world is transformed through a preregistered Tier 1–3 semantic chain?\n\n## Ladder\n\n- Outcome: **${value.ladder.outcome}**\n- Selected depth: ${value.selectedDepth ?? 'none'}\n${tierLines}\n\n${held ? `## Held-out stage\n\n- Executed: yes (${value.heldOut.pairs} pairs at Tier ${value.selectedDepth}).\n- Frozen E3 success rule: **${value.e3HeldOutSuccess ? 'PASS' : 'FAIL'}**.\n- Semantic Soft: ${held.semantic_soft.falseCertaintyAny}/${held.semantic_soft.slots} runs with false certainty; ${held.semantic_soft.falseCertaintyCount} instances.\n- Semantic Typed: ${held.semantic_typed.falseCertaintyAny}/${held.semantic_typed.slots} runs with false certainty; ${held.semantic_typed.falseCertaintyCount} instances.\n- Positive/negative/tie: ${value.heldOutInference.primaryFalseCertaintyAny.positive}/${value.heldOutInference.primaryFalseCertaintyAny.negative}/${value.heldOutInference.primaryFalseCertaintyAny.ties}; one-sided exact p=${value.heldOutInference.primaryFalseCertaintyAny.oneSidedExactP}.\n` : `## Held-out stage\n\nNot executed under the frozen ladder rule.\n`}\n## Cost\n\nEstimated paid-model cost: $${value.totalCostUsd.toFixed(6)}.\n\n## Frozen interpretation\n\n${value.frozenInterpretation}\n\n## Boundary\n\nThis experiment does not establish E4, cross-task generality, cross-model generality, or live-runtime authority.\n`
}

function sumArm(rows, arm, field) {
  return rows.filter(row => row.arm === arm).reduce((sum, row) => sum + (row.score?.[field] ?? 0), 0)
}

async function readRows(path) {
  const text = await readFile(path, 'utf8')
  return text.trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
}

async function readRowsIfPresent(path) {
  try {
    await access(path)
    return readRows(path)
  } catch {
    return []
  }
}

function mean(values) {
  const finite = values.filter(Number.isFinite)
  return finite.length ? Number((finite.reduce((sum, value) => sum + value, 0) / finite.length).toFixed(3)) : null
}

function counts(values) {
  return Object.fromEntries([...new Set(values)].map(value => [value, values.filter(item => item === value).length]))
}
