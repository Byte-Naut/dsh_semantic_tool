The Tier 3 lifecycle policy adapter in `src/status-adapter.mjs` has been updated to conform to `OBSERVATION-CONTRACT.md` across all observation carrier combinations. Visible tests pass, and the derived view for the queried observation snapshot (`depth-consumer` / `depthEndpoint`) has been computed.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL",
    "handoffComplete": "UNKNOWN",
    "handoffAction": "DEFER_FOR_EVIDENCE",
    "recoveryAllowed": "UNKNOWN",
    "recoveryAction": "DEFER_FOR_EVIDENCE",
    "serviceAdvertisable": "UNKNOWN",
    "publicationAction": "DEFER_FOR_EVIDENCE"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "NOT_AVAILABLE"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
