The Tier 3 lifecycle policy adapter has been updated in `src/status-adapter.mjs` to satisfy the full observation contract across all combinations of carriers (`KNOWN_VALUE`, `KNOWN_ABSENT`, `UNKNOWN`) and strict Boolean derivations. The visible test suite passes.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL",
    "handoffComplete": "UNKNOWN",
    "handoffAction": "DEFER_FOR_EVIDENCE",
    "recoveryAllowed": "UNKNOWN",
    "recoveryAction": "DEFER_FOR_EVIDENCE",
    "serviceAdvertisable": "UNKNOWN",
    "publicationAction": "DEFER_FOR_EVIDENCE"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "NOT_AVAILABLE"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
