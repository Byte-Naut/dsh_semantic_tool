function strictNot(v) {
  if (v === 'TRUE') return 'FALSE'
  if (v === 'FALSE') return 'TRUE'
  return 'UNKNOWN'
}

function strictAnd(x, y) {
  if (x === 'UNKNOWN' || y === 'UNKNOWN') return 'UNKNOWN'
  if (x === 'TRUE' && y === 'TRUE') return 'TRUE'
  return 'FALSE'
}

function actionGuard(truth, action) {
  if (truth === 'TRUE') return action
  if (truth === 'FALSE') return 'NO_ACTION'
  return 'DEFER_FOR_EVIDENCE'
}

export function deriveLifecycleView(observation) {
  const targetBinding = observation?.targetBinding
  const committedBinding = observation?.committedBinding
  const activeRun = observation?.activeRun
  const lastSuccessfulPackage = observation?.lastSuccessfulPackage
  const cleanupReceipt = observation?.cleanupReceipt

  // transitioning
  let transitioning
  if (!targetBinding || !committedBinding || targetBinding.kind === 'UNKNOWN' || committedBinding.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (targetBinding.kind === 'KNOWN_ABSENT' && committedBinding.kind === 'KNOWN_ABSENT') {
    transitioning = 'FALSE'
  } else if (targetBinding.kind === 'KNOWN_VALUE' && committedBinding.kind === 'KNOWN_VALUE') {
    transitioning = targetBinding.value === committedBinding.value ? 'FALSE' : 'TRUE'
  } else {
    transitioning = 'TRUE'
  }

  // activeRunPresent
  let activeRunPresent
  if (!activeRun || activeRun.kind === 'UNKNOWN') {
    activeRunPresent = 'UNKNOWN'
  } else if (activeRun.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else {
    activeRunPresent = 'FALSE'
  }

  // cleanupComplete
  let cleanupComplete
  if (!cleanupReceipt || cleanupReceipt.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanupReceipt.kind === 'KNOWN_VALUE' && cleanupReceipt.value === 'DISPOSED') {
    cleanupComplete = 'TRUE'
  } else {
    cleanupComplete = 'FALSE'
  }

  // providerAction
  const providerAction = actionGuard(transitioning, 'ALLOW_CURRENT_LOAD_TO_SETTLE')

  // packageAction
  let packageAction
  if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else {
    if (!lastSuccessfulPackage || lastSuccessfulPackage.kind === 'UNKNOWN') {
      packageAction = 'DEFER_FOR_EVIDENCE'
    } else if (lastSuccessfulPackage.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else {
      packageAction = 'NO_ACTION'
    }
  }

  // Tier 1
  const handoffComplete = strictAnd(strictNot(transitioning), cleanupComplete)
  const handoffAction = actionGuard(handoffComplete, 'FINALIZE_HANDOFF')

  // Tier 2
  const recoveryAllowed = strictAnd(strictNot(activeRunPresent), handoffComplete)
  const recoveryAction = actionGuard(recoveryAllowed, 'FINALIZE_RECOVERY')

  // Tier 3
  const serviceAdvertisable = strictAnd(recoveryAllowed, strictNot(transitioning))
  const publicationAction = actionGuard(serviceAdvertisable, 'PUBLISH_SERVICE')

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
    handoffComplete,
    handoffAction,
    recoveryAllowed,
    recoveryAction,
    serviceAdvertisable,
    publicationAction,
  }
}
