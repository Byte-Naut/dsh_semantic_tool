function STRICT_NOT(val) {
  if (val === 'TRUE') return 'FALSE'
  if (val === 'FALSE') return 'TRUE'
  return 'UNKNOWN'
}

function STRICT_AND(a, b) {
  if (a === 'UNKNOWN' || b === 'UNKNOWN') return 'UNKNOWN'
  if (a === 'TRUE' && b === 'TRUE') return 'TRUE'
  return 'FALSE'
}

function guardAction(truthVal, namedAction) {
  if (truthVal === 'TRUE') return namedAction
  if (truthVal === 'FALSE') return 'NO_ACTION'
  return 'DEFER_FOR_EVIDENCE'
}

function areBindingsEqual(b1, b2) {
  if (b1.kind === 'KNOWN_ABSENT' && b2.kind === 'KNOWN_ABSENT') return true
  if (b1.kind === 'KNOWN_VALUE' && b2.kind === 'KNOWN_VALUE') return b1.value === b2.value
  return false
}

export function deriveLifecycleView(observation) {
  const target = observation?.targetBinding ?? { kind: 'UNKNOWN' }
  const committed = observation?.committedBinding ?? { kind: 'UNKNOWN' }
  const active = observation?.activeRun ?? { kind: 'UNKNOWN' }
  const lastSuccessful = observation?.lastSuccessfulPackage ?? { kind: 'UNKNOWN' }
  const cleanup = observation?.cleanupReceipt ?? { kind: 'UNKNOWN' }

  let transitioning
  if (target.kind === 'UNKNOWN' || committed.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (areBindingsEqual(target, committed)) {
    transitioning = 'FALSE'
  } else {
    transitioning = 'TRUE'
  }

  let activeRunPresent
  if (active.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else if (active.kind === 'KNOWN_ABSENT') {
    activeRunPresent = 'FALSE'
  } else {
    activeRunPresent = 'UNKNOWN'
  }

  let cleanupComplete
  if (cleanup.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanup.kind === 'KNOWN_ABSENT') {
    cleanupComplete = 'FALSE'
  } else if (cleanup.kind === 'KNOWN_VALUE') {
    cleanupComplete = cleanup.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  } else {
    cleanupComplete = 'UNKNOWN'
  }

  let providerAction
  if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else if (transitioning === 'FALSE') {
    providerAction = 'NO_ACTION'
  } else {
    providerAction = 'DEFER_FOR_EVIDENCE'
  }

  let packageAction
  if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else {
    // activeRunPresent is 'FALSE'
    if (lastSuccessful.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else if (lastSuccessful.kind === 'KNOWN_ABSENT') {
      packageAction = 'NO_ACTION'
    } else {
      packageAction = 'DEFER_FOR_EVIDENCE'
    }
  }

  const handoffComplete = STRICT_AND(STRICT_NOT(transitioning), cleanupComplete)
  const handoffAction = guardAction(handoffComplete, 'FINALIZE_HANDOFF')

  const recoveryAllowed = STRICT_AND(STRICT_NOT(activeRunPresent), handoffComplete)
  const recoveryAction = guardAction(recoveryAllowed, 'FINALIZE_RECOVERY')

  const serviceAdvertisable = STRICT_AND(recoveryAllowed, STRICT_NOT(transitioning))
  const publicationAction = guardAction(serviceAdvertisable, 'PUBLISH_SERVICE')

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
    handoffComplete,
    handoffAction,
    recoveryAllowed,
    recoveryAction,
    serviceAdvertisable,
    publicationAction,
  }
}
