import assert from 'node:assert/strict'
import { mkdir, mkdtemp, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import test from 'node:test'
import { seedByNumber } from '../runner/seed-catalog.mjs'
import { createEpistemicRuntime, normalizedSnapshot, referenceSource } from '../tasks/e3-transformation-depth-adapter/fixture.mjs'
import { workspaceFiles } from '../tasks/e3-transformation-depth-adapter/spec.mjs'
import { hashJson } from '../src/hash.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { parseFinalRecord } from '../src/records.mjs'
import { oneSidedExactSignP } from '../src/statistics.mjs'

test('terminal parser permits prose but requires a terminal JSON fence', () => {
  assert.equal(parseFinalRecord('note\n```json\n{"status":"PASS"}\n```').ok, true)
  assert.equal(parseFinalRecord('```json\n{"status":"PASS"}\n```\nsuffix').ok, false)
})

test('normalized world is byte-identical across seeds and tiers', () => {
  const expected = hashJson(normalizedSnapshot(seedByNumber(17)))
  for (const number of [17, 18, 25, 26, 33, 34, 40]) {
    assert.equal(hashJson(normalizedSnapshot(seedByNumber(number))), expected)
  }
  const snapshot = normalizedSnapshot()
  assert.equal(snapshot.observations.targetBinding.kind, 'KNOWN_VALUE')
  assert.equal(snapshot.observations.activeRun.kind, 'KNOWN_ABSENT')
  assert.equal(snapshot.observations.committedBinding.kind, 'UNKNOWN')
  assert.equal(snapshot.observations.cleanupReceipt.kind, 'UNKNOWN')
})

for (const [depth, number] of [[1, 17], [2, 25], [3, 33]]) {
  test(`Tier ${depth} scaffold exposes false certainty without known-case regression`, async () => {
    const seed = seedByNumber(number)
    await mkdir('test-workspaces', { recursive: true })
    const workspace = await mkdtemp(resolve(`test-workspaces/e3-depth-t${depth}-scaffold-`))
    await materializeWorkspace(workspace, workspaceFiles(seed))
    const runtime = createEpistemicRuntime(seed, workspace)
    const grade = await runtime.grade()
    assert.equal(grade.falseCertaintyCount > 0, true)
    assert.equal(grade.knownCaseErrorCount, 0)
    assert.equal(grade.invalidOutputCount, 0)
    assert.equal((await runtime.typedObligationCheck()).status, 'FAIL')
  })

  test(`Tier ${depth} reference passes all hidden obligations`, async () => {
    const seed = seedByNumber(number)
    await mkdir('test-workspaces', { recursive: true })
    const workspace = await mkdtemp(resolve(`test-workspaces/e3-depth-t${depth}-reference-`))
    await materializeWorkspace(workspace, workspaceFiles(seed))
    await writeFile(join(workspace, 'src/status-adapter.mjs'), referenceSource(depth))
    const runtime = createEpistemicRuntime(seed, workspace)
    const grade = await runtime.grade()
    assert.equal(grade.fullPass, true)
    assert.equal(grade.falseCertaintyCount, 0)
    assert.equal(grade.knownCaseErrorCount, 0)
    assert.equal((await runtime.typedObligationCheck()).status, 'PASS')
    assert.equal(grade.currentExpected.handoffComplete, 'UNKNOWN')
    if (depth >= 2) assert.equal(grade.currentExpected.recoveryAllowed, 'UNKNOWN')
    if (depth >= 3) assert.equal(grade.currentExpected.serviceAdvertisable, 'UNKNOWN')
  })
}

test('workspace and card stimuli are constant within each tier', () => {
  assert.equal(hashJson(workspaceFiles(seedByNumber(17))), hashJson(workspaceFiles(seedByNumber(18))))
  assert.equal(hashJson(workspaceFiles(seedByNumber(25))), hashJson(workspaceFiles(seedByNumber(32))))
  assert.equal(hashJson(workspaceFiles(seedByNumber(33))), hashJson(workspaceFiles(seedByNumber(40))))
})

test('exact one-sided paired calculation is fixed', () => {
  assert.equal(oneSidedExactSignP(6, 0), 0.015625)
  assert.equal(oneSidedExactSignP(5, 0), 0.03125)
  assert.equal(oneSidedExactSignP(0, 0), 1)
})
