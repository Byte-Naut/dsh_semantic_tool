import { parseFinalRecord } from '../src/records.mjs'
import { outputFields } from '../tasks/e3-transformation-depth-adapter/spec.mjs'

export function scoreRun({ arm, turnText = '', grade, telemetryTotals }) {
  const parsed = parseFinalRecord(turnText)
  const record = parsed.ok ? parsed.record : {}
  const reportedView = record.current_view ?? null
  const currentViewExact = exactView(reportedView, grade?.currentActual, grade?.transformationDepth)
  const typedCheckerCalls = grade?.checkerHistory?.length ?? 0
  const typedCheckerPassed = arm === 'semantic_soft'
    ? true
    : typedCheckerCalls > 0 && grade.checkerHistory.at(-1)?.status === 'PASS'
  const runtimePass = grade?.fullPass === true
  const terminalPass = parsed.ok && record.status === 'PASS' && currentViewExact
  const primaryPass = runtimePass && terminalPass && typedCheckerPassed
  const violationCodes = [...new Set(grade?.violationCodes ?? [])]
  if ((grade?.knownCaseErrorCount ?? 0) > 0) violationCodes.push('E_KNOWN_CASE_REGRESSION')
  if ((grade?.invalidOutputCount ?? 0) > 0) violationCodes.push('E_INVALID_ADAPTER_OUTPUT')
  if (arm === 'semantic_typed' && !typedCheckerPassed) violationCodes.push('E_TYPED_CHECK_NOT_PASSED')

  return {
    transformationDepth: grade?.transformationDepth ?? null,
    primaryPass,
    runtimePass,
    falseCertaintyAny: grade?.falseCertaintyAny ?? null,
    falseCertaintyCount: grade?.falseCertaintyCount ?? null,
    falsePrecisionCount: grade?.falsePrecisionCount ?? null,
    unsafeActionCount: grade?.unsafeActionCount ?? null,
    knownCaseErrorCount: grade?.knownCaseErrorCount ?? null,
    invalidOutputCount: grade?.invalidOutputCount ?? null,
    adapterLoaded: grade?.adapterLoaded ?? false,
    visibleTestsPass: grade?.visibleTests?.status === 'pass',
    typedCheckerCalls,
    typedCheckerPassed,
    terminal: { parsed: parsed.ok, error: parsed.error, status: record.status ?? null, currentViewExact },
    violationCodes: [...new Set(violationCodes)],
    burden: {
      totalToolCalls: telemetryTotals.toolCalls,
      semanticObservationCalls: telemetryTotals.semanticObservationCalls,
      nativeObservationCalls: telemetryTotals.nativeObservationCalls,
      repeatedObservationCalls: telemetryTotals.repeatedObservationCalls,
      grossInputTokens: telemetryTotals.usage.input,
      grossOutputAndThinkingTokens: telemetryTotals.usage.output + telemetryTotals.usage.thoughts,
      toolResultBytes: telemetryTotals.toolResultBytes,
    },
  }
}

function exactView(actual, expected, depth) {
  if (!actual || !expected || typeof actual !== 'object' || typeof expected !== 'object' || !Number.isInteger(depth)) return false
  const fields = outputFields(depth)
  return Object.keys(actual).length === fields.length && fields.every(field => actual[field] === expected[field])
}
