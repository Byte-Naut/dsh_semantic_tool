export const TIER_PLANS = Object.freeze([
  Object.freeze({ depth: 1, calibrationSeedNumbers: Object.freeze([17, 18]), heldOutSeedNumbers: Object.freeze([19, 20, 21, 22, 23, 24]) }),
  Object.freeze({ depth: 2, calibrationSeedNumbers: Object.freeze([25, 26]), heldOutSeedNumbers: Object.freeze([27, 28, 29, 30, 31, 32]) }),
  Object.freeze({ depth: 3, calibrationSeedNumbers: Object.freeze([33, 34]), heldOutSeedNumbers: Object.freeze([35, 36, 37, 38, 39, 40]) }),
])

export const EXPERIMENT = Object.freeze({
  id: 'cordis-agent-semantic-discipline-e3-depth-v03',
  phase: 'bounded staged E3 transformation-depth experiment',
  hypothesis: 'typed semantic obligations reduce false certainty as semantic transformation depth increases',
  model: 'gemini-3.8-flash',
  thinkingLevel: 'medium',
  temperature: 1,
  candidateCount: 1,
  maxOutputTokensPerRequest: 32_768,
  maxToolCallsPerTurn: 24,
  maxRequestsPerTurn: 28,
  maxGrossInputTokensPerRun: 1_000_000,
  maxGrossOutputTokensPerRun: 100_000,
  requestTimeoutMs: 180_000,
  runTimeoutMs: 600_000,
  httpAttempts: 1,
  modelSeedBase: 110_000,
  fallback: false,
  tierPlans: TIER_PLANS,
  pricingUsdPerMillion: Object.freeze({ input: 0.75, outputIncludingThinking: 3.75 }),
})

export const TASK_ID = 'e3-transformation-depth-adapter'
export const ARMS = Object.freeze(['semantic_soft', 'semantic_typed'])
export const TRUTH_VALUES = Object.freeze(['TRUE', 'FALSE', 'UNKNOWN'])

export function modelSeed(fixtureNumber) {
  return EXPERIMENT.modelSeedBase + fixtureNumber
}

export function depthForSeedNumber(number) {
  const plan = TIER_PLANS.find(item => item.calibrationSeedNumbers.includes(number) || item.heldOutSeedNumbers.includes(number))
  if (!plan) throw new Error(`unknown depth seed number: ${number}`)
  return plan.depth
}

export function allSeedNumbers() {
  return TIER_PLANS.flatMap(item => [...item.calibrationSeedNumbers, ...item.heldOutSeedNumbers])
}
