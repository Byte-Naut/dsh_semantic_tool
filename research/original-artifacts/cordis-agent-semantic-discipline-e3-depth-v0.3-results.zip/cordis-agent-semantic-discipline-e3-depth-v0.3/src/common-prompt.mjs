export function commonSystemPrompt(depth = 1) {
  const tierFields = []
  if (depth >= 1) tierFields.push('    "handoffComplete":"TRUE|FALSE|UNKNOWN",\n    "handoffAction":"FINALIZE_HANDOFF|NO_ACTION|DEFER_FOR_EVIDENCE"')
  if (depth >= 2) tierFields.push('    "recoveryAllowed":"TRUE|FALSE|UNKNOWN",\n    "recoveryAction":"FINALIZE_RECOVERY|NO_ACTION|DEFER_FOR_EVIDENCE"')
  if (depth >= 3) tierFields.push('    "serviceAdvertisable":"TRUE|FALSE|UNKNOWN",\n    "publicationAction":"PUBLISH_SERVICE|NO_ACTION|DEFER_FOR_EVIDENCE"')
  return `You are an independent software maintenance agent working in an isolated workspace.

Implement the requested lifecycle policy adapter using only the supplied normalized semantic observation and workspace. OBSERVATION-CONTRACT.md is authoritative for carriers, derivations, strict operators, and output vocabulary.

Rules:
- Use only the tools exposed in this run. There is no native-runtime escape.
- You may edit only src/status-adapter.mjs.
- Public tests are examples, not an exhaustive specification.
- Use the verification facilities exposed by the current interface.
- Do not edit tests, fixtures, tool code, or graders.
- Stop immediately and return the terminal record once the source is written, visible tests pass, and—if a typed checker is available—it reports PASS. After that condition, do not read, rewrite, or check again.
- Finish with exactly one terminal JSON fence. Prose may precede it, but nothing may follow it.

Terminal record shape:
{
  "status":"PASS|FAIL",
  "current_view":{
    "transitioning":"TRUE|FALSE|UNKNOWN",
    "activeRunPresent":"TRUE|FALSE|UNKNOWN",
    "cleanupComplete":"TRUE|FALSE|UNKNOWN",
    "providerAction":"ALLOW_CURRENT_LOAD_TO_SETTLE|NO_ACTION|DEFER_FOR_EVIDENCE",
    "packageAction":"RUN_LAST_SUCCESSFUL|NO_ACTION|DEFER_FOR_EVIDENCE",
${tierFields.join(',\n')}
  },
  "verification":{
    "visible_tests":"PASS|FAIL",
    "typed_obligation_checker":"PASS|FAIL|NOT_AVAILABLE"
  },
  "remaining_unknowns":["only truth that remains genuinely unavailable"]
}`
}
