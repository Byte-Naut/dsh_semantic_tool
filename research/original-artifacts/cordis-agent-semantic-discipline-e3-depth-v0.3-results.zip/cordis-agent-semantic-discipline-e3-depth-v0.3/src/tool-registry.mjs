import { hashJson } from './hash.mjs'
import { WorkspaceAccess } from './workspace.mjs'

const OBJECT = 'object'

export function createToolRegistry({ arm, runtime, workspace, editableFiles, telemetry }) {
  const access = new WorkspaceAccess(workspace, { editableFiles, telemetry })
  const tools = []
  const transcript = []
  const add = (name, description, parametersJsonSchema, category, domain, handler) => {
    tools.push({ declaration: { name, description, ...(parametersJsonSchema ? { parametersJsonSchema } : {}) }, category, domain, handler })
  }

  add('list_files', 'List files in the isolated Agent-readable workspace.', null,
    'READ_SOURCE', 'workspace', () => access.listFiles())
  add('read_file', 'Read one UTF-8 file from the isolated Agent-readable workspace.', objectSchema({
    path: { type: 'string' },
  }, ['path']), 'READ_SOURCE', 'workspace', ({ path }) => access.readFile(path))
  add('write_file', 'Replace the approved status-adapter source file with supplied UTF-8 content.', objectSchema({
    path: { type: 'string', enum: ['src/status-adapter.mjs'] }, content: { type: 'string' },
  }, ['path', 'content']), 'EDIT_ARTIFACT', 'workspace', ({ path, content }) => access.writeFile(path, content))
  add('run_visible_tests', 'Run the two visible fully-known input examples.', null,
    'RUN_CHECK', 'workspace', () => access.runVisibleTests())
  add('software_semantic_query', 'Return the normalized lifecycle observation. This is the sole runtime-truth interface in both arms.', objectSchema({
    query: { type: 'string', enum: ['current_lifecycle_observation'] },
    subject: { type: OBJECT, additionalProperties: false, properties: { consumer: { type: 'string' }, service: { type: 'string' } }, required: ['consumer', 'service'] },
  }, ['query', 'subject']), 'OBSERVE_SEMANTIC', 'normalized_state', args => runtime.semanticQuery(args))

  if (arm === 'semantic_typed') {
    add('typed_obligation_check', 'Mechanically check the adapter against OBSERVATION-CONTRACT.md. It observes no additional world facts and returns only aggregate counts and violation codes.', null,
      'CHECK_TYPED_OBLIGATION', 'epistemic_algebra', () => runtime.typedObligationCheck())
  } else if (arm !== 'semantic_soft') {
    throw new Error(`unknown arm: ${arm}`)
  }

  const byName = new Map(tools.map(tool => [tool.declaration.name, tool]))
  return {
    declarations: tools.map(tool => tool.declaration),
    metadata: tools.map(({ declaration, category, domain }) => ({ name: declaration.name, category, domain })),
    transcript,
    async call(name, args = {}) {
      const tool = byName.get(name)
      if (!tool) throw new Error(`tool is unavailable in this arm: ${name}`)
      const argsHash = hashJson(args)
      telemetry.record('tool_called', { name, category: tool.category, domain: tool.domain, inputBytes: Buffer.byteLength(JSON.stringify(args)), argsHash, turn: 1 })
      const started = performance.now()
      try {
        const output = await tool.handler(args)
        const evidenceTags = runtime.evidenceTagsForTool?.(name, args, output) ?? []
        transcript.push({ sequence: transcript.length + 1, name, args, status: 'ok', output: jsonSafe(output), evidenceTags })
        telemetry.record('tool_returned', { name, category: tool.category, domain: tool.domain, argsHash, evidenceTags, outputBytes: Buffer.byteLength(JSON.stringify(output)), durationMs: Math.round(performance.now() - started), status: 'ok', turn: 1 })
        return output
      } catch (error) {
        const output = { error: error instanceof Error ? error.message : String(error) }
        transcript.push({ sequence: transcript.length + 1, name, args, status: 'error', output, evidenceTags: [] })
        telemetry.record('tool_returned', { name, category: tool.category, domain: tool.domain, argsHash, evidenceTags: [], outputBytes: Buffer.byteLength(JSON.stringify(output)), durationMs: Math.round(performance.now() - started), status: 'error', turn: 1 })
        return output
      }
    },
  }
}

function objectSchema(properties, required = []) {
  return { type: OBJECT, additionalProperties: false, properties, ...(required.length ? { required } : {}) }
}

function jsonSafe(value) {
  return value === undefined ? null : JSON.parse(JSON.stringify(value))
}
