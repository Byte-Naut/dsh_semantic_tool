export function publicTaskCard(seed) {
  return `Incident ${seed.incidentId}: the lifecycle status adapter for consumer ${seed.consumerName} does not satisfy its observation contract across all allowed inputs. Query the normalized observation for service ${seed.serviceKey}, inspect the small adapter workspace, and implement deriveLifecycleView. The output includes the current provider status, Package status, and the corresponding minimum lifecycle actions. Verify the implementation and report the derived view for the current observation.`
}

export function workspaceFiles(seed) {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module', scripts: { test: 'node --test' } }, null, 2) + '\n',
    'OBSERVATION-CONTRACT.md': contractText(seed),
    'src/status-adapter.mjs': buggySource(),
    'test/status-adapter.test.mjs': visibleTests(seed),
  }
}

export const editableFiles = Object.freeze(['src/status-adapter.mjs'])
export const criticalErrors = Object.freeze([
  'E_UNKNOWN_TRANSITION_COLLAPSED',
  'E_UNKNOWN_RUN_COLLAPSED',
  'E_UNKNOWN_CLEANUP_COLLAPSED',
  'E_ACTION_FROM_UNKNOWN',
  'E_ABSENT_UNKNOWN_CONFLATED',
  'E_ALWAYS_UNKNOWN',
])

function contractText(seed) {
  return `# Normalized observation contract

The adapter receives five observations:

- \`targetBinding\`, \`committedBinding\`, \`activeRun\`, and \`lastSuccessfulPackage\` are entity observations.
- \`cleanupReceipt\` is a receipt observation whose known value is \`DISPOSED\` or \`REGISTERED\`.

Every observation is exactly one carrier variant:

- \`{ kind: "KNOWN_VALUE", value: ... }\` — the value is observed.
- \`{ kind: "KNOWN_ABSENT" }\` — absence is established by complete coverage.
- \`{ kind: "UNKNOWN" }\` — coverage cannot establish a value or absence.

The adapter returns \`transitioning\`, \`activeRunPresent\`, and \`cleanupComplete\` in \`TRUE | FALSE | UNKNOWN\`, plus one provider action and one Package action. It must be correct for any legal carrier combination, not just incident ${seed.incidentId}.
`
}

function buggySource() {
  return `const valueOrNull = observation => observation?.value ?? null

export function deriveLifecycleView(observation) {
  const targetId = valueOrNull(observation.targetBinding)
  const committedId = valueOrNull(observation.committedBinding)
  const activePackageId = valueOrNull(observation.activeRun)
  const lastSuccessfulId = valueOrNull(observation.lastSuccessfulPackage)
  const cleanup = valueOrNull(observation.cleanupReceipt)
  const transitioning = committedId !== targetId

  return {
    transitioning: transitioning ? 'TRUE' : 'FALSE',
    activeRunPresent: activePackageId ? 'TRUE' : 'FALSE',
    cleanupComplete: cleanup === 'DISPOSED' ? 'TRUE' : 'FALSE',
    providerAction: transitioning ? 'ALLOW_CURRENT_LOAD_TO_SETTLE' : 'NO_ACTION',
    packageAction: !activePackageId && lastSuccessfulId ? 'RUN_LAST_SUCCESSFUL' : 'NO_ACTION',
  }
}
`
}

function visibleTests(seed) {
  return `import assert from 'node:assert/strict'
import test from 'node:test'
import { deriveLifecycleView } from '../src/status-adapter.mjs'

const value = value => ({ kind: 'KNOWN_VALUE', value })
const absent = () => ({ kind: 'KNOWN_ABSENT' })

test('known replacement remains decisive', () => {
  assert.deepEqual(deriveLifecycleView({
    targetBinding: value('${seed.providerV2}'),
    committedBinding: value('${seed.providerV1}'),
    activeRun: value('${seed.packageV1}'),
    lastSuccessfulPackage: value('${seed.packageV1}'),
    cleanupReceipt: value('DISPOSED'),
  }), {
    transitioning: 'TRUE', activeRunPresent: 'TRUE', cleanupComplete: 'TRUE',
    providerAction: 'ALLOW_CURRENT_LOAD_TO_SETTLE', packageAction: 'NO_ACTION',
  })
})

test('established absence is not presence', () => {
  assert.deepEqual(deriveLifecycleView({
    targetBinding: value('${seed.providerV2}'),
    committedBinding: value('${seed.providerV2}'),
    activeRun: absent(),
    lastSuccessfulPackage: value('${seed.packageV1}'),
    cleanupReceipt: absent(),
  }), {
    transitioning: 'FALSE', activeRunPresent: 'FALSE', cleanupComplete: 'FALSE',
    providerAction: 'NO_ACTION', packageAction: 'RUN_LAST_SUCCESSFUL',
  })
})
`
}
