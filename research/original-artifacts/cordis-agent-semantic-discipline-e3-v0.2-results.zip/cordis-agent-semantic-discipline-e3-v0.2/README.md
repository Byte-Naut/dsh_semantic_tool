# Cordis Agent Semantic Discipline E3 v0.2

This cue-reduced benchmark isolates E3 from E1/E2. Both paired arms receive the same normalized lifecycle snapshot, task card, workspace, model configuration, and non-treatment tools.

- `semantic_soft`: normalized facts plus ordinary source editing and visible tests.
- `semantic_typed`: the same interface plus one executable typed-obligation checker. The checker adds no world facts; it enforces three-valued propagation, safe deferral, known-absence separation, and known-case decisiveness.

The primary endpoint is executable false certainty: returning `TRUE`/`FALSE` where evidence requires `UNKNOWN`, or selecting a non-deferred action whose premise is unknown. Hidden known-input cases prevent an always-`UNKNOWN` implementation from passing.

Compared with v0.1, task/common-prompt wording no longer names the expected false-certainty repair, both arms receive 24 tool calls, and a shared stop rule requires an immediate terminal answer after verification. The frozen staged protocol uses entirely new S09–S16 seeds: two calibration pairs and six untouched held-out pairs executed only if the predeclared continuation gate passes.

Commands:

```bash
npm test
npm run freeze
npm run validate
node runner/run-experiment.mjs --key-stdin
npm run analyze
```
