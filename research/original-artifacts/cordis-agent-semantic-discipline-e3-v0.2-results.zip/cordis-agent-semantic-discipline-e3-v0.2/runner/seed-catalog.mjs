const ROWS = Object.freeze([
  ['indigo', 'pulse', 'monitor'],
  ['juniper', 'token', 'inspector'],
  ['kelp', 'stream', 'reader'],
  ['lilac', 'graph', 'browser'],
  ['maple', 'event', 'timeline'],
  ['navy', 'record', 'reviewer'],
  ['ochre', 'policy', 'auditor'],
  ['pearl', 'state', 'observer'],
])

export function seedByNumber(number) {
  const row = ROWS[number - 9]
  if (!row) throw new Error(`unknown seed number: ${number}`)
  const [prefix, service, consumer] = row
  return Object.freeze({
    number,
    seedId: `e3-epistemic-adapter-s${String(number).padStart(2, '0')}`,
    incidentId: `E3-${prefix.toUpperCase()}-${String(number).padStart(2, '0')}`,
    serviceKey: `${service}Endpoint`,
    consumerName: `${prefix}-${consumer}`,
    providerV1: `${prefix}-provider-v1`,
    providerV2: `${prefix}-provider-v2`,
    packageV1: `${prefix}-package-v1`,
  })
}

export function seeds(numbers) {
  return numbers.map(seedByNumber)
}

export function pairedOrder(numbers) {
  return numbers.flatMap(number => {
    const seed = seedByNumber(number)
    const arms = number % 2 ? ['semantic_typed', 'semantic_soft'] : ['semantic_soft', 'semantic_typed']
    return arms.map(arm => ({ seed, arm }))
  })
}
