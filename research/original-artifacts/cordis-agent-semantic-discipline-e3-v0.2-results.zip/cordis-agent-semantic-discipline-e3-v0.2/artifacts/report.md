# E3 typed semantic-discipline experiment

## Frozen question

Do executable typed epistemic obligations reduce false certainty after both arms receive identical normalized facts?

## Calibration

- Continuation gate: **STOP**
- Semantic soft: 0/2 runs with false certainty; 0 instances.
- Semantic typed: 0/2 runs with false certainty; 0 instances.

## Held-out stage

Not executed because the frozen calibration continuation gate did not pass.

## Cost

Estimated paid-model cost: $0.295225.

## Interpretation boundary

This is one compact adapter family and one model. It does not establish E4 capability-boundary shift or cross-task/model generality.
