The lifecycle status adapter in `src/status-adapter.mjs` has been updated to handle three-valued epistemic observations (`KNOWN_VALUE`, `KNOWN_ABSENT`, `UNKNOWN`) across all inputs in accordance with the observation contract.

Visible test verification passes.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "NOT_AVAILABLE"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
