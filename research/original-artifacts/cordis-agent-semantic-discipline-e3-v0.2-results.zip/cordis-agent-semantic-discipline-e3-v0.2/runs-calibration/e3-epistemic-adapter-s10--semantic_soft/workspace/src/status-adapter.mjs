export function deriveLifecycleView(observation) {
  const targetBinding = observation?.targetBinding
  const committedBinding = observation?.committedBinding
  const activeRun = observation?.activeRun
  const lastSuccessfulPackage = observation?.lastSuccessfulPackage
  const cleanupReceipt = observation?.cleanupReceipt

  let transitioning = 'UNKNOWN'
  if (targetBinding?.kind === 'UNKNOWN' || committedBinding?.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (targetBinding?.kind === 'KNOWN_ABSENT' && committedBinding?.kind === 'KNOWN_ABSENT') {
    transitioning = 'FALSE'
  } else if (targetBinding?.kind === 'KNOWN_VALUE' && committedBinding?.kind === 'KNOWN_VALUE') {
    transitioning = targetBinding.value === committedBinding.value ? 'FALSE' : 'TRUE'
  } else {
    transitioning = 'TRUE'
  }

  let activeRunPresent = 'UNKNOWN'
  if (activeRun?.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else if (activeRun?.kind === 'KNOWN_ABSENT') {
    activeRunPresent = 'FALSE'
  } else if (activeRun?.kind === 'UNKNOWN') {
    activeRunPresent = 'UNKNOWN'
  }

  let cleanupComplete = 'UNKNOWN'
  if (cleanupReceipt?.kind === 'KNOWN_VALUE') {
    cleanupComplete = cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  } else if (cleanupReceipt?.kind === 'KNOWN_ABSENT') {
    cleanupComplete = 'FALSE'
  } else if (cleanupReceipt?.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  }

  let providerAction = 'DEFER_FOR_EVIDENCE'
  if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else if (transitioning === 'FALSE') {
    providerAction = 'NO_ACTION'
  } else {
    providerAction = 'DEFER_FOR_EVIDENCE'
  }

  let packageAction = 'DEFER_FOR_EVIDENCE'
  if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'FALSE') {
    if (lastSuccessfulPackage?.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else if (lastSuccessfulPackage?.kind === 'KNOWN_ABSENT') {
      packageAction = 'NO_ACTION'
    } else {
      packageAction = 'DEFER_FOR_EVIDENCE'
    }
  } else {
    if (lastSuccessfulPackage?.kind === 'KNOWN_ABSENT') {
      packageAction = 'NO_ACTION'
    } else {
      packageAction = 'DEFER_FOR_EVIDENCE'
    }
  }

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
  }
}
