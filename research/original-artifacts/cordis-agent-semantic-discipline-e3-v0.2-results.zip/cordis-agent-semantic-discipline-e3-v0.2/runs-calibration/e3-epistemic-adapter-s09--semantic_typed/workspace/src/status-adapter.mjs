export function deriveLifecycleView(observation) {
  // activeRunPresent
  let activeRunPresent
  if (observation.activeRun?.kind === 'UNKNOWN') {
    activeRunPresent = 'UNKNOWN'
  } else if (observation.activeRun?.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else {
    activeRunPresent = 'FALSE'
  }

  // cleanupComplete
  let cleanupComplete
  if (observation.cleanupReceipt?.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (observation.cleanupReceipt?.kind === 'KNOWN_VALUE') {
    cleanupComplete = observation.cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  } else {
    cleanupComplete = 'FALSE'
  }

  // transitioning
  let transitioning
  if (observation.targetBinding?.kind === 'UNKNOWN' || observation.committedBinding?.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else {
    const targetVal = observation.targetBinding?.kind === 'KNOWN_VALUE' ? observation.targetBinding.value : null
    const committedVal = observation.committedBinding?.kind === 'KNOWN_VALUE' ? observation.committedBinding.value : null
    transitioning = targetVal !== committedVal ? 'TRUE' : 'FALSE'
  }

  // providerAction
  let providerAction
  if (transitioning === 'UNKNOWN') {
    providerAction = 'DEFER_FOR_EVIDENCE'
  } else if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else {
    providerAction = 'NO_ACTION'
  }

  // packageAction
  let packageAction
  const activeUnknown = observation.activeRun?.kind === 'UNKNOWN'
  const lastPkgUnknown = observation.lastSuccessfulPackage?.kind === 'UNKNOWN'

  if (activeUnknown) {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else {
    // activeRunPresent is FALSE
    if (lastPkgUnknown) {
      packageAction = 'DEFER_FOR_EVIDENCE'
    } else if (observation.lastSuccessfulPackage?.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else {
      packageAction = 'NO_ACTION'
    }
  }

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
  }
}
