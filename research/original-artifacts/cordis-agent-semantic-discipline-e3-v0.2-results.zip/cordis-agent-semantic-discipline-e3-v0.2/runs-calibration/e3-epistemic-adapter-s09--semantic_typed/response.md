The lifecycle status adapter has been updated in `src/status-adapter.mjs` to properly propagate unknown observations and adhere to epistemic obligations:
- Unknown comparison, presence, and receipt propagate to `UNKNOWN`.
- Actions dependent on uncertain or unknown states evaluate to `DEFER_FOR_EVIDENCE`.
- Fully known inputs remain decisive, preserving `KNOWN_ABSENT` distinctions.

Both visible tests and the typed obligation check pass.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "PASS"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
