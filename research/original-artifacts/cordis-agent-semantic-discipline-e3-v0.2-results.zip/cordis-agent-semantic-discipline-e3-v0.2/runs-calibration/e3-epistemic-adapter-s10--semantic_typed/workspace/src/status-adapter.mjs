export function deriveLifecycleView(observation) {
  const {
    targetBinding,
    committedBinding,
    activeRun,
    lastSuccessfulPackage,
    cleanupReceipt,
  } = observation

  const transitioning =
    targetBinding?.kind === 'UNKNOWN' || committedBinding?.kind === 'UNKNOWN'
      ? 'UNKNOWN'
      : (targetBinding?.kind === 'KNOWN_VALUE' && committedBinding?.kind === 'KNOWN_VALUE')
        ? (targetBinding.value !== committedBinding.value ? 'TRUE' : 'FALSE')
        : (targetBinding?.kind === 'KNOWN_ABSENT' && committedBinding?.kind === 'KNOWN_ABSENT')
          ? 'FALSE'
          : 'TRUE'

  const activeRunPresent =
    activeRun?.kind === 'UNKNOWN'
      ? 'UNKNOWN'
      : activeRun?.kind === 'KNOWN_VALUE'
        ? 'TRUE'
        : 'FALSE'

  const cleanupComplete =
    cleanupReceipt?.kind === 'UNKNOWN'
      ? 'UNKNOWN'
      : cleanupReceipt?.kind === 'KNOWN_VALUE'
        ? (cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE')
        : 'FALSE'

  const providerAction =
    transitioning === 'UNKNOWN'
      ? 'DEFER_FOR_EVIDENCE'
      : transitioning === 'TRUE'
        ? 'ALLOW_CURRENT_LOAD_TO_SETTLE'
        : 'NO_ACTION'

  let packageAction
  if (activeRun?.kind === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else if (activeRun?.kind === 'KNOWN_VALUE') {
    packageAction = 'NO_ACTION'
  } else {
    // activeRun is KNOWN_ABSENT
    if (lastSuccessfulPackage?.kind === 'UNKNOWN') {
      packageAction = 'DEFER_FOR_EVIDENCE'
    } else if (lastSuccessfulPackage?.kind === 'KNOWN_VALUE') {
      packageAction = 'RUN_LAST_SUCCESSFUL'
    } else {
      packageAction = 'NO_ACTION'
    }
  }

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
  }
}
