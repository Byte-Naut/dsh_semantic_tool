The lifecycle status adapter in `src/status-adapter.mjs` has been updated to handle all three observation variants (`KNOWN_VALUE`, `KNOWN_ABSENT`, and `UNKNOWN`) in conformance with the epistemic obligations:
- Indeterminate provider transitions propagate to `UNKNOWN` and cause provider actions to `DEFER_FOR_EVIDENCE`.
- Active run presence and cleanup completion propagate `UNKNOWN` when coverage is incomplete, while distinguishing `KNOWN_ABSENT` from `UNKNOWN`.
- Fully known inputs remain decisive, allowing package recovery to proceed with `RUN_LAST_SUCCESSFUL` when absence of an active run and presence of the last successful package are both known.

Both the visible test suite and the typed obligation check pass without violations.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "PASS"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
