import assert from 'node:assert/strict'
import test from 'node:test'
import { deriveLifecycleView } from '../src/status-adapter.mjs'

const value = value => ({ kind: 'KNOWN_VALUE', value })
const absent = () => ({ kind: 'KNOWN_ABSENT' })

test('known replacement remains decisive', () => {
  assert.deepEqual(deriveLifecycleView({
    targetBinding: value('indigo-provider-v2'),
    committedBinding: value('indigo-provider-v1'),
    activeRun: value('indigo-package-v1'),
    lastSuccessfulPackage: value('indigo-package-v1'),
    cleanupReceipt: value('DISPOSED'),
  }), {
    transitioning: 'TRUE', activeRunPresent: 'TRUE', cleanupComplete: 'TRUE',
    providerAction: 'ALLOW_CURRENT_LOAD_TO_SETTLE', packageAction: 'NO_ACTION',
  })
})

test('established absence is not presence', () => {
  assert.deepEqual(deriveLifecycleView({
    targetBinding: value('indigo-provider-v2'),
    committedBinding: value('indigo-provider-v2'),
    activeRun: absent(),
    lastSuccessfulPackage: value('indigo-package-v1'),
    cleanupReceipt: absent(),
  }), {
    transitioning: 'FALSE', activeRunPresent: 'FALSE', cleanupComplete: 'FALSE',
    providerAction: 'NO_ACTION', packageAction: 'RUN_LAST_SUCCESSFUL',
  })
})
