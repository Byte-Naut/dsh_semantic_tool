function getBinding(obs) {
  if (!obs || obs.kind === 'UNKNOWN') return { kind: 'UNKNOWN' }
  if (obs.kind === 'KNOWN_ABSENT') return { kind: 'ABSENT' }
  if (obs.kind === 'KNOWN_VALUE') return { kind: 'VALUE', value: obs.value }
  return { kind: 'UNKNOWN' }
}

export function deriveLifecycleView(observation) {
  const target = getBinding(observation?.targetBinding)
  const committed = getBinding(observation?.committedBinding)

  let transitioning
  if (target.kind === 'UNKNOWN' || committed.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (target.kind === 'ABSENT' && committed.kind === 'ABSENT') {
    transitioning = 'FALSE'
  } else if (target.kind === 'VALUE' && committed.kind === 'VALUE' && target.value === committed.value) {
    transitioning = 'FALSE'
  } else {
    transitioning = 'TRUE'
  }

  let providerAction
  if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else if (transitioning === 'FALSE') {
    providerAction = 'NO_ACTION'
  } else {
    providerAction = 'DEFER_FOR_EVIDENCE'
  }

  const activeObs = observation?.activeRun
  let activeRunPresent
  if (!activeObs || activeObs.kind === 'UNKNOWN') {
    activeRunPresent = 'UNKNOWN'
  } else if (activeObs.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else {
    activeRunPresent = 'FALSE'
  }

  const cleanupObs = observation?.cleanupReceipt
  let cleanupComplete
  if (!cleanupObs || cleanupObs.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanupObs.kind === 'KNOWN_VALUE') {
    cleanupComplete = cleanupObs.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  } else {
    cleanupComplete = 'FALSE'
  }

  const lastSuccessfulObs = observation?.lastSuccessfulPackage
  let lastSuccessfulPresent
  if (!lastSuccessfulObs || lastSuccessfulObs.kind === 'UNKNOWN') {
    lastSuccessfulPresent = 'UNKNOWN'
  } else if (lastSuccessfulObs.kind === 'KNOWN_VALUE') {
    lastSuccessfulPresent = 'TRUE'
  } else {
    lastSuccessfulPresent = 'FALSE'
  }

  let packageAction
  if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (lastSuccessfulPresent === 'FALSE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'FALSE' && lastSuccessfulPresent === 'TRUE') {
    packageAction = 'RUN_LAST_SUCCESSFUL'
  } else {
    packageAction = 'DEFER_FOR_EVIDENCE'
  }

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
  }
}
