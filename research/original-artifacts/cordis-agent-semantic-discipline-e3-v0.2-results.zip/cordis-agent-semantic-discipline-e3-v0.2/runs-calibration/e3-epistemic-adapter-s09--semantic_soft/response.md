The lifecycle status adapter has been updated to handle the normalized observation contract across all input carrier states (`KNOWN_VALUE`, `KNOWN_ABSENT`, and `UNKNOWN`). It correctly derives the provider and package lifecycle status alongside the corresponding minimum lifecycle actions, with tests passing.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "NOT_AVAILABLE"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
