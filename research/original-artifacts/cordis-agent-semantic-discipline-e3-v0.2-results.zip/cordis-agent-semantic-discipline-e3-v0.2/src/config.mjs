export const EXPERIMENT = Object.freeze({
  id: 'cordis-agent-semantic-discipline-e3-v02',
  phase: 'cue-reduced staged paired E3 mechanism experiment',
  hypothesis: 'typed semantic obligations reduce false certainty after identical normalized facts are supplied',
  model: 'gemini-3.8-flash',
  thinkingLevel: 'medium',
  temperature: 1,
  candidateCount: 1,
  maxOutputTokensPerRequest: 32_768,
  maxToolCallsPerTurn: 24,
  maxRequestsPerTurn: 28,
  maxGrossInputTokensPerRun: 1_000_000,
  maxGrossOutputTokensPerRun: 100_000,
  requestTimeoutMs: 180_000,
  runTimeoutMs: 600_000,
  httpAttempts: 1,
  modelSeedBase: 87_000,
  fallback: false,
  calibrationSeedNumbers: Object.freeze([9, 10]),
  heldOutSeedNumbers: Object.freeze([11, 12, 13, 14, 15, 16]),
  pricingUsdPerMillion: Object.freeze({ input: 0.75, outputIncludingThinking: 3.75 }),
})

export const TASK_ID = 'e3-epistemic-adapter'
export const ARMS = Object.freeze(['semantic_soft', 'semantic_typed'])

export const TRUTH_VALUES = Object.freeze(['TRUE', 'FALSE', 'UNKNOWN'])
export const PROVIDER_ACTIONS = Object.freeze(['ALLOW_CURRENT_LOAD_TO_SETTLE', 'NO_ACTION', 'DEFER_FOR_EVIDENCE'])
export const PACKAGE_ACTIONS = Object.freeze(['RUN_LAST_SUCCESSFUL', 'NO_ACTION', 'DEFER_FOR_EVIDENCE'])

export function modelSeed(fixtureNumber) {
  return EXPERIMENT.modelSeedBase + fixtureNumber
}
