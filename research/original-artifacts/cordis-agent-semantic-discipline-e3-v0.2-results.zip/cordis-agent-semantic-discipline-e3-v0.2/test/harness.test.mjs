import assert from 'node:assert/strict'
import { mkdir, mkdtemp, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import test from 'node:test'
import { seedByNumber } from '../runner/seed-catalog.mjs'
import { createEpistemicRuntime, normalizedSnapshot, referenceSource } from '../tasks/e3-epistemic-adapter/fixture.mjs'
import { workspaceFiles } from '../tasks/e3-epistemic-adapter/spec.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { parseFinalRecord } from '../src/records.mjs'
import { oneSidedExactSignP } from '../src/statistics.mjs'

test('terminal parser permits prose but requires a terminal JSON fence', () => {
  assert.equal(parseFinalRecord('note\n```json\n{"status":"PASS"}\n```').ok, true)
  assert.equal(parseFinalRecord('```json\n{"status":"PASS"}\n```\nsuffix').ok, false)
})

test('normalized snapshot preserves value, known absence, and unknown', () => {
  const snapshot = normalizedSnapshot(seedByNumber(9))
  assert.equal(snapshot.observations.targetBinding.kind, 'KNOWN_VALUE')
  assert.equal(snapshot.observations.activeRun.kind, 'KNOWN_ABSENT')
  assert.equal(snapshot.observations.committedBinding.kind, 'UNKNOWN')
})

test('buggy scaffold exposes false certainty without known-case regression', async () => {
  const seed = seedByNumber(9)
  await mkdir('test-workspaces', { recursive: true })
  const workspace = await mkdtemp(resolve('test-workspaces/e3-scaffold-'))
  await materializeWorkspace(workspace, workspaceFiles(seed))
  const runtime = createEpistemicRuntime(seed, workspace)
  const grade = await runtime.grade()
  assert.equal(grade.falseCertaintyCount > 0, true)
  assert.equal(grade.knownCaseErrorCount, 0)
  assert.equal((await runtime.typedObligationCheck()).status, 'FAIL')
})

test('reference adapter passes hidden epistemic obligations and visible examples', async () => {
  const seed = seedByNumber(10)
  await mkdir('test-workspaces', { recursive: true })
  const workspace = await mkdtemp(resolve('test-workspaces/e3-reference-'))
  await materializeWorkspace(workspace, workspaceFiles(seed))
  await writeFile(join(workspace, 'src/status-adapter.mjs'), referenceSource())
  const runtime = createEpistemicRuntime(seed, workspace)
  const grade = await runtime.grade()
  assert.equal(grade.fullPass, true)
  assert.equal(grade.falseCertaintyCount, 0)
  assert.equal(grade.knownCaseErrorCount, 0)
  assert.equal((await runtime.typedObligationCheck()).status, 'PASS')
})

test('exact one-sided paired calculation is fixed', () => {
  assert.equal(oneSidedExactSignP(6, 0), 0.015625)
  assert.equal(oneSidedExactSignP(5, 0), 0.03125)
  assert.equal(oneSidedExactSignP(0, 0), 1)
})
