import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { ARMS, EXPERIMENT, TASK_ID, modelSeed } from '../src/config.mjs'
import { createRuntime, taskCard, taskCriticalErrors, taskEditableFiles, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { GeminiAgent } from '../src/gemini-agent.mjs'
import { Telemetry, appendJsonLine } from '../src/telemetry.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { classifyRunError } from '../src/outcome-classification.mjs'
import { scoreRun } from '../evaluator-private/score-run.mjs'
import { pairedOrder } from './seed-catalog.mjs'

const apiKey = await acquireKey()
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
const parity = JSON.parse(await readFile('artifacts/parity-validation.json', 'utf8'))
if (!parity.passed) throw new Error('offline parity validation did not pass')
await verifyFrozenInputs(preregistration)
if (parity.sourceTreeHash !== preregistration.sourceTree.hash) throw new Error('parity validation did not use frozen source')

const preflight = new GeminiAgent({ apiKey, taskId: TASK_ID, fixtureNumber: EXPERIMENT.calibrationSeedNumbers[0], telemetry: new Telemetry('preflight') })
const modelMetadata = await preflight.modelMetadata()
await writeFile('artifacts/model-metadata.json', JSON.stringify({ requestedModel: EXPERIMENT.model, retrievedAt: new Date().toISOString(), metadata: modelMetadata }, null, 2) + '\n')
console.log(`model preflight passed for ${EXPERIMENT.model}`)

const calibrationRows = await runStage('calibration', EXPERIMENT.calibrationSeedNumbers, apiKey, modelMetadata)
const gate = calibrationGate(calibrationRows)
await writeFile('artifacts/calibration-gate.json', JSON.stringify(gate, null, 2) + '\n')
console.log(`calibration continuation gate: ${gate.pass ? 'PASS' : 'STOP'}`)

if (gate.pass) {
  await runStage('heldout', EXPERIMENT.heldOutSeedNumbers, apiKey, modelMetadata)
  console.log('conditional held-out E3 stage completed')
} else {
  console.log('held-out stage not executed under the frozen stopping rule')
}

async function runStage(stage, seedNumbers, secret, metadata) {
  const runDirectory = `runs-${stage}`
  await mkdir(runDirectory, { recursive: false })
  const rows = []
  const order = pairedOrder(seedNumbers)
  for (const [index, item] of order.entries()) {
    const runId = `${item.seed.seedId}--${item.arm}`
    console.log(`[${stage} ${index + 1}/${order.length}] starting ${runId}`)
    const result = await runSingle({ ...item, stage, runId, runDirectory, apiKey: secret, modelMetadata: metadata })
    rows.push(result)
    await appendJsonLine(`${runDirectory}/results.jsonl`, result)
    console.log(`[${stage} ${index + 1}/${order.length}] ${runId}: ${result.validity} / false-certainty=${result.score?.falseCertaintyCount ?? 'NA'} / runtime=${result.score?.runtimePass ?? false}`)
  }
  return rows
}

async function runSingle({ seed, arm, stage, runId, runDirectory, apiKey: secret, modelMetadata }) {
  const runRoot = resolve(runDirectory, runId)
  const workspace = join(runRoot, 'workspace')
  await mkdir(runRoot, { recursive: false })
  const telemetry = new Telemetry(runId)
  const startedAt = new Date().toISOString()
  const started = performance.now()
  let runtime = null
  let agent = null
  let registry = null
  let response = null
  let grade = null
  let caught = null
  let initialTree = null
  let finalTree = null
  const card = taskCard(TASK_ID, seed)

  try {
    await materializeWorkspace(workspace, taskWorkspaceFiles(TASK_ID, seed))
    initialTree = await hashTree(workspace)
    runtime = await createRuntime(TASK_ID, seed, workspace)
    agent = new GeminiAgent({ apiKey: secret, taskId: TASK_ID, fixtureNumber: seed.number, telemetry })
    registry = createToolRegistry({ arm, runtime, workspace, editableFiles: taskEditableFiles(TASK_ID), telemetry })
    response = await agent.runTurn({ turn: 1, message: card, registry })
  } catch (error) {
    caught = error
    telemetry.record('run_interrupted', { classification: classifyRunError(error), errorCode: error?.code ?? null, turn: error?.turn ?? null, error: sanitizeError(error, secret) })
  }
  try {
    if (runtime) grade = await runtime.grade()
  } catch (error) {
    caught ??= error
    telemetry.record('grade_failed', { error: sanitizeError(error, secret) })
  }
  if (initialTree) finalTree = await hashTree(workspace)

  const totals = telemetry.totals()
  const turnText = response?.text ?? latestTurnText(agent)
  const score = runtime && grade ? scoreRun({ arm, turnText, grade, telemetryTotals: totals }) : null
  const versions = [...new Set((agent?.responses ?? []).map(item => item.modelVersion).filter(Boolean))]
  const validity = caught ? classifyRunError(caught) : versions.length === 1 ? 'valid' : 'invalid-model-version'
  const result = {
    schemaVersion: 1,
    experimentId: EXPERIMENT.id,
    stage,
    runId,
    taskId: TASK_ID,
    seedId: seed.seedId,
    fixtureNumber: seed.number,
    arm,
    requestedModel: EXPERIMENT.model,
    reportedModelVersions: versions,
    modelMetadataName: modelMetadata.name ?? null,
    thinkingLevel: EXPERIMENT.thinkingLevel,
    temperature: EXPERIMENT.temperature,
    modelSeed: modelSeed(seed.number),
    validity,
    completedWithinBudget: validity === 'valid',
    startedAt,
    completedAt: new Date().toISOString(),
    durationMs: Math.round(performance.now() - started),
    initialWorkspaceHash: initialTree?.hash ?? null,
    finalWorkspaceHash: finalTree?.hash ?? null,
    filesChanged: initialTree && finalTree ? changedFiles(initialTree.entries, finalTree.entries) : [],
    taskCriticalErrorVocabulary: taskCriticalErrors(TASK_ID),
    errorCode: caught?.code ?? null,
    error: caught ? sanitizeError(caught, secret) : null,
    score,
    costUsd: calculateCost(totals.usage),
  }
  await writeRunArtifacts({ runRoot, seed, arm, card, turnText, telemetry, result, exchanges: agent?.responses ?? [], registry, grade })
  return result
}

async function writeRunArtifacts({ runRoot, seed, arm, card, turnText, telemetry, result, exchanges, registry, grade }) {
  await telemetry.write(join(runRoot, 'telemetry.jsonl'))
  await writeFile(join(runRoot, 'task.json'), JSON.stringify({ seed, arm, taskCard: card }, null, 2) + '\n')
  await writeFile(join(runRoot, 'tool-schema.json'), JSON.stringify({ declarations: registry?.declarations ?? [], metadata: registry?.metadata ?? [] }, null, 2) + '\n')
  await writeFile(join(runRoot, 'tool-transcript.json'), JSON.stringify(registry?.transcript ?? [], null, 2) + '\n')
  await writeFile(join(runRoot, 'response.md'), (turnText || '').trimEnd() + '\n')
  await writeFile(join(runRoot, 'model-exchanges.json'), JSON.stringify(exchanges, null, 2) + '\n')
  await writeFile(join(runRoot, 'hidden-grade.json'), JSON.stringify(grade, null, 2) + '\n')
  await writeFile(join(runRoot, 'result.json'), JSON.stringify(result, null, 2) + '\n')
}

function calibrationGate(rows) {
  const bySeed = pairRows(rows)
  const allValid = rows.length === 4 && rows.every(row => row.validity === 'valid' && row.completedWithinBudget)
  const typed = rows.filter(row => row.arm === 'semantic_typed')
  const soft = rows.filter(row => row.arm === 'semantic_soft')
  const typedClean = typed.length === 2 && typed.every(row => row.score?.falseCertaintyCount === 0 && row.score?.knownCaseErrorCount === 0 && row.score?.invalidOutputCount === 0 && row.score?.typedCheckerPassed)
  const softKnownClean = soft.length === 2 && soft.every(row => row.score?.knownCaseErrorCount === 0 && row.score?.invalidOutputCount === 0)
  const deltas = [...bySeed.values()].map(pair => (pair.semantic_soft?.score?.falseCertaintyCount ?? -Infinity) - (pair.semantic_typed?.score?.falseCertaintyCount ?? Infinity))
  const exposed = deltas.some(delta => delta > 0)
  const neverWorse = deltas.every(delta => delta >= 0)
  return { schemaVersion: 1, pass: allValid && typedClean && softKnownClean && exposed && neverWorse, allValid, typedClean, softKnownClean, exposed, neverWorse, falseCertaintyCountDeltas: deltas }
}

function pairRows(rows) {
  const map = new Map()
  for (const row of rows) {
    const pair = map.get(row.seedId) ?? {}
    pair[row.arm] = row
    map.set(row.seedId, pair)
  }
  return map
}

function latestTurnText(agent) {
  return (agent?.responses ?? []).filter(item => item.turn === 1 && item.text).at(-1)?.text ?? ''
}

function changedFiles(beforeEntries, afterEntries) {
  const before = new Map(beforeEntries)
  const after = new Map(afterEntries)
  return [...new Set([...before.keys(), ...after.keys()])].filter(path => before.get(path) !== after.get(path)).sort()
}

function calculateCost(usage) {
  const input = usage.input * EXPERIMENT.pricingUsdPerMillion.input / 1_000_000
  const output = (usage.output + usage.thoughts) * EXPERIMENT.pricingUsdPerMillion.outputIncludingThinking / 1_000_000
  return Number((input + output).toFixed(6))
}

async function verifyFrozenInputs(preregistration) {
  const sourceTree = await hashTree('.', { exclude: excludedFromFreeze })
  if (sourceTree.hash !== preregistration.sourceTree.hash) throw new Error('source tree differs from preregistration freeze')
  const lockHash = hashJson(JSON.parse(await readFile('package-lock.json', 'utf8')))
  if (lockHash !== preregistration.packageLockHash) throw new Error('package lock differs from preregistration freeze')
  if (preregistration.experiment.model !== EXPERIMENT.model || preregistration.experiment.fallback !== false) throw new Error('model protocol drift')
  if (hashJson(preregistration.stages.calibration.runOrder) !== hashJson(pairedOrder(EXPERIMENT.calibrationSeedNumbers).map(({ seed, arm }) => ({ seedId: seed.seedId, arm })))) throw new Error('calibration order drift')
  if (hashJson(preregistration.stages.heldOut.runOrder) !== hashJson(pairedOrder(EXPERIMENT.heldOutSeedNumbers).map(({ seed, arm }) => ({ seedId: seed.seedId, arm })))) throw new Error('held-out order drift')
}

function excludedFromFreeze(name, entry) {
  return name === 'node_modules' || name.startsWith('node_modules/')
    || name === 'artifacts' || name.startsWith('artifacts/')
    || name === 'runs-calibration' || name.startsWith('runs-calibration/')
    || name === 'runs-heldout' || name.startsWith('runs-heldout/')
    || name === 'validation-workspaces' || name.startsWith('validation-workspaces/')
    || name === 'test-workspaces' || name.startsWith('test-workspaces/')
    || (entry.isFile() && name === 'package-lock.json')
}

async function acquireKey() {
  if (process.argv.includes('--key-stdin')) {
    let value = ''
    for await (const chunk of process.stdin) {
      value += chunk
      if (value.includes('\n')) break
    }
    const key = value.split(/\r?\n/, 1)[0].trim()
    if (!key) throw new Error('empty Gemini API key on stdin')
    return key
  }
  const key = process.env.GEMINI_API_KEY
  if (!key) throw new Error('GEMINI_API_KEY is unset; pass --key-stdin or set process environment')
  return key
}

function sanitizeError(error, secret) {
  const source = error instanceof Error ? `${error.name}: ${error.message}` : String(error)
  return source.split(secret).join('[REDACTED]')
}
