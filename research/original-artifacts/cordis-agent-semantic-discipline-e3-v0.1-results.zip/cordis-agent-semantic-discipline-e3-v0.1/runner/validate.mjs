import { mkdir, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { EXPERIMENT, TASK_ID } from '../src/config.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { createRuntime, taskCard, taskEditableFiles, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { normalizedSnapshot, referenceSource } from '../tasks/e3-epistemic-adapter/fixture.mjs'
import { seeds } from './seed-catalog.mjs'

const preregistration = JSON.parse(await import('node:fs/promises').then(fs => fs.readFile('artifacts/preregistration.json', 'utf8')))
const sourceTree = await hashTree('.', { exclude: excludedFromFreeze })
assert(sourceTree.hash === preregistration.sourceTree.hash, 'source changed after freeze')

const validations = []
await mkdir('validation-workspaces', { recursive: false })
for (const seed of seeds([...EXPERIMENT.calibrationSeedNumbers, ...EXPERIMENT.heldOutSeedNumbers])) {
  const workspace = resolve('validation-workspaces', seed.seedId)
  await materializeWorkspace(workspace, taskWorkspaceFiles(TASK_ID, seed))
  const runtime = await createRuntime(TASK_ID, seed, workspace)
  const initial = await runtime.grade()
  assert(initial.falseCertaintyCount > 0, `${seed.seedId}: scaffold does not expose false certainty`)
  assert(initial.knownCaseErrorCount === 0, `${seed.seedId}: scaffold confounds known-case correctness`)
  const caught = await runtime.typedObligationCheck()
  assert(caught.status === 'FAIL' && caught.falseCertaintyCount > 0, `${seed.seedId}: checker did not catch scaffold`)

  await writeFile(join(workspace, 'src/status-adapter.mjs'), referenceSource())
  const reference = await runtime.grade()
  const checked = await runtime.typedObligationCheck()
  assert(reference.fullPass, `${seed.seedId}: reference solution failed`)
  assert(checked.status === 'PASS', `${seed.seedId}: checker rejected reference`)

  const softRuntime = await createRuntime(TASK_ID, seed, workspace)
  const typedRuntime = await createRuntime(TASK_ID, seed, workspace)
  const softRegistry = createToolRegistry({ arm: 'semantic_soft', runtime: softRuntime, workspace, editableFiles: taskEditableFiles(TASK_ID), telemetry: new Telemetry(`validate:${seed.seedId}:soft`) })
  const typedRegistry = createToolRegistry({ arm: 'semantic_typed', runtime: typedRuntime, workspace, editableFiles: taskEditableFiles(TASK_ID), telemetry: new Telemetry(`validate:${seed.seedId}:typed`) })
  const softCommon = softRegistry.declarations.filter(row => row.name !== 'typed_obligation_check')
  const typedCommon = typedRegistry.declarations.filter(row => row.name !== 'typed_obligation_check')
  assert(hashJson(softCommon) === hashJson(typedCommon), `${seed.seedId}: non-treatment tool drift`)
  assert(!softRegistry.declarations.some(row => row.name === 'typed_obligation_check'), `${seed.seedId}: checker leaked to soft arm`)
  assert(typedRegistry.declarations.filter(row => row.name === 'typed_obligation_check').length === 1, `${seed.seedId}: typed checker missing`)
  assert(hashJson(softRuntime.semanticQuery({ query: 'current_lifecycle_observation', subject: { consumer: seed.consumerName, service: seed.serviceKey } }))
    === hashJson(typedRuntime.semanticQuery({ query: 'current_lifecycle_observation', subject: { consumer: seed.consumerName, service: seed.serviceKey } })), `${seed.seedId}: normalized facts differ by arm`)
  assert(hashJson(normalizedSnapshot(seed)) === hashJson(softRuntime.semanticQuery({ query: 'current_lifecycle_observation', subject: { consumer: seed.consumerName, service: seed.serviceKey } })), `${seed.seedId}: query drift`)
  assert(taskCard(TASK_ID, seed) === taskCard(TASK_ID, seed), `${seed.seedId}: task card drift`)
  validations.push({ seedId: seed.seedId, scaffoldFalseCertaintyCount: initial.falseCertaintyCount, scaffoldKnownCaseErrors: initial.knownCaseErrorCount, referencePass: reference.fullPass, checkerCatchesScaffold: caught.status === 'FAIL', checkerAcceptsReference: checked.status === 'PASS', commonToolsIdentical: true, normalizedFactsIdentical: true })
}

const result = { schemaVersion: 1, passed: true, sourceTreeHash: sourceTree.hash, seedCount: validations.length, validations }
await writeFile('artifacts/parity-validation.json', JSON.stringify(result, null, 2) + '\n')
console.log(`offline E3 validation passed for ${validations.length} seeds`)

function excludedFromFreeze(name, entry) {
  return name === 'node_modules' || name.startsWith('node_modules/')
    || name === 'artifacts' || name.startsWith('artifacts/')
    || name === 'runs-calibration' || name.startsWith('runs-calibration/')
    || name === 'runs-heldout' || name.startsWith('runs-heldout/')
    || name === 'validation-workspaces' || name.startsWith('validation-workspaces/')
    || name === 'test-workspaces' || name.startsWith('test-workspaces/')
    || (entry.isFile() && name === 'package-lock.json')
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}
