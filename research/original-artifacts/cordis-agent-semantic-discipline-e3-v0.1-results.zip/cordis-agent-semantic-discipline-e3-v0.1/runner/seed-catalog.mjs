const ROWS = Object.freeze([
  ['amber', 'clock', 'panel'],
  ['birch', 'quota', 'digest'],
  ['cobalt', 'metric', 'screen'],
  ['delta', 'route', 'report'],
  ['ember', 'signal', 'console'],
  ['frost', 'index', 'viewer'],
  ['garnet', 'ledger', 'summary'],
  ['harbor', 'cache', 'dashboard'],
])

export function seedByNumber(number) {
  const row = ROWS[number - 1]
  if (!row) throw new Error(`unknown seed number: ${number}`)
  const [prefix, service, consumer] = row
  return Object.freeze({
    number,
    seedId: `e3-epistemic-adapter-s${String(number).padStart(2, '0')}`,
    incidentId: `E3-${prefix.toUpperCase()}-${String(number).padStart(2, '0')}`,
    serviceKey: `${service}Endpoint`,
    consumerName: `${prefix}-${consumer}`,
    providerV1: `${prefix}-provider-v1`,
    providerV2: `${prefix}-provider-v2`,
    packageV1: `${prefix}-package-v1`,
  })
}

export function seeds(numbers) {
  return numbers.map(seedByNumber)
}

export function pairedOrder(numbers) {
  return numbers.flatMap(number => {
    const seed = seedByNumber(number)
    const arms = number % 2 ? ['semantic_typed', 'semantic_soft'] : ['semantic_soft', 'semantic_typed']
    return arms.map(arm => ({ seed, arm }))
  })
}
