The lifecycle status adapter in `src/status-adapter.mjs` has been updated to handle all carrier variants (`KNOWN_VALUE`, `KNOWN_ABSENT`, and `UNKNOWN`) using 3-valued epistemic logic, properly distinguishing established absence from unavailable truth:

- **Transitioning & Provider Action**: Evaluates whether `targetBinding` matches `committedBinding`. If either binding observation has `kind: 'UNKNOWN'`, `transitioning` resolves to `'UNKNOWN'` and `providerAction` defers to `'DEFER_FOR_EVIDENCE'`.
- **Active Run & Package Action**: `activeRunPresent` reflects the established presence or absence of `activeRun`. `packageAction` triggers `'RUN_LAST_SUCCESSFUL'` when an active run is known absent and a last successful package is known present.
- **Cleanup Complete**: Evaluates `cleanupReceipt`, reporting `'TRUE'` only when confirmed `'DISPOSED'`, `'FALSE'` on established absence or non-disposed states, and `'UNKNOWN'` when observation coverage is unavailable.

For consumer `birch-digest` and service `quotaEndpoint`, query results show `targetBinding` and `lastSuccessfulPackage` are known values, `activeRun` is established absent, while `committedBinding` and `cleanupReceipt` remain genuinely unavailable.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "NOT_AVAILABLE"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
