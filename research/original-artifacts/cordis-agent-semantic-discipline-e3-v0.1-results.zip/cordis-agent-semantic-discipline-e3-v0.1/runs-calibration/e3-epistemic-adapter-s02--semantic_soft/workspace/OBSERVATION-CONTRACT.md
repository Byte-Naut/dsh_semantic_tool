# Normalized observation contract

The adapter receives five observations:

- `targetBinding`, `committedBinding`, `activeRun`, and `lastSuccessfulPackage` are entity observations.
- `cleanupReceipt` is a receipt observation whose known value is `DISPOSED` or `REGISTERED`.

Every observation is exactly one carrier variant:

- `{ kind: "KNOWN_VALUE", value: ... }` — the value is observed.
- `{ kind: "KNOWN_ABSENT" }` — absence is established by complete coverage.
- `{ kind: "UNKNOWN" }` — coverage cannot establish a value or absence.

The adapter returns `transitioning`, `activeRunPresent`, and `cleanupComplete` in `TRUE | FALSE | UNKNOWN`, plus one provider action and one Package action. It must be correct for any legal carrier combination, not just incident E3-BIRCH-02.
