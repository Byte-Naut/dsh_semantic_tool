export function deriveLifecycleView(observation = {}) {
  const targetBinding = observation.targetBinding ?? { kind: 'UNKNOWN' }
  const committedBinding = observation.committedBinding ?? { kind: 'UNKNOWN' }
  const activeRun = observation.activeRun ?? { kind: 'UNKNOWN' }
  const lastSuccessfulPackage = observation.lastSuccessfulPackage ?? { kind: 'UNKNOWN' }
  const cleanupReceipt = observation.cleanupReceipt ?? { kind: 'UNKNOWN' }

  // 1. transitioning
  let transitioning
  if (targetBinding.kind === 'UNKNOWN' || committedBinding.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (targetBinding.kind === 'KNOWN_ABSENT' && committedBinding.kind === 'KNOWN_ABSENT') {
    transitioning = 'FALSE'
  } else if (targetBinding.kind === 'KNOWN_ABSENT' || committedBinding.kind === 'KNOWN_ABSENT') {
    transitioning = 'TRUE'
  } else {
    transitioning = targetBinding.value === committedBinding.value ? 'FALSE' : 'TRUE'
  }

  // 2. activeRunPresent
  let activeRunPresent
  if (activeRun.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else if (activeRun.kind === 'KNOWN_ABSENT') {
    activeRunPresent = 'FALSE'
  } else {
    activeRunPresent = 'UNKNOWN'
  }

  // 3. cleanupComplete
  let cleanupComplete
  if (cleanupReceipt.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanupReceipt.kind === 'KNOWN_ABSENT') {
    cleanupComplete = 'FALSE'
  } else {
    cleanupComplete = cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  }

  // 4. providerAction
  let providerAction
  if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else if (transitioning === 'FALSE') {
    providerAction = 'NO_ACTION'
  } else {
    providerAction = 'DEFER_FOR_EVIDENCE'
  }

  // 5. packageAction
  let packageAction
  if (activeRun.kind === 'KNOWN_VALUE') {
    packageAction = 'NO_ACTION'
  } else if (lastSuccessfulPackage.kind === 'KNOWN_ABSENT') {
    packageAction = 'NO_ACTION'
  } else if (activeRun.kind === 'KNOWN_ABSENT' && lastSuccessfulPackage.kind === 'KNOWN_VALUE') {
    packageAction = 'RUN_LAST_SUCCESSFUL'
  } else {
    packageAction = 'DEFER_FOR_EVIDENCE'
  }

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
  }
}
