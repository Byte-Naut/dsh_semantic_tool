The lifecycle status adapter in `src/status-adapter.mjs` has been updated to distinguish established absence (`KNOWN_ABSENT`) from unavailable truth (`UNKNOWN`).

1. **Epistemic Derivation**:
   - `transitioning`: Established as `FALSE` only when `targetBinding` and `committedBinding` are proven identical (including both absent); established as `TRUE` when their observed values or presence differ; evaluates to `UNKNOWN` when coverage of either binding is unavailable.
   - `activeRunPresent`: Reports `TRUE` on `KNOWN_VALUE`, `FALSE` on `KNOWN_ABSENT`, and `UNKNOWN` when coverage is unavailable.
   - `cleanupComplete`: Evaluates to `TRUE` if `cleanupReceipt.value === 'DISPOSED'`, `FALSE` if `KNOWN_ABSENT` or `REGISTERED`, and `UNKNOWN` when coverage is unavailable.
   - `providerAction`: Returns `ALLOW_CURRENT_LOAD_TO_SETTLE` when transitioning is `TRUE`, `NO_ACTION` when `FALSE`, and `DEFER_FOR_EVIDENCE` when transitioning is `UNKNOWN`.
   - `packageAction`: When an active run is present (`KNOWN_VALUE`), no package execution is needed (`NO_ACTION`). When an active run is established absent (`KNOWN_ABSENT`) and a known last successful package exists (`KNOWN_VALUE`), returns `RUN_LAST_SUCCESSFUL`. If absence of a last successful package is established (`KNOWN_ABSENT`), returns `NO_ACTION`. In incomplete or uncertain scenarios, it defers for evidence (`DEFER_FOR_EVIDENCE`).

2. **Incident E3-AMBER-01 View**:
   - `targetBinding`: `KNOWN_VALUE` (`amber-provider-v2`)
   - `committedBinding`: `UNKNOWN`
   - `activeRun`: `KNOWN_ABSENT`
   - `lastSuccessfulPackage`: `KNOWN_VALUE` (`amber-package-v1`)
   - `cleanupReceipt`: `UNKNOWN`
   
   Yielding `transitioning: "UNKNOWN"`, `activeRunPresent: "FALSE"`, `cleanupComplete: "UNKNOWN"`, `providerAction: "DEFER_FOR_EVIDENCE"`, and `packageAction: "RUN_LAST_SUCCESSFUL"`.

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "NOT_AVAILABLE"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
