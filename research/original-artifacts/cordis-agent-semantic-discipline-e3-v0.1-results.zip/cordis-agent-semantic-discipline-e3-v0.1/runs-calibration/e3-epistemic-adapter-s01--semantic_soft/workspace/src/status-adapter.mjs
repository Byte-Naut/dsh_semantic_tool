function deriveTransitioning(targetBinding, committedBinding) {
  if (
    !targetBinding ||
    !committedBinding ||
    targetBinding.kind === 'UNKNOWN' ||
    committedBinding.kind === 'UNKNOWN'
  ) {
    return 'UNKNOWN'
  }

  if (targetBinding.kind === 'KNOWN_ABSENT' && committedBinding.kind === 'KNOWN_ABSENT') {
    return 'FALSE'
  }

  if (targetBinding.kind === 'KNOWN_ABSENT' || committedBinding.kind === 'KNOWN_ABSENT') {
    return 'TRUE'
  }

  return targetBinding.value !== committedBinding.value ? 'TRUE' : 'FALSE'
}

function deriveActiveRunPresent(activeRun) {
  if (activeRun?.kind === 'KNOWN_VALUE') {
    return 'TRUE'
  }
  if (activeRun?.kind === 'KNOWN_ABSENT') {
    return 'FALSE'
  }
  return 'UNKNOWN'
}

function deriveCleanupComplete(cleanupReceipt) {
  if (cleanupReceipt?.kind === 'KNOWN_VALUE') {
    return cleanupReceipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  }
  if (cleanupReceipt?.kind === 'KNOWN_ABSENT') {
    return 'FALSE'
  }
  return 'UNKNOWN'
}

function deriveProviderAction(transitioning) {
  if (transitioning === 'TRUE') {
    return 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  }
  if (transitioning === 'FALSE') {
    return 'NO_ACTION'
  }
  return 'DEFER_FOR_EVIDENCE'
}

function derivePackageAction(activeRun, lastSuccessfulPackage) {
  const activePresent = activeRun?.kind === 'KNOWN_VALUE'
  const activeAbsent = activeRun?.kind === 'KNOWN_ABSENT'
  const lastKnown = lastSuccessfulPackage?.kind === 'KNOWN_VALUE'
  const lastAbsent = lastSuccessfulPackage?.kind === 'KNOWN_ABSENT'

  if (activePresent) {
    return 'NO_ACTION'
  }

  if (activeAbsent) {
    if (lastKnown) {
      return 'RUN_LAST_SUCCESSFUL'
    }
    if (lastAbsent) {
      return 'NO_ACTION'
    }
    return 'DEFER_FOR_EVIDENCE'
  }

  // activeRun is UNKNOWN
  if (lastAbsent) {
    return 'NO_ACTION'
  }
  return 'DEFER_FOR_EVIDENCE'
}

export function deriveLifecycleView(observation = {}) {
  const transitioning = deriveTransitioning(
    observation.targetBinding,
    observation.committedBinding,
  )
  const activeRunPresent = deriveActiveRunPresent(observation.activeRun)
  const cleanupComplete = deriveCleanupComplete(observation.cleanupReceipt)
  const providerAction = deriveProviderAction(transitioning)
  const packageAction = derivePackageAction(
    observation.activeRun,
    observation.lastSuccessfulPackage,
  )

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
  }
}
