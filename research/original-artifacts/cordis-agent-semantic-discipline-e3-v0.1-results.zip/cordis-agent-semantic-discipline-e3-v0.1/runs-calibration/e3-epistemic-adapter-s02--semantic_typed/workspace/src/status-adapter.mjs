export function deriveLifecycleView(observation) {
  const target = observation.targetBinding
  const committed = observation.committedBinding
  const active = observation.activeRun
  const lastSuccessful = observation.lastSuccessfulPackage
  const cleanup = observation.cleanupReceipt

  // 1. transitioning
  let transitioning
  if (target?.kind === 'UNKNOWN' || committed?.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (target?.kind === 'KNOWN_ABSENT' && committed?.kind === 'KNOWN_ABSENT') {
    transitioning = 'FALSE'
  } else if (target?.kind === 'KNOWN_VALUE' && committed?.kind === 'KNOWN_VALUE') {
    transitioning = target.value !== committed.value ? 'TRUE' : 'FALSE'
  } else {
    // one is KNOWN_ABSENT, the other is KNOWN_VALUE
    transitioning = 'TRUE'
  }

  // 2. activeRunPresent
  let activeRunPresent
  if (active?.kind === 'UNKNOWN') {
    activeRunPresent = 'UNKNOWN'
  } else if (active?.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else {
    activeRunPresent = 'FALSE'
  }

  // 3. cleanupComplete
  let cleanupComplete
  if (cleanup?.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanup?.kind === 'KNOWN_VALUE' && cleanup.value === 'DISPOSED') {
    cleanupComplete = 'TRUE'
  } else {
    cleanupComplete = 'FALSE'
  }

  // 4. providerAction
  let providerAction
  if (transitioning === 'UNKNOWN') {
    providerAction = 'DEFER_FOR_EVIDENCE'
  } else if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else {
    providerAction = 'NO_ACTION'
  }

  // 5. packageAction
  let packageAction
  if (lastSuccessful?.kind === 'KNOWN_ABSENT') {
    packageAction = 'NO_ACTION'
  } else if (active?.kind === 'KNOWN_VALUE') {
    packageAction = 'NO_ACTION'
  } else if (active?.kind === 'UNKNOWN' || lastSuccessful?.kind === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else if (active?.kind === 'KNOWN_ABSENT' && lastSuccessful?.kind === 'KNOWN_VALUE') {
    packageAction = 'RUN_LAST_SUCCESSFUL'
  } else {
    packageAction = 'NO_ACTION'
  }

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
  }
}
