The lifecycle status adapter in `src/status-adapter.mjs` has been updated to handle partial semantic coverage and all carrier observation kinds (`KNOWN_VALUE`, `KNOWN_ABSENT`, and `UNKNOWN`).

Key updates:
- Propagates `UNKNOWN` for binding comparisons (`transitioning`), active run presence (`activeRunPresent`), and cleanup receipts (`cleanupComplete`).
- Preserves established absence (`KNOWN_ABSENT`) distinct from unavailable truth (`UNKNOWN`).
- Defers dependent actions (`DEFER_FOR_EVIDENCE`) when necessary evidence is `UNKNOWN`, while allowing decisive actions (`RUN_LAST_SUCCESSFUL`) when prerequisite absence and target values are established facts.
- Verified against visible test suites and epistemic obligation checks (`PASS`).

```json
{
  "status": "PASS",
  "current_view": {
    "transitioning": "UNKNOWN",
    "activeRunPresent": "FALSE",
    "cleanupComplete": "UNKNOWN",
    "providerAction": "DEFER_FOR_EVIDENCE",
    "packageAction": "RUN_LAST_SUCCESSFUL"
  },
  "verification": {
    "visible_tests": "PASS",
    "typed_obligation_checker": "PASS"
  },
  "remaining_unknowns": [
    "cleanupReceipt",
    "committedBinding"
  ]
}
```
