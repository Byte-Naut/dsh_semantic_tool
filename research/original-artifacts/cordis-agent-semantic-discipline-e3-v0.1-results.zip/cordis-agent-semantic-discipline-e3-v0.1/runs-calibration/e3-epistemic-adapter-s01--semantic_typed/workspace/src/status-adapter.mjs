export function deriveLifecycleView(observation) {
  const target = observation.targetBinding
  const committed = observation.committedBinding
  const activeRun = observation.activeRun
  const lastPkg = observation.lastSuccessfulPackage
  const cleanup = observation.cleanupReceipt

  // transitioning
  let transitioning
  if (!target || !committed || target.kind === 'UNKNOWN' || committed.kind === 'UNKNOWN') {
    transitioning = 'UNKNOWN'
  } else if (target.kind === 'KNOWN_VALUE' && committed.kind === 'KNOWN_VALUE') {
    transitioning = target.value !== committed.value ? 'TRUE' : 'FALSE'
  } else if (target.kind === 'KNOWN_ABSENT' && committed.kind === 'KNOWN_ABSENT') {
    transitioning = 'FALSE'
  } else {
    transitioning = 'TRUE'
  }

  // activeRunPresent
  let activeRunPresent
  if (!activeRun || activeRun.kind === 'UNKNOWN') {
    activeRunPresent = 'UNKNOWN'
  } else if (activeRun.kind === 'KNOWN_VALUE') {
    activeRunPresent = 'TRUE'
  } else {
    activeRunPresent = 'FALSE'
  }

  // cleanupComplete
  let cleanupComplete
  if (!cleanup || cleanup.kind === 'UNKNOWN') {
    cleanupComplete = 'UNKNOWN'
  } else if (cleanup.kind === 'KNOWN_VALUE') {
    cleanupComplete = cleanup.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
  } else {
    cleanupComplete = 'FALSE'
  }

  // providerAction
  let providerAction
  if (transitioning === 'UNKNOWN') {
    providerAction = 'DEFER_FOR_EVIDENCE'
  } else if (transitioning === 'TRUE') {
    providerAction = 'ALLOW_CURRENT_LOAD_TO_SETTLE'
  } else {
    providerAction = 'NO_ACTION'
  }

  // packageAction
  let packageAction
  if (lastPkg?.kind === 'KNOWN_ABSENT') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'TRUE') {
    packageAction = 'NO_ACTION'
  } else if (activeRunPresent === 'UNKNOWN' || !lastPkg || lastPkg.kind === 'UNKNOWN') {
    packageAction = 'DEFER_FOR_EVIDENCE'
  } else {
    packageAction = 'RUN_LAST_SUCCESSFUL'
  }

  return {
    transitioning,
    activeRunPresent,
    cleanupComplete,
    providerAction,
    packageAction,
  }
}
