export function oneSidedExactSignP(positive, negative) {
  const n = positive + negative
  if (n === 0) return 1
  let probability = 0
  for (let k = positive; k <= n; k += 1) probability += choose(n, k) * 0.5 ** n
  return probability
}

function choose(n, k) {
  const width = Math.min(k, n - k)
  let value = 1
  for (let index = 1; index <= width; index += 1) value = value * (n - width + index) / index
  return value
}
