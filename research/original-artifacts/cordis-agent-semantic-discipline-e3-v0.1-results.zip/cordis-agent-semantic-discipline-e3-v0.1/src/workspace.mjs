import { execFile } from 'node:child_process'
import { mkdir, readFile, readdir, stat, writeFile } from 'node:fs/promises'
import { dirname, join, relative, resolve, sep } from 'node:path'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)

export async function materializeWorkspace(root, files) {
  await mkdir(root, { recursive: true })
  for (const [name, content] of Object.entries(files)) {
    const path = safePath(root, name)
    await mkdir(dirname(path), { recursive: true })
    await writeFile(path, content)
  }
}

export class WorkspaceAccess {
  constructor(root, { editableFiles, telemetry }) {
    this.root = root
    this.editableFiles = new Set(editableFiles)
    this.telemetry = telemetry
  }

  async listFiles() {
    const files = []
    await walk(this.root, this.root, files)
    return files.sort()
  }

  async readFile(name) {
    const content = await readFile(safePath(this.root, name), 'utf8')
    this.telemetry.record('file_read', { path: name, bytes: Buffer.byteLength(content) })
    return { path: name, content }
  }

  async writeFile(name, content) {
    if (!this.editableFiles.has(name)) throw new Error(`file is outside the approved edit scope: ${name}`)
    const path = safePath(this.root, name)
    const before = await readFile(path, 'utf8')
    await writeFile(path, normalizeNewline(content))
    const after = await readFile(path, 'utf8')
    this.telemetry.record('file_changed', { path: name, beforeLines: lineCount(before), afterLines: lineCount(after) })
    return { path: name, bytes: Buffer.byteLength(after) }
  }

  async runVisibleTests() {
    const started = performance.now()
    try {
      const { stdout, stderr } = await execFileAsync(process.execPath, ['--test'], {
        cwd: this.root, timeout: 60_000, maxBuffer: 512_000, env: { PATH: process.env.PATH },
      })
      this.telemetry.record('test_executed', { commandId: 'node--test', status: 'pass', durationMs: Math.round(performance.now() - started) })
      return { status: 'pass', stdout, stderr }
    } catch (error) {
      this.telemetry.record('test_executed', { commandId: 'node--test', status: 'fail', durationMs: Math.round(performance.now() - started) })
      return { status: 'fail', stdout: error.stdout ?? '', stderr: error.stderr ?? String(error.message) }
    }
  }
}

export function safePath(root, name) {
  if (typeof name !== 'string' || !name || name.includes('\0')) throw new Error('invalid path')
  const absoluteRoot = resolve(root)
  const path = resolve(absoluteRoot, name)
  if (path !== absoluteRoot && !path.startsWith(absoluteRoot + sep)) throw new Error(`path escapes Agent workspace: ${name}`)
  return path
}

async function walk(root, directory, output) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isDirectory()) await walk(root, path, output)
    else if (entry.isFile() && (await stat(path)).size >= 0) output.push(relative(root, path))
  }
}

function normalizeNewline(value) {
  return String(value).replace(/\s*$/, '') + '\n'
}

function lineCount(value) {
  return value === '' ? 0 : value.replace(/\n$/, '').split('\n').length
}
