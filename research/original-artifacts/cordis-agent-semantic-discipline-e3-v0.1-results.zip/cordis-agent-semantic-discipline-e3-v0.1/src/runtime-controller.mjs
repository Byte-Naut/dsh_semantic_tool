import * as task from '../tasks/e3-epistemic-adapter/spec.mjs'
import { createEpistemicRuntime } from '../tasks/e3-epistemic-adapter/fixture.mjs'
import { TASK_ID } from './config.mjs'

export async function createRuntime(taskId, seed, workspace) {
  requireTask(taskId)
  return createEpistemicRuntime(seed, workspace)
}

export function taskCard(taskId, seed) {
  requireTask(taskId)
  return task.publicTaskCard(seed)
}

export function taskWorkspaceFiles(taskId, seed) {
  requireTask(taskId)
  return task.workspaceFiles(seed)
}

export function taskEditableFiles(taskId) {
  requireTask(taskId)
  return task.editableFiles
}

export function taskCriticalErrors(taskId) {
  requireTask(taskId)
  return task.criticalErrors
}

function requireTask(taskId) {
  if (taskId !== TASK_ID) throw new Error(`unknown task: ${taskId}`)
}
