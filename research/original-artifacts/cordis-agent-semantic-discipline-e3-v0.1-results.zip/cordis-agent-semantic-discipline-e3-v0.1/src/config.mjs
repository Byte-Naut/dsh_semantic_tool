export const EXPERIMENT = Object.freeze({
  id: 'cordis-agent-semantic-discipline-e3-v01',
  phase: 'staged paired E3 mechanism experiment',
  hypothesis: 'typed semantic obligations reduce false certainty after identical normalized facts are supplied',
  model: 'gemini-3.8-flash',
  thinkingLevel: 'medium',
  temperature: 1,
  candidateCount: 1,
  maxOutputTokensPerRequest: 32_768,
  maxToolCallsPerTurn: 16,
  maxRequestsPerTurn: 20,
  maxGrossInputTokensPerRun: 1_000_000,
  maxGrossOutputTokensPerRun: 100_000,
  requestTimeoutMs: 180_000,
  runTimeoutMs: 600_000,
  httpAttempts: 1,
  modelSeedBase: 73_000,
  fallback: false,
  calibrationSeedNumbers: Object.freeze([1, 2]),
  heldOutSeedNumbers: Object.freeze([3, 4, 5, 6, 7, 8]),
  pricingUsdPerMillion: Object.freeze({ input: 0.75, outputIncludingThinking: 3.75 }),
})

export const TASK_ID = 'e3-epistemic-adapter'
export const ARMS = Object.freeze(['semantic_soft', 'semantic_typed'])

export const TRUTH_VALUES = Object.freeze(['TRUE', 'FALSE', 'UNKNOWN'])
export const PROVIDER_ACTIONS = Object.freeze(['ALLOW_CURRENT_LOAD_TO_SETTLE', 'NO_ACTION', 'DEFER_FOR_EVIDENCE'])
export const PACKAGE_ACTIONS = Object.freeze(['RUN_LAST_SUCCESSFUL', 'NO_ACTION', 'DEFER_FOR_EVIDENCE'])

export function modelSeed(fixtureNumber) {
  return EXPERIMENT.modelSeedBase + fixtureNumber
}
