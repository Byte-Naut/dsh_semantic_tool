# Cordis Agent Semantic Discipline E3 v0.1

This benchmark isolates E3 from E1/E2. Both paired arms receive the same normalized lifecycle snapshot, task card, workspace, model configuration, and non-treatment tools.

- `semantic_soft`: normalized facts plus ordinary source editing and visible tests.
- `semantic_typed`: the same interface plus one executable typed-obligation checker. The checker adds no world facts; it enforces three-valued propagation, safe deferral, known-absence separation, and known-case decisiveness.

The primary endpoint is executable false certainty: returning `TRUE`/`FALSE` where evidence requires `UNKNOWN`, or selecting a non-deferred action whose premise is unknown. Hidden known-input cases prevent an always-`UNKNOWN` implementation from passing.

The frozen staged protocol runs two calibration pairs and conditionally runs six untouched held-out pairs only if the predeclared continuation gate passes.

Commands:

```bash
npm test
npm run freeze
npm run validate
node runner/run-experiment.mjs --key-stdin
npm run analyze
```
