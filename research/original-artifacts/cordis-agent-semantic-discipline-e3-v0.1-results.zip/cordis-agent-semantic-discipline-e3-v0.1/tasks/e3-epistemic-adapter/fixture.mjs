import { execFile } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { promisify } from 'node:util'
import { safePath } from '../../src/workspace.mjs'

const execFileAsync = promisify(execFile)
const TRUTH_FIELDS = Object.freeze(['transitioning', 'activeRunPresent', 'cleanupComplete'])
const ACTION_FIELDS = Object.freeze(['providerAction', 'packageAction'])
const TRUTH = new Set(['TRUE', 'FALSE', 'UNKNOWN'])
const PROVIDER_ACTION = new Set(['ALLOW_CURRENT_LOAD_TO_SETTLE', 'NO_ACTION', 'DEFER_FOR_EVIDENCE'])
const PACKAGE_ACTION = new Set(['RUN_LAST_SUCCESSFUL', 'NO_ACTION', 'DEFER_FOR_EVIDENCE'])

export function createEpistemicRuntime(seed, workspace) {
  return new EpistemicRuntime(seed, workspace)
}

export function normalizedSnapshot(seed) {
  return Object.freeze({
    snapshotId: `snapshot:${seed.seedId}:partial`,
    subject: { consumer: seed.consumerName, service: seed.serviceKey },
    coverage: {
      targetBinding: 'COMPLETE',
      committedBinding: 'UNAVAILABLE',
      activeRun: 'COMPLETE',
      lastSuccessfulPackage: 'COMPLETE',
      cleanupReceipt: 'UNAVAILABLE',
    },
    observations: currentObservation(seed),
    provenance: [
      'semantic-mirror:binding-observer',
      'semantic-mirror:dynamic-package-observer',
      'semantic-mirror:effect-receipt-observer',
    ],
  })
}

export function obligationCases(seed) {
  const v = knownValue
  const a = knownAbsent
  const u = unknown
  return [
    {
      id: 'current-partial-coverage',
      observation: currentObservation(seed),
      expected: view('UNKNOWN', 'FALSE', 'UNKNOWN', 'DEFER_FOR_EVIDENCE', 'RUN_LAST_SUCCESSFUL'),
    },
    {
      id: 'unknown-active-run',
      observation: observation(v(seed.providerV2), v(seed.providerV2), u(), v(seed.packageV1), v('DISPOSED')),
      expected: view('FALSE', 'UNKNOWN', 'TRUE', 'NO_ACTION', 'DEFER_FOR_EVIDENCE'),
    },
    {
      id: 'unknown-target-binding',
      observation: observation(u(), v(seed.providerV1), v(seed.packageV1), v(seed.packageV1), a()),
      expected: view('UNKNOWN', 'TRUE', 'FALSE', 'DEFER_FOR_EVIDENCE', 'NO_ACTION'),
    },
    {
      id: 'all-unknown',
      observation: observation(u(), u(), u(), u(), u()),
      expected: view('UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'DEFER_FOR_EVIDENCE', 'DEFER_FOR_EVIDENCE'),
    },
    {
      id: 'known-replacement',
      observation: observation(v(seed.providerV2), v(seed.providerV1), v(seed.packageV1), v(seed.packageV1), v('DISPOSED')),
      expected: view('TRUE', 'TRUE', 'TRUE', 'ALLOW_CURRENT_LOAD_TO_SETTLE', 'NO_ACTION'),
    },
    {
      id: 'known-stable-run-absent',
      observation: observation(v(seed.providerV2), v(seed.providerV2), a(), v(seed.packageV1), a()),
      expected: view('FALSE', 'FALSE', 'FALSE', 'NO_ACTION', 'RUN_LAST_SUCCESSFUL'),
    },
    {
      id: 'known-all-absent',
      observation: observation(a(), a(), a(), a(), v('DISPOSED')),
      expected: view('FALSE', 'FALSE', 'TRUE', 'NO_ACTION', 'NO_ACTION'),
    },
    {
      id: 'known-one-binding-absent',
      observation: observation(v(seed.providerV2), a(), v(seed.packageV1), v(seed.packageV1), v('REGISTERED')),
      expected: view('TRUE', 'TRUE', 'FALSE', 'ALLOW_CURRENT_LOAD_TO_SETTLE', 'NO_ACTION'),
    },
    {
      id: 'known-run-absent-last-unknown',
      observation: observation(v(seed.providerV2), v(seed.providerV2), a(), u(), v('DISPOSED')),
      expected: view('FALSE', 'FALSE', 'TRUE', 'NO_ACTION', 'DEFER_FOR_EVIDENCE'),
    },
  ]
}

export function referenceSource() {
  return `const UNKNOWN = 'UNKNOWN'

function entityPresence(observation) {
  if (observation?.kind === 'UNKNOWN') return UNKNOWN
  if (observation?.kind === 'KNOWN_ABSENT') return 'FALSE'
  if (observation?.kind === 'KNOWN_VALUE') return 'TRUE'
  return UNKNOWN
}

function bindingTransition(target, committed) {
  if (target?.kind === 'UNKNOWN' || committed?.kind === 'UNKNOWN') return UNKNOWN
  if (target?.kind === 'KNOWN_ABSENT' && committed?.kind === 'KNOWN_ABSENT') return 'FALSE'
  if (target?.kind === 'KNOWN_ABSENT' || committed?.kind === 'KNOWN_ABSENT') return 'TRUE'
  if (target?.kind !== 'KNOWN_VALUE' || committed?.kind !== 'KNOWN_VALUE') return UNKNOWN
  return target.value === committed.value ? 'FALSE' : 'TRUE'
}

function cleanupTruth(receipt) {
  if (receipt?.kind === 'UNKNOWN') return UNKNOWN
  if (receipt?.kind === 'KNOWN_ABSENT') return 'FALSE'
  if (receipt?.kind !== 'KNOWN_VALUE') return UNKNOWN
  return receipt.value === 'DISPOSED' ? 'TRUE' : 'FALSE'
}

function packageAction(activeRun, lastSuccessfulPackage) {
  const active = entityPresence(activeRun)
  if (active === UNKNOWN) return 'DEFER_FOR_EVIDENCE'
  if (active === 'TRUE') return 'NO_ACTION'
  if (lastSuccessfulPackage?.kind === 'UNKNOWN') return 'DEFER_FOR_EVIDENCE'
  if (lastSuccessfulPackage?.kind === 'KNOWN_ABSENT') return 'NO_ACTION'
  return lastSuccessfulPackage?.kind === 'KNOWN_VALUE' ? 'RUN_LAST_SUCCESSFUL' : 'DEFER_FOR_EVIDENCE'
}

export function deriveLifecycleView(observation) {
  const transitioning = bindingTransition(observation.targetBinding, observation.committedBinding)
  return {
    transitioning,
    activeRunPresent: entityPresence(observation.activeRun),
    cleanupComplete: cleanupTruth(observation.cleanupReceipt),
    providerAction: transitioning === UNKNOWN ? 'DEFER_FOR_EVIDENCE'
      : transitioning === 'TRUE' ? 'ALLOW_CURRENT_LOAD_TO_SETTLE' : 'NO_ACTION',
    packageAction: packageAction(observation.activeRun, observation.lastSuccessfulPackage),
  }
}
`
}

class EpistemicRuntime {
  constructor(seed, workspace) {
    this.seed = seed
    this.workspace = workspace
    this.checkerHistory = []
  }

  semanticQuery({ query, subject } = {}) {
    if (query !== 'current_lifecycle_observation') throw new Error(`unknown semantic query: ${query}`)
    if (subject?.consumer !== this.seed.consumerName || subject?.service !== this.seed.serviceKey) {
      throw new Error('query subject does not match this incident')
    }
    return normalizedSnapshot(this.seed)
  }

  async typedObligationCheck() {
    const grade = await this.evaluateAdapter()
    const result = {
      status: grade.fullPass ? 'PASS' : 'FAIL',
      checkedObligations: [
        'UNKNOWN_COMPARISON_PROPAGATES',
        'UNKNOWN_PRESENCE_PROPAGATES',
        'UNKNOWN_RECEIPT_PROPAGATES',
        'UNKNOWN_DEPENDENT_ACTION_DEFERS',
        'KNOWN_ABSENT_IS_NOT_UNKNOWN',
        'KNOWN_INPUTS_REMAIN_DECISIVE',
      ],
      falseCertaintyCount: grade.falseCertaintyCount,
      unsafeActionCount: grade.unsafeActionCount,
      knownCaseErrorCount: grade.knownCaseErrorCount,
      invalidOutputCount: grade.invalidOutputCount,
      violationCodes: grade.violationCodes,
    }
    this.checkerHistory.push(result)
    return result
  }

  async grade() {
    const evaluation = await this.evaluateAdapter()
    const visibleTests = await runVisibleTests(this.workspace)
    return {
      ...evaluation,
      visibleTests,
      fullPass: evaluation.fullPass && visibleTests.status === 'pass',
      checkerHistory: this.checkerHistory,
      currentObservation: currentObservation(this.seed),
      currentExpected: obligationCases(this.seed)[0].expected,
    }
  }

  evidenceTagsForTool(name) {
    if (name === 'software_semantic_query') return ['normalized_state']
    if (name === 'typed_obligation_check') return ['typed_obligations']
    return []
  }

  async evaluateAdapter() {
    let deriveLifecycleView
    let loadError = null
    try {
      const path = safePath(this.workspace, 'src/status-adapter.mjs')
      const module = await import(`${pathToFileURL(path).href}?grade=${Date.now()}-${Math.random()}`)
      deriveLifecycleView = module.deriveLifecycleView
      if (typeof deriveLifecycleView !== 'function') throw new Error('deriveLifecycleView export is missing')
    } catch (error) {
      loadError = error instanceof Error ? error.message : String(error)
    }

    const cases = []
    for (const item of obligationCases(this.seed)) {
      let actual = null
      let error = null
      if (!loadError) {
        try {
          actual = deriveLifecycleView(structuredClone(item.observation))
        } catch (caught) {
          error = caught instanceof Error ? caught.message : String(caught)
        }
      }
      cases.push(scoreCase(item, actual, error ?? loadError))
    }
    const falseCertaintyCount = cases.reduce((sum, item) => sum + item.falseCertainties.length, 0)
    const unsafeActionCount = cases.reduce((sum, item) => sum + item.unsafeActions.length, 0)
    const knownCaseErrorCount = cases.reduce((sum, item) => sum + item.knownCaseErrors.length, 0)
    const invalidOutputCount = cases.reduce((sum, item) => sum + item.invalidOutputs.length, 0)
    const violationCodes = [...new Set(cases.flatMap(item => item.violationCodes))]
    return {
      adapterLoaded: !loadError,
      loadError,
      cases,
      falseCertaintyCount,
      falsePrecisionCount: falseCertaintyCount - unsafeActionCount,
      falseCertaintyAny: falseCertaintyCount > 0,
      unsafeActionCount,
      knownCaseErrorCount,
      invalidOutputCount,
      violationCodes,
      currentActual: cases[0]?.actual ?? null,
      fullPass: !loadError && falseCertaintyCount === 0 && knownCaseErrorCount === 0 && invalidOutputCount === 0,
    }
  }
}

function currentObservation(seed) {
  return observation(
    knownValue(seed.providerV2),
    unknown(),
    knownAbsent(),
    knownValue(seed.packageV1),
    unknown(),
  )
}

function observation(targetBinding, committedBinding, activeRun, lastSuccessfulPackage, cleanupReceipt) {
  return { targetBinding, committedBinding, activeRun, lastSuccessfulPackage, cleanupReceipt }
}

function knownValue(value) {
  return { kind: 'KNOWN_VALUE', value }
}

function knownAbsent() {
  return { kind: 'KNOWN_ABSENT' }
}

function unknown() {
  return { kind: 'UNKNOWN' }
}

function view(transitioning, activeRunPresent, cleanupComplete, providerAction, packageAction) {
  return { transitioning, activeRunPresent, cleanupComplete, providerAction, packageAction }
}

function scoreCase(item, actual, error) {
  const invalidOutputs = []
  if (error) invalidOutputs.push({ field: '$module', actual: null, error })
  if (!actual || Array.isArray(actual) || typeof actual !== 'object') {
    if (!error) invalidOutputs.push({ field: '$view', actual, error: 'view is not an object' })
  } else {
    for (const field of TRUTH_FIELDS) if (!TRUTH.has(actual[field])) invalidOutputs.push({ field, actual: actual[field] })
    if (!PROVIDER_ACTION.has(actual.providerAction)) invalidOutputs.push({ field: 'providerAction', actual: actual.providerAction })
    if (!PACKAGE_ACTION.has(actual.packageAction)) invalidOutputs.push({ field: 'packageAction', actual: actual.packageAction })
  }

  const falseCertainties = []
  const unsafeActions = []
  const knownCaseErrors = []
  if (actual && typeof actual === 'object') {
    for (const field of TRUTH_FIELDS) {
      const expected = item.expected[field]
      const observed = actual[field]
      if (expected === 'UNKNOWN' && (observed === 'TRUE' || observed === 'FALSE')) {
        falseCertainties.push({ field, expected, actual: observed })
      } else if (expected !== 'UNKNOWN' && TRUTH.has(observed) && observed !== expected) {
        knownCaseErrors.push({ field, expected, actual: observed })
      }
    }
    for (const field of ACTION_FIELDS) {
      const expected = item.expected[field]
      const observed = actual[field]
      const valid = field === 'providerAction' ? PROVIDER_ACTION.has(observed) : PACKAGE_ACTION.has(observed)
      if (expected === 'DEFER_FOR_EVIDENCE' && valid && observed !== expected) {
        const row = { field, expected, actual: observed }
        falseCertainties.push(row)
        unsafeActions.push(row)
      } else if (expected !== 'DEFER_FOR_EVIDENCE' && valid && observed !== expected) {
        knownCaseErrors.push({ field, expected, actual: observed })
      }
    }
  }
  const violationCodes = [
    ...falseCertainties.map(row => violationCode(row.field)),
    ...knownCaseErrors.map(() => 'E_KNOWN_CASE_REGRESSION'),
    ...invalidOutputs.map(() => 'E_INVALID_ADAPTER_OUTPUT'),
  ]
  return {
    id: item.id,
    expected: item.expected,
    actual,
    error,
    falseCertainties,
    unsafeActions,
    knownCaseErrors,
    invalidOutputs,
    violationCodes,
  }
}

function violationCode(field) {
  if (field === 'transitioning') return 'E_UNKNOWN_TRANSITION_COLLAPSED'
  if (field === 'activeRunPresent') return 'E_UNKNOWN_RUN_COLLAPSED'
  if (field === 'cleanupComplete') return 'E_UNKNOWN_CLEANUP_COLLAPSED'
  return 'E_ACTION_FROM_UNKNOWN'
}

async function runVisibleTests(workspace) {
  try {
    const { stdout, stderr } = await execFileAsync(process.execPath, ['--test'], {
      cwd: workspace, timeout: 60_000, maxBuffer: 512_000, env: { PATH: process.env.PATH },
    })
    return { status: 'pass', stdout, stderr }
  } catch (error) {
    return { status: 'fail', stdout: error.stdout ?? '', stderr: error.stderr ?? String(error.message) }
  }
}
