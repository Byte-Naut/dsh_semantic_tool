import { createT1Runtime } from '../tasks/t1-provider-withdrawal/fixture-factory.mjs'
import * as t1 from '../tasks/t1-provider-withdrawal/spec.mjs'
import { createT2Runtime } from '../tasks/t2-loading-status/fixture-factory.mjs'
import * as t2 from '../tasks/t2-loading-status/spec.mjs'
import { createT3Runtime } from '../tasks/t3-failed-update/fixture-factory.mjs'
import * as t3 from '../tasks/t3-failed-update/spec.mjs'

const TASKS = Object.freeze({
  't1-provider-withdrawal': { spec: t1, createRuntime: createT1Runtime },
  't2-loading-status': { spec: t2, createRuntime: createT2Runtime },
  't3-failed-update': { spec: t3, createRuntime: createT3Runtime },
})

export function taskDefinition(taskId) {
  const task = TASKS[taskId]
  if (!task) throw new Error(`unknown task: ${taskId}`)
  return task
}

export async function createRuntime(taskId, seed, workspace) {
  return taskDefinition(taskId).createRuntime(seed, workspace)
}

export function taskCard(taskId, seed, runtime) {
  return taskDefinition(taskId).spec.publicTaskCard(seed, runtime.publicState)
}

export function taskWorkspaceFiles(taskId, seed) {
  return taskDefinition(taskId).spec.workspaceFiles(seed)
}

export function taskEditableFiles(taskId) {
  return taskDefinition(taskId).spec.editableFiles
}

export function taskCriticalErrors(taskId) {
  return taskDefinition(taskId).spec.criticalErrors
}
