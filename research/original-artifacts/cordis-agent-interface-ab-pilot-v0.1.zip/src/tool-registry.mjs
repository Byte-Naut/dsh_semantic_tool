import { WorkspaceAccess } from './workspace.mjs'

const OBJECT = 'object'

export function createToolRegistry({ arm, runtime, workspace, editableFiles, telemetry, turn }) {
  const access = new WorkspaceAccess(workspace, { editableFiles, telemetry, turn })
  const tools = []
  const add = (name, description, parametersJsonSchema, category, handler) => {
    tools.push({
      declaration: { name, description, ...(parametersJsonSchema ? { parametersJsonSchema } : {}) },
      category,
      handler,
    })
  }

  add('list_files', 'List files in the isolated Agent-readable workspace.', null, 'READ_SOURCE', () => access.listFiles())
  add('read_file', 'Read one UTF-8 file from the isolated Agent-readable workspace.', objectSchema({
    path: { type: 'string' },
  }, ['path']), 'READ_SOURCE', ({ path }) => access.readFile(path))
  add('run_visible_tests', 'Run the fixture-owned visible Node tests and return their raw result.', null, 'RUN_CHECK', () => access.runVisibleTests())
  add('list_checkpoints', 'List immutable runtime checkpoints exposed for this incident.', null, 'OBSERVE_NATIVE', () => runtime.checkpoints())
  add('native_list_fibers', 'List raw Cordis fiber identity, state, parent, and declared-injection fields without joining dependencies.', checkpointSchema(), 'OBSERVE_NATIVE', ({ checkpointId }) => {
    const snapshot = runtime.nativeSnapshot(checkpointId)
    return snapshot.fibers.map(({ targetBindings, committedBindings, effects, ...fiber }) => fiber)
  })
  add('native_inspect_fiber', 'Read raw target store, committed store, and tracked effect metadata for one Cordis fiber.', objectSchema({
    fiberId: { type: 'string' },
    checkpointId: { type: 'string' },
  }, ['fiberId']), 'OBSERVE_NATIVE', ({ fiberId, checkpointId }) => {
    const fiber = runtime.nativeSnapshot(checkpointId).fibers.find(row => row.fiberId === fiberId || row.name === fiberId)
    if (!fiber) throw new Error(`unknown fiber: ${fiberId}`)
    return fiber
  })
  add('native_list_services', 'List raw registered service implementations, providers, versions, and visibility at one checkpoint.', checkpointSchema(), 'OBSERVE_NATIVE', ({ checkpointId }) => runtime.nativeSnapshot(checkpointId).services)
  add('native_event_slice', 'Return the ordered raw lifecycle and fixture event slice for this incident.', null, 'OBSERVE_NATIVE', () => runtime.nativeEvents())
  add('cordis_inspect_self', 'Inspect source-free session-owned dynamic Plugin, immutable Package, latest-attempt, and active-Run fields.', null, 'OBSERVE_NATIVE', () => runtime.cordisInspectSelf())

  if (runtime.inspectPackage) {
    add('dynamic_inspect_package', 'Read one exact immutable dynamic Package, including its stored source and current lifecycle pointers.', objectSchema({
      pluginId: { type: 'string' },
      packageId: { type: 'string' },
    }, ['pluginId', 'packageId']), 'OBSERVE_NATIVE', args => runtime.inspectPackage(args))
  }

  if (arm === 'relational') {
    add('software_semantic_query', 'Run one read-only semantic query over an immutable runtime snapshot. The result includes declared coverage, unknowns, and ground-fact provenance.', objectSchema({
      query: {
        type: 'string',
        enum: ['impact_remove', 'explain_binding_divergence', 'explain_dynamic_package_state'],
      },
      subject: {
        type: OBJECT,
        additionalProperties: false,
        properties: {
          snapshotId: { type: 'string' },
          serviceImplId: { type: 'string' },
          fiberId: { type: 'string' },
          serviceKey: { type: 'string' },
          pluginId: { type: 'string' },
        },
      },
    }, ['query', 'subject']), 'OBSERVE_RELATIONAL', request => runtime.semanticQuery(request))
  }

  if (turn === 2) {
    if (editableFiles.length) {
      add('write_file', 'Replace one approved benchmark-owned source file with the supplied UTF-8 content.', objectSchema({
        path: { type: 'string' },
        content: { type: 'string' },
      }, ['path', 'content']), 'EDIT_ARTIFACT', ({ path, content }) => access.writeFile(path, content))
    }
    if (runtime.definePackage) {
      add('dynamic_define_package', 'Define a fresh immutable Host Package, either on an existing Plugin or on a newly requested Plugin.', objectSchema({
        pluginId: { type: 'string' },
        newPluginPrefix: { type: 'string' },
        name: { type: 'string' },
        purpose: { type: 'string' },
        hostCode: { type: 'string' },
      }, ['name', 'purpose', 'hostCode']), 'MUTATE_FIXTURE', args => runtime.definePackage(args))
      add('dynamic_run_package', 'Run or update one exact immutable Package. Mode run restarts the selected current version; mode update switches versions.', objectSchema({
        pluginId: { type: 'string' },
        packageId: { type: 'string' },
        mode: { type: 'string', enum: ['run', 'update'] },
      }, ['pluginId', 'packageId', 'mode']), 'MUTATE_FIXTURE', args => runtime.runPackage(args))
    }
  }

  const byName = new Map(tools.map(tool => [tool.declaration.name, tool]))
  return {
    declarations: tools.map(tool => tool.declaration),
    async call(name, args = {}) {
      const tool = byName.get(name)
      if (!tool) throw new Error(`tool is unavailable in this turn: ${name}`)
      const inputBytes = Buffer.byteLength(JSON.stringify(args))
      telemetry.record('tool_called', { name, category: tool.category, inputBytes, turn })
      const started = performance.now()
      try {
        const output = await tool.handler(args)
        const outputBytes = Buffer.byteLength(JSON.stringify(output))
        telemetry.record('tool_returned', {
          name,
          category: tool.category,
          outputBytes,
          durationMs: Math.round(performance.now() - started),
          status: 'ok',
          turn,
        })
        return output
      } catch (error) {
        const output = { error: error instanceof Error ? error.message : String(error) }
        telemetry.record('tool_returned', {
          name,
          category: tool.category,
          outputBytes: Buffer.byteLength(JSON.stringify(output)),
          durationMs: Math.round(performance.now() - started),
          status: 'error',
          turn,
        })
        return output
      }
    },
  }
}

function checkpointSchema() {
  return objectSchema({ checkpointId: { type: 'string' } })
}

function objectSchema(properties, required = []) {
  return {
    type: OBJECT,
    additionalProperties: false,
    properties,
    ...(required.length ? { required } : {}),
  }
}
