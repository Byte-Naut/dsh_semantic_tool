import { appendFile, mkdir, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'

export class Telemetry {
  #events = []
  #sequence = 0

  constructor(runId) {
    this.runId = runId
  }

  record(kind, payload = {}) {
    const event = Object.freeze({
      sequence: ++this.#sequence,
      runId: this.runId,
      kind,
      at: new Date().toISOString(),
      ...redact(payload),
    })
    this.#events.push(event)
    return event
  }

  events() {
    return [...this.#events]
  }

  totals() {
    const usage = this.#events
      .filter(event => event.kind === 'model_usage')
      .reduce((sum, event) => ({
        input: sum.input + (event.inputTokens ?? 0),
        cached: sum.cached + (event.cachedInputTokens ?? 0),
        output: sum.output + (event.outputTokens ?? 0),
        thoughts: sum.thoughts + (event.thoughtTokens ?? 0),
        total: sum.total + (event.totalTokens ?? 0),
      }), { input: 0, cached: 0, output: 0, thoughts: 0, total: 0 })
    return {
      usage,
      toolCalls: this.#events.filter(event => event.kind === 'tool_called').length,
      nativeObservationCalls: this.#events.filter(event => event.kind === 'tool_called' && event.category === 'OBSERVE_NATIVE').length,
      relationalObservationCalls: this.#events.filter(event => event.kind === 'tool_called' && event.category === 'OBSERVE_RELATIONAL').length,
      toolResultBytes: this.#events
        .filter(event => event.kind === 'tool_returned')
        .reduce((sum, event) => sum + (event.outputBytes ?? 0), 0),
    }
  }

  async write(path) {
    await mkdir(dirname(path), { recursive: true })
    await writeFile(path, this.#events.map(event => JSON.stringify(event)).join('\n') + '\n')
  }
}

export async function appendJsonLine(path, value) {
  await mkdir(dirname(path), { recursive: true })
  await appendFile(path, JSON.stringify(redact(value)) + '\n')
}

function redact(value) {
  if (Array.isArray(value)) return value.map(redact)
  if (!value || typeof value !== 'object') return value
  return Object.fromEntries(Object.entries(value).map(([key, item]) => {
    if (/api.?key|authorization|secret|credential/i.test(key)) return [key, '[REDACTED]']
    return [key, redact(item)]
  }))
}
