export class FakeScheduler {
  #nextId = 1
  #jobs = new Map()
  events = []

  setInterval(callback, label) {
    const id = this.#nextId++
    this.#jobs.set(id, { callback, label, active: true })
    this.events.push({ kind: 'scheduled', id, label })
    return id
  }

  clearInterval(id) {
    const job = this.#jobs.get(id)
    if (!job || !job.active) return false
    job.active = false
    this.events.push({ kind: 'cancelled', id, label: job.label })
    return true
  }

  tick() {
    for (const [id, job] of this.#jobs) {
      if (!job.active) continue
      job.callback()
      this.events.push({ kind: 'fired', id, label: job.label })
    }
  }

  activeLabels() {
    return [...this.#jobs.values()]
      .filter(job => job.active)
      .map(job => job.label)
      .sort()
  }

  cancellationCount(label) {
    return this.events.filter(event => event.kind === 'cancelled' && event.label === label).length
  }
}
