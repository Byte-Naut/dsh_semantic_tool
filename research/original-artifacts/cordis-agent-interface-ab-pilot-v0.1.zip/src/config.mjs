export const EXPERIMENT = Object.freeze({
  id: 'cordis-agent-interface-gemini38-pilot-v1',
  model: 'gemini-3.8-flash',
  thinkingLevel: 'medium',
  temperature: 1,
  candidateCount: 1,
  maxOutputTokensPerRequest: 32_768,
  maxToolCallsPerTurn: 24,
  maxRequestsPerTurn: 28,
  maxGrossInputTokensPerRun: 2_000_000,
  maxGrossOutputTokensPerRun: 100_000,
  requestTimeoutMs: 180_000,
  runTimeoutMs: 1_200_000,
  httpAttempts: 1,
  modelSeedBase: 41_000,
  fallback: false,
  turns: 2,
  pilotPairsPerTask: 2,
  mainPairsPerTask: 12,
  pricingUsdPerMillion: Object.freeze({
    input: 0.75,
    outputIncludingThinking: 3.75,
  }),
})

export const TASK_IDS = Object.freeze([
  't1-provider-withdrawal',
  't2-loading-status',
  't3-failed-update',
])

export const ARMS = Object.freeze(['native', 'relational'])

export function modelSeed(taskId, fixtureNumber) {
  const taskIndex = TASK_IDS.indexOf(taskId)
  if (taskIndex < 0) throw new Error(`unknown task: ${taskId}`)
  return EXPERIMENT.modelSeedBase + taskIndex * 100 + fixtureNumber
}

export const TURN_TWO_APPROVAL = 'The proposed semantic delta is approved for this isolated benchmark fixture. Implement it, run the required checks, and report the implementation-to-design comparison. Do not expand the approved scope.'

export const TURN_ONE_RECORD = Object.freeze({
  status: 'PASS | SPEC_GAP | SEMANTIC_REGRESSION',
  runtime_truth: [],
  derived_causes: [],
  unknowns: [],
  failure_witness: {
    initial: [],
    actions: [],
    bad_state: [],
  },
  selected_delta: {
    delete: [],
    insert: [],
  },
  verification_obligations: [],
})

export const TURN_TWO_RECORD = Object.freeze({
  implementation_status: 'PASS | IMPLEMENTATION_DEVIATION | SEMANTIC_REGRESSION',
  files_changed: [],
  lifecycle_actions: [],
  checks: [],
  final_runtime_truth: [],
  remaining_unknowns: [],
})
