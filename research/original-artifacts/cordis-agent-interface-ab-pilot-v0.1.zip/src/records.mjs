export function parseFinalRecord(text) {
  const value = String(text ?? '')
  const terminal = value.match(/```(?:json)?\s*([\s\S]*?)\s*```\s*$/i)
  const fences = [...value.matchAll(/```(?:json)?\s*([\s\S]*?)\s*```/gi)]
  if (!terminal) {
    return { ok: false, exactTerminalFence: false, fencedObjectCount: fences.length, error: 'missing terminal fenced JSON object' }
  }
  try {
    const record = JSON.parse(terminal[1])
    if (!record || Array.isArray(record) || typeof record !== 'object') {
      return { ok: false, exactTerminalFence: true, fencedObjectCount: fences.length, error: 'terminal JSON is not an object' }
    }
    return { ok: true, exactTerminalFence: true, fencedObjectCount: fences.length, record }
  } catch (error) {
    return {
      ok: false,
      exactTerminalFence: true,
      fencedObjectCount: fences.length,
      error: error instanceof Error ? error.message : String(error),
    }
  }
}

export function recordText(record) {
  return record?.ok ? JSON.stringify(record.record) : ''
}
