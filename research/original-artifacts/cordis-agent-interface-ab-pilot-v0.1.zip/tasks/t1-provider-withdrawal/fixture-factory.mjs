import { pathToFileURL } from 'node:url'
import { Context } from 'cordis'
import { FakeScheduler } from '../../src/fake-scheduler.mjs'
import { captureCordisNative } from '../../src/native-snapshot.mjs'
import { safePath } from '../../src/workspace.mjs'
import { CordisCollector, stateName } from '../../vendor/semantic-mirror-v0.3/collector.mjs'
import { impactRemove } from '../../vendor/semantic-mirror-v0.3/impact-query.mjs'

export async function createT1Runtime(seed, workspace) {
  const fixture = await bootFixture(seed, workspace)
  const before = fixture.collector.capture(`${seed.incidentId}:before-retirement`)
  const rawBefore = captureCordisNative({
    label: 'before-retirement',
    root: fixture.root,
    collector: fixture.collector,
    fibers: Object.values(fixture.fibers),
  })
  const serviceImplId = fixture.collector.serviceImplId(fixture.selectedImpl)
  const serviceImplAlias = `selected:${seed.serviceKey}`

  fixture.scheduler.tick()
  const callbacksBeforeRetirement = fixture.callbackSink.length
  await fixture.fibers.provider.dispose()
  await Promise.all([fixture.fibers.direct.await(), fixture.fibers.transitive.await()])
  fixture.scheduler.tick()

  const after = fixture.collector.capture(`${seed.incidentId}:after-retirement`)
  const rawAfter = captureCordisNative({
    label: 'after-retirement',
    root: fixture.root,
    collector: fixture.collector,
    fibers: Object.values(fixture.fibers),
  })

  const checkpoints = new Map([
    ['before-retirement', { relational: before, native: rawBefore }],
    [before.id, { relational: before, native: rawBefore }],
    ['after-retirement', { relational: after, native: rawAfter }],
    [after.id, { relational: after, native: rawAfter }],
  ])

  return {
    taskId: seed.taskId,
    seed,
    publicState: { serviceImplAlias, beforeSnapshotId: before.id, afterSnapshotId: after.id },
    defaultCheckpoint: 'after-retirement',
    queryCheckpoint: 'before-retirement',
    checkpoints: () => [
      { alias: 'before-retirement', snapshotId: before.id, phase: 'pre-retirement' },
      { alias: 'after-retirement', snapshotId: after.id, phase: 'post-retirement-symptom' },
    ],
    nativeSnapshot(checkpoint) {
      return resolveCheckpoint(checkpoints, checkpoint ?? 'after-retirement').native
    },
    nativeEvents() {
      return {
        cordis: fixture.collector.eventLog(),
        externalScheduler: fixture.scheduler.events,
        callbackObservations: fixture.callbackSink,
      }
    },
    cordisInspectSelf() {
      return { dynamicPlugins: [], note: 'No session-owned dynamic package participates in this incident.' }
    },
    semanticQuery(request) {
      if (request.query !== 'impact_remove') throw new Error('this task supports impact_remove')
      const selected = request.subject?.serviceImplId
      if (![serviceImplId, serviceImplAlias].includes(selected)) {
        throw new Error(`unknown service implementation: ${selected}`)
      }
      const snapshot = resolveCheckpoint(checkpoints, request.subject?.snapshotId ?? 'before-retirement').relational
      const result = impactRemove(snapshot, serviceImplId)
      return {
        ...result,
        coverage: {
          ...result.coverage,
          external_effect_truth: 'unavailable',
        },
        unknowns: [...result.unknowns, 'Whether an externally scheduled callback stopped is not established by Cordis effect metadata.'],
      }
    },
    async grade() {
      const candidate = await bootFixture(seed, workspace)
      candidate.scheduler.tick()
      const beforeCount = candidate.callbackSink.length
      await candidate.fibers.provider.dispose()
      await Promise.all([candidate.fibers.direct.await(), candidate.fibers.transitive.await()])
      candidate.scheduler.tick()
      const afterCount = candidate.callbackSink.length
      const result = {
        affectedNames: [seed.directConsumerName, seed.transitiveConsumerName],
        providerDisposed: stateName(candidate.fibers.provider.state) === 'disposed',
        directPending: stateName(candidate.fibers.direct.state) === 'pending',
        transitivePending: stateName(candidate.fibers.transitive.state) === 'pending',
        orphanStopped: afterCount === beforeCount,
        orphanDisposerCount: candidate.scheduler.cancellationCount(seed.orphanLabel),
        unrelatedActive: stateName(candidate.fibers.decoyProvider.state) === 'active'
          && stateName(candidate.fibers.decoyConsumer.state) === 'active',
        visibleSelectedService: candidate.root.reflect._getImpl(seed.serviceKey, false) !== undefined,
      }
      await candidate.dispose()
      return {
        ...result,
        pass: result.providerDisposed
          && result.directPending
          && result.transitivePending
          && result.orphanStopped
          && result.orphanDisposerCount === 1
          && result.unrelatedActive
          && !result.visibleSelectedService,
      }
    },
    failureWitness: {
      callbacksBeforeRetirement,
      callbacksAfterRetirement: fixture.callbackSink.length,
      orphanStillActive: fixture.scheduler.activeLabels().includes(seed.orphanLabel),
    },
    async dispose() {
      await fixture.dispose()
    },
  }
}

async function bootFixture(seed, workspace) {
  const root = new Context()
  const scheduler = new FakeScheduler()
  const callbackSink = []
  const collector = new CordisCollector(root, { runtimeId: `rt:${seed.seedId}` })
  await collector.attach()
  const source = safePath(workspace, 'src/callback-owner.mjs')
  const { installCallback } = await import(`${pathToFileURL(source).href}?load=${Date.now()}-${Math.random()}`)

  const trackedEffect = (ctx, label) => ctx.effect(() => () => {}, label)
  const maybeInstallLeak = (target, ctx) => {
    if (seed.leakTarget !== target) return
    installCallback(ctx, scheduler, seed.orphanLabel, callbackSink, seed.payload)
  }
  const Provider = {
    name: seed.providerName,
    apply(ctx) {
      ctx.provide(seed.serviceKey, Object.freeze({ version: 'primary' }))
      trackedEffect(ctx, `${seed.serviceKey}:provider-owned`)
    },
  }
  const Direct = {
    name: seed.directConsumerName,
    inject: [seed.serviceKey],
    apply(ctx) {
      ctx.provide(seed.derivedServiceKey, Object.freeze({ version: 'derived' }))
      trackedEffect(ctx, `${seed.derivedServiceKey}:direct-owned`)
      maybeInstallLeak('direct', ctx)
    },
  }
  const Transitive = {
    name: seed.transitiveConsumerName,
    inject: [seed.derivedServiceKey],
    apply(ctx) {
      trackedEffect(ctx, `${seed.derivedServiceKey}:transitive-owned`)
      maybeInstallLeak('transitive', ctx)
    },
  }
  const DecoyProvider = {
    name: seed.decoyProviderName,
    apply(ctx) {
      ctx.provide(`${seed.serviceKey}Decoy`, Object.freeze({ version: 'decoy' }))
    },
  }
  const DecoyConsumer = {
    name: seed.decoyConsumerName,
    inject: [`${seed.serviceKey}Decoy`],
    apply(ctx) {
      void ctx[`${seed.serviceKey}Decoy`]
      trackedEffect(ctx, 'decoy-owned')
    },
  }

  const provider = root.plugin(Provider)
  await provider
  const direct = root.plugin(Direct)
  await direct
  const transitive = root.plugin(Transitive)
  await transitive
  const decoyProvider = root.plugin(DecoyProvider)
  await decoyProvider
  const decoyConsumer = root.plugin(DecoyConsumer)
  await decoyConsumer
  const selectedImpl = root.reflect._getImpl(seed.serviceKey, false)
  if (!selectedImpl) throw new Error('T1 failed to publish selected service')

  const fibers = { provider, direct, transitive, decoyProvider, decoyConsumer }
  return {
    root,
    scheduler,
    callbackSink,
    collector,
    selectedImpl,
    fibers,
    async dispose() {
      await collector.detach()
      await Promise.all(Object.values(fibers).map(fiber => fiber.dispose()))
    },
  }
}

function resolveCheckpoint(checkpoints, id) {
  const checkpoint = checkpoints.get(id)
  if (!checkpoint) throw new Error(`unknown checkpoint: ${id}`)
  return checkpoint
}
