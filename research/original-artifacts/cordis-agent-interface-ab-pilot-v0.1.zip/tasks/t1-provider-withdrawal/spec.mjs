export function publicTaskCard(seed, runtime) {
  return `A Cordis process retires service implementation \`${runtime.serviceImplAlias}\`. A callback labeled \`${seed.orphanLabel}\` continues after the retirement completes. Diagnose the complete affected plugin chain and the ownership defect. Distinguish observed Cordis-tracked cleanup from external-effect truth, then propose the smallest repair. Preserve the unrelated plugins and do not modify Cordis core. Stop after the semantic design delta; do not edit files yet. The fixture controller and permitted inspection tools are available under incident \`${seed.incidentId}\`.`
}

export function workspaceFiles(seed) {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module', scripts: { test: 'node --test' } }, null, 2) + '\n',
    'src/callback-owner.mjs': `/** Installs the callback used by ${seed.leakTarget} consumer. */
export function installCallback(ctx, scheduler, label, sink, payload) {
  const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
  return { handle }
}
`,
    'test/callback-owner.test.mjs': `import assert from 'node:assert/strict'
import test from 'node:test'
import { installCallback } from '../src/callback-owner.mjs'

test('the callback is owned by a Cordis effect and is cancelled by its inverse', () => {
  const calls = []
  const intervals = new Map()
  let nextId = 1
  let registeredLabel
  let disposer
  const scheduler = {
    setInterval(callback, label) {
      const id = nextId++
      intervals.set(id, { callback, label })
      return id
    },
    clearInterval(id) {
      return intervals.delete(id)
    },
  }
  const ctx = {
    effect(callback, label) {
      registeredLabel = label
      disposer = callback()
    },
  }

  installCallback(ctx, scheduler, '${seed.orphanLabel}', calls, ${seed.payload})
  assert.equal(registeredLabel, '${seed.orphanLabel}')
  assert.equal(typeof disposer, 'function')
  for (const job of intervals.values()) job.callback()
  assert.deepEqual(calls, [{ label: '${seed.orphanLabel}', payload: ${seed.payload} }])
  disposer()
  assert.equal(intervals.size, 0)
})
`,
  }
}

export const editableFiles = Object.freeze(['src/callback-owner.mjs'])

export const criticalErrors = Object.freeze([
  'E_DIRECT_ONLY',
  'E_ABSENCE_WITHOUT_COVERAGE',
  'E_TRACKED_EQUALS_EXTERNAL',
  'E_CORE_PATCH',
  'E_DECOY_DAMAGE',
])
