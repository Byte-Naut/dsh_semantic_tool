export function publicTaskCard(seed) {
  return `During a hot replacement, \`${seed.statusAdapter}\` reports provider \`${seed.providerV2}\` as serving consumer \`${seed.consumerName}\`, but the consumer's paused work still uses \`${seed.providerV1}\`. Reproduce the paused LOADING state, determine the provider committed to the current consumer session and the provider selected for the next reload, then propose the smallest status-adapter repair. Preserve Cordis lifecycle behavior and do not wait for the transition to disappear. Stop after the semantic design delta; do not edit files yet. Use checkpoint \`${seed.checkpointAlias}\`.`
}

export function workspaceFiles(seed) {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module', scripts: { test: 'node --test' } }, null, 2) + '\n',
    'src/status-adapter.mjs': `function providerId(implementation) {
  return implementation?.fiber?.name ?? null
}

/** Reports the current and selected providers for one required service. */
export function buildStatus(consumerFiber, serviceKey) {
  const target = consumerFiber._store?.[serviceKey]
  return {
    servingProviderId: providerId(target),
    targetProviderId: providerId(target),
    transitioning: false,
  }
}
`,
    'test/status-adapter.test.mjs': `import assert from 'node:assert/strict'
import test from 'node:test'
import { buildStatus } from '../src/status-adapter.mjs'

const implementation = name => ({ fiber: { name } })

test('reports the provider used by paused work separately from the reload target', () => {
  const fiber = {
    state: 1,
    store: { ${JSON.stringify(seed.serviceKey)}: implementation('${seed.providerV1}') },
    _store: { ${JSON.stringify(seed.serviceKey)}: implementation('${seed.providerV2}') },
  }
  assert.deepEqual(buildStatus(fiber, '${seed.serviceKey}'), {
    servingProviderId: '${seed.providerV1}',
    targetProviderId: '${seed.providerV2}',
    transitioning: true,
  })
})
`,
  }
}

export const editableFiles = Object.freeze(['src/status-adapter.mjs'])

export const criticalErrors = Object.freeze([
  'E_BINDING_COLLAPSE',
  'E_LOADING_MEANS_NONE',
  'E_WAIT_AWAY',
  'E_UNKNOWN_COPY',
  'E_LIFECYCLE_REWRITE',
])
