import { pathToFileURL } from 'node:url'
import { Context } from 'cordis'
import { captureCordisNative } from '../../src/native-snapshot.mjs'
import { safePath } from '../../src/workspace.mjs'
import { CordisCollector, stateName } from '../../vendor/semantic-mirror-v0.3/collector.mjs'
import { explainBindingDivergence } from '../../vendor/semantic-mirror-v0.3/binding-query.mjs'

export async function createT2Runtime(seed, workspace) {
  const root = new Context()
  const firstLoadGate = deferred()
  const firstLoadStarted = deferred()
  const activity = { applied: [], completed: [], disposed: [] }
  let applyCount = 0
  const collector = new CordisCollector(root, { runtimeId: `rt:${seed.seedId}` })
  await collector.attach()

  const provider = (name, version) => ({
    name,
    apply(ctx) {
      ctx.provide(seed.serviceKey, Object.freeze({ version }))
    },
  })
  const Consumer = {
    name: seed.consumerName,
    inject: [seed.serviceKey],
    async apply(ctx) {
      const version = ctx[seed.serviceKey].version
      const call = ++applyCount
      activity.applied.push(version)
      ctx.effect(() => () => activity.disposed.push(version), `session:${version}`)
      if (call === 1) {
        firstLoadStarted.resolve()
        await firstLoadGate.promise
      }
      activity.completed.push(version)
    },
  }

  const providerV1 = root.plugin(provider(seed.providerV1, seed.valueV1))
  await providerV1
  const consumer = root.plugin(Consumer)
  await firstLoadStarted.promise
  const providerV1Disposal = providerV1.dispose()
  await waitFor(() => root.reflect._getImpl(seed.serviceKey, false) === undefined)
  const providerV2 = root.plugin(provider(seed.providerV2, seed.valueV2))
  await providerV2

  const during = collector.capture(seed.checkpointAlias)
  const rawDuring = captureCordisNative({
    label: seed.checkpointAlias,
    root,
    collector,
    fibers: [providerV1, providerV2, consumer],
  })
  const consumerId = collector.fiberId(consumer)
  const checkpoints = new Map([
    [seed.checkpointAlias, { relational: during, native: rawDuring }],
    [during.id, { relational: during, native: rawDuring }],
  ])
  const initialAdapter = await loadAdapter(workspace)
  const badStatus = initialAdapter.buildStatus(consumer, seed.serviceKey)
  let released = false

  return {
    taskId: seed.taskId,
    seed,
    publicState: { consumerId, checkpointId: during.id, checkpointAlias: seed.checkpointAlias },
    defaultCheckpoint: seed.checkpointAlias,
    queryCheckpoint: seed.checkpointAlias,
    checkpoints: () => [{
      alias: seed.checkpointAlias,
      snapshotId: during.id,
      phase: 'consumer-loading-provider-replacement',
    }],
    nativeSnapshot(checkpoint) {
      return resolveCheckpoint(checkpoints, checkpoint ?? seed.checkpointAlias).native
    },
    nativeEvents() {
      return { cordis: collector.eventLog(), activity: structuredClone(activity) }
    },
    cordisInspectSelf() {
      return { dynamicPlugins: [], note: 'No session-owned dynamic package participates in this incident.' }
    },
    semanticQuery(request) {
      if (request.query !== 'explain_binding_divergence') {
        throw new Error('this task supports explain_binding_divergence')
      }
      const requestedFiber = request.subject?.fiberId
      if (requestedFiber !== consumerId && requestedFiber !== seed.consumerName) {
        throw new Error(`unknown consumer fiber: ${requestedFiber}`)
      }
      if (request.subject?.serviceKey !== seed.serviceKey) {
        throw new Error(`unknown service key: ${request.subject?.serviceKey}`)
      }
      const snapshot = resolveCheckpoint(
        checkpoints,
        request.subject?.snapshotId ?? seed.checkpointAlias,
      ).relational
      return explainBindingDivergence(snapshot, consumerId, seed.serviceKey)
    },
    failureWitness: {
      state: stateName(consumer.state),
      badStatus,
      applied: [...activity.applied],
      completed: [...activity.completed],
    },
    async grade() {
      const adapter = await loadAdapter(workspace)
      const paused = adapter.buildStatus(consumer, seed.serviceKey)
      const missingCommittedFiber = {
        store: {},
        _store: consumer._store,
      }
      const missingCommitted = adapter.buildStatus(missingCommittedFiber, seed.serviceKey)
      firstLoadGate.resolve()
      released = true
      await Promise.all([consumer.await(), providerV1Disposal])
      const converged = adapter.buildStatus(consumer, seed.serviceKey)
      const result = {
        paused,
        missingCommitted,
        converged,
        consumerStateAfter: stateName(consumer.state),
        activity: structuredClone(activity),
        pausedCorrect: paused.servingProviderId === seed.providerV1
          && paused.targetProviderId === seed.providerV2
          && paused.transitioning === true,
        unknownPreserved: missingCommitted.servingProviderId == null
          && missingCommitted.targetProviderId === seed.providerV2
          && missingCommitted.transitioning !== false,
        convergedCorrect: converged.servingProviderId === seed.providerV2
          && converged.targetProviderId === seed.providerV2
          && converged.transitioning === false,
      }
      return {
        ...result,
        pass: result.pausedCorrect
          && result.unknownPreserved
          && result.convergedCorrect
          && result.consumerStateAfter === 'active'
          && result.activity.disposed.includes(seed.valueV1),
      }
    },
    async dispose() {
      if (!released) {
        firstLoadGate.resolve()
        await Promise.allSettled([consumer.await(), providerV1Disposal])
      }
      await collector.detach()
      await Promise.allSettled([consumer.dispose(), providerV1.dispose(), providerV2.dispose()])
    },
  }
}

async function loadAdapter(workspace) {
  const source = safePath(workspace, 'src/status-adapter.mjs')
  return import(`${pathToFileURL(source).href}?load=${Date.now()}-${Math.random()}`)
}

function resolveCheckpoint(checkpoints, id) {
  const checkpoint = checkpoints.get(id)
  if (!checkpoint) throw new Error(`unknown checkpoint: ${id}`)
  return checkpoint
}

function deferred() {
  let resolve
  const promise = new Promise(settle => { resolve = settle })
  return { promise, resolve }
}

async function waitFor(predicate, attempts = 200) {
  for (let attempt = 0; attempt < attempts; attempt++) {
    if (predicate()) return
    await new Promise(resolve => setTimeout(resolve, 0))
  }
  throw new Error('timed out waiting for Cordis lifecycle condition')
}
