import { Context } from '@deepseek-ai/cordis'
import DynamicCordisRunnerService from '@deepseek-ai/dsh-cordis-host-runner'
import { DynamicPackageCollector } from '../../vendor/semantic-mirror-v0.3/dynamic-collector.mjs'
import { explainDynamicPackageState } from '../../vendor/semantic-mirror-v0.3/package-query.mjs'

export async function createT3Runtime(seed) {
  const root = new Context()
  const nativeEvents = []
  const actionLog = []
  const observationLog = []
  const disposeTools = root.provide('tools', Object.freeze({}))
  for (const eventName of ['cordis/dynamic-package', 'cordis/dynamic-retract']) {
    root.on(eventName, payload => nativeEvents.push({ eventName, payload }))
  }
  const runnerFiber = root.plugin(DynamicCordisRunnerService)
  await runnerFiber
  const runner = root.dynamicCordisRunner
  const agent = Object.freeze({
    id: `session:${seed.seedId}`,
    steer() {},
    inject() {},
  })

  const v1 = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'new', idPrefix: seed.pluginPrefix },
    name: `${seed.pluginPrefix} stable package`,
    purpose: 'serve the benchmark endpoint',
    code: { host: validHostCode(seed.serviceKey, seed.stableValue) },
  })
  const v1Receipt = await runner.run(agent, v1.pluginId, v1.packageId, 'run')
  if (!v1Receipt.ok) throw new Error(v1Receipt.message)

  const decoy = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'new', idPrefix: seed.decoyPrefix },
    name: `${seed.decoyPrefix} unrelated package`,
    purpose: 'unrelated decoy plugin',
    code: { host: validHostCode(`${seed.serviceKey}Decoy`, 'decoy-stable') },
  })
  const decoyReceipt = await runner.run(agent, decoy.pluginId, decoy.packageId, 'run')
  if (!decoyReceipt.ok) throw new Error(decoyReceipt.message)

  const v2 = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'existing', pluginId: v1.pluginId },
    name: `${seed.pluginPrefix} failed update`,
    purpose: 'publish the repaired endpoint value',
    code: { host: brokenHostCode(seed) },
  })
  const failedReceipt = await runner.run(agent, v1.pluginId, v2.packageId, 'update')
  if (failedReceipt.ok || failedReceipt.reason !== 'host-half-failed') {
    throw new Error('T3 did not produce the required host-half failure')
  }

  const collector = new DynamicPackageCollector(runner, { runtimeId: `rt:${seed.seedId}` })
  const failed = collector.capture(`${seed.incidentId}:failed-update`)
  const failedInventory = sourceFree(runner.inventory())
  const decoyBefore = sourceFree(runner.inspectPlugin(agent, decoy.pluginId))

  const runtime = {
    taskId: seed.taskId,
    seed,
    publicState: {
      pluginId: String(v1.pluginId),
      failedSnapshotId: failed.id,
      v1PackageId: String(v1.packageId),
      v2PackageId: String(v2.packageId),
    },
    defaultCheckpoint: 'failed-update',
    queryCheckpoint: 'failed-update',
    checkpoints: () => [{
      alias: 'failed-update',
      snapshotId: failed.id,
      phase: 'host-update-failed',
    }],
    nativeSnapshot() {
      return { label: 'failed-update', fibers: [], services: [], dynamicInventory: failedInventory }
    },
    nativeEvents() {
      return { dynamicRunner: nativeEvents, failedReceipt: sourceFree(failedReceipt) }
    },
    cordisInspectSelf() {
      observationLog.push({ kind: 'inspect-self' })
      return {
        plugins: runner.listPlugins(agent).map(sourceFree),
        selectedPluginId: String(v1.pluginId),
      }
    },
    inspectPackage({ pluginId, packageId }) {
      observationLog.push({ kind: 'inspect-package', pluginId, packageId })
      return sourceFree(runner.inspectPackage(agent, pluginId, packageId))
    },
    semanticQuery(request) {
      if (request.query !== 'explain_dynamic_package_state') {
        throw new Error('this task supports explain_dynamic_package_state')
      }
      const pluginId = request.subject?.pluginId
      if (pluginId !== String(v1.pluginId)) throw new Error(`unknown selected plugin: ${pluginId}`)
      return explainDynamicPackageState(failed, pluginId)
    },
    async definePackage({ pluginId, newPluginPrefix, name, purpose, hostCode }) {
      const request = pluginId
        ? { plugin: { kind: 'existing', pluginId } }
        : { plugin: { kind: 'new', idPrefix: newPluginPrefix } }
      const definition = runner.define({
        sessionId: agent.id,
        ...request,
        name,
        purpose,
        code: { host: hostCode },
      })
      actionLog.push({
        kind: 'define',
        requestedPluginId: pluginId ?? null,
        createdPluginId: String(definition.pluginId),
        packageId: String(definition.packageId),
      })
      return sourceFree(definition)
    },
    async runPackage({ pluginId, packageId, mode }) {
      const receipt = await runner.run(agent, pluginId, packageId, mode)
      const value = visibleValue(root, seed.serviceKey)
      actionLog.push({ kind: 'run', pluginId, packageId, mode, receipt: sourceFree(receipt), visibleValue: value })
      return { ...sourceFree(receipt), observedServiceValue: value }
    },
    failureWitness: {
      failedReceipt: sourceFree(failedReceipt),
      currentServiceValue: visibleValue(root, seed.serviceKey),
      inventory: failedInventory,
    },
    async grade() {
      const selected = sourceFree(runner.inspectPlugin(agent, v1.pluginId))
      const decoyAfter = sourceFree(runner.inspectPlugin(agent, decoy.pluginId))
      const firstMutation = actionLog[0]
      const inspectedFailedSource = observationLog.some(entry => entry.kind === 'inspect-package'
        && entry.pluginId === String(v1.pluginId)
        && entry.packageId === String(v2.packageId))
      const packageIdsBefore = new Set([String(v1.packageId), String(v2.packageId)])
      const newPackages = selected.packages.filter(pkg => !packageIdsBefore.has(String(pkg.packageId)))
      const activePackageId = selected.activeRun?.packageId ?? null
      const stateCorrect = selected.currentPackageId === activePackageId
        && selected.nextPackageId === undefined
        && newPackages.length === 1
        && activePackageId === newPackages[0].packageId
      const restoreFirst = firstMutation?.kind === 'run'
        && firstMutation.pluginId === String(v1.pluginId)
        && firstMutation.packageId === String(v1.packageId)
        && firstMutation.mode === 'run'
        && firstMutation.receipt.ok === true
        && firstMutation.visibleValue === seed.stableValue
      const noReplacementPlugin = runner.listPlugins(agent).length === 2
      const decoyUnchanged = JSON.stringify(decoyAfter) === JSON.stringify(decoyBefore)
      const result = {
        actionLog: sourceFree(actionLog),
        selected,
        inspectedFailedSource,
        restoreFirst,
        stateCorrect,
        noReplacementPlugin,
        decoyUnchanged,
        finalServiceValue: visibleValue(root, seed.serviceKey),
      }
      return {
        ...result,
        pass: inspectedFailedSource
          && restoreFirst
          && stateCorrect
          && noReplacementPlugin
          && decoyUnchanged
          && result.finalServiceValue === seed.repairedValue,
      }
    },
    async dispose() {
      await runnerFiber.dispose()
      await disposeTools()
    },
  }
  return runtime
}

function validHostCode(serviceKey, value) {
  return `return { apply(ctx) { ctx.provide(${JSON.stringify(serviceKey)}, Object.freeze({ version: ${JSON.stringify(value)} })) } }`
}

function brokenHostCode(seed) {
  return `return { apply(ctx) { throw new Error(${JSON.stringify(seed.failureMessage)}); ctx.provide(${JSON.stringify(seed.serviceKey)}, Object.freeze({ version: ${JSON.stringify(seed.repairedValue)} })) } }`
}

function visibleValue(root, serviceKey) {
  return root.reflect._getImpl(serviceKey, false)?.value?.version ?? null
}

function sourceFree(value) {
  return JSON.parse(JSON.stringify(value))
}
