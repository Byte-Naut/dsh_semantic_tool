export function publicTaskCard(_seed, runtime) {
  return `Session-owned dynamic Plugin \`${runtime.pluginId}\` stopped serving after an attempted update. Restore the last known good behavior first, then repair the failed source as a new immutable Package under the same Plugin. Do not create a replacement Plugin or overwrite an existing Package. In this turn, inspect the runtime, distinguish the last successful Package, the failed target, and the actual active Run, and propose the exact recovery and repair sequence. Stop before taking lifecycle actions.`
}

export function workspaceFiles() {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module' }, null, 2) + '\n',
    'README.md': '# Dynamic package incident workspace\n\nUse the permitted runtime inspection and lifecycle tools. Dynamic Package versions are immutable.\n',
  }
}

export const editableFiles = Object.freeze([])

export const criticalErrors = Object.freeze([
  'E_CURRENT_IS_ACTIVE',
  'E_WRONG_ROLLBACK_MODE',
  'E_REPAIR_BEFORE_RESTORE',
  'E_NEW_PLUGIN',
  'E_OVERWRITE_VERSION',
  'E_DECOY_ACTION',
])
