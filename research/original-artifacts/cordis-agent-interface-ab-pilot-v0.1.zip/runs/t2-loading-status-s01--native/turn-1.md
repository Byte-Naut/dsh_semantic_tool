### Diagnostic Baseline (D0)

At checkpoint `cut-harbor-loading`, a hot replacement of service `beaconPort` is in progress:
- Consumer `harbor-pulse-worker` (`fiber:rt:t2-loading-status-s01:3`) is in state `loading` with an ongoing session effect (`session:amber-v1`).
- Its committed binding (`committedBindings.beaconPort`, accessible via `consumerFiber.store`) remains bound to provider `harbor-beacon-blue` (`fiber:rt:t2-loading-status-s01:15` / `24`, version `amber-v1`).
- Its target binding for reload (`targetBindings.beaconPort`, accessible via `consumerFiber._store`) is staged with replacement provider `harbor-beacon-green` (`fiber:rt:t2-loading-status-s01:4`, version `amber-v2`).
- However, `buildStatus` in `src/status-adapter.mjs` unconditionally reads `consumerFiber._store?.[serviceKey]` for both `servingProviderId` and `targetProviderId` and hardcodes `transitioning: false`.
- Consequently, `amberStatusAdapter` prematurely reports `harbor-beacon-green` as serving the consumer and hides the in-progress transition while paused work is still executing against `harbor-beacon-blue`.

---

### Checkable Failure Witness

1. **Initial State**:
   - Consumer fiber object has `store.beaconPort` referencing `harbor-beacon-blue` and `_store.beaconPort` referencing `harbor-beacon-green`.
2. **Action**:
   - Invoke `buildStatus(consumerFiber, 'beaconPort')`.
3. **Bad State**:
   - Returns `{ servingProviderId: 'harbor-beacon-green', targetProviderId: 'harbor-beacon-green', transitioning: false }`.
   - Expected `{ servingProviderId: 'harbor-beacon-blue', targetProviderId: 'harbor-beacon-green', transitioning: true }`.
   - Witnessed via `node --test` failure in `test/status-adapter.test.mjs`.

---

### Repair Candidates

#### Candidate 1 (Selected D*)
Read `serving` implementation from `consumerFiber.store?.[serviceKey]` and `target` implementation from `consumerFiber._store?.[serviceKey]`. Compute `servingProviderId = providerId(serving)` and `targetProviderId = providerId(target)`, and determine `transitioning = servingProviderId !== targetProviderId`.
- **Pros**: Minimal, robust to missing stores (`?.` operator), directly reflects provider identity transition across session boundaries, matches Cordis fiber store staging model.
- **Cons**: None for the adapter contract.

#### Candidate 2
Read `serving` from `consumerFiber.store?.[serviceKey]` and `target` from `consumerFiber._store?.[serviceKey]`, but determine `transitioning` by object reference inequality `serving !== target` or inspecting `consumerFiber.state`.
- **Pros**: Detects in-place re-instantiation even if provider name stays identical.
- **Cons**: Unnecessarily couples status reporting to implementation object references or specific numeric fiber lifecycle state enums, which may vary across lifecycle hooks.

---

### Selected Delta (D*)

#### Delete:
```javascript
  const target = consumerFiber._store?.[serviceKey]
  return {
    servingProviderId: providerId(target),
    targetProviderId: providerId(target),
    transitioning: false,
  }
```

#### Insert:
```javascript
  const serving = consumerFiber.store?.[serviceKey]
  const target = consumerFiber._store?.[serviceKey]
  const servingProviderId = providerId(serving)
  const targetProviderId = providerId(target)
  return {
    servingProviderId,
    targetProviderId,
    transitioning: servingProviderId !== targetProviderId,
  }
```

---

### Remaining Unknowns
- Behavior when `store` has not yet been initialized on initial consumer bootstrap before any provider is committed (safely yields `servingProviderId: null`).

---

### Verification Obligations
1. Unit test `test/status-adapter.test.mjs` executes and passes via `run_visible_tests`.
2. `servingProviderId` evaluates to `harbor-beacon-blue` for consumer `harbor-pulse-worker`.
3. `targetProviderId` evaluates to `harbor-beacon-green`.
4. `transitioning` evaluates to `true` while the fiber is in loading transition and `false` when serving and target coincide.

```json
{
  "status": "PASS",
  "runtime_truth": [
    "Checkpoint cut-harbor-loading contains consumer fiber harbor-pulse-worker in state loading",
    "harbor-pulse-worker committedBindings.beaconPort references harbor-beacon-blue (amber-v1)",
    "harbor-pulse-worker targetBindings.beaconPort references harbor-beacon-green (amber-v2)",
    "src/status-adapter.mjs reads only consumerFiber._store for both servingProviderId and targetProviderId with transitioning hardcoded to false"
  ],
  "derived_causes": [
    "buildStatus queries target store (_store) for current serving provider instead of committed store (store)",
    "transitioning flag is hardcoded to false rather than detecting divergence between committed serving provider and reload target provider"
  ],
  "unknowns": [
    "Whether uninitialized consumers before initial injection resolve servingProviderId to null or inherit targetProviderId"
  ],
  "failure_witness": {
    "initial": [
      "consumerFiber has store.beaconPort bound to harbor-beacon-blue and _store.beaconPort bound to harbor-beacon-green"
    ],
    "actions": [
      "buildStatus(consumerFiber, 'beaconPort') is called"
    ],
    "bad_state": [
      "servingProviderId is 'harbor-beacon-green' instead of 'harbor-beacon-blue'",
      "transitioning is false instead of true"
    ]
  },
  "selected_delta": {
    "delete": [
      "  const target = consumerFiber._store?.[serviceKey]",
      "  return {",
      "    servingProviderId: providerId(target),",
      "    targetProviderId: providerId(target),",
      "    transitioning: false,",
      "  }"
    ],
    "insert": [
      "  const serving = consumerFiber.store?.[serviceKey]",
      "  const target = consumerFiber._store?.[serviceKey]",
      "  const servingProviderId = providerId(serving)",
      "  const targetProviderId = providerId(target)",
      "  return {",
      "    servingProviderId,",
      "    targetProviderId,",
      "    transitioning: servingProviderId !== targetProviderId,",
      "  }"
    ]
  },
  "verification_obligations": [
    "run_visible_tests passes cleanly",
    "buildStatus reports servingProviderId as 'harbor-beacon-blue'",
    "buildStatus reports targetProviderId as 'harbor-beacon-green'",
    "buildStatus reports transitioning as true when providers differ and false when identical"
  ]
}
```
