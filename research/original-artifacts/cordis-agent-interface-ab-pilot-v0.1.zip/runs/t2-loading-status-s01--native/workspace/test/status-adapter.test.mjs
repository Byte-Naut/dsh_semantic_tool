import assert from 'node:assert/strict'
import test from 'node:test'
import { buildStatus } from '../src/status-adapter.mjs'

const implementation = name => ({ fiber: { name } })

test('reports the provider used by paused work separately from the reload target', () => {
  const fiber = {
    state: 1,
    store: { "beaconPort": implementation('harbor-beacon-blue') },
    _store: { "beaconPort": implementation('harbor-beacon-green') },
  }
  assert.deepEqual(buildStatus(fiber, 'beaconPort'), {
    servingProviderId: 'harbor-beacon-blue',
    targetProviderId: 'harbor-beacon-green',
    transitioning: true,
  })
})
