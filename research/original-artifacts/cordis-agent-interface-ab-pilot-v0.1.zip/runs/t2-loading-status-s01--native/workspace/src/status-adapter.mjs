function providerId(implementation) {
  return implementation?.fiber?.name ?? null
}

/** Reports the current and selected providers for one required service. */
export function buildStatus(consumerFiber, serviceKey) {
  const serving = consumerFiber.store?.[serviceKey]
  const target = consumerFiber._store?.[serviceKey]
  const servingProviderId = providerId(serving)
  const targetProviderId = providerId(target)
  return {
    servingProviderId,
    targetProviderId,
    transitioning: servingProviderId !== targetProviderId,
  }
}
