### Implementation Summary

The approved delta was applied to `src/callback-owner.mjs` without modifying Cordis core, tests, or any unrelated files. 

- `installCallback` now attaches the callback scheduling to `ctx.effect(..., label)`.
- The effect callback mounts the interval via `scheduler.setInterval` and returns the inverse cleanup closure `() => scheduler.clearInterval(handle)`.
- When Cordis unloads or disposes the fiber during provider retirement, the inverse cleanup function is called, cancelling the interval and preventing orphan callbacks.

### Verification

- Ran `run_visible_tests`: 1 test passed, 0 failures.
  - Asserted `registeredLabel === 'amber-orphan-callback'`.
  - Asserted `disposer` is a valid teardown function.
  - Asserted `disposer()` clears the interval handle from the scheduler.

---

```json
{
  "implementation_status": "PASS",
  "files_changed": [
    "src/callback-owner.mjs"
  ],
  "lifecycle_actions": [],
  "checks": [
    {
      "command": "node --test",
      "status": "PASS",
      "stdout": "✔ the callback is owned by a Cordis effect and is cancelled by its inverse (1.224297ms)\nℹ tests 1\nℹ suites 0\nℹ pass 1\nℹ fail 0\nℹ cancelled 0\nℹ skipped 0\nℹ todo 0\nℹ duration_ms 56.626078"
    }
  ],
  "final_runtime_truth": [
    "src/callback-owner.mjs registers the timer inside ctx.effect(callback, label) and returns the effect disposer.",
    "Calling the effect disposer invokes scheduler.clearInterval(handle), ensuring intervals map size is reduced to 0 upon fiber unloading.",
    "Visible test suite passes cleanly with 1 test passed and 0 failures."
  ],
  "remaining_unknowns": []
}
```
