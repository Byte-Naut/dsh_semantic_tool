### Baseline Implementation (D0)

In `src/callback-owner.mjs`:
```javascript
export function installCallback(ctx, scheduler, label, sink, payload) {
  const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
  return { handle }
}
```
The function schedules an external timer directly via `scheduler.setInterval` and returns `{ handle }`, omitting any registration with the Cordis context lifecycle via `ctx.effect(callback, label)`.

---

### Failure Witness and Affected Plugin Chain

#### 1. Affected Plugin Chain
From the Cordis runtime incident (`snap:rt:t1-provider-withdrawal-s01:1` to `snap:rt:t1-provider-withdrawal-s01:2`):
- **Provider Plugin**: `harbor-beacon-provider` (`fiber:rt:t1-provider-withdrawal-s01:2`) registered and provided service `beaconSource`.
- **Direct Dependent / Intermediate Provider**: `harbor-pulse-builder` (`fiber:rt:t1-provider-withdrawal-s01:3`) declared injection `[beaconSource]` and provided derived service `pulseModel`.
- **Transitive Dependent / Consumer**: `harbor-pulse-publisher` (`fiber:rt:t1-provider-withdrawal-s01:4`) declared injection `[pulseModel]` and ran `installCallback` with label `amber-orphan-callback`.
- **Unrelated / Decoy Plugins (Preserved)**:
  - `amber-decoy-provider` (`fiber:rt:t1-provider-withdrawal-s01:5`), providing `beaconSourceDecoy`.
  - `amber-decoy-consumer` (`fiber:rt:t1-provider-withdrawal-s01:6`), consuming `beaconSourceDecoy`.
  - `ctr-semantic-observer` (`fiber:rt:t1-provider-withdrawal-s01:1`) and `root` (`fiber:rt:t1-provider-withdrawal-s01:0`).

#### 2. Cordis-Tracked Cleanup vs. External-Effect Truth
- **Observed Cordis-Tracked Cleanup**:
  - When `selected:beaconSource` was withdrawn, fiber 2 transitioned `active -> unloading -> disposed`, and service `beaconSource` was unbound.
  - Intermediate fiber 3 lost `beaconSource`, transitioned `active -> unloading -> pending`, and service `pulseModel` was unbound.
  - Transitive fiber 4 lost `pulseModel`, transitioned `active -> unloading -> pending`, and all internal fiber effects (`effects: []`) were cleared.
- **External-Effect Truth**:
  - Because `installCallback` scheduled interval id 1 without binding its cancellation to a Cordis effect teardown callback, interval id 1 remained active in `externalScheduler`.
  - As observed in `callbackObservations` and `externalScheduler`, interval id 1 fired twice after the retirement and unbinding finished, pushing callbacks labeled `amber-orphan-callback` with payload `17`.

#### 3. Test Failure Witness
Executing `run_visible_tests` produces:
```
✖ the callback is owned by a Cordis effect and is cancelled by its inverse
AssertionError [ERR_ASSERTION]: Expected values to be strictly equal:
+ actual - expected
+ undefined
- 'amber-orphan-callback'
```

---

### Repair Candidates

- **Candidate A (Idiomatic Cordis Context Effect Lifecycle - Selected D\*)**:
  Wrap timer registration in `ctx.effect(callback, label)`. The effect callback starts the interval via `scheduler.setInterval` and returns a disposer closure `() => scheduler.clearInterval(handle)`. When the fiber unloads or is disposed, Cordis invokes the disposer, cancelling the timer.
  ```javascript
  export function installCallback(ctx, scheduler, label, sink, payload) {
    return ctx.effect(() => {
      const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
      return () => scheduler.clearInterval(handle)
    }, label)
  }
  ```

- **Candidate B (Eager Schedule with Disposer-Only Effect)**:
  Schedule the timer immediately outside the effect closure and register only the cancellation closure in `ctx.effect`:
  ```javascript
  export function installCallback(ctx, scheduler, label, sink, payload) {
    const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
    ctx.effect(() => () => scheduler.clearInterval(handle), label)
    return { handle }
  }
  ```
  *Evaluation*: Candidate B executes side-effects before effect attachment and breaks idempotency if the effect is mounted lazily or re-evaluated. Candidate A correctly encapsulates both acquisition and release inside the Cordis effect function.

---

### Selected Delta (D\*)

In `src/callback-owner.mjs`:
- Remove:
  ```javascript
    const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
    return { handle }
  ```
- Insert:
  ```javascript
    return ctx.effect(() => {
      const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
      return () => scheduler.clearInterval(handle)
    }, label)
  ```

---

```json
{
  "status": "PASS",
  "runtime_truth": [
    "Checkpoint snap:rt:t1-provider-withdrawal-s01:1 shows fiber 2 (harbor-beacon-provider) providing beaconSource, fiber 3 (harbor-pulse-builder) providing pulseModel, and fiber 4 (harbor-pulse-publisher) consuming pulseModel.",
    "Checkpoint snap:rt:t1-provider-withdrawal-s01:2 shows fiber 2 disposed and fibers 3 and 4 in pending state with all Cordis effects cleared (effects: []).",
    "Decoy plugins amber-decoy-provider (fiber 5) and amber-decoy-consumer (fiber 6) remain active and untouched throughout retirement.",
    "native_event_slice shows interval id 1 registered with label amber-orphan-callback and firing twice after retirement completion because no clearInterval was executed.",
    "run_visible_tests fails with AssertionError: Expected actual undefined to equal 'amber-orphan-callback' because installCallback does not call ctx.effect."
  ],
  "derived_causes": [
    "installCallback directly invokes scheduler.setInterval without binding the timer lifecycle to ctx.effect(callback, label).",
    "When beaconSource is retired, Cordis initiates cascading unloading down the dependency chain (harbor-pulse-builder -> harbor-pulse-publisher), but has no registered effect disposer to cancel the external timer.",
    "The orphan timer continues firing indefinitely in the external scheduler after all Cordis-tracked fiber states and effects have been cleaned up."
  ],
  "unknowns": [],
  "failure_witness": {
    "initial": [
      "src/callback-owner.mjs schedules interval via scheduler.setInterval without calling ctx.effect.",
      "Checkpoint 1 exhibits active fibers 2, 3, and 4."
    ],
    "actions": [
      "Retire service selected:beaconSource from harbor-beacon-provider.",
      "Execute run_visible_tests."
    ],
    "bad_state": [
      "externalScheduler records two firings of amber-orphan-callback after fibers 2, 3, and 4 complete unloading/pending/disposal.",
      "test/callback-owner.test.mjs fails at assert.equal(registeredLabel, 'amber-orphan-callback')."
    ]
  },
  "selected_delta": {
    "delete": [
      "  const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)",
      "  return { handle }"
    ],
    "insert": [
      "  return ctx.effect(() => {",
      "    const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)",
      "    return () => scheduler.clearInterval(handle)",
      "  }, label)"
    ]
  },
  "verification_obligations": [
    "Execute run_visible_tests and verify 1 passing test with 0 failures.",
    "Confirm that ctx.effect receives the effect callback and the label parameter ('amber-orphan-callback').",
    "Confirm that invoking the disposer function returned by the effect callback invokes scheduler.clearInterval(handle) and clears intervals Map.",
    "Confirm that unrelated plugins and files remain unmodified."
  ]
}
```
