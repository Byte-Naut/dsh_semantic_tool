import assert from 'node:assert/strict'
import test from 'node:test'
import { installCallback } from '../src/callback-owner.mjs'

test('the callback is owned by a Cordis effect and is cancelled by its inverse', () => {
  const calls = []
  const intervals = new Map()
  let nextId = 1
  let registeredLabel
  let disposer
  const scheduler = {
    setInterval(callback, label) {
      const id = nextId++
      intervals.set(id, { callback, label })
      return id
    },
    clearInterval(id) {
      return intervals.delete(id)
    },
  }
  const ctx = {
    effect(callback, label) {
      registeredLabel = label
      disposer = callback()
    },
  }

  installCallback(ctx, scheduler, 'amber-orphan-callback', calls, 17)
  assert.equal(registeredLabel, 'amber-orphan-callback')
  assert.equal(typeof disposer, 'function')
  for (const job of intervals.values()) job.callback()
  assert.deepEqual(calls, [{ label: 'amber-orphan-callback', payload: 17 }])
  disposer()
  assert.equal(intervals.size, 0)
})
