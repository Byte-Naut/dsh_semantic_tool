### D0: Baseline Defect & Observed Runtime Truth

#### 1. Affected Plugin Chain vs. Unaffected Plugins
- **Provider**: `orchard-ledger-provider` (`fiber:rt:t1-provider-withdrawal-s02:2`) registered and provided primary implementation `service-impl:rt:t1-provider-withdrawal-s02:28` for service `ledgerSource`.
- **Direct Consumer**: `orchard-index-builder` (`fiber:rt:t1-provider-withdrawal-s02:3`) injected `ledgerSource` and provided derived service `indexModel` (`service-impl:rt:t1-provider-withdrawal-s02:32`).
- **Transitive Consumer**: `orchard-index-publisher` (`fiber:rt:t1-provider-withdrawal-s02:4`) injected `indexModel`.
- **Unaffected Plugins**:
  - `cobalt-decoy-provider` (`fiber:rt:t1-provider-withdrawal-s02:5`) and `cobalt-decoy-consumer` (`fiber:rt:t1-provider-withdrawal-s02:6`) rely solely on `ledgerSourceDecoy` and remained active and isolated from `ledgerSource`.
  - `ctr-semantic-observer` (`fiber:rt:t1-provider-withdrawal-s02:1`) and `root` (`fiber:rt:t1-provider-withdrawal-s02:0`) remained intact.

#### 2. Cordis-Tracked Cleanup vs. External-Effect Truth
- **Cordis Runtime Cleanup**:
  - When `selected:ledgerSource` was retired, `orchard-ledger-provider` transitioned `active -> unloading -> disposed`.
  - Cascading dependency resolution unloaded direct consumer `orchard-index-builder` (`active -> unloading -> pending`), revoking `indexModel`.
  - Transitive consumer `orchard-index-publisher` unloaded (`active -> unloading -> pending`).
  - Cordis disposed all 5 tracked internal effects (`ctx.provide("ledgerSource")`, `ledgerSource:provider-owned`, `ctx.provide("indexModel")`, `indexModel:direct-owned`, `indexModel:transitive-owned`). At checkpoint `after-retirement`, Cordis fiber effect metadata is completely empty (`effects: []`).
- **External-Effect Ground Truth**:
  - Despite full Cordis-internal effect disposal, external scheduler trace reveals callback `cobalt-orphan-callback` fired repeatedly post-retirement (`externalScheduler: [{kind: 'fired', label: 'cobalt-orphan-callback'}, ...]`).
  - **Ownership Defect**: In `src/callback-owner.mjs`, `installCallback` directly invokes `scheduler.setInterval(...)` and returns a raw handle without wrapping the recurring timer inside `ctx.effect(...)` and without returning an inverse cancellation function (`scheduler.clearInterval(handle)`). Cordis therefore had no tracking or lifecycle ownership of the external timer.

---

### Checkable Failure Witness

1. **Initial State**:
   - `orchard-ledger-provider`, `orchard-index-builder`, and `orchard-index-publisher` are `active`.
   - External recurring interval `cobalt-orphan-callback` is scheduled via `installCallback`.
2. **Action**:
   - Provider `orchard-ledger-provider` is disposed, revoking `ledgerSource`.
   - `node --test` runs visible test suite.
3. **Bad State**:
   - In runtime, timer `cobalt-orphan-callback` continues firing past fiber retirement.
   - In unit test `test/callback-owner.test.mjs`, `installCallback` fails to register with `ctx.effect`, producing `AssertionError [ERR_ASSERTION]: Expected values to be strictly equal: undefined === 'cobalt-orphan-callback'`.

---

### Repair Candidates

- **Candidate A (Cordis-Managed Fiber Effect Teardown - Selected D*)**:
  Wrap the external interval creation inside `ctx.effect(callback, label)`. The effect callback registers `scheduler.setInterval` and returns a disposer inverse `() => scheduler.clearInterval(handle)`. When the hosting Cordis fiber unloads or is disposed upon provider withdrawal, Cordis automatically executes the teardown function, canceling the interval.
- **Candidate B (Direct Handle Return with Manual Context Event Listener)**:
  Retain the external registration outside `ctx.effect` and attach manual listeners to context lifecycle events (e.g. `ctx.on('dispose', ...)`).
  *Rejection reason*: Bypasses Cordis's first-class declarative effect lifecycle tracking, fails to register the effect label with Cordis effect introspection tools, and violates the explicit contract checked in `test/callback-owner.test.mjs`.

---

### Selected Delta (D*)

#### Target: `src/callback-owner.mjs`

```diff
 export function installCallback(ctx, scheduler, label, sink, payload) {
-  const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
-  return { handle }
+  return ctx.effect(() => {
+    const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
+    return () => scheduler.clearInterval(handle)
+  }, label)
 }
```

---

### Remaining Unknowns

- Whether any external callers rely on `{ handle }` return value rather than the Cordis effect lifecycle handle (no workspace code references this; tests expect standard Cordis effect registration).
- Exact host scheduler behavior beyond the provided mock scheduler interface.

---

### Verification Obligations

1. Execute `run_visible_tests` (`npm test`) to confirm `test/callback-owner.test.mjs` passes (`registeredLabel === 'cobalt-orphan-callback'`, disposer function returned and clears intervals).
2. Ensure no modifications are made to Cordis core, test suites, or decoy plugins (`cobalt-decoy-*`).

```json
{
  "status": "SPEC_GAP",
  "runtime_truth": [
    "Retirement of primary service implementation service-impl:rt:t1-provider-withdrawal-s02:28 (ledgerSource) caused orchard-ledger-provider to dispose.",
    "Dependency cascade transitioned direct consumer orchard-index-builder and transitive consumer orchard-index-publisher from active to pending.",
    "Cordis successfully disposed all 5 internal tracked effects across the orchard plugin chain, leaving effects empty at after-retirement snapshot.",
    "Callback cobalt-orphan-callback was scheduled outside Cordis ctx.effect ownership, continuing to fire in externalScheduler after fiber unloading.",
    "Decoy plugins cobalt-decoy-provider and cobalt-decoy-consumer remained active and unaffected."
  ],
  "derived_causes": [
    "installCallback directly invokes scheduler.setInterval without delegating to ctx.effect(callback, label).",
    "No cleanup inverse (scheduler.clearInterval) was registered with the Cordis fiber lifecycle, causing untracked orphan callback execution upon service retirement."
  ],
  "unknowns": [
    "Whether any unmonitored external async tasks or non-standard schedulers exist outside the fixture harness."
  ],
  "failure_witness": {
    "initial": [
      "Fibers orchard-ledger-provider, orchard-index-builder, and orchard-index-publisher are active with committed bindings.",
      "src/callback-owner.mjs defines installCallback without ctx.effect registration."
    ],
    "actions": [
      "Retire selected:ledgerSource provider fiber orchard-ledger-provider.",
      "Execute visible tests: node --test."
    ],
    "bad_state": [
      "externalScheduler event slice shows cobalt-orphan-callback fired after retirement.",
      "Test 'the callback is owned by a Cordis effect and is cancelled by its inverse' throws AssertionError because registeredLabel is undefined."
    ]
  },
  "selected_delta": {
    "delete": [
      "  const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)",
      "  return { handle }"
    ],
    "insert": [
      "  return ctx.effect(() => {",
      "    const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)",
      "    return () => scheduler.clearInterval(handle)",
      "  }, label)"
    ]
  },
  "verification_obligations": [
    "Apply selected delta exclusively to src/callback-owner.mjs.",
    "Run visible test suite via run_visible_tests and verify 100% test pass rate.",
    "Confirm no modifications to tests, decoy plugins, or Cordis core."
  ]
}
```
