### Implementation Summary

The approved recovery and repair sequence was executed:
1. **Restored Last Known Good Behavior**: Invoked `dynamic_run_package` with `mode: "run"` for package `pkg-1` on plugin `harbor-1`, returning status `running` and service value `"amber-stable"`.
2. **Defined New Repaired Package**: Defined immutable package `pkg-4` under existing plugin `harbor-1` containing the repaired host code without the bootstrap error. Existing packages `pkg-1` and `pkg-3` were preserved without modification.
3. **Updated to Repaired Package**: Executed `dynamic_run_package` with `mode: "update"` for `pkg-4` on plugin `harbor-1`, reaching active status `running` with verified service value `"amber-repaired"`.

```json
{
  "implementation_status": "PASS",
  "files_changed": [],
  "lifecycle_actions": [
    "dynamic_run_package(pluginId='harbor-1', packageId='pkg-1', mode='run')",
    "dynamic_define_package(pluginId='harbor-1', name='harbor repaired package', purpose='publish the repaired endpoint value', hostCode='return { apply(ctx) { ctx.provide(\"pulseEndpoint\", Object.freeze({ version: \"amber-repaired\" })) } }')",
    "dynamic_run_package(pluginId='harbor-1', packageId='pkg-4', mode='update')"
  ],
  "checks": [
    "run_visible_tests: passed (0 failures)",
    "dynamic_run_package rollback: returned ok=true, status='running', observedServiceValue='amber-stable'",
    "dynamic_define_package: created immutable package pkg-4 under harbor-1",
    "dynamic_run_package update: returned ok=true, status='running', observedServiceValue='amber-repaired'",
    "cordis_inspect_self: harbor-1 activeRun={ packageId: 'pkg-4', pluginRunId: 'run-5' }, currentPackageId='pkg-4', status='running'"
  ],
  "final_runtime_truth": [
    "Plugin harbor-1 is active and running under package pkg-4 (run-5)",
    "Service pulseEndpoint is active with repaired value amber-repaired",
    "Packages pkg-1, pkg-3, and pkg-4 exist immutably under harbor-1",
    "Decoy plugin amber-2 remains unaffected"
  ],
  "remaining_unknowns": []
}
```
