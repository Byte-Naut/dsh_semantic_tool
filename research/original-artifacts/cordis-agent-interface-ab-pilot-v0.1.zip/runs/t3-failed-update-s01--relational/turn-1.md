### Diagnostic Summary

Inspection of dynamic plugin `harbor-1` reveals:
1. **Last successful Package**: `pkg-1` (`harbor stable package`), which registered `pulseEndpoint` at version `"amber-stable"`.
2. **Failed target Package**: `pkg-3` (`harbor failed update`), which threw `Error: amber bootstrap exploded` during host bootstrap.
3. **Active Run**: `null` (absent), because `run-1` was retracted during the update attempt and `run-3` failed during host load, leaving `harbor-1` without an active run.

#### Repair Candidates
- **Candidate 1 (Direct recovery then forward-patch)**: Run `pkg-1` on `harbor-1` to restore baseline service immediately. Then declare a new immutable Package under `harbor-1` with the bootstrap exception removed, and update `harbor-1` to the new package.
- **Candidate 2 (Direct forward-patch without rollback)**: Skip rolling back to `pkg-1` and immediately publish and update to the repaired package. (Rejected: violates explicit requirement to restore last known good behavior first).

**Selected Repair (D\*)**: Candidate 1.

```json
{
  "status": "PASS",
  "runtime_truth": [
    "Plugin harbor-1 has lastSuccessfulPackageId = pkg-1",
    "Plugin harbor-1 has failed target nextPackageId = pkg-3",
    "Plugin harbor-1 has activeRun = null due to retracted run-1 and failed run-3",
    "Package pkg-3 host source throws Error('amber bootstrap exploded') before ctx.provide",
    "Package pkg-1 host source successfully provides pulseEndpoint amber-stable"
  ],
  "derived_causes": [
    "An update from pkg-1 to pkg-3 was attempted, retracting run-1",
    "Host bootstrap of pkg-3 failed with an uncaught exception, aborting run-3",
    "Plugin harbor-1 was left in an unserved state with no active run"
  ],
  "unknowns": [],
  "failure_witness": {
    "initial": [
      "Plugin harbor-1 active run is null",
      "No service pulseEndpoint is provided by harbor-1"
    ],
    "actions": [
      "Query activeRun on harbor-1",
      "Inspect latestRun error on harbor-1"
    ],
    "bad_state": [
      "activeRun is null",
      "latestRun.status is failed with error 'amber bootstrap exploded'"
    ]
  },
  "selected_delta": {
    "delete": [
      "throw new Error(\"amber bootstrap exploded\");"
    ],
    "insert": []
  },
  "verification_obligations": [
    "Execute recovery run of pkg-1 on harbor-1 and verify activeRun is running with pulseEndpoint version amber-stable",
    "Register a new immutable package under harbor-1 containing the repaired host source without the bootstrap exception",
    "Execute update of harbor-1 to the new package and verify activeRun is running with pulseEndpoint version amber-repaired",
    "Verify no existing packages (pkg-1, pkg-3) are overwritten or replacement plugins created"
  ]
}
```
