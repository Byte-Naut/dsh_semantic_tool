### Diagnostic Assessment (D0)

#### 1. Direct Runtime Observations
* **Dynamic Plugins (`cordis_inspect_self`)**:
  * `cobalt-2`: Decoy plugin, healthy. `activeRun` is `{ packageId: "pkg-2", pluginRunId: "run-2" }`, `latestRun.status: "running"`.
  * `orchar-1`: Selected target plugin.
    * `currentPackageId`: `"pkg-1"`
    * `packageId`: `"pkg-3"`
    * `nextPackageId`: `"pkg-3"`
    * `activeRun`: **Absent (`undefined`)**. No package is currently active or serving.
    * `latestRun`: `{ pluginRunId: "run-3", packageId: "pkg-3", mode: "update", status: "failed", host: { status: "failed" }, error: { message: "Error: cobalt activation rejected", phase: "host-load" } }`.
* **Dynamic Packages (`dynamic_inspect_package`)**:
  * `pkg-1` (`"orchar stable package"`): Last successful package.
    * Host code: `return { apply(ctx) { ctx.provide("indexEndpoint", Object.freeze({ version: "cobalt-stable" })) } }`
  * `pkg-3` (`"orchar failed update"`): Target of the failed update.
    * Host code: `return { apply(ctx) { throw new Error("cobalt activation rejected"); ctx.provide("indexEndpoint", Object.freeze({ version: "cobalt-repaired" })) } }`
* **Event Slice (`native_event_slice`)**:
  * Dynamic runner registered and ran `pkg-1` (`run-1`).
  * Dynamic runner retracted `pkg-1` (`run-1`) upon initiating the update to `pkg-3`.
  * `startHostHalf` for `pkg-3` threw `Error: cobalt activation rejected` at host load phase.
  * `failedReceipt`: `reason: "host-half-failed"`, `message: "Error: cobalt activation rejected"`.
* **Checkpoints**: `snap:rt:t3-failed-update-s02:1` (`failed-update` at phase `host-update-failed`).

#### 2. Runtime Entity Distinction
* **Last Successful Package**: `pkg-1` (`"orchar stable package"`). Provided `indexEndpoint` with `{ version: "cobalt-stable" }`.
* **Failed Target Package**: `pkg-3` (`"orchar failed update"`). Intended to provide `indexEndpoint` with `{ version: "cobalt-repaired" }`, but aborted execution due to `throw new Error("cobalt activation rejected")`.
* **Actual Active Run**: **None** (`undefined`). `run-1` was retracted during the update, and `run-3` failed to activate.

#### 3. Deterministic Derivations & Root Cause
When the host runner attempted to update `orchar-1` to `pkg-3`, it retracted `pkg-1` (`run-1`). Loading `pkg-3` triggered the synchronous exception in its `apply(ctx)` function, causing `run-3` to fail during `host-load`. Because dynamic packages are immutable, `pkg-3` cannot be edited directly, and because `run-1` was retracted without automatic fallback, `orchar-1` is left without an active run.

---

### Repair Candidates

* **Candidate 1 (Selected D*)**: Two-phase recovery conforming to task constraints:
  1. *Restore*: Reactivate/rollback `orchar-1` to last known good package `pkg-1`, verifying an active run is restored serving `"cobalt-stable"`.
  2. *Repair*: Register a new immutable package (e.g. `pkg-4`) under `orchar-1` containing the repaired host code with the throw removed (`return { apply(ctx) { ctx.provide("indexEndpoint", Object.freeze({ version: "cobalt-repaired" })) } }`).
  3. *Update*: Apply the update on `orchar-1` to the new package, verifying active run reaches `"running"` with `"cobalt-repaired"`.

* **Candidate 2 (Rejected)**: Direct jump to repaired package without restoring `pkg-1` first. Rejected because the prompt explicitly mandates restoring the last known good behavior first before deploying the repair.

* **Candidate 3 (Rejected)**: Creating a new replacement plugin or modifying decoy plugin `cobalt-2`. Rejected by operational constraints forbidding replacement plugins and requiring mutations under `orchar-1`.

---

### Delta Specification (D*)

For the new immutable package source under `orchar-1`:
```javascript
// DELETE
throw new Error("cobalt activation rejected");

// RETAIN / INSERT
return { apply(ctx) { ctx.provide("indexEndpoint", Object.freeze({ version: "cobalt-repaired" })) } }
```

---

```json
{
  "status": "PASS",
  "runtime_truth": [
    "Plugin orchar-1 currently has no activeRun (undefined); latestRun is run-3 in status failed",
    "Last successful package is pkg-1 ('orchar stable package'), which previously served indexEndpoint with version cobalt-stable",
    "Failed update package is pkg-3 ('orchar failed update'), which throws 'Error: cobalt activation rejected' during apply(ctx)",
    "During the update attempt, pkg-1 was retracted and pkg-3 failed at host-load, leaving orchar-1 unserved",
    "Plugin cobalt-2 remains unaffected and running pkg-2 under run-2"
  ],
  "derived_causes": [
    "pkg-3 contains an explicit unhandled throw ('cobalt activation rejected') that aborts host-half activation",
    "Retraction of pkg-1 before successful activation of pkg-3 left the plugin with no active run upon update failure",
    "Immutability of dynamic packages requires creating a new package version rather than modifying pkg-3"
  ],
  "unknowns": [],
  "failure_witness": {
    "initial": [
      "cordis_inspect_self reports orchar-1 has activeRun: undefined and currentPackageId: 'pkg-1'",
      "cordis_inspect_self reports orchar-1 latestRun.status: 'failed' with error 'Error: cobalt activation rejected'"
    ],
    "actions": [
      "Inspect plugin orchar-1 activeRun field",
      "Inspect dynamic package pkg-3 source code"
    ],
    "bad_state": [
      "orchar-1 activeRun is undefined",
      "orchar-1 latestRun.error.phase is 'host-load'",
      "indexEndpoint service is not currently provided by orchar-1"
    ]
  },
  "selected_delta": {
    "delete": [
      "throw new Error(\"cobalt activation rejected\");"
    ],
    "insert": [
      "return { apply(ctx) { ctx.provide(\"indexEndpoint\", Object.freeze({ version: \"cobalt-repaired\" })) } }"
    ]
  },
  "verification_obligations": [
    "No lifecycle mutations or file edits performed in Turn 1",
    "In Turn 2, restore/activate pkg-1 on orchar-1 first and confirm activeRun is restored",
    "Create a new immutable package under pluginId orchar-1 with the throw removed",
    "Activate/update orchar-1 to the new package and verify activeRun is running and providing indexEndpoint version cobalt-repaired",
    "Ensure cobalt-2 remains healthy and unmodified throughout"
  ]
}
```
