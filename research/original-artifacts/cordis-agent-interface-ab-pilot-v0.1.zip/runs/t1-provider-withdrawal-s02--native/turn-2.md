The approved delta has been implemented in `src/callback-owner.mjs`. The external timer registration is now wrapped in `ctx.effect`, associating it with the Cordis context and returning an inverse disposer that calls `scheduler.clearInterval(handle)`.

All visible tests now pass without deviation from the approved design.

```json
{
  "implementation_status": "PASS",
  "files_changed": [
    "src/callback-owner.mjs"
  ],
  "lifecycle_actions": [],
  "checks": [
    "node --test (run_visible_tests): 1 passed, 0 failed"
  ],
  "final_runtime_truth": [
    "installCallback binds scheduler.setInterval inside ctx.effect with the provided label",
    "ctx.effect returns a cleanup disposer executing scheduler.clearInterval(handle) on context unmount/disposal",
    "Visible unit test verifies registration label and clean timer cancellation via the effect inverse"
  ],
  "remaining_unknowns": []
}
```
