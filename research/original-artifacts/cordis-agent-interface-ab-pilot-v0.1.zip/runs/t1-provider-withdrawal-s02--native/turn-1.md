### Diagnostic Summary (D0)

1. **Affected Plugin Dependency Chain**:
   - **Service Provider**: `orchard-ledger-provider` (`fiber:rt:t1-provider-withdrawal-s02:2`) provides service `ledgerSource`.
   - **Direct Consumer & Intermediate Provider**: `orchard-index-builder` (`fiber:rt:t1-provider-withdrawal-s02:3`) requires `ledgerSource` and provides service `indexModel`.
   - **Transitive Consumer**: `orchard-index-publisher` (`fiber:rt:t1-provider-withdrawal-s02:4`) requires `indexModel`.
   - **Unrelated Preserved Plugins**: `cobalt-decoy-provider` (`fiber:rt:t1-provider-withdrawal-s02:5`) and `cobalt-decoy-consumer` (`fiber:rt:t1-provider-withdrawal-s02:6`) manage `ledgerSourceDecoy` and remain untouched in `active` state; `ctr-semantic-observer` (`fiber:rt:t1-provider-withdrawal-s02:1`) remains active.

2. **Observed Cordis-Tracked Cleanup vs. External-Effect Truth**:
   - **Cordis-Tracked Cleanup**: When `ledgerSource` was retired, `orchard-ledger-provider` transitioned from `active` to `unloading` to `disposed`. Due to dependency revocation, `orchard-index-builder` and `orchard-index-publisher` transitioned to `pending`. Cordis successfully untracked all registered internal effects (`effects: []` at `snap:rt:t1-provider-withdrawal-s02:2`).
   - **External-Effect Truth**: In `src/callback-owner.mjs`, `installCallback` scheduled a recurring timer directly via `scheduler.setInterval` without registering an effect lifecycle handler via `ctx.effect(...)`. Because Cordis was unaware of the external scheduler handle, fiber retirement and state transitions did not trigger `scheduler.clearInterval`. The timer remained active on the external scheduler and continued firing callback `cobalt-orphan-callback` post-retirement.

3. **Checkable Failure Witness**:
   - Running `test/callback-owner.test.mjs` executes `installCallback(ctx, scheduler, 'cobalt-orphan-callback', calls, 34)` and asserts that `registeredLabel === 'cobalt-orphan-callback'` and `typeof disposer === 'function'`.
   - Currently, `ctx.effect` is never called, yielding `registeredLabel = undefined` and failing the test.

4. **Repair Candidates**:
   - *Candidate 1 (Selected D\*)*: Wrap the scheduler registration within `ctx.effect(() => { const handle = scheduler.setInterval(...); return () => scheduler.clearInterval(handle); }, label)`. This attaches the external timer lifecycle to Cordis context management and provides an inverse disposer invoked upon fiber unloading/disposal.
   - *Candidate 2*: Manually listen to context disposal hooks (e.g. `ctx.on('dispose', ...)`). This is less idiomatic than `ctx.effect`, violates the context effect contract expected by the consumer, and fails `test/callback-owner.test.mjs`.

```json
{
  "status": "SEMANTIC_REGRESSION",
  "runtime_truth": [
    "orchard-ledger-provider (fiber:rt:t1-provider-withdrawal-s02:2) disposed upon ledgerSource retirement",
    "orchard-index-builder (fiber:rt:t1-provider-withdrawal-s02:3) transitioned to pending due to revoked ledgerSource injection",
    "orchard-index-publisher (fiber:rt:t1-provider-withdrawal-s02:4) transitioned to pending due to revoked indexModel injection",
    "Cordis-tracked fiber effects for fibers 2, 3, and 4 are completely drained at snap:rt:t1-provider-withdrawal-s02:2",
    "External scheduler timer with label cobalt-orphan-callback continued firing because installCallback bypassed ctx.effect",
    "Unrelated decoy chain (cobalt-decoy-provider, cobalt-decoy-consumer) and observer remained active throughout"
  ],
  "derived_causes": [
    "src/callback-owner.mjs calls scheduler.setInterval directly and returns { handle } without binding to Cordis ctx.effect",
    "Without ctx.effect, Cordis cannot invoke an inverse disposer when the consumer fiber transitions from active to unloading/pending"
  ],
  "unknowns": [],
  "failure_witness": {
    "initial": [
      "src/callback-owner.mjs registers timer directly with scheduler without calling ctx.effect"
    ],
    "actions": [
      "run_visible_tests"
    ],
    "bad_state": [
      "AssertionError: Expected values to be strictly equal: + undefined - 'cobalt-orphan-callback' at test/callback-owner.test.mjs:29:10"
    ]
  },
  "selected_delta": {
    "delete": [
      "  const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)",
      "  return { handle }"
    ],
    "insert": [
      "  return ctx.effect(() => {",
      "    const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)",
      "    return () => scheduler.clearInterval(handle)",
      "  }, label)"
    ]
  },
  "verification_obligations": [
    "node --test passes completely in test/callback-owner.test.mjs",
    "Preserve existing signatures and unrelated source files"
  ]
}
```
