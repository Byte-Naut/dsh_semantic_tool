/** Installs the callback used by direct consumer. */
export function installCallback(ctx, scheduler, label, sink, payload) {
  return ctx.effect(() => {
    const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
    return () => scheduler.clearInterval(handle)
  }, label)
}
