import assert from 'node:assert/strict'
import test from 'node:test'
import { buildStatus } from '../src/status-adapter.mjs'

const implementation = name => ({ fiber: { name } })

test('reports the provider used by paused work separately from the reload target', () => {
  const fiber = {
    state: 1,
    store: { "ledgerPort": implementation('orchard-ledger-blue') },
    _store: { "ledgerPort": implementation('orchard-ledger-green') },
  }
  assert.deepEqual(buildStatus(fiber, 'ledgerPort'), {
    servingProviderId: 'orchard-ledger-blue',
    targetProviderId: 'orchard-ledger-green',
    transitioning: true,
  })
})
