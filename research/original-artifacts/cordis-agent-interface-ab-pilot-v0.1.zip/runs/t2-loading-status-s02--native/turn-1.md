### Diagnostic Assessment (D0)

At checkpoint `cut-orchard-loading`, Cordis runtime inspection reveals the consumer fiber `orchard-index-worker` (`fiber:rt:t2-loading-status-s02:3`) is paused in the `loading` state during a hot replacement:
- **Committed provider (current session / paused work)**: `orchard-ledger-blue` (`fiber:rt:t2-loading-status-s02:15`, version `cobalt-v1`), stored on `consumerFiber.store['ledgerPort']`.
- **Selected provider (target for next reload)**: `orchard-ledger-green` (`fiber:rt:t2-loading-status-s02:4`, version `cobalt-v2`), stored on `consumerFiber._store['ledgerPort']`.

In `src/status-adapter.mjs`, `buildStatus(consumerFiber, serviceKey)` reads only `consumerFiber._store?.[serviceKey]` and uses it for both `servingProviderId` and `targetProviderId`, while hardcoding `transitioning: false`. Consequently, `cobaltStatusAdapter` erroneously reports `orchard-ledger-green` as serving paused work and hides the active transition.

---

### Checkable Failure Witness

1. **Initial State**:
   Consumer fiber with:
   - `fiber.store['ledgerPort']` referencing `orchard-ledger-blue`
   - `fiber._store['ledgerPort']` referencing `orchard-ledger-green`
   - `fiber.state` is `1` (`loading`)
2. **Action**:
   Invoke `buildStatus(fiber, 'ledgerPort')`.
3. **Observed (Bad) State**:
   Returns `{ servingProviderId: 'orchard-ledger-green', targetProviderId: 'orchard-ledger-green', transitioning: false }`.
4. **Expected State**:
   Returns `{ servingProviderId: 'orchard-ledger-blue', targetProviderId: 'orchard-ledger-green', transitioning: true }`.

---

### Repair Candidates

#### Candidate 1 (Provider ID mismatch detection - Selected D*)
Derive `servingProviderId` from `consumerFiber.store?.[serviceKey]` and `targetProviderId` from `consumerFiber._store?.[serviceKey]`. Determine `transitioning` by checking `servingProviderId !== targetProviderId`.

#### Candidate 2 (Implementation reference divergence)
Derive `servingProviderId` and `targetProviderId` from `consumerFiber.store` and `consumerFiber._store`, but determine `transitioning` based on whether the underlying implementation objects diverge (`serving !== target && Boolean(serving && target)`).

**Selection Rationale**:
Candidate 1 directly reflects provider-level transition status matching the adapter's declared contract (`servingProviderId` vs `targetProviderId`) and handles missing/null provider IDs consistently without exposing internal implementation object identity.

---

### Selected Delta (D*)

In `src/status-adapter.mjs`:
```diff
 export function buildStatus(consumerFiber, serviceKey) {
+  const serving = consumerFiber.store?.[serviceKey]
   const target = consumerFiber._store?.[serviceKey]
+  const servingProviderId = providerId(serving)
+  const targetProviderId = providerId(target)
   return {
-    servingProviderId: providerId(target),
-    targetProviderId: providerId(target),
-    transitioning: false,
+    servingProviderId,
+    targetProviderId,
+    transitioning: servingProviderId !== targetProviderId,
   }
 }
```

---

### Verification Obligations

1. Apply proposed delta to `src/status-adapter.mjs`.
2. Run fixture-owned tests via `run_visible_tests` to verify `test/status-adapter.test.mjs` passes.
3. Verify that non-transitioning fibers (where `store` and `_store` resolve to the same provider) return `transitioning: false`.

```json
{
  "status": "SEMANTIC_REGRESSION",
  "runtime_truth": [
    "Checkpoint cut-orchard-loading contains consumer fiber orchard-index-worker (fiber:rt:t2-loading-status-s02:3) in state loading",
    "orchard-index-worker committedBindings for ledgerPort point to orchard-ledger-blue (fiber:rt:t2-loading-status-s02:15, version cobalt-v1)",
    "orchard-index-worker targetBindings for ledgerPort point to orchard-ledger-green (fiber:rt:t2-loading-status-s02:4, version cobalt-v2)",
    "src/status-adapter.mjs only inspects consumerFiber._store, causing servingProviderId to report targetProviderId and transitioning to return false"
  ],
  "derived_causes": [
    "buildStatus derives servingProviderId from consumerFiber._store instead of consumerFiber.store",
    "buildStatus hardcodes transitioning: false instead of checking divergence between committed and target providers"
  ],
  "unknowns": [],
  "failure_witness": {
    "initial": [
      "consumerFiber.store.ledgerPort has implementation orchard-ledger-blue",
      "consumerFiber._store.ledgerPort has implementation orchard-ledger-green"
    ],
    "actions": [
      "buildStatus(consumerFiber, 'ledgerPort')"
    ],
    "bad_state": [
      "servingProviderId is 'orchard-ledger-green'",
      "targetProviderId is 'orchard-ledger-green'",
      "transitioning is false"
    ]
  },
  "selected_delta": {
    "delete": [
      "  const target = consumerFiber._store?.[serviceKey]",
      "  return {",
      "    servingProviderId: providerId(target),",
      "    targetProviderId: providerId(target),",
      "    transitioning: false,",
      "  }"
    ],
    "insert": [
      "  const serving = consumerFiber.store?.[serviceKey]",
      "  const target = consumerFiber._store?.[serviceKey]",
      "  const servingProviderId = providerId(serving)",
      "  const targetProviderId = providerId(target)",
      "  return {",
      "    servingProviderId,",
      "    targetProviderId,",
      "    transitioning: servingProviderId !== targetProviderId,",
      "  }"
    ]
  },
  "verification_obligations": [
    "Execute run_visible_tests to verify test/status-adapter.test.mjs passes",
    "Confirm servingProviderId reflects consumerFiber.store?.[serviceKey]",
    "Confirm targetProviderId reflects consumerFiber._store?.[serviceKey]",
    "Confirm transitioning is true when servingProviderId !== targetProviderId and false when equal"
  ]
}
```
