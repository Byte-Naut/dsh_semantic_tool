### Implementation and Verification Summary

1. **Restoration of Last Known Good State**:
   - Executed `dynamic_run_package` with `mode: "run"` on package `pkg-1` for plugin `harbor-1`.
   - Verified that `harbor-1` transitioned to `status: "running"` under `pluginRunId: "run-4"`, successfully restoring the endpoint service value `"amber-stable"`.

2. **Definition of New Repaired Package**:
   - Executed `dynamic_define_package` under existing plugin `harbor-1` with name `"harbor repaired package"`, purpose `"publish the repaired endpoint value"`, and host code removing the bootstrap failure:
     ```javascript
     return { apply(ctx) { ctx.provide("pulseEndpoint", Object.freeze({ version: "amber-repaired" })) } }
     ```
   - Runtime allocated immutable package `pkg-4` attached to `harbor-1`.
   - Verified that historical packages `pkg-1` and `pkg-3` remained unmodified and no replacement plugin was created.

3. **Activation of Repaired Package**:
   - Executed `dynamic_run_package` with `mode: "update"` targeting `pkg-4` on `harbor-1`.
   - Verified that `harbor-1` transitioned to `status: "running"` with `pluginRunId: "run-5"`, current package `pkg-4`, and endpoint service value `"amber-repaired"`.

4. **Comparison to Approved Design**:
   - The implementation matches the approved sequence (rollback to `pkg-1` first, creation of an immutable package under `harbor-1`, followed by update to the new package).

```json
{
  "implementation_status": "PASS",
  "files_changed": [],
  "lifecycle_actions": [
    "dynamic_run_package(mode='run', packageId='pkg-1', pluginId='harbor-1')",
    "dynamic_define_package(pluginId='harbor-1', name='harbor repaired package', purpose='publish the repaired endpoint value', hostCode='return { apply(ctx) { ctx.provide(\"pulseEndpoint\", Object.freeze({ version: \"amber-repaired\" })) } }')",
    "dynamic_run_package(mode='update', packageId='pkg-4', pluginId='harbor-1')"
  ],
  "checks": [
    "Confirmed dynamic_run_package('run', 'pkg-1') restored status 'running' with observedServiceValue 'amber-stable' (run-4).",
    "Confirmed dynamic_define_package registered immutable package pkg-4 under existing plugin harbor-1.",
    "Confirmed dynamic_inspect_package on pkg-1 and pkg-3 verified both packages remain unmodified.",
    "Confirmed dynamic_run_package('update', 'pkg-4') completed successfully with status 'running' and observedServiceValue 'amber-repaired' (run-5).",
    "Confirmed cordis_inspect_self reports activeRun on pkg-4 (run-5) and currentPackageId 'pkg-4' on harbor-1, with amber-2 undisturbed.",
    "Confirmed run_visible_tests passed."
  ],
  "final_runtime_truth": [
    "Plugin harbor-1 is active on package pkg-4 under run-5 with status 'running'.",
    "Service pulseEndpoint is actively provided with version 'amber-repaired'.",
    "Packages pkg-1, pkg-3, and pkg-4 all exist immutably under harbor-1.",
    "Unrelated plugin amber-2 remains unaffected on pkg-2 under run-2."
  ],
  "remaining_unknowns": []
}
```
