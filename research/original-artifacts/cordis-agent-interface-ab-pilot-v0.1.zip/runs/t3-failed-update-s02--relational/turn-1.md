### Runtime Inspection & Ground Truth

From `cordis_inspect_self`, `dynamic_inspect_package`, `software_semantic_query`, and `native_event_slice`:

1. **Last Successful Package**:
   - `packageId`: `pkg-1` (`"orchar stable package"`).
   - Host source:
     ```javascript
     return { apply(ctx) { ctx.provide("indexEndpoint", Object.freeze({ version: "cobalt-stable" })) } }
     ```
   - Purpose: `"serve the benchmark endpoint"`.

2. **Failed Target Package**:
   - `packageId`: `pkg-3` (`"orchar failed update"`).
   - Host source:
     ```javascript
     return { apply(ctx) { throw new Error("cobalt activation rejected"); ctx.provide("indexEndpoint", Object.freeze({ version: "cobalt-repaired" })) } }
     ```
   - Status: Failed during host load phase (`phase: "host-load"`, error: `"Error: cobalt activation rejected"`).
   - Purpose: `"publish the repaired endpoint value"`.

3. **Actual Active Run**:
   - `activeRun`: `null` (absent on `orchar-1`).
   - Although `currentPackageId` remains pointed to `pkg-1`, the original active run (`run-1`) was retracted via `cordis/dynamic-retract` when update `run-3` was attempted. Because update `run-3` failed during host activation, dynamic plugin `orchar-1` is currently serving nothing (`failedUpdateGap: true`, `lastSuccessfulIsCurrentlyRunning: false`).

---

### D0 (Baseline Failure State)

Dynamic plugin `orchar-1` has no active run (`activeRun: null`), and the index endpoint service is unserved. The latest attempted run (`run-3`) failed because package `pkg-3` unconditionally throws `new Error("cobalt activation rejected")` during `apply(ctx)` before providing `indexEndpoint`.

---

### Checkable Failure Witness

1. **Initial State**:
   - Dynamic plugin `orchar-1` has `currentPackageId: "pkg-1"`, `nextPackageId: "pkg-3"`.
   - `activeRun` is `null`.
2. **Action**:
   - Querying `explain_dynamic_package_state` for `orchar-1` confirms `activeRun: null`, `lastSuccessfulIsCurrentlyRunning: false`, and `failedUpdateGap: true`.
3. **Bad State**:
   - Neither `pkg-1` nor `pkg-3` is active; `indexEndpoint` is not provided.

---

### Semantically Distinct Repair Candidates

- **Candidate 1 (Two-stage recovery + new package update - Selected)**:
  1. Restore service immediately by initiating an explicit run of the last known good package `pkg-1` on dynamic plugin `orchar-1`.
  2. Create a new immutable package (e.g., `pkg-4`) under `orchar-1` containing the repaired host source (removing the `throw new Error("cobalt activation rejected");` statement).
  3. Update dynamic plugin `orchar-1` to the new package, achieving the intended `"cobalt-repaired"` endpoint value.

- **Candidate 2 (Direct repair without restoring last known good)**:
  - Skip restoring `pkg-1` and immediately update `orchar-1` to a newly defined package with the repaired source code.
  - *Evaluation*: Rejected because it violates the task specification ("Restore the last known good behavior first, then repair the failed source as a new immutable Package under the same Plugin").

- **Candidate 3 (In-place package overwrite / retry of pkg-3)**:
  - Attempt to mutate `pkg-3` or retry `run` on `pkg-3`.
  - *Evaluation*: Rejected because packages are immutable, task rules forbid overwriting existing packages, and retrying `pkg-3` directly would re-trigger the rejection error.

---

### Selected D* and Lifecycle Sequence

1. **Lifecycle Action 1 (Restore)**: Execute `run` for plugin `orchar-1` with `packageId: "pkg-1"`. Verify `activeRun` is established and `indexEndpoint` provides `"cobalt-stable"`.
2. **Lifecycle Action 2 (Define Repair Package)**: Register a new immutable package under plugin `orchar-1` with host code:
   ```javascript
   return { apply(ctx) { ctx.provide("indexEndpoint", Object.freeze({ version: "cobalt-repaired" })) } }
   ```
3. **Lifecycle Action 3 (Apply Repaired Package)**: Execute `update` on `orchar-1` to target the newly registered package. Verify `activeRun` is running on the new package without errors.

---

### Remaining Unknowns

- The exact identifier that the host runtime will assign to the newly created package (likely `pkg-4`).

---

### Verification Obligations

1. After restoration step: Verify `activeRun` on `orchar-1` is running with `packageId: "pkg-1"` and `indexEndpoint` serves `version: "cobalt-stable"`.
2. After package definition and update step: Verify `activeRun` is running on the new package without error and `indexEndpoint` serves `version: "cobalt-repaired"`.
3. Verify that `pkg-1`, `pkg-2`, and `pkg-3` remain intact and unmutated.

```json
{
  "status": "PASS",
  "runtime_truth": [
    "Dynamic plugin orchar-1 has currentPackageId 'pkg-1', nextPackageId 'pkg-3', and activeRun null.",
    "The last successful package is 'pkg-1', which provides indexEndpoint with version 'cobalt-stable'.",
    "The failed target package is 'pkg-3', which threw 'Error: cobalt activation rejected' during host-load phase.",
    "Dynamic event slice records dynamic-retract for pkg-1 during update attempt run-3, leaving orchar-1 with no running package."
  ],
  "derived_causes": [
    "Retraction of pkg-1 combined with activation failure in pkg-3 caused a failed update gap where orchar-1 has no active run.",
    "Package pkg-3 contains an unconditional throw in apply(ctx) before ctx.provide('indexEndpoint', ...)."
  ],
  "unknowns": [
    "Exact runtime-generated ID for the next immutable package created under orchar-1."
  ],
  "failure_witness": {
    "initial": [
      "Plugin orchar-1 stopped serving after update attempt run-3.",
      "Package pkg-1 is retracted; package pkg-3 failed activation."
    ],
    "actions": [
      "Inspect runtime state via cordis_inspect_self, dynamic_inspect_package, and software_semantic_query(explain_dynamic_package_state)."
    ],
    "bad_state": [
      "activeRun is null for plugin orchar-1.",
      "failedUpdateGap is true and lastSuccessfulIsCurrentlyRunning is false."
    ]
  },
  "selected_delta": {
    "delete": [
      "throw new Error(\"cobalt activation rejected\");"
    ],
    "insert": []
  },
  "verification_obligations": [
    "Verify explicit run of pkg-1 restores activeRun for orchar-1 and serves indexEndpoint 'cobalt-stable'.",
    "Verify definition of new package under orchar-1 with repaired host code.",
    "Verify update of orchar-1 to the new package completes successfully with activeRun running and serving indexEndpoint 'cobalt-repaired'.",
    "Confirm no existing packages or plugins were overwritten or replaced."
  ]
}
```
