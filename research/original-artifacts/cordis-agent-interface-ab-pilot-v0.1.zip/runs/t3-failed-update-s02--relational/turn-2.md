### Implementation & Verification Summary

1. **Restored Last Known Good (`pkg-1`)**:
   - Executed `dynamic_run_package` in `run` mode with `packageId: "pkg-1"` on plugin `orchar-1`.
   - Verified that the run succeeded (`ok: true`, `status: "running"`, `pluginRunId: "run-4"`) and provided `observedServiceValue: "cobalt-stable"`.

2. **Defined New Immutable Package (`pkg-4`)**:
   - Executed `dynamic_define_package` under plugin `orchar-1` with name `"orchar repaired package"`, purpose `"publish the repaired endpoint value"`, and host code:
     ```javascript
     return { apply(ctx) { ctx.provide("indexEndpoint", Object.freeze({ version: "cobalt-repaired" })) } }
     ```
   - The runtime generated immutable package identifier `pkg-4`.

3. **Updated Plugin to Repaired Package**:
   - Executed `dynamic_run_package` in `update` mode with `packageId: "pkg-4"` on plugin `orchar-1`.
   - Verified update succeeded (`ok: true`, `status: "running"`, `pluginRunId: "run-5"`) and published the repaired service value (`observedServiceValue: "cobalt-repaired"`).

4. **Consistency & Non-Regression Checks**:
   - `cordis_inspect_self` confirms plugin `orchar-1` now has `activeRun` pointing to `{ packageId: "pkg-4", pluginRunId: "run-5" }` and `currentPackageId: "pkg-4"`.
   - Packages `pkg-1`, `pkg-3`, and `pkg-4` remain intact and unmutated under `orchar-1`.
   - Unrelated decoy plugin `cobalt-2` remains unaffected in state `running` on `pkg-2`.
   - `run_visible_tests` ran with zero failures.

```json
{
  "implementation_status": "PASS",
  "files_changed": [],
  "lifecycle_actions": [
    "dynamic_run_package({ pluginId: 'orchar-1', packageId: 'pkg-1', mode: 'run' })",
    "dynamic_define_package({ pluginId: 'orchar-1', name: 'orchar repaired package', purpose: 'publish the repaired endpoint value', hostCode: 'return { apply(ctx) { ctx.provide(\"indexEndpoint\", Object.freeze({ version: \"cobalt-repaired\" })) } }' })",
    "dynamic_run_package({ pluginId: 'orchar-1', packageId: 'pkg-4', mode: 'update' })"
  ],
  "checks": [
    "Confirmed dynamic_run_package restored pkg-1 to running state with observedServiceValue 'cobalt-stable'.",
    "Confirmed dynamic_define_package registered new immutable package 'pkg-4' under orchar-1.",
    "Confirmed dynamic_run_package updated orchar-1 to pkg-4 with observedServiceValue 'cobalt-repaired'.",
    "Verified cordis_inspect_self: orchar-1 activeRun is { packageId: 'pkg-4', pluginRunId: 'run-5' } and status is running.",
    "Verified dynamic_inspect_package confirms pkg-1, pkg-3, and pkg-4 exist and immutability was preserved.",
    "Executed run_visible_tests: passed."
  ],
  "final_runtime_truth": [
    "Dynamic plugin orchar-1 is actively running package pkg-4 under run-5.",
    "The indexEndpoint service is active with version 'cobalt-repaired'.",
    "Original packages pkg-1 and pkg-3 remain unchanged; no replacement plugins were created."
  ],
  "remaining_unknowns": []
}
```
