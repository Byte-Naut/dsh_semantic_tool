### Diagnostic Analysis (Incident `inc-harbor-01`)

#### 1. Baseline State (D0) and Complete Affected Plugin Chain
- **Root & Observer**:
  - `root` (`fiber:rt:t1-provider-withdrawal-s01:0`): Root fiber, active.
  - `ctr-semantic-observer` (`fiber:rt:t1-provider-withdrawal-s01:1`): Active observer, unaffected.
- **Affected Chain**:
  - **Provider**: `harbor-beacon-provider` (`fiber:rt:t1-provider-withdrawal-s01:2`) registered service implementation `selected:beaconSource` (`service-impl:rt:t1-provider-withdrawal-s01:28`).
  - **Direct Consumer / Intermediate Provider**: `harbor-pulse-builder` (`fiber:rt:t1-provider-withdrawal-s01:3`) declared injection `beaconSource` and registered service implementation `pulseModel` (`service-impl:rt:t1-provider-withdrawal-s01:32`).
  - **Transitive Consumer**: `harbor-pulse-publisher` (`fiber:rt:t1-provider-withdrawal-s01:4`) declared injection `pulseModel` and invoked `installCallback` to schedule `amber-orphan-callback`.
- **Preserved Unrelated Plugins**:
  - `amber-decoy-provider` (`fiber:rt:t1-provider-withdrawal-s01:5`) providing `beaconSourceDecoy`.
  - `amber-decoy-consumer` (`fiber:rt:t1-provider-withdrawal-s01:6`) consuming `beaconSourceDecoy`. Both remain active and unaffected.

#### 2. Cordis-Tracked Cleanup vs. External-Effect Truth
- **Observed Cordis-Tracked Cleanup**:
  - Upon retirement of `service-impl:rt:t1-provider-withdrawal-s01:28`, `harbor-beacon-provider` disposed its effects (`ctx.provide("beaconSource")`, `beaconSource:provider-owned`) and transitioned to `disposed`.
  - Service loss propagated downstream: `harbor-pulse-builder` unloaded its effects (`ctx.provide("pulseModel")`, `pulseModel:direct-owned`) and transitioned to `pending`.
  - `harbor-pulse-publisher` unloaded its tracked effect (`pulseModel:transitive-owned`) and transitioned to `pending`.
  - At checkpoint `snap:rt:t1-provider-withdrawal-s01:2`, Cordis fiber effect lists for fibers 2, 3, and 4 are completely drained.
- **External-Effect Truth**:
  - In `native_event_slice`, the external timer `#1` (`amber-orphan-callback`) remained scheduled and fired repeatedly after provider disposal and fiber unloading completed (`callbackObservations` captured multiple executions with payload `17`).

#### 3. Ownership Defect
- In `src/callback-owner.mjs`, `installCallback(ctx, scheduler, label, sink, payload)` scheduled an external recurring timer via `scheduler.setInterval(...)` directly, bypassing `ctx.effect(...)`.
- Because the timer handle was not enclosed in a Cordis lifecycle effect returning an inverse disposer (`scheduler.clearInterval(handle)`), Cordis fiber teardown could not tear down the external interval job.

#### 4. Repair Candidates
- **Candidate A (Selected D*)**: Register the timer within `ctx.effect(callback, label)` and return `() => scheduler.clearInterval(handle)` as its inverse disposer. This binds the interval lifecycle directly to the fiber's Cordis context, satisfying `test/callback-owner.test.mjs`.
- **Candidate B (Manual Caller Disposer)**: Return an unmanaged `{ handle, dispose }` object without invoking `ctx.effect`. Rejected because consumers depend on Cordis context lifecycle unwinding rather than manual cleanup management.

---

```json
{
  "status": "PASS",
  "runtime_truth": [
    "Checkpoint snap:rt:t1-provider-withdrawal-s01:1 shows fiber:rt:t1-provider-withdrawal-s01:2 providing beaconSource, fiber:rt:t1-provider-withdrawal-s01:3 consuming beaconSource and providing pulseModel, and fiber:rt:t1-provider-withdrawal-s01:4 consuming pulseModel.",
    "Checkpoint snap:rt:t1-provider-withdrawal-s01:2 shows fiber:rt:t1-provider-withdrawal-s01:2 disposed, while fibers 3 and 4 transitioned to pending with empty committedBindings and empty effects.",
    "Decoy fibers fiber:rt:t1-provider-withdrawal-s01:5 and fiber:rt:t1-provider-withdrawal-s01:6 remain active across both checkpoints.",
    "native_event_slice shows externalScheduler job #1 (label 'amber-orphan-callback') fired twice after fiber:rt:t1-provider-withdrawal-s01:2 reached disposed status."
  ],
  "derived_causes": [
    "installCallback schedules scheduler.setInterval directly without wrapping the invocation in ctx.effect(callback, label).",
    "Because no inverse disposer is returned to ctx.effect, Cordis fiber teardown of harbor-pulse-publisher cannot cancel the timer on transition from active to pending."
  ],
  "unknowns": [
    "Whether any external callers outside the test suite rely on the legacy return shape { handle }."
  ],
  "failure_witness": {
    "initial": [
      "harbor-beacon-provider is active providing beaconSource.",
      "harbor-pulse-builder is active consuming beaconSource and providing pulseModel.",
      "harbor-pulse-publisher is active consuming pulseModel with amber-orphan-callback running."
    ],
    "actions": [
      "Retire service implementation selected:beaconSource (service-impl:rt:t1-provider-withdrawal-s01:28).",
      "harbor-beacon-provider unloads and disposes.",
      "harbor-pulse-builder and harbor-pulse-publisher unload and transition to pending."
    ],
    "bad_state": [
      "amber-orphan-callback continues firing in externalScheduler after retirement completes.",
      "test/callback-owner.test.mjs fails with AssertionError: Expected values to be strictly equal: undefined === 'amber-orphan-callback'."
    ]
  },
  "selected_delta": {
    "delete": [
      "  const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)",
      "  return { handle }"
    ],
    "insert": [
      "  return ctx.effect(() => {",
      "    const handle = scheduler.setInterval(() => sink.push({ label, payload }), label)",
      "    return () => scheduler.clearInterval(handle)",
      "  }, label)"
    ]
  },
  "verification_obligations": [
    "Run node --test via run_visible_tests and ensure test/callback-owner.test.mjs passes.",
    "Verify that registeredLabel is 'amber-orphan-callback', disposer is a function, and disposer() clears intervals."
  ]
}
```
