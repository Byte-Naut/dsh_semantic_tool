### Implementation Summary

The approved delta $D^*$ was implemented in `src/status-adapter.mjs`. 
- `serving` is extracted from the consumer fiber's committed store `consumerFiber.store?.[serviceKey]`.
- `target` is extracted from the consumer fiber's staged store `consumerFiber._store?.[serviceKey]`.
- `servingProviderId` and `targetProviderId` are derived via `providerId()`.
- `transitioning` is dynamically determined by evaluating `servingProviderId !== targetProviderId`.

Visible tests pass cleanly.

```json
{
  "implementation_status": "PASS",
  "files_changed": [
    "src/status-adapter.mjs"
  ],
  "lifecycle_actions": [],
  "checks": [
    "node --test via run_visible_tests passed (test/status-adapter.test.mjs: 1 pass, 0 fail)"
  ],
  "final_runtime_truth": [
    "buildStatus now reports servingProviderId as 'orchard-ledger-blue' and targetProviderId as 'orchard-ledger-green' with transitioning: true when consumer is paused during replacement.",
    "No changes made to tests, Cordis framework core, or runtime lifecycle."
  ],
  "remaining_unknowns": []
}
```
