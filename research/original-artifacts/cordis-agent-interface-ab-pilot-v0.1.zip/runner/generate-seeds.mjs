import { mkdir, writeFile } from 'node:fs/promises'
import { allSeeds, pilotSeeds } from './seed-catalog.mjs'
import { hashJson } from '../src/hash.mjs'

await mkdir('artifacts', { recursive: true })
const all = allSeeds().map(seed => ({ ...seed, hash: hashJson(seed) }))
const pilotIds = new Set(pilotSeeds().map(seed => seed.seedId))
await writeFile('artifacts/seeds.json', JSON.stringify({
  generatedAt: new Date().toISOString(),
  all,
  pilot: all.filter(seed => pilotIds.has(seed.seedId)),
}, null, 2) + '\n')
console.log(`generated ${all.length} fixture seeds; pilot uses ${pilotIds.size}`)
