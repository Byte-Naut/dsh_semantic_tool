import { readFile, readdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { EXPERIMENT } from '../src/config.mjs'

const runDirectories = (await readdir('runs', { withFileTypes: true }))
  .filter(entry => entry.isDirectory())
  .map(entry => entry.name)
  .sort()
const results = []
for (const directory of runDirectories) {
  results.push(JSON.parse(await readFile(join('runs', directory, 'result.json'), 'utf8')))
}
if (results.length !== 12) throw new Error(`expected 12 run results, found ${results.length}`)

const valid = results.filter(result => result.validity === 'valid')
const invalid = results.filter(result => result.validity !== 'valid')
const arms = Object.fromEntries(['native', 'relational'].map(arm => {
  const rows = valid.filter(result => result.arm === arm)
  return [arm, summarize(rows)]
}))
const pairs = pairResults(valid)
const observedTotalCost = sum(results.map(result => result.costUsd ?? 0))
const perRunCosts = valid.map(result => result.costUsd ?? 0).sort((a, b) => a - b)
const costProjection = {
  observedPilotUsd: round(observedTotalCost),
  meanPerRunUsd: round(mean(perRunCosts)),
  maxPerRunUsd: round(Math.max(0, ...perRunCosts)),
  projected72MeanUsd: round(mean(perRunCosts) * 72),
  projected72ObservedMaxUsd: round(Math.max(0, ...perRunCosts) * 72),
}
const analysis = {
  schemaVersion: 1,
  experimentId: EXPERIMENT.id,
  generatedAt: new Date().toISOString(),
  pilotInterpretation: 'instrumentation/floor/ceiling pilot; descriptive only, not a confirmatory efficacy estimate',
  runCount: results.length,
  validCount: valid.length,
  invalidCount: invalid.length,
  invalidRuns: invalid.map(result => ({ runId: result.runId, validity: result.validity, error: result.error ?? null })),
  arms,
  paired: summarizePairs(pairs),
  costProjection,
  observedModelVersions: [...new Set(valid.flatMap(result => result.reportedModelVersions ?? []))],
}
await writeFile('artifacts/pilot-analysis.json', JSON.stringify(analysis, null, 2) + '\n')
await writeFile('artifacts/pilot-report.md', renderReport(analysis, results))
console.log(`analyzed ${results.length} runs (${valid.length} valid); pilot cost $${costProjection.observedPilotUsd}`)

function summarize(rows) {
  return {
    n: rows.length,
    primaryPasses: rows.filter(row => row.score?.primaryPass).length,
    runtimePasses: rows.filter(row => row.score?.runtimePass).length,
    recordCompliant: rows.filter(row => row.score?.recordCompliance).length,
    criticalErrors: rows.reduce((sum, row) => sum + (row.score?.criticalErrors?.length ?? 0), 0),
    meanToolCalls: round(mean(rows.map(row => row.score?.telemetryTotals?.toolCalls ?? 0))),
    meanNativeObservationCalls: round(mean(rows.map(row => row.score?.telemetryTotals?.nativeObservationCalls ?? 0))),
    meanRelationalObservationCalls: round(mean(rows.map(row => row.score?.telemetryTotals?.relationalObservationCalls ?? 0))),
    meanGrossInputTokens: round(mean(rows.map(row => row.score?.telemetryTotals?.usage?.input ?? 0))),
    meanOutputPlusThinkingTokens: round(mean(rows.map(row => {
      const usage = row.score?.telemetryTotals?.usage ?? {}
      return (usage.output ?? 0) + (usage.thoughts ?? 0)
    }))),
    meanDurationMs: round(mean(rows.map(row => row.durationMs ?? 0))),
    totalCostUsd: round(sum(rows.map(row => row.costUsd ?? 0))),
  }
}

function pairResults(rows) {
  const bySeed = new Map()
  for (const row of rows) {
    const pair = bySeed.get(row.seedId) ?? {}
    pair[row.arm] = row
    bySeed.set(row.seedId, pair)
  }
  return [...bySeed.entries()]
    .filter(([, pair]) => pair.native && pair.relational)
    .map(([seedId, pair]) => ({ seedId, native: pair.native, relational: pair.relational }))
}

function summarizePairs(pairs) {
  const primaryDeltas = pairs.map(pair => Number(pair.relational.score.primaryPass) - Number(pair.native.score.primaryPass))
  const toolDeltas = pairs.map(pair => pair.relational.score.telemetryTotals.toolCalls - pair.native.score.telemetryTotals.toolCalls)
  const inputDeltas = pairs.map(pair => pair.relational.score.telemetryTotals.usage.input - pair.native.score.telemetryTotals.usage.input)
  const semanticErrorDeltas = pairs.map(pair => pair.relational.score.criticalErrors.length - pair.native.score.criticalErrors.length)
  return {
    completePairs: pairs.length,
    relationalBetterPrimary: primaryDeltas.filter(value => value > 0).length,
    tiesPrimary: primaryDeltas.filter(value => value === 0).length,
    nativeBetterPrimary: primaryDeltas.filter(value => value < 0).length,
    meanPrimaryPassDelta: round(mean(primaryDeltas)),
    meanToolCallDelta: round(mean(toolDeltas)),
    meanGrossInputTokenDelta: round(mean(inputDeltas)),
    meanCriticalErrorDelta: round(mean(semanticErrorDeltas)),
  }
}

function renderReport(analysis, results) {
  const a = analysis.arms
  const rows = results.sort((left, right) => left.runId.localeCompare(right.runId))
  return `# Gemini 3.8 Flash Agent-interface A/B pilot

## Status

- Runs: ${analysis.runCount}; valid: ${analysis.validCount}; invalid: ${analysis.invalidCount}
- Reported model version(s): ${analysis.observedModelVersions.join(', ') || 'none'}
- Interpretation: ${analysis.pilotInterpretation}

## Arm summaries

| Metric | Native | Relational |
|---|---:|---:|
| Valid runs | ${a.native.n} | ${a.relational.n} |
| Primary pass | ${a.native.primaryPasses} | ${a.relational.primaryPasses} |
| Hidden runtime pass | ${a.native.runtimePasses} | ${a.relational.runtimePasses} |
| Record compliant | ${a.native.recordCompliant} | ${a.relational.recordCompliant} |
| Critical semantic errors | ${a.native.criticalErrors} | ${a.relational.criticalErrors} |
| Mean tool calls | ${a.native.meanToolCalls} | ${a.relational.meanToolCalls} |
| Mean native observation calls | ${a.native.meanNativeObservationCalls} | ${a.relational.meanNativeObservationCalls} |
| Mean relational observation calls | ${a.native.meanRelationalObservationCalls} | ${a.relational.meanRelationalObservationCalls} |
| Mean gross input tokens | ${a.native.meanGrossInputTokens} | ${a.relational.meanGrossInputTokens} |
| Mean output + thinking tokens | ${a.native.meanOutputPlusThinkingTokens} | ${a.relational.meanOutputPlusThinkingTokens} |
| Mean duration (ms) | ${a.native.meanDurationMs} | ${a.relational.meanDurationMs} |
| Total estimated cost (USD) | ${a.native.totalCostUsd} | ${a.relational.totalCostUsd} |

## Paired descriptive comparison

${JSON.stringify(analysis.paired, null, 2)}

This 12-run pilot is not used as a confirmatory significance test. It checks execution validity, outcome variance, rubric ceiling/floor, and the plausibility of the preregistered 72-run study.

## Cost

- Pilot observed: $${analysis.costProjection.observedPilotUsd}
- 72 runs at observed mean: $${analysis.costProjection.projected72MeanUsd}
- 72 runs at observed maximum per-run cost: $${analysis.costProjection.projected72ObservedMaxUsd}

The estimate uses $${EXPERIMENT.pricingUsdPerMillion.input}/M gross prompt tokens and $${EXPERIMENT.pricingUsdPerMillion.outputIncludingThinking}/M candidate-plus-thinking tokens.

## Run ledger

| Run | Validity | Primary | Runtime | Critical errors | Tool calls | Input tokens | Output + thinking | Cost USD |
|---|---|---:|---:|---:|---:|---:|---:|---:|
${rows.map(row => {
  const usage = row.score?.telemetryTotals?.usage ?? {}
  return `| ${row.runId} | ${row.validity} | ${Number(Boolean(row.score?.primaryPass))} | ${Number(Boolean(row.score?.runtimePass))} | ${row.score?.criticalErrors?.length ?? ''} | ${row.score?.telemetryTotals?.toolCalls ?? ''} | ${usage.input ?? ''} | ${(usage.output ?? 0) + (usage.thoughts ?? 0)} | ${row.costUsd ?? 0} |`
}).join('\n')}
`
}

function mean(values) {
  return values.length ? sum(values) / values.length : 0
}

function sum(values) {
  return values.reduce((total, value) => total + value, 0)
}

function round(value) {
  return Number(Number(value).toFixed(4))
}
