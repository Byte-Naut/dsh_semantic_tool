import { ARMS, TASK_IDS } from '../src/config.mjs'
import { seedFor } from './seed-catalog.mjs'

export function pilotRunOrder() {
  const output = []
  for (const [taskIndex, taskId] of TASK_IDS.entries()) {
    for (const number of [1, 2]) {
      const seed = seedFor(taskId, number)
      const first = (taskIndex + number) % 2 === 0 ? 'native' : 'relational'
      const second = ARMS.find(arm => arm !== first)
      output.push({ taskId, seed, arm: first }, { taskId, seed, arm: second })
    }
  }
  return output
}
