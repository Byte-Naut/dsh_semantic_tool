const WORDS = Object.freeze([
  ['harbor', 'beacon', 'pulse', 'amber'],
  ['orchard', 'ledger', 'index', 'cobalt'],
  ['quarry', 'signal', 'view', 'crimson'],
  ['marina', 'quota', 'panel', 'delta'],
  ['foundry', 'metric', 'screen', 'ember'],
  ['granary', 'route', 'digest', 'frost'],
  ['terrace', 'catalog', 'summary', 'garnet'],
  ['aviary', 'notice', 'feed', 'hazel'],
  ['citadel', 'status', 'report', 'indigo'],
  ['meadow', 'sample', 'projection', 'jade'],
  ['tundra', 'record', 'display', 'kelp'],
  ['estuary', 'channel', 'snapshot', 'lilac'],
])

export function allSeeds() {
  return ['t1-provider-withdrawal', 't2-loading-status', 't3-failed-update']
    .flatMap(taskId => Array.from({ length: 12 }, (_, index) => seedFor(taskId, index + 1)))
}

export function pilotSeeds() {
  return ['t1-provider-withdrawal', 't2-loading-status', 't3-failed-update']
    .flatMap(taskId => [seedFor(taskId, 1), seedFor(taskId, 2)])
}

export function seedFor(taskId, number) {
  if (!Number.isInteger(number) || number < 1 || number > 12) {
    throw new Error(`seed number must be 1..12: ${number}`)
  }
  const [place, service, derived, color] = WORDS[number - 1]
  const common = {
    taskId,
    number,
    seedId: `${taskId}-s${String(number).padStart(2, '0')}`,
    incidentId: `inc-${place}-${String(number).padStart(2, '0')}`,
  }
  if (taskId === 't1-provider-withdrawal') {
    return Object.freeze({
      ...common,
      serviceKey: `${service}Source`,
      derivedServiceKey: `${derived}Model`,
      providerName: `${place}-${service}-provider`,
      directConsumerName: `${place}-${derived}-builder`,
      transitiveConsumerName: `${place}-${derived}-publisher`,
      decoyProviderName: `${color}-decoy-provider`,
      decoyConsumerName: `${color}-decoy-consumer`,
      orphanLabel: `${color}-orphan-callback`,
      leakTarget: number % 2 === 0 ? 'direct' : 'transitive',
      payload: number * 17,
    })
  }
  if (taskId === 't2-loading-status') {
    return Object.freeze({
      ...common,
      serviceKey: `${service}Port`,
      providerV1: `${place}-${service}-blue`,
      providerV2: `${place}-${service}-green`,
      consumerName: `${place}-${derived}-worker`,
      statusAdapter: `${color}StatusAdapter`,
      checkpointAlias: `cut-${place}-loading`,
      valueV1: `${color}-v1`,
      valueV2: `${color}-v2`,
    })
  }
  if (taskId === 't3-failed-update') {
    return Object.freeze({
      ...common,
      pluginPrefix: place.slice(0, 6),
      serviceKey: `${derived}Endpoint`,
      stableValue: `${color}-stable`,
      repairedValue: `${color}-repaired`,
      failureMessage: number % 2 === 0
        ? `${color} activation rejected`
        : `${color} bootstrap exploded`,
      decoyPrefix: color.slice(0, 6),
    })
  }
  throw new Error(`unknown task: ${taskId}`)
}
