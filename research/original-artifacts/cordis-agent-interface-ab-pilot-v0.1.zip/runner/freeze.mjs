import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { EXPERIMENT, ARMS, TASK_IDS, TURN_TWO_APPROVAL } from '../src/config.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { commonSystemPrompt } from '../src/common-prompt.mjs'
import { pilotSeeds } from './seed-catalog.mjs'
import { pilotRunOrder } from './run-order.mjs'

const sourceTree = await hashTree('.', {
  exclude: (name, entry) => name === 'node_modules'
    || name.startsWith('node_modules/')
    || name === 'artifacts'
    || name.startsWith('artifacts/')
    || name === 'runs'
    || name.startsWith('runs/')
    || name === 'workspaces'
    || name.startsWith('workspaces/')
    || (entry.isFile() && name === 'package-lock.json'),
})
const lockHash = hashJson(JSON.parse(await readFile('package-lock.json', 'utf8')))
const preregistration = {
  schemaVersion: 1,
  frozenAt: new Date().toISOString(),
  experiment: EXPERIMENT,
  estimand: 'semantic interface causes a measurable benefit under a fixed independent strong model',
  tasks: TASK_IDS,
  arms: ARMS,
  pilotSeeds: pilotSeeds().map(seed => seed.seedId),
  runCount: pilotSeeds().length * ARMS.length,
  runOrder: pilotRunOrder().map(({ seed, arm }) => ({ seedId: seed.seedId, arm })),
  invariantControls: [
    'same model and reported model version',
    'same thinking level, temperature, sampling seed, budgets, timeout, task card, workspace files, and runtime semantics',
    'fresh conversation and fresh runtime for every run',
    'no fallback model',
  ],
  permittedArmDifference: 'relational arm adds exactly software_semantic_query as a read-only tool',
  informationFirewall: [
    'no theory papers or companion',
    'no semantic-mirror rationale or expected superiority claim',
    'no reference delta, hidden oracle, grader, other-arm trajectory, or prior trajectory',
  ],
  turnTwoApproval: TURN_TWO_APPROVAL,
  commonPromptHash: hashJson(commonSystemPrompt()),
  sourceTree,
  packageLockHash: lockHash,
  retryPolicy: 'one HTTP attempt per model request; infrastructure failure is invalid, never a model fallback',
  primaryOutcome: 'private task diagnosis checklist AND hidden runtime grade AND zero critical semantic errors',
  pilotUse: 'instrumentation/floor/ceiling validation only; no efficacy claim and no post-result prompt/tool/grader edits',
}
await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/preregistration.json', JSON.stringify(preregistration, null, 2) + '\n')
console.log(`frozen ${sourceTree.entries.length} files as ${sourceTree.hash}`)
