import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { resolve, join } from 'node:path'
import { EXPERIMENT, TURN_TWO_APPROVAL } from '../src/config.mjs'
import { createRuntime, taskCard, taskCriticalErrors, taskEditableFiles, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { GeminiAgent } from '../src/gemini-agent.mjs'
import { Telemetry, appendJsonLine } from '../src/telemetry.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { scoreRun } from '../evaluator-private/score-run.mjs'
import { pilotRunOrder } from './run-order.mjs'

const apiKey = await acquireKey()
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
const parity = JSON.parse(await readFile('artifacts/parity-validation.json', 'utf8'))
if (!parity.passed) throw new Error('offline parity validation did not pass')
await verifyFrozenInputs(preregistration)
if (parity.sourceTreeHash !== preregistration.sourceTree.hash) {
  throw new Error('parity validation was not executed against the frozen source tree')
}
verifyRunOrder(preregistration)

await mkdir('runs', { recursive: true })
const preflightTelemetry = new Telemetry('preflight')
const preflightAgent = new GeminiAgent({
  apiKey,
  taskId: 't1-provider-withdrawal',
  fixtureNumber: 1,
  telemetry: preflightTelemetry,
})
const modelMetadata = await preflightAgent.modelMetadata()
await writeFile('runs/model-metadata.json', JSON.stringify({
  requestedModel: EXPERIMENT.model,
  retrievedAt: new Date().toISOString(),
  metadata: modelMetadata,
}, null, 2) + '\n')
console.log(`model preflight passed for ${EXPERIMENT.model}`)

const order = pilotRunOrder()
for (const [index, item] of order.entries()) {
  const runId = `${item.seed.seedId}--${item.arm}`
  console.log(`[${index + 1}/${order.length}] starting ${runId}`)
  const result = await runSingle({ ...item, runId, apiKey, modelMetadata })
  await appendJsonLine('runs/results.jsonl', result)
  console.log(`[${index + 1}/${order.length}] ${runId}: ${result.validity} / primary=${result.score?.primaryPass ?? false}`)
}
console.log('12-run pilot execution completed')

async function runSingle({ seed, taskId, arm, runId, apiKey: secret, modelMetadata: metadata }) {
  const runRoot = resolve('runs', runId)
  const workspace = join(runRoot, 'workspace')
  await mkdir(runRoot, { recursive: false })
  const telemetry = new Telemetry(runId)
  const startedAt = new Date().toISOString()
  const started = performance.now()
  let runtime
  try {
    const files = taskWorkspaceFiles(taskId, seed)
    await materializeWorkspace(workspace, files)
    const initialTree = await hashTree(workspace)
    runtime = await createRuntime(taskId, seed, workspace)
    const card = taskCard(taskId, seed, runtime)
    const agent = new GeminiAgent({
      apiKey: secret,
      taskId,
      fixtureNumber: seed.number,
      telemetry,
    })
    const turnOneRegistry = createToolRegistry({
      arm,
      runtime,
      workspace,
      editableFiles: taskEditableFiles(taskId),
      telemetry,
      turn: 1,
    })
    const turnOne = await agent.runTurn({ turn: 1, message: card, registry: turnOneRegistry })
    const turnTwoRegistry = createToolRegistry({
      arm,
      runtime,
      workspace,
      editableFiles: taskEditableFiles(taskId),
      telemetry,
      turn: 2,
    })
    const turnTwo = await agent.runTurn({ turn: 2, message: TURN_TWO_APPROVAL, registry: turnTwoRegistry })
    const grade = await runtime.grade()
    const totals = telemetry.totals()
    const score = scoreRun({
      taskId, seed, runtime,
      turnOneText: turnOne.text,
      turnTwoText: turnTwo.text,
      grade,
      telemetryTotals: totals,
    })
    const finalTree = await hashTree(workspace)
    const filesChanged = changedFiles(initialTree.entries, finalTree.entries)
    const versions = [...new Set(agent.responses.map(response => response.modelVersion).filter(Boolean))]
    const result = {
      schemaVersion: 1,
      experimentId: EXPERIMENT.id,
      runId,
      taskId,
      seedId: seed.seedId,
      fixtureNumber: seed.number,
      arm,
      requestedModel: EXPERIMENT.model,
      reportedModelVersions: versions,
      modelMetadataName: metadata.name ?? null,
      thinkingLevel: EXPERIMENT.thinkingLevel,
      temperature: EXPERIMENT.temperature,
      modelSeed: EXPERIMENT.modelSeedBase + ['t1-provider-withdrawal', 't2-loading-status', 't3-failed-update'].indexOf(taskId) * 100 + seed.number,
      validity: versions.length === 1 ? 'valid' : 'invalid-model-version',
      startedAt,
      completedAt: new Date().toISOString(),
      durationMs: Math.round(performance.now() - started),
      initialWorkspaceHash: initialTree.hash,
      finalWorkspaceHash: finalTree.hash,
      filesChanged,
      taskCriticalErrorVocabulary: taskCriticalErrors(taskId),
      score,
      costUsd: calculateCost(totals.usage),
    }
    await writeRunArtifacts({
      runRoot, seed, card, arm,
      turnOne, turnTwo, telemetry, result,
      toolDeclarations: {
        turnOne: turnOneRegistry.declarations,
        turnTwo: turnTwoRegistry.declarations,
      },
    })
    return result
  } catch (error) {
    const message = sanitizeError(error, secret)
    telemetry.record('run_failed', { error: message })
    const result = {
      schemaVersion: 1,
      experimentId: EXPERIMENT.id,
      runId, taskId, seedId: seed.seedId, fixtureNumber: seed.number, arm,
      requestedModel: EXPERIMENT.model,
      validity: 'invalid-infrastructure',
      startedAt,
      completedAt: new Date().toISOString(),
      durationMs: Math.round(performance.now() - started),
      error: message,
      score: null,
      costUsd: calculateCost(telemetry.totals().usage),
    }
    await telemetry.write(join(runRoot, 'telemetry.jsonl'))
    await writeFile(join(runRoot, 'result.json'), JSON.stringify(result, null, 2) + '\n')
    return result
  } finally {
    if (runtime) await runtime.dispose().catch(() => {})
  }
}

async function writeRunArtifacts({ runRoot, seed, card, arm, turnOne, turnTwo, telemetry, result, toolDeclarations }) {
  await telemetry.write(join(runRoot, 'telemetry.jsonl'))
  await writeFile(join(runRoot, 'task.json'), JSON.stringify({ seed, arm, taskCard: card }, null, 2) + '\n')
  await writeFile(join(runRoot, 'tool-schema.json'), JSON.stringify(toolDeclarations, null, 2) + '\n')
  await writeFile(join(runRoot, 'turn-1.md'), turnOne.text.trimEnd() + '\n')
  await writeFile(join(runRoot, 'turn-2.md'), turnTwo.text.trimEnd() + '\n')
  await writeFile(join(runRoot, 'model-exchanges.json'), JSON.stringify({
    turnOne: turnOne.exchanges,
    turnTwo: turnTwo.exchanges,
  }, null, 2) + '\n')
  await writeFile(join(runRoot, 'result.json'), JSON.stringify(result, null, 2) + '\n')
}

function changedFiles(beforeEntries, afterEntries) {
  const before = new Map(beforeEntries)
  const after = new Map(afterEntries)
  return [...new Set([...before.keys(), ...after.keys()])]
    .filter(path => before.get(path) !== after.get(path))
    .sort()
}

function calculateCost(usage) {
  const input = usage.input * EXPERIMENT.pricingUsdPerMillion.input / 1_000_000
  const outputIncludingThinking = (usage.output + usage.thoughts)
    * EXPERIMENT.pricingUsdPerMillion.outputIncludingThinking / 1_000_000
  return Number((input + outputIncludingThinking).toFixed(6))
}

function verifyRunOrder(preregistration) {
  const actual = pilotRunOrder().map(({ seed, arm }) => ({ seedId: seed.seedId, arm }))
  if (hashJson(actual) !== hashJson(preregistration.runOrder)) {
    throw new Error('run order differs from preregistration')
  }
  if (preregistration.experiment.model !== EXPERIMENT.model || preregistration.experiment.fallback !== false) {
    throw new Error('live model configuration differs from preregistration')
  }
}

async function verifyFrozenInputs(preregistration) {
  const sourceTree = await hashTree('.', {
    exclude: (name, entry) => name === 'node_modules'
      || name.startsWith('node_modules/')
      || name === 'artifacts'
      || name.startsWith('artifacts/')
      || name === 'runs'
      || name.startsWith('runs/')
      || name === 'workspaces'
      || name.startsWith('workspaces/')
      || (entry.isFile() && name === 'package-lock.json'),
  })
  if (sourceTree.hash !== preregistration.sourceTree.hash) {
    throw new Error('source tree differs from preregistration freeze')
  }
  const lockHash = hashJson(JSON.parse(await readFile('package-lock.json', 'utf8')))
  if (lockHash !== preregistration.packageLockHash) {
    throw new Error('package lock differs from preregistration freeze')
  }
}

async function acquireKey() {
  if (process.argv.includes('--key-stdin')) {
    let value = ''
    for await (const chunk of process.stdin) {
      value += chunk
      if (value.includes('\n')) break
    }
    const key = value.split(/\r?\n/, 1)[0].trim()
    if (!key) throw new Error('empty Gemini API key on stdin')
    return key
  }
  const key = process.env.GEMINI_API_KEY
  if (!key) throw new Error('GEMINI_API_KEY is unset; pass --key-stdin or set the process environment')
  return key
}

function sanitizeError(error, secret) {
  const source = error instanceof Error ? `${error.name}: ${error.message}` : String(error)
  return source.split(secret).join('[REDACTED]')
}
