import { mkdtemp, mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { tmpdir } from 'node:os'
import { allSeeds } from './seed-catalog.mjs'
import { createRuntime, taskEditableFiles, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace, WorkspaceAccess } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { applyReferenceDelta } from '../evaluator-private/reference-deltas.mjs'

const validationRoot = resolve('workspaces')
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
await mkdir(validationRoot, { recursive: true })
const cases = []

for (const seed of allSeeds()) {
  const caseRoot = await mkdtemp(join(validationRoot, `${seed.seedId}-`))
  const nativeWorkspace = join(caseRoot, 'native')
  const relationalWorkspace = join(caseRoot, 'relational')
  const files = taskWorkspaceFiles(seed.taskId, seed)
  await Promise.all([
    materializeWorkspace(nativeWorkspace, files),
    materializeWorkspace(relationalWorkspace, files),
  ])
  const [nativeTree, relationalTree] = await Promise.all([
    hashTree(nativeWorkspace),
    hashTree(relationalWorkspace),
  ])
  assert(nativeTree.hash === relationalTree.hash, `${seed.seedId}: initial workspaces differ`)

  const runtime = await createRuntime(seed.taskId, seed, nativeWorkspace)
  try {
    const telemetry = new Telemetry(`validate:${seed.seedId}`)
    for (const turn of [1, 2]) {
      const nativeRegistry = createToolRegistry({
        arm: 'native', runtime, workspace: nativeWorkspace,
        editableFiles: taskEditableFiles(seed.taskId), telemetry, turn,
      })
      const relationalRegistry = createToolRegistry({
        arm: 'relational', runtime, workspace: nativeWorkspace,
        editableFiles: taskEditableFiles(seed.taskId), telemetry, turn,
      })
      validateToolDelta(seed.seedId, turn, nativeRegistry.declarations, relationalRegistry.declarations)
    }
    const semanticWitness = validateSemanticWitness(seed, runtime)
    await applyReferenceDelta(seed.taskId, seed, nativeWorkspace, runtime)
    const visible = seed.taskId === 't3-failed-update'
      ? { status: 'not-applicable' }
      : await new WorkspaceAccess(nativeWorkspace, {
          editableFiles: [], telemetry, turn: 2,
        }).runVisibleTests()
    assert(visible.status !== 'fail', `${seed.seedId}: reference delta fails visible tests`)
    const grade = await runtime.grade()
    assert(grade.pass, `${seed.seedId}: reference delta fails hidden runtime grade`)
    cases.push({
      seedId: seed.seedId,
      workspaceHash: nativeTree.hash,
      semanticWitness,
      visibleStatus: visible.status,
      referenceGradePass: grade.pass,
    })
    process.stdout.write(`validated ${seed.seedId}\n`)
  } finally {
    await runtime.dispose()
  }
}

const report = {
  schemaVersion: 1,
  generatedAt: new Date().toISOString(),
  passed: cases.length === allSeeds().length,
  caseCount: cases.length,
  sourceTreeHash: preregistration.sourceTree.hash,
  assertions: [
    'Native and Relational Agent-readable workspace trees are byte-identical per seed.',
    'All common tool declarations are byte-identical; Relational adds exactly one read-only software_semantic_query.',
    'Every frozen semantic query agrees with an independently read native witness for its task.',
    'The preregistered reference delta passes visible and hidden runtime checks for every main-study seed.',
  ],
  cases,
  digest: hashJson(cases),
}
await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/parity-validation.json', JSON.stringify(report, null, 2) + '\n')
console.log(`parity/reference closure passed for ${cases.length} seeds; digest ${report.digest}`)

function validateToolDelta(seedId, turn, nativeDeclarations, relationalDeclarations) {
  const relationalOnly = relationalDeclarations.filter(candidate => (
    !nativeDeclarations.some(native => native.name === candidate.name)
  ))
  assert(relationalOnly.length === 1, `${seedId} turn ${turn}: expected one relational-only tool`)
  assert(relationalOnly[0].name === 'software_semantic_query', `${seedId} turn ${turn}: wrong relational-only tool`)
  const common = relationalDeclarations.filter(item => item.name !== 'software_semantic_query')
  assert(hashJson(common) === hashJson(nativeDeclarations), `${seedId} turn ${turn}: common tool schema mismatch`)
}

function validateSemanticWitness(seed, runtime) {
  if (seed.taskId === 't1-provider-withdrawal') {
    const result = runtime.semanticQuery({
      query: 'impact_remove',
      subject: {
        snapshotId: runtime.publicState.beforeSnapshotId,
        serviceImplId: runtime.publicState.serviceImplAlias,
      },
    })
    assert(result.directConsumers.includes(seed.directConsumerName), `${seed.seedId}: direct consumer absent`)
    assert(result.transitiveConsumers.includes(seed.transitiveConsumerName), `${seed.seedId}: transitive consumer absent`)
    assert(result.coverage.external_effect_truth === 'unavailable', `${seed.seedId}: external coverage not unavailable`)
    return { direct: result.directConsumers, transitive: result.transitiveConsumers, external: result.coverage.external_effect_truth }
  }
  if (seed.taskId === 't2-loading-status') {
    const result = runtime.semanticQuery({
      query: 'explain_binding_divergence',
      subject: {
        snapshotId: runtime.publicState.checkpointId,
        fiberId: runtime.publicState.consumerId,
        serviceKey: seed.serviceKey,
      },
    })
    assert(result.consumer.state === 'loading', `${seed.seedId}: consumer not loading`)
    assert(result.committed.providerName === seed.providerV1, `${seed.seedId}: committed provider mismatch`)
    assert(result.target.providerName === seed.providerV2, `${seed.seedId}: target provider mismatch`)
    return { state: result.consumer.state, committed: result.committed.providerName, target: result.target.providerName }
  }
  const result = runtime.semanticQuery({
    query: 'explain_dynamic_package_state',
    subject: { pluginId: runtime.publicState.pluginId, snapshotId: runtime.publicState.failedSnapshotId },
  })
  assert(result.lastSuccessfulPackageId === runtime.publicState.v1PackageId, `${seed.seedId}: last-successful mismatch`)
  assert(result.failedOrInProgressTargetPackageId === runtime.publicState.v2PackageId, `${seed.seedId}: failed target mismatch`)
  assert(result.activeRun === null, `${seed.seedId}: active run should be strongly absent`)
  assert(result.recovery?.mode === 'run', `${seed.seedId}: recovery mode mismatch`)
  return { lastSuccessful: result.lastSuccessfulPackageId, failedTarget: result.failedOrInProgressTargetPackageId, activeRun: null, recovery: result.recovery }
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}
