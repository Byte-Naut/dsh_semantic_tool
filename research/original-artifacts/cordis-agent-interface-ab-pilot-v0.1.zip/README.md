# Cordis Agent Interface Benchmark

This package implements the preregistered paired comparison between a Native Cordis inspection surface and the same surface augmented by one read-only relational semantic-query tool.

The pilot uses two paired seeds for each of three tasks, for twelve model runs in total. Every run uses `gemini-3.8-flash`, medium thinking, a fresh conversation, a fresh workspace, a fresh runtime, and no model fallback.

The Agent-readable workspace never contains the theory papers, semantic-mirror rationale, reference delta, hidden oracle, grader, prior trajectories, or arm label. The Relational arm differs only by the additional read-only tool declaration.

## Commands

```sh
npm install
npm run freeze
npm run generate
npm test
npm run validate
node runner/run-pilot.mjs --key-stdin
npm run analyze
```

For `--key-stdin`, provide exactly one key line on standard input. The key remains process-local and is never included in an artifact, command line, or event record. `GEMINI_API_KEY` remains supported for unattended execution.
