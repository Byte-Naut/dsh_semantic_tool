import { writeFile } from 'node:fs/promises'
import { safePath } from '../src/workspace.mjs'

export async function applyReferenceDelta(taskId, seed, workspace, runtime) {
  if (taskId === 't1-provider-withdrawal') {
    await writeFile(safePath(workspace, 'src/callback-owner.mjs'), `/** Installs one callback as a Cordis-owned effect. */
export function installCallback(ctx, scheduler, label, sink, payload) {
  let handle
  ctx.effect(() => {
    handle = scheduler.setInterval(() => sink.push({ label, payload }), label)
    return () => scheduler.clearInterval(handle)
  }, label)
  return { handle }
}
`)
    return
  }
  if (taskId === 't2-loading-status') {
    await writeFile(safePath(workspace, 'src/status-adapter.mjs'), `function providerId(implementation) {
  return implementation?.fiber?.name ?? null
}

/** Keeps current-session truth separate from the next reload target. */
export function buildStatus(consumerFiber, serviceKey) {
  const committed = consumerFiber.store?.[serviceKey]
  const target = consumerFiber._store?.[serviceKey]
  const servingProviderId = providerId(committed)
  const targetProviderId = providerId(target)
  return {
    servingProviderId,
    targetProviderId,
    transitioning: servingProviderId == null || targetProviderId == null
      ? null
      : servingProviderId !== targetProviderId,
  }
}
`)
    return
  }
  if (taskId === 't3-failed-update') {
    const { pluginId, v1PackageId, v2PackageId } = runtime.publicState
    await runtime.inspectPackage({ pluginId, packageId: v2PackageId })
    const restored = await runtime.runPackage({ pluginId, packageId: v1PackageId, mode: 'run' })
    if (!restored.ok) throw new Error('reference restore failed')
    const defined = await runtime.definePackage({
      pluginId,
      name: `${seed.pluginPrefix} repaired package`,
      purpose: 'publish the repaired endpoint value',
      hostCode: `return { apply(ctx) { ctx.provide(${JSON.stringify(seed.serviceKey)}, Object.freeze({ version: ${JSON.stringify(seed.repairedValue)} })) } }`,
    })
    const updated = await runtime.runPackage({ pluginId, packageId: defined.packageId, mode: 'update' })
    if (!updated.ok) throw new Error('reference update failed')
    return
  }
  throw new Error(`unknown task: ${taskId}`)
}
