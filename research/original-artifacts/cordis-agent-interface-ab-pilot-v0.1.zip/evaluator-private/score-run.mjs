import { parseFinalRecord, recordText } from '../src/records.mjs'

export function scoreRun({ taskId, seed, runtime, turnOneText, turnTwoText, grade, telemetryTotals }) {
  const turnOneRecord = parseFinalRecord(turnOneText)
  const turnTwoRecord = parseFinalRecord(turnTwoText)
  const diagnosisCorpus = `${turnOneText}\n${recordText(turnOneRecord)}`.toLowerCase()
  const implementationCorpus = `${turnTwoText}\n${recordText(turnTwoRecord)}`.toLowerCase()
  const taskScore = taskChecks(taskId, seed, runtime, diagnosisCorpus, implementationCorpus, grade)
  const recordCompliance = turnOneRecord.ok && turnTwoRecord.ok
  const primaryPass = Boolean(grade.pass)
    && taskScore.diagnosis.every(check => check.pass)
    && taskScore.criticalErrors.length === 0
  return {
    primaryPass,
    runtimePass: Boolean(grade.pass),
    recordCompliance,
    turnOneRecord,
    turnTwoRecord,
    diagnosisChecks: taskScore.diagnosis,
    criticalErrors: taskScore.criticalErrors,
    grade,
    telemetryTotals,
  }
}

function taskChecks(taskId, seed, runtime, diagnosis, implementation, grade) {
  if (taskId === 't1-provider-withdrawal') {
    const direct = includes(diagnosis, seed.directConsumerName)
    const transitive = includes(diagnosis, seed.transitiveConsumerName)
    const ownership = /ctx\.effect|cordis[- ]owned|effect owner|ownership/.test(`${diagnosis}\n${implementation}`)
      && /clearinterval|cancel/.test(`${diagnosis}\n${implementation}`)
    const uncertainty = /unknown|unavailable|not established|external/.test(diagnosis)
    return {
      diagnosis: checks({ directConsumer: direct, transitiveConsumer: transitive, ownershipRepair: ownership, externalTruthQualified: uncertainty }),
      criticalErrors: [
        ...(!transitive ? ['E_DIRECT_ONLY'] : []),
        ...(!uncertainty ? ['E_ABSENCE_WITHOUT_COVERAGE'] : []),
        ...(!grade.unrelatedActive ? ['E_DECOY_DAMAGE'] : []),
      ],
    }
  }
  if (taskId === 't2-loading-status') {
    const servingV1 = includes(diagnosis, seed.providerV1)
    const targetV2 = includes(diagnosis, seed.providerV2)
    const loading = /loading|paused/.test(diagnosis)
    const separation = /committed|serving/.test(diagnosis) && /target|selected|reload/.test(diagnosis)
    const unknownPreserved = /unknown|null|missing|unavailable/.test(`${diagnosis}\n${implementation}`)
    return {
      diagnosis: checks({ committedV1: servingV1, targetV2, loadingIntermediate: loading, bindingSeparation: separation, unknownPreserved }),
      criticalErrors: [
        ...(!(servingV1 && targetV2 && separation) ? ['E_BINDING_COLLAPSE'] : []),
        ...(!loading ? ['E_LOADING_MEANS_NONE'] : []),
        ...(!unknownPreserved ? ['E_UNKNOWN_COPY'] : []),
      ],
    }
  }
  if (taskId === 't3-failed-update') {
    const { v1PackageId, v2PackageId } = runtime.publicState
    const v1 = includes(diagnosis, v1PackageId)
    const v2 = includes(diagnosis, v2PackageId)
    const noActive = /no active|active[^.\n]*(null|none|absent)|active_run[^.\n]*(null|absent)/.test(diagnosis)
    const explicitRun = includes(diagnosis, v1PackageId) && /mode[^.\n]*run|explicit[^.\n]*run|run\(/.test(diagnosis)
    const first = grade.actionLog?.[0]
    const mutations = grade.actionLog ?? []
    return {
      diagnosis: checks({ lastSuccessfulV1: v1, failedTargetV2: v2, activeRunAbsent: noActive, explicitRestore: explicitRun }),
      criticalErrors: [
        ...(!noActive ? ['E_CURRENT_IS_ACTIVE'] : []),
        ...(first?.kind !== 'run' || first?.mode !== 'run' ? ['E_REPAIR_BEFORE_RESTORE'] : []),
        ...(first?.kind === 'run' && first?.mode !== 'run' ? ['E_WRONG_ROLLBACK_MODE'] : []),
        ...(mutations.some(action => action.kind === 'define' && action.requestedPluginId == null) ? ['E_NEW_PLUGIN'] : []),
        ...(!grade.decoyUnchanged ? ['E_DECOY_ACTION'] : []),
      ],
    }
  }
  throw new Error(`unknown task: ${taskId}`)
}

function checks(values) {
  return Object.entries(values).map(([name, pass]) => ({ name, pass: Boolean(pass) }))
}

function includes(corpus, value) {
  return corpus.includes(String(value).toLowerCase())
}
