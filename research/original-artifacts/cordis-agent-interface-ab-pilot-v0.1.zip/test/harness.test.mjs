import assert from 'node:assert/strict'
import test from 'node:test'
import { pilotSeeds } from '../runner/seed-catalog.mjs'
import { pilotRunOrder } from '../runner/run-order.mjs'
import { ARMS } from '../src/config.mjs'
import { parseFinalRecord } from '../src/records.mjs'

test('pilot has exactly two paired seeds per task and twelve fixed runs', () => {
  assert.equal(pilotSeeds().length, 6)
  const order = pilotRunOrder()
  assert.equal(order.length, 12)
  const grouped = Map.groupBy(order, row => row.seed.seedId)
  assert.equal(grouped.size, 6)
  for (const rows of grouped.values()) {
    assert.deepEqual(rows.map(row => row.arm).sort(), [...ARMS].sort())
  }
})

test('record parser requires a terminal fenced JSON object', () => {
  assert.deepEqual(parseFinalRecord('answer\n```json\n{"status":"PASS"}\n```').record, { status: 'PASS' })
  assert.equal(parseFinalRecord('{"status":"PASS"}').ok, false)
  assert.equal(parseFinalRecord('```json\nnot-json\n```').ok, false)
})
