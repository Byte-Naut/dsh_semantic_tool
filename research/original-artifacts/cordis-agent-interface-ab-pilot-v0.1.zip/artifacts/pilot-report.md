# Gemini 3.8 Flash Agent-interface A/B pilot

## Status

- Runs: 12; valid: 12; invalid: 0
- Reported model version(s): gemini-3.8-flash
- Interpretation: instrumentation/floor/ceiling pilot; descriptive only, not a confirmatory efficacy estimate

## Arm summaries

| Metric | Native | Relational |
|---|---:|---:|
| Valid runs | 6 | 6 |
| Primary pass | 4 | 5 |
| Hidden runtime pass | 6 | 6 |
| Record compliant | 1 | 3 |
| Critical semantic errors | 0 | 0 |
| Mean tool calls | 21.3333 | 20.3333 |
| Mean native observation calls | 12 | 10 |
| Mean relational observation calls | 0 | 1.5 |
| Mean gross input tokens | 152688.1667 | 135701 |
| Mean output + thinking tokens | 10555.5 | 10489.3333 |
| Mean duration (ms) | 75090.8333 | 77722.8333 |
| Total estimated cost (USD) | 0.9246 | 0.8467 |

## Paired descriptive comparison

{
  "completePairs": 6,
  "relationalBetterPrimary": 1,
  "tiesPrimary": 5,
  "nativeBetterPrimary": 0,
  "meanPrimaryPassDelta": 0.1667,
  "meanToolCallDelta": -1,
  "meanGrossInputTokenDelta": -16987.1667,
  "meanCriticalErrorDelta": 0
}

This 12-run pilot is not used as a confirmatory significance test. It checks execution validity, outcome variance, rubric ceiling/floor, and the plausibility of the preregistered 72-run study.

## Cost

- Pilot observed: $1.7713
- 72 runs at observed mean: $10.6276
- 72 runs at observed maximum per-run cost: $14.0539

The estimate uses $0.75/M gross prompt tokens and $3.75/M candidate-plus-thinking tokens.

## Run ledger

| Run | Validity | Primary | Runtime | Critical errors | Tool calls | Input tokens | Output + thinking | Cost USD |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| t1-provider-withdrawal-s01--native | valid | 1 | 1 | 0 | 25 | 205278 | 10996 | 0.195193 |
| t1-provider-withdrawal-s01--relational | valid | 1 | 1 | 0 | 24 | 190027 | 9354 | 0.177598 |
| t1-provider-withdrawal-s02--native | valid | 1 | 1 | 0 | 23 | 180654 | 10305 | 0.174134 |
| t1-provider-withdrawal-s02--relational | valid | 1 | 1 | 0 | 27 | 177369 | 12104 | 0.178417 |
| t2-loading-status-s01--native | valid | 1 | 1 | 0 | 19 | 115027 | 10219 | 0.124592 |
| t2-loading-status-s01--relational | valid | 1 | 1 | 0 | 13 | 75077 | 13529 | 0.107041 |
| t2-loading-status-s02--native | valid | 1 | 1 | 0 | 14 | 68941 | 10345 | 0.0905 |
| t2-loading-status-s02--relational | valid | 1 | 1 | 0 | 17 | 123205 | 13837 | 0.144292 |
| t3-failed-update-s01--native | valid | 0 | 1 | 0 | 23 | 198071 | 9678 | 0.184846 |
| t3-failed-update-s01--relational | valid | 0 | 1 | 0 | 19 | 131206 | 6236 | 0.12179 |
| t3-failed-update-s02--native | valid | 0 | 1 | 0 | 24 | 148158 | 11790 | 0.155331 |
| t3-failed-update-s02--relational | valid | 1 | 1 | 0 | 22 | 117322 | 7876 | 0.117527 |
