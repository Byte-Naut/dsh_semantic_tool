import assert from 'node:assert/strict'
import test from 'node:test'
import { calibrationSeeds } from '../runner/seed-catalog.mjs'
import { calibrationRunOrder } from '../runner/run-order.mjs'
import { ARMS } from '../src/config.mjs'
import { parseFinalRecord } from '../src/records.mjs'

test('calibration has two paired seeds at each level and twelve frozen run slots', () => {
  assert.equal(calibrationSeeds().length, 6)
  const order = calibrationRunOrder()
  assert.equal(order.length, 12)
  const grouped = Map.groupBy(order, row => row.seed.seedId)
  assert.equal(grouped.size, 6)
  for (const rows of grouped.values()) assert.deepEqual(rows.map(row => row.arm).sort(), [...ARMS].sort())
})

test('record parser selects the last JSON fence and requires it to be terminal', () => {
  const response = `Evidence:\n\`\`\`js\nconst x = 1\n\`\`\`\nDraft:\n\`\`\`json\n{"draft":true}\n\`\`\`\nFinal:\n\`\`\`json\n{"status":"PASS"}\n\`\`\``
  assert.deepEqual(parseFinalRecord(response).record, { status: 'PASS' })
  assert.equal(parseFinalRecord(`${response}\ntrailing prose`).ok, false)
  assert.equal(parseFinalRecord('{"status":"PASS"}').ok, false)
  assert.equal(parseFinalRecord('```json\nnot-json\n```').ok, false)
})

test('difficulty ladder adds executable semantic dimensions without adding source noise', () => {
  const levels = calibrationSeeds().filter(seed => seed.number === 1)
  assert.deepEqual(levels.map(seed => seed.level), [1, 2, 3])
  assert.equal(levels[0].serviceKey, levels[1].serviceKey)
  assert.equal(levels[1].serviceKey, levels[2].serviceKey)
  assert.equal('auxiliaryServiceKey' in levels[0], false)
  assert.equal('auxiliaryServiceKey' in levels[2], true)
})
