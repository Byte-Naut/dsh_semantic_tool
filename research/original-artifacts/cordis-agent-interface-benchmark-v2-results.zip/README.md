# Cordis Agent-interface benchmark v2

This package calibrates a paired Native-versus-Relational agent experiment on one executable incident family at three semantic-complexity levels.

- L1: failed dynamic update plus direct service consumer.
- L2: L1 plus transitive service propagation and external effect ownership.
- L3: L2 plus a concurrent provider replacement paused in LOADING, committed/target divergence, and a constrained counterfactual recovery choice.

The arms use the same model, prompt, workspace, runtime, budgets, and native capabilities. The Relational arm adds one read-only `software_semantic_query`. Agent-visible inputs exclude theory, experiment motivation, reference actions, private grading, and trajectories.

The 12-run calibration is descriptive. It measures executable correctness and a continuous semantic-reconstruction burden; it is not a confirmatory efficacy study.

## Reproduce

```sh
npm run generate
npm test
npm run freeze
npm run validate
npm run calibrate -- --key-stdin
npm run analyze
```

The API key is accepted from hidden standard input and is never persisted.
