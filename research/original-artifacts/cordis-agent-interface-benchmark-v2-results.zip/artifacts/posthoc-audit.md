# v2 难度校准：post-hoc 审计

> 本文是敏感性与轨迹审计，不替换冻结的 preregistration、raw result 或 primary outcome。

## 可支持结论

本轮定位到了一个边界，但没有得到可解释的 A/B correctness 估计：12 个 slot 中 3 个完成，9 个在 Turn 1 用尽工具预算。Native 0/6 完成，Relational 3/6 完成；由于没有完成的 Native pair，不能把它表述为 runtime correctness 或 failure-boundary shift 的证明。

组合 query 的局部信号是明确的：在双方都达到 evidence closure 的 5 个 pair 中，Relational 每次都更早，平均提前 2.2 次调用。但两臂仍都触及全部 8 个 native 域；Relational 之后继续重建原生状态，因此没有形成总轨迹压缩。

| Turn-1 指标 | Native | Relational |
|---|---:|---:|
| Slots / completed | 6 / 0 | 6 / 3 |
| Mean tool calls | 22.8333 | 23.5 |
| Mean observation calls | 17.6667 | 17 |
| Mean native observations | 17.6667 | 15.1667 |
| Mean native domains | 8 | 8 |
| Mean calls to sufficient evidence | 15 | 13.3333 |
| Evidence closure reached | 5/6 | 6/6 |
| Mean calls after sufficient evidence | 8 | 10.1667 |
| Mean gross input tokens | 89427.6667 | 110695.5 |

## 冻结分数与敏感性

- 冻结 primary：0/3 completed runs。
- 两个 L1 Relational run 的 semantic closure 均为 1，真实 runtime 均通过；primary=false 仅因 scorer 拒绝 query 返回的语义动作名。别名不敏感审计下为 2/3 completed runs。
- 这项敏感性分析是 post-hoc，不可升级为预注册 primary。

## 一个真实语义失败

完成的 Hard Relational run 正确完成 package recovery、传递 consumer 恢复、旧 handle 精确退役、新 callback ownership、双 binding 识别与安全收敛；但当 committed observation 缺失而 target 存在时，status adapter 返回 `transitioning=true`，正确值应为 `null/UNKNOWN`。因此该 run 的 hidden runtime fail 是有效反例，不是 rubric 假阴性。

## 三个假设

- H1 correctness：not estimable: there is no completed Native pair; two completed Relational easy runs pass runtime, and one hard run has a genuine UNKNOWN-propagation failure
- H2 reconstruction burden：mixed: Relational reached sufficient evidence earlier in all five comparable pairs and used 2.5 fewer native observations on average, but touched the same eight domains, used slightly more total Turn-1 calls, and used more input tokens
- H3 capability boundary：not demonstrated: the study found a real partial-observability failure but cannot establish a shifted reasoning boundary from censored unpaired outcomes

## Harness 诊断

- Nine budget-exhausted agent trajectories were mislabeled invalid-infrastructure by the frozen runner.
- Frozen action scoring accepted tool function names but rejected semantically identical action names returned by the relational query.
- external_effect_truth conflated mirror coverage (unavailable) with a later native scheduler observation (known); the hard run described both correctly in prose.
- The hard record used minimumSafeAction rather than the frozen minimum_safe_action field; this is structural noncompliance, not wrong counterfactual content.
- Budget-exhausted runs did not persist partial model exchanges, limiting auditability to telemetry.
- Both arms touched all eight native observation domains; the Relational treatment behaved as an optional query addition, not an interface-first policy.
- The easy-to-medium semantic step was too large for a 24-call Turn-1 budget: all medium runs were censored before action.

## 下一次校准门控

- Use an interface-first Experimental arm: query for covered domains, native tools only for declared UNKNOWN/oracle domains and Package source.
- Raise the common Turn-1 tool budget enough to observe solutions rather than stopping behavior, while keeping the same gross-token cap.
- Insert an intermediate level that adds transitive impact or ownership, not both simultaneously.
- Freeze enumerated semantic action IDs and map them explicitly to tool calls; do not score action wording.
- Split external coverage from external native observation into two record fields.
- Persist partial model exchanges on budget exhaustion and classify it as a model/agent outcome, not infrastructure failure.
- Run a four-slot harness calibration before another 12-run study.

本轮实际 API 费用：$2.2472。若机械投影到 72 runs：按全部 slot 均值为 $13.483，按完成 run 均值为 $33.6219，按本轮最大单次为 $48.4408；由于本轮大量提前截断，这三个数只能作为预算区间，不能作为精确预期。
