# Agent-facing runtime truth layer：v2 难度校准报告

## 实验状态

- 假设：semantic normalization reduces reconstruction burden and shifts the failure boundary of strong software agents
- 设计：easy / medium / hard 各 2 个配对 seed，共 12 runs；有效 3，无效 9
- 模型版本：gemini-3.8-flash
- 推断边界：preregistered 12-run paired difficulty calibration; descriptive, not confirmatory
- failure-boundary 信号：non-ceiling variance observed without a relational correctness advantage

## 总体双臂

| 指标 | Native | Relational |
|---|---:|---:|
| Primary pass | 0/0 | 0/3 |
| Hidden runtime pass | 0/0 | 2/3 |
| Perfect semantic closure | 0/0 | 2/3 |
| Mean semantic closure | 0 | 0.9167 |
| Mean tool calls | 0 | 35 |
| Mean observation calls | 0 | 22.6667 |
| Mean native observation calls | 0 | 21 |
| Mean native domains touched | 0 | 8 |
| Mean repeat observations | 0 | 5 |
| Mean gross input tokens | 0 | 477173.3333 |
| Mean tool-result bytes | 0 | 48533.6667 |
| Total estimated cost (USD) | 0 | 1.4009 |

## 难度边界

| Level | Native primary | Relational primary | Native closure | Relational closure | Δ input tokens R−N | Δ tool calls R−N |
|---|---:|---:|---:|---:|---:|---:|
| easy | 0/0 | 0/2 | 0 | 1 | 0 | 0 |
| medium | 0/0 | 0/0 | 0 | 0 | 0 | 0 |
| hard | 0/0 | 0/1 | 0 | 0.75 | 0 | 0 |

## 配对重建负担

- Gross input token：平均 R−N = 0（null%）
- Tool calls：平均 R−N = 0；Relational 更少 0/0 pairs
- Native observations：平均 R−N = 0
- Native domains：平均 R−N = 0
- Tool-result bytes：平均 R−N = 0
- 成本：平均相对变化 null%

这些是冻结后的描述性校准结果，不是显著性检验；n=2 pairs/level 不支持一般化能力结论。

## 费用

- 本轮实际：$2.2472
- 72 runs 按本轮均值：$33.6219
- 72 runs 按本轮最大单次：$48.4408

## Run ledger

| Run | Valid | Primary | Runtime | Closure | Tools | Native obs | Input | Cost |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| l1-cross-layer-recovery-s01--native | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.102153 |
| l1-cross-layer-recovery-s01--relational | valid | 0 | 1 | 1 | 33 | 21 | 381023 | 0.38383 |
| l1-cross-layer-recovery-s02--native | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.069721 |
| l1-cross-layer-recovery-s02--relational | valid | 0 | 1 | 1 | 35 | 22 | 341835 | 0.344295 |
| l2-transitive-ownership-s01--native | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.099962 |
| l2-transitive-ownership-s01--relational | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.098947 |
| l2-transitive-ownership-s02--native | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.083876 |
| l2-transitive-ownership-s02--relational | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.121892 |
| l3-concurrent-boundary-s01--native | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.070097 |
| l3-concurrent-boundary-s01--relational | valid | 0 | 0 | 0.75 | 37 | 20 | 708662 | 0.672789 |
| l3-concurrent-boundary-s02--native | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.102886 |
| l3-concurrent-boundary-s02--relational | invalid-infrastructure | 0 | 0 | 0 |  |  |  | 0.096716 |
