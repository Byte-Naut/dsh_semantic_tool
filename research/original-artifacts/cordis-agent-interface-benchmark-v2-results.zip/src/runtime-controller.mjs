import * as l1 from '../tasks/l1-cross-layer-recovery/spec.mjs'
import * as l2 from '../tasks/l2-transitive-ownership/spec.mjs'
import * as l3 from '../tasks/l3-concurrent-boundary/spec.mjs'
import { createCompositeRuntime } from '../tasks/composite-fixture.mjs'

const TASKS = Object.freeze({
  'l1-cross-layer-recovery': { level: 1, spec: l1 },
  'l2-transitive-ownership': { level: 2, spec: l2 },
  'l3-concurrent-boundary': { level: 3, spec: l3 },
})

export async function createRuntime(taskId, seed, workspace) {
  const task = resolveTask(taskId)
  return createCompositeRuntime(seed, workspace, task.level)
}

export function taskCard(taskId, seed, runtime) {
  return resolveTask(taskId).spec.publicTaskCard(seed, runtime.publicState)
}

export function taskWorkspaceFiles(taskId, seed) {
  return resolveTask(taskId).spec.workspaceFiles(seed)
}

export function taskEditableFiles(taskId) {
  return resolveTask(taskId).spec.editableFiles
}

export function taskCriticalErrors(taskId) {
  return resolveTask(taskId).spec.criticalErrors
}

function resolveTask(taskId) {
  const task = TASKS[taskId]
  if (!task) throw new Error(`unknown task: ${taskId}`)
  return task
}
