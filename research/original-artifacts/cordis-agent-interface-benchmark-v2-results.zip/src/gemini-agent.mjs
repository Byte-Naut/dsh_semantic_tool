import { GoogleGenAI } from '@google/genai'
import { EXPERIMENT, modelSeed } from './config.mjs'
import { commonSystemPrompt } from './common-prompt.mjs'

export class GeminiAgent {
  constructor({ apiKey, taskId, fixtureNumber, telemetry }) {
    if (!apiKey) throw new Error('Gemini API key is required')
    this.telemetry = telemetry
    this.taskId = taskId
    this.fixtureNumber = fixtureNumber
    this.ai = new GoogleGenAI({ apiKey })
    this.chat = this.ai.chats.create({ model: EXPERIMENT.model })
    this.responses = []
  }

  async modelMetadata() {
    const model = await this.ai.models.get({
      model: EXPERIMENT.model,
      config: { httpOptions: requestHttpOptions() },
    })
    return jsonSafe(model)
  }

  async runTurn({ turn, message, registry }) {
    let nextMessage = message
    let requestCount = 0
    let toolCallCount = 0
    const exchanges = []

    while (requestCount < EXPERIMENT.maxRequestsPerTurn) {
      requestCount += 1
      this.telemetry.record('model_request_started', {
        turn,
        request: requestCount,
        messageKind: typeof nextMessage === 'string' ? 'user_text' : 'function_responses',
      })
      const started = performance.now()
      const response = await this.chat.sendMessage({
        message: nextMessage,
        config: requestConfig(this.taskId, this.fixtureNumber, registry.declarations),
      })
      const durationMs = Math.round(performance.now() - started)
      const usage = usageRecord(response.usageMetadata)
      this.telemetry.record('model_usage', {
        turn,
        request: requestCount,
        durationMs,
        modelVersion: response.modelVersion ?? null,
        responseId: response.responseId ?? null,
        finishReason: response.candidates?.[0]?.finishReason ?? null,
        ...usage,
      })
      enforceRunTokenCaps(this.telemetry)

      const functionCalls = response.functionCalls ?? []
      const text = functionCalls.length ? candidateText(response) : (response.text ?? '')
      const exchange = {
        turn,
        request: requestCount,
        responseId: response.responseId ?? null,
        modelVersion: response.modelVersion ?? null,
        finishReason: response.candidates?.[0]?.finishReason ?? null,
        usage,
        text,
        functionCalls: functionCalls.map(call => ({ id: call.id ?? null, name: call.name ?? null, args: call.args ?? {} })),
      }
      exchanges.push(exchange)
      this.responses.push(exchange)

      if (!functionCalls.length) {
        this.telemetry.record('turn_completed', { turn, requestCount, toolCallCount, textBytes: Buffer.byteLength(text) })
        return { text, exchanges, requestCount, toolCallCount }
      }

      if (toolCallCount + functionCalls.length > EXPERIMENT.maxToolCallsPerTurn) {
        throw new Error(`turn ${turn} exceeded tool-call budget ${EXPERIMENT.maxToolCallsPerTurn}`)
      }
      const responseParts = []
      for (const call of functionCalls) {
        toolCallCount += 1
        const name = call.name ?? ''
        const output = await registry.call(name, call.args ?? {})
        responseParts.push({
          functionResponse: {
            ...(call.id ? { id: call.id } : {}),
            name,
            response: output && typeof output === 'object'
              ? { output: jsonSafe(output) }
              : { output: output ?? null },
          },
        })
      }
      nextMessage = responseParts
    }
    throw new Error(`turn ${turn} exceeded request budget ${EXPERIMENT.maxRequestsPerTurn}`)
  }
}

function requestConfig(taskId, fixtureNumber, declarations) {
  return {
    systemInstruction: commonSystemPrompt(),
    temperature: EXPERIMENT.temperature,
    candidateCount: EXPERIMENT.candidateCount,
    maxOutputTokens: EXPERIMENT.maxOutputTokensPerRequest,
    seed: modelSeed(taskId, fixtureNumber),
    thinkingConfig: {
      thinkingLevel: EXPERIMENT.thinkingLevel,
      includeThoughts: false,
    },
    tools: [{ functionDeclarations: declarations }],
    toolConfig: { functionCallingConfig: { mode: 'AUTO' } },
    httpOptions: requestHttpOptions(),
  }
}

function requestHttpOptions() {
  return {
    timeout: EXPERIMENT.requestTimeoutMs,
    retryOptions: { attempts: EXPERIMENT.httpAttempts },
  }
}

function usageRecord(usage = {}) {
  return {
    inputTokens: usage.promptTokenCount ?? 0,
    cachedInputTokens: usage.cachedContentTokenCount ?? 0,
    outputTokens: usage.candidatesTokenCount ?? 0,
    thoughtTokens: usage.thoughtsTokenCount ?? 0,
    toolUsePromptTokens: usage.toolUsePromptTokenCount ?? 0,
    totalTokens: usage.totalTokenCount ?? 0,
  }
}

function enforceRunTokenCaps(telemetry) {
  const { usage } = telemetry.totals()
  if (usage.input > EXPERIMENT.maxGrossInputTokensPerRun) {
    throw new Error(`run exceeded gross input-token cap ${EXPERIMENT.maxGrossInputTokensPerRun}`)
  }
  if (usage.output + usage.thoughts > EXPERIMENT.maxGrossOutputTokensPerRun) {
    throw new Error(`run exceeded gross output-token cap ${EXPERIMENT.maxGrossOutputTokensPerRun}`)
  }
}

function jsonSafe(value) {
  return JSON.parse(JSON.stringify(value))
}

function candidateText(response) {
  return (response.candidates?.[0]?.content?.parts ?? [])
    .filter(part => typeof part.text === 'string')
    .map(part => part.text)
    .join('')
}
