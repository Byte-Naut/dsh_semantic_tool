import { hashJson } from './hash.mjs'
import { WorkspaceAccess } from './workspace.mjs'

const OBJECT = 'object'

export function createToolRegistry({ arm, runtime, workspace, editableFiles, telemetry, turn }) {
  const access = new WorkspaceAccess(workspace, { editableFiles, telemetry, turn })
  const tools = []
  const add = (name, description, parametersJsonSchema, category, domain, handler) => {
    tools.push({
      declaration: { name, description, ...(parametersJsonSchema ? { parametersJsonSchema } : {}) },
      category,
      domain,
      handler,
    })
  }

  add('list_files', 'List files in the isolated Agent-readable workspace.', null, 'READ_SOURCE', 'workspace', () => access.listFiles())
  add('read_file', 'Read one UTF-8 file from the isolated Agent-readable workspace.', objectSchema({
    path: { type: 'string' },
  }, ['path']), 'READ_SOURCE', 'workspace', ({ path }) => access.readFile(path))
  add('run_visible_tests', 'Run fixture-owned visible Node tests and return their raw result.', null, 'RUN_CHECK', 'workspace', () => access.runVisibleTests())
  add('list_checkpoints', 'List immutable runtime checkpoints exposed for this incident.', null, 'OBSERVE_NATIVE', 'timeline', () => runtime.checkpoints())
  add('native_dynamic_inventory', 'Read raw session-owned Plugin, immutable Package, latest-attempt, and active-Run fields.', null, 'OBSERVE_NATIVE', 'dynamic_package', () => runtime.dynamicInventory())
  add('native_inspect_package', 'Read one exact immutable dynamic Package including stored source.', objectSchema({
    pluginId: { type: 'string' },
    packageId: { type: 'string' },
  }, ['pluginId', 'packageId']), 'OBSERVE_NATIVE', 'package_source', args => runtime.inspectPackage(args))
  add('native_list_services', 'List raw service implementations, providers, versions, and visibility at a checkpoint.', checkpointSchema(), 'OBSERVE_NATIVE', 'services', ({ checkpointId }) => runtime.nativeSnapshot(checkpointId).services)
  add('native_list_fibers', 'List raw Cordis fiber identity, state, parent, and declared injection fields without joining dependencies.', checkpointSchema(), 'OBSERVE_NATIVE', 'fibers', ({ checkpointId }) => runtime.nativeSnapshot(checkpointId).fibers.map(({ targetBindings, committedBindings, effects, ...fiber }) => fiber))
  add('native_inspect_fiber', 'Read raw target store, committed store, and tracked effect metadata for one Cordis fiber.', objectSchema({
    fiberId: { type: 'string' },
    checkpointId: { type: 'string' },
  }, ['fiberId']), 'OBSERVE_NATIVE', 'fiber_bindings_effects', ({ fiberId, checkpointId }) => {
    const fiber = runtime.nativeSnapshot(checkpointId).fibers.find(row => row.fiberId === fiberId || row.name === fiberId)
    if (!fiber) throw new Error(`unknown fiber: ${fiberId}`)
    return fiber
  })
  add('native_event_slice', 'Return ordered raw lifecycle and fixture events for this incident.', null, 'OBSERVE_NATIVE', 'events', () => runtime.nativeEvents())
  add('native_external_effects', 'Read scheduler jobs that exist outside Cordis tracked-effect coverage.', null, 'OBSERVE_NATIVE', 'external_effects', () => runtime.externalEffects())

  if (arm === 'relational') {
    add('software_semantic_query', 'Run one read-only pre-specified semantic query over immutable runtime snapshots. Returns coverage, unknowns, and provenance.', objectSchema({
      query: { type: 'string', enum: ['explain_composite_incident'] },
      subject: {
        type: OBJECT,
        additionalProperties: false,
        properties: {
          pluginId: { type: 'string' },
          failedSnapshotId: { type: 'string' },
        },
      },
    }, ['query', 'subject']), 'OBSERVE_RELATIONAL', 'semantic_query', request => runtime.semanticQuery(request))
  }

  if (turn === 2) {
    if (editableFiles.length) {
      add('write_file', 'Replace one approved benchmark-owned source file with supplied UTF-8 content.', objectSchema({
        path: { type: 'string' },
        content: { type: 'string' },
      }, ['path', 'content']), 'EDIT_ARTIFACT', 'workspace', ({ path, content }) => access.writeFile(path, content))
    }
    add('dynamic_define_package', 'Define a fresh immutable Package on the existing selected Plugin. Replacement Plugins are not permitted.', objectSchema({
      pluginId: { type: 'string' },
      name: { type: 'string' },
      purpose: { type: 'string' },
      hostCode: { type: 'string' },
    }, ['pluginId', 'name', 'purpose', 'hostCode']), 'MUTATE_FIXTURE', 'dynamic_package', args => runtime.definePackage(args))
    add('dynamic_run_package', 'Run or update one exact immutable Package. Mode run restarts the last-known-good version; update switches versions.', objectSchema({
      pluginId: { type: 'string' },
      packageId: { type: 'string' },
      mode: { type: 'string', enum: ['run', 'update'] },
    }, ['pluginId', 'packageId', 'mode']), 'MUTATE_FIXTURE', 'dynamic_package', args => runtime.runPackage(args))
    if (runtime.retireEscapedHandle) {
      add('external_retire_escaped_handle', 'Retire the exact escaped callback handle identified in this incident; does not affect later owned handles.', objectSchema({
        handleId: { type: 'string' },
      }, ['handleId']), 'MUTATE_FIXTURE', 'external_effects', args => runtime.retireEscapedHandle(args))
    }
    if (runtime.auxiliaryTransition) {
      add('auxiliary_transition', 'Resolve the already in-flight auxiliary provider replacement using one explicit strategy.', objectSchema({
        action: { type: 'string', enum: ['allow_current_load_to_settle', 'withdraw_target_before_settle'] },
      }, ['action']), 'MUTATE_FIXTURE', 'auxiliary_binding', args => runtime.auxiliaryTransition(args))
    }
  }

  const byName = new Map(tools.map(tool => [tool.declaration.name, tool]))
  return {
    declarations: tools.map(tool => tool.declaration),
    metadata: tools.map(({ declaration, category, domain }) => ({ name: declaration.name, category, domain })),
    async call(name, args = {}) {
      const tool = byName.get(name)
      if (!tool) throw new Error(`tool is unavailable in this turn: ${name}`)
      const inputBytes = Buffer.byteLength(JSON.stringify(args))
      const argsHash = hashJson(args)
      telemetry.record('tool_called', { name, category: tool.category, domain: tool.domain, inputBytes, argsHash, turn })
      const started = performance.now()
      try {
        const output = await tool.handler(args)
        const outputBytes = Buffer.byteLength(JSON.stringify(output))
        const evidenceTags = runtime.evidenceTagsForTool?.(name, args, output) ?? []
        telemetry.record('tool_returned', {
          name,
          category: tool.category,
          domain: tool.domain,
          argsHash,
          evidenceTags,
          outputBytes,
          durationMs: Math.round(performance.now() - started),
          status: 'ok',
          turn,
        })
        return output
      } catch (error) {
        const output = { error: error instanceof Error ? error.message : String(error) }
        telemetry.record('tool_returned', {
          name,
          category: tool.category,
          domain: tool.domain,
          argsHash,
          evidenceTags: [],
          outputBytes: Buffer.byteLength(JSON.stringify(output)),
          durationMs: Math.round(performance.now() - started),
          status: 'error',
          turn,
        })
        return output
      }
    },
  }
}

function checkpointSchema() {
  return objectSchema({ checkpointId: { type: 'string' } })
}

function objectSchema(properties, required = []) {
  return {
    type: OBJECT,
    additionalProperties: false,
    properties,
    ...(required.length ? { required } : {}),
  }
}
