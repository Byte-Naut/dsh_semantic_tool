export const EXPERIMENT = Object.freeze({
  id: 'cordis-agent-interface-gemini38-v2-calibration',
  hypothesis: 'semantic normalization reduces reconstruction burden and shifts the failure boundary of strong software agents',
  model: 'gemini-3.8-flash',
  thinkingLevel: 'medium',
  temperature: 1,
  candidateCount: 1,
  maxOutputTokensPerRequest: 32_768,
  maxToolCallsPerTurn: 24,
  maxRequestsPerTurn: 28,
  maxGrossInputTokensPerRun: 2_000_000,
  maxGrossOutputTokensPerRun: 100_000,
  requestTimeoutMs: 180_000,
  runTimeoutMs: 1_200_000,
  httpAttempts: 1,
  modelSeedBase: 53_000,
  fallback: false,
  calibrationPairsPerLevel: 2,
  confirmatoryPairsPerLevel: 12,
  pricingUsdPerMillion: Object.freeze({
    input: 0.75,
    outputIncludingThinking: 3.75,
  }),
})

export const TASK_IDS = Object.freeze([
  'l1-cross-layer-recovery',
  'l2-transitive-ownership',
  'l3-concurrent-boundary',
])

export const DIFFICULTY = Object.freeze({
  'l1-cross-layer-recovery': 'easy',
  'l2-transitive-ownership': 'medium',
  'l3-concurrent-boundary': 'hard',
})

export const ARMS = Object.freeze(['native', 'relational'])

export function modelSeed(taskId, fixtureNumber) {
  const taskIndex = TASK_IDS.indexOf(taskId)
  if (taskIndex < 0) throw new Error(`unknown task: ${taskId}`)
  return EXPERIMENT.modelSeedBase + taskIndex * 100 + fixtureNumber
}

export const TURN_TWO_APPROVAL = `Your diagnosis and proposed lifecycle plan are approved exactly as written. Execute the smallest safe repair using only the available tools. Do not broaden scope or restart unrelated components. Then verify the resulting runtime state and finish with one terminal \`\`\`json block of this shape:
{
  "summary": "short result",
  "actions_executed": [{"action":"exact tool-level action","target":"exact id","mode":"exact mode or null"}],
  "verification": {
    "primary_service": "repaired|not_repaired|unknown",
    "primary_consumers": "active|not_active|unknown",
    "external_effect": "retired_and_owned|not_repaired|not_applicable|unknown",
    "auxiliary_binding": "converged|preserved_in_flight|not_applicable|unknown"
  },
  "remaining_unknowns": ["only genuine unknowns"]
}`

export const TURN_ONE_RECORD_SHAPE = Object.freeze({
  diagnosis: {
    runtime_truth: {
      dynamic: {
        last_successful_package_id: 'string|null',
        failed_target_package_id: 'string|null',
        active_run_package_id: 'string|null',
      },
      impact: {
        direct_consumers: ['string'],
        transitive_consumers: ['string'],
      },
      effects: {
        tracked_effects_at_risk: ['string'],
        external_effect_truth: 'known|unknown',
      },
      auxiliary: {
        state: 'loading|stable|not_applicable|unknown',
        committed_provider_id: 'string|null',
        target_provider_id: 'string|null',
      },
    },
    planned_lifecycle_actions: [{ action: 'string', target: 'string', mode: 'string|null' }],
    counterfactual: {
      unsafe_action: 'string|null',
      consequence: 'string',
      minimum_safe_action: 'string|null',
    },
    unknowns: ['string'],
  },
})
