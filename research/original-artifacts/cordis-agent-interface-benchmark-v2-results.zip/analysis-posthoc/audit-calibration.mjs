import { readFile, readdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'

const runIds = (await readdir('runs', { withFileTypes: true }))
  .filter(entry => entry.isDirectory()).map(entry => entry.name).sort()
const rows = []
for (const runId of runIds) {
  const result = JSON.parse(await readFile(join('runs', runId, 'result.json'), 'utf8'))
  const events = (await readFile(join('runs', runId, 'telemetry.jsonl'), 'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse)
  rows.push(auditRun(result, events))
}

const pairs = [...Map.groupBy(rows, row => row.seedId).values()]
  .map(group => ({ native: group.find(row => row.arm === 'native'), relational: group.find(row => row.arm === 'relational') }))
const comparableEvidencePairs = pairs.filter(pair => pair.native.turnOne.callsToSufficientEvidence != null
  && pair.relational.turnOne.callsToSufficientEvidence != null)
const audit = {
  schemaVersion: 1,
  generatedAt: new Date().toISOString(),
  status: 'post-hoc sensitivity and trajectory audit; never substitutes for frozen preregistered outcomes',
  runCount: rows.length,
  requestedModel: 'gemini-3.8-flash',
  reportedModelVersions: [...new Set(rows.flatMap(row => row.reportedModelVersions))],
  execution: {
    completed: rows.filter(row => row.executionClass === 'completed').length,
    budgetExhausted: rows.filter(row => row.executionClass === 'agent-budget-exhausted').length,
    otherInvalid: rows.filter(row => !['completed', 'agent-budget-exhausted'].includes(row.executionClass)).length,
    byArm: Object.fromEntries(['native', 'relational'].map(arm => [arm, executionSummary(rows.filter(row => row.arm === arm))])),
    byLevel: Object.fromEntries(['easy', 'medium', 'hard'].map(level => [level, Object.fromEntries(['native', 'relational'].map(arm => [arm, executionSummary(rows.filter(row => row.level === level && row.arm === arm))]))])),
  },
  turnOneTrajectory: {
    byArm: Object.fromEntries(['native', 'relational'].map(arm => [arm, trajectorySummary(rows.filter(row => row.arm === arm))])),
    paired: {
      evidenceComparablePairs: comparableEvidencePairs.length,
      callsToSufficientEvidenceRelationalMinusNative: comparableEvidencePairs.map(pair => pair.relational.turnOne.callsToSufficientEvidence - pair.native.turnOne.callsToSufficientEvidence),
      meanCallsToSufficientEvidenceDelta: round(mean(comparableEvidencePairs.map(pair => pair.relational.turnOne.callsToSufficientEvidence - pair.native.turnOne.callsToSufficientEvidence))),
      relationalEarlierEvidencePairs: comparableEvidencePairs.filter(pair => pair.relational.turnOne.callsToSufficientEvidence < pair.native.turnOne.callsToSufficientEvidence).length,
      nativeDomainsTouchedDelta: pairs.map(pair => pair.relational.turnOne.nativeDomainsTouched - pair.native.turnOne.nativeDomainsTouched),
    },
  },
  frozenOutcome: {
    validRuns: rows.filter(row => row.validity === 'valid').length,
    frozenPrimaryPasses: rows.filter(row => row.frozenPrimaryPass).length,
    runtimePassesAmongCompleted: rows.filter(row => row.executionClass === 'completed' && row.runtimePass).length,
  },
  sensitivity: {
    aliasInsensitiveRuntimeSemanticPasses: rows.filter(row => row.aliasInsensitiveRuntimeSemanticPass).length,
    affectedRuns: rows.filter(row => row.aliasSensitivityAffected).map(row => row.runId),
    rule: 'Accept the pre-specified query semantic action names as aliases for their exact tool operations; still require executable runtime pass.',
  },
  genuineSemanticFailure: {
    runId: 'l3-concurrent-boundary-s01--relational',
    condition: 'status adapter observed target provider but had no committed provider observation',
    expected: 'transitioning = null/UNKNOWN',
    observed: 'transitioning = true',
    unaffectedSuccesses: ['package recovery', 'transitive consumer recovery', 'escaped-handle retirement', 'future callback ownership', 'committed/target divergence while both observed', 'safe auxiliary convergence'],
  },
  auditFindings: [
    'Nine budget-exhausted agent trajectories were mislabeled invalid-infrastructure by the frozen runner.',
    'Frozen action scoring accepted tool function names but rejected semantically identical action names returned by the relational query.',
    'external_effect_truth conflated mirror coverage (unavailable) with a later native scheduler observation (known); the hard run described both correctly in prose.',
    'The hard record used minimumSafeAction rather than the frozen minimum_safe_action field; this is structural noncompliance, not wrong counterfactual content.',
    'Budget-exhausted runs did not persist partial model exchanges, limiting auditability to telemetry.',
    'Both arms touched all eight native observation domains; the Relational treatment behaved as an optional query addition, not an interface-first policy.',
    'The easy-to-medium semantic step was too large for a 24-call Turn-1 budget: all medium runs were censored before action.',
  ],
  interpretation: {
    H1: 'not estimable: there is no completed Native pair; two completed Relational easy runs pass runtime, and one hard run has a genuine UNKNOWN-propagation failure',
    H2: 'mixed: Relational reached sufficient evidence earlier in all five comparable pairs and used 2.5 fewer native observations on average, but touched the same eight domains, used slightly more total Turn-1 calls, and used more input tokens',
    H3: 'not demonstrated: the study found a real partial-observability failure but cannot establish a shifted reasoning boundary from censored unpaired outcomes',
  },
  nextCalibrationRequirements: [
    'Use an interface-first Experimental arm: query for covered domains, native tools only for declared UNKNOWN/oracle domains and Package source.',
    'Raise the common Turn-1 tool budget enough to observe solutions rather than stopping behavior, while keeping the same gross-token cap.',
    'Insert an intermediate level that adds transitive impact or ownership, not both simultaneously.',
    'Freeze enumerated semantic action IDs and map them explicitly to tool calls; do not score action wording.',
    'Split external coverage from external native observation into two record fields.',
    'Persist partial model exchanges on budget exhaustion and classify it as a model/agent outcome, not infrastructure failure.',
    'Run a four-slot harness calibration before another 12-run study.',
  ],
  observedCostUsd: round(sum(rows.map(row => row.costUsd))),
  costProjection72: {
    atAllSlotMeanUsd: round(mean(rows.map(row => row.costUsd)) * 72),
    atCompletedRunMeanUsd: round(mean(rows.filter(row => row.executionClass === 'completed').map(row => row.costUsd)) * 72),
    atObservedMaximumUsd: round(Math.max(...rows.map(row => row.costUsd)) * 72),
  },
  rows,
}

await writeFile('artifacts/posthoc-audit.json', JSON.stringify(audit, null, 2) + '\n')
await writeFile('artifacts/posthoc-audit.md', render(audit))
console.log(`post-hoc audit: ${audit.execution.completed} completed, ${audit.execution.budgetExhausted} budget-exhausted, $${audit.observedCostUsd}`)

function auditRun(result, events) {
  const levelNumber = Number(result.difficulty)
  const level = ['easy', 'medium', 'hard'][levelNumber - 1]
  const turnOne = events.filter(event => event.turn === 1)
  const calls = turnOne.filter(event => event.kind === 'tool_called')
  const returns = turnOne.filter(event => event.kind === 'tool_returned' && event.status === 'ok')
  const required = requiredTags(levelNumber)
  const observed = new Set()
  let callsSeen = 0
  let callsToSufficientEvidence = null
  for (const event of turnOne) {
    if (event.kind === 'tool_called') callsSeen += 1
    if (event.kind !== 'tool_returned' || event.status !== 'ok') continue
    for (const tag of event.evidenceTags ?? []) observed.add(tag)
    if (callsToSufficientEvidence == null && required.every(tag => observed.has(tag))) callsToSufficientEvidence = callsSeen
  }
  const usage = turnOne.filter(event => event.kind === 'model_usage')
  const executionClass = result.validity === 'valid'
    ? 'completed'
    : /exceeded tool-call budget/.test(result.error ?? '')
      ? 'agent-budget-exhausted'
      : result.validity
  const aliasSensitivityAffected = result.validity === 'valid'
    && result.score?.runtimePass === true
    && result.score?.semanticClosure?.closureScore === 1
    && result.score?.criticalErrors?.every(error => error === 'E_REPAIR_BEFORE_RESTORE')
  return {
    runId: result.runId,
    seedId: result.seedId,
    arm: result.arm,
    level,
    validity: result.validity,
    executionClass,
    error: result.error ?? null,
    reportedModelVersions: result.reportedModelVersions ?? [],
    frozenPrimaryPass: Boolean(result.score?.primaryPass),
    runtimePass: Boolean(result.score?.runtimePass),
    semanticClosure: result.score?.semanticClosure?.closureScore ?? null,
    aliasSensitivityAffected,
    aliasInsensitiveRuntimeSemanticPass: aliasSensitivityAffected || Boolean(result.score?.primaryPass),
    costUsd: result.costUsd ?? 0,
    turnOne: {
      completed: turnOne.some(event => event.kind === 'turn_completed'),
      toolCalls: calls.length,
      nativeObservationCalls: calls.filter(event => event.category === 'OBSERVE_NATIVE').length,
      relationalObservationCalls: calls.filter(event => event.category === 'OBSERVE_RELATIONAL').length,
      observationCalls: calls.filter(event => ['OBSERVE_NATIVE', 'OBSERVE_RELATIONAL'].includes(event.category)).length,
      nativeDomainsTouched: new Set(calls.filter(event => event.category === 'OBSERVE_NATIVE').map(event => event.domain)).size,
      grossInputTokens: sum(usage.map(event => event.inputTokens ?? 0)),
      grossOutputAndThinkingTokens: sum(usage.map(event => (event.outputTokens ?? 0) + (event.thoughtTokens ?? 0))),
      toolResultBytes: sum(returns.map(event => event.outputBytes ?? 0)),
      callsToSufficientEvidence,
      evidenceCoverage: required.filter(tag => observed.has(tag)).length / required.length,
      callsAfterSufficientEvidence: callsToSufficientEvidence == null ? null : calls.length - callsToSufficientEvidence,
    },
  }
}

function requiredTags(level) {
  return ['dynamic_truth', 'direct_impact', 'tracked_effects', 'failed_source',
    ...(level >= 2 ? ['transitive_impact', 'external_effect_truth', 'ownership_source'] : []),
    ...(level >= 3 ? ['binding_divergence', 'counterfactual', 'adapter_source'] : [])]
}

function executionSummary(rows) {
  return {
    slots: rows.length,
    completed: rows.filter(row => row.executionClass === 'completed').length,
    budgetExhausted: rows.filter(row => row.executionClass === 'agent-budget-exhausted').length,
    runtimePasses: rows.filter(row => row.runtimePass).length,
  }
}

function trajectorySummary(rows) {
  return {
    n: rows.length,
    completed: rows.filter(row => row.turnOne.completed).length,
    meanToolCalls: round(mean(rows.map(row => row.turnOne.toolCalls))),
    meanObservationCalls: round(mean(rows.map(row => row.turnOne.observationCalls))),
    meanNativeObservationCalls: round(mean(rows.map(row => row.turnOne.nativeObservationCalls))),
    meanRelationalObservationCalls: round(mean(rows.map(row => row.turnOne.relationalObservationCalls))),
    meanNativeDomainsTouched: round(mean(rows.map(row => row.turnOne.nativeDomainsTouched))),
    meanCallsToSufficientEvidence: round(mean(rows.map(row => row.turnOne.callsToSufficientEvidence).filter(value => value != null))),
    sufficientEvidenceReached: rows.filter(row => row.turnOne.callsToSufficientEvidence != null).length,
    meanCallsAfterSufficientEvidence: round(mean(rows.map(row => row.turnOne.callsAfterSufficientEvidence).filter(value => value != null))),
    meanGrossInputTokens: round(mean(rows.map(row => row.turnOne.grossInputTokens))),
    meanToolResultBytes: round(mean(rows.map(row => row.turnOne.toolResultBytes))),
  }
}

function render(a) {
  const n = a.turnOneTrajectory.byArm.native
  const r = a.turnOneTrajectory.byArm.relational
  return `# v2 难度校准：post-hoc 审计

> 本文是敏感性与轨迹审计，不替换冻结的 preregistration、raw result 或 primary outcome。

## 可支持结论

本轮定位到了一个边界，但没有得到可解释的 A/B correctness 估计：12 个 slot 中 3 个完成，9 个在 Turn 1 用尽工具预算。Native 0/6 完成，Relational 3/6 完成；由于没有完成的 Native pair，不能把它表述为 runtime correctness 或 failure-boundary shift 的证明。

组合 query 的局部信号是明确的：在双方都达到 evidence closure 的 5 个 pair 中，Relational 每次都更早，平均提前 ${Math.abs(a.turnOneTrajectory.paired.meanCallsToSufficientEvidenceDelta)} 次调用。但两臂仍都触及全部 8 个 native 域；Relational 之后继续重建原生状态，因此没有形成总轨迹压缩。

| Turn-1 指标 | Native | Relational |
|---|---:|---:|
| Slots / completed | ${n.n} / ${n.completed} | ${r.n} / ${r.completed} |
| Mean tool calls | ${n.meanToolCalls} | ${r.meanToolCalls} |
| Mean observation calls | ${n.meanObservationCalls} | ${r.meanObservationCalls} |
| Mean native observations | ${n.meanNativeObservationCalls} | ${r.meanNativeObservationCalls} |
| Mean native domains | ${n.meanNativeDomainsTouched} | ${r.meanNativeDomainsTouched} |
| Mean calls to sufficient evidence | ${n.meanCallsToSufficientEvidence} | ${r.meanCallsToSufficientEvidence} |
| Evidence closure reached | ${n.sufficientEvidenceReached}/${n.n} | ${r.sufficientEvidenceReached}/${r.n} |
| Mean calls after sufficient evidence | ${n.meanCallsAfterSufficientEvidence} | ${r.meanCallsAfterSufficientEvidence} |
| Mean gross input tokens | ${n.meanGrossInputTokens} | ${r.meanGrossInputTokens} |

## 冻结分数与敏感性

- 冻结 primary：${a.frozenOutcome.frozenPrimaryPasses}/${a.frozenOutcome.validRuns} completed runs。
- 两个 L1 Relational run 的 semantic closure 均为 1，真实 runtime 均通过；primary=false 仅因 scorer 拒绝 query 返回的语义动作名。别名不敏感审计下为 2/3 completed runs。
- 这项敏感性分析是 post-hoc，不可升级为预注册 primary。

## 一个真实语义失败

完成的 Hard Relational run 正确完成 package recovery、传递 consumer 恢复、旧 handle 精确退役、新 callback ownership、双 binding 识别与安全收敛；但当 committed observation 缺失而 target 存在时，status adapter 返回 \`transitioning=true\`，正确值应为 \`null/UNKNOWN\`。因此该 run 的 hidden runtime fail 是有效反例，不是 rubric 假阴性。

## 三个假设

- H1 correctness：${a.interpretation.H1}
- H2 reconstruction burden：${a.interpretation.H2}
- H3 capability boundary：${a.interpretation.H3}

## Harness 诊断

${a.auditFindings.map(item => `- ${item}`).join('\n')}

## 下一次校准门控

${a.nextCalibrationRequirements.map(item => `- ${item}`).join('\n')}

本轮实际 API 费用：$${a.observedCostUsd}。若机械投影到 72 runs：按全部 slot 均值为 $${a.costProjection72.atAllSlotMeanUsd}，按完成 run 均值为 $${a.costProjection72.atCompletedRunMeanUsd}，按本轮最大单次为 $${a.costProjection72.atObservedMaximumUsd}；由于本轮大量提前截断，这三个数只能作为预算区间，不能作为精确预期。
`
}

function mean(values) { return values.length ? sum(values) / values.length : 0 }
function sum(values) { return values.reduce((total, value) => total + value, 0) }
function round(value) { return Number(Number(value).toFixed(4)) }
