import { execFile } from 'node:child_process'
import { copyFile, mkdir, readFile, readdir, stat, unlink, writeFile } from 'node:fs/promises'
import { join, relative, resolve } from 'node:path'
import { promisify } from 'node:util'
import { hashFile, hashJson } from '../src/hash.mjs'

const execFileAsync = promisify(execFile)
const projectRoot = resolve('.')
const parent = resolve('..')
const archive = join(parent, 'cordis-agent-interface-benchmark-v2-results.zip')
const reportCopy = join(parent, 'cordis-agent-interface-v2-experiment-report.md')
const checksumPath = join(parent, 'cordis-agent-interface-benchmark-v2-results.sha256')
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
const parity = JSON.parse(await readFile('artifacts/parity-validation.json', 'utf8'))

const frozenMismatches = []
for (const [name, expected] of preregistration.sourceTree.entries) {
  const actual = await hashFile(join(projectRoot, name)).catch(() => null)
  if (actual !== expected) frozenMismatches.push({ name, expected, actual })
}
const runIds = (await readdir('runs', { withFileTypes: true })).filter(entry => entry.isDirectory()).map(entry => entry.name).sort()
const results = []
for (const runId of runIds) results.push(JSON.parse(await readFile(join('runs', runId, 'result.json'), 'utf8')))
const secretMatches = await scanSecrets(projectRoot)
const manifest = {
  schemaVersion: 1,
  createdAt: new Date().toISOString(),
  experimentId: preregistration.experiment.id,
  frozenSourceTreeHash: preregistration.sourceTree.hash,
  frozenSourceFileCount: preregistration.sourceTree.entries.length,
  frozenSourceFilesUnchangedAfterExecution: frozenMismatches.length === 0,
  frozenSourceMismatches: frozenMismatches,
  posthocFilesAreOutsideFrozenSource: true,
  parityPassed: parity.passed,
  parityCaseCount: parity.caseCount,
  parityDigest: parity.digest,
  runSlots: results.length,
  completedRuns: results.filter(row => row.validity === 'valid').length,
  budgetExhaustedRuns: results.filter(row => /exceeded tool-call budget/.test(row.error ?? '')).length,
  reportedModelVersions: [...new Set(results.flatMap(row => row.reportedModelVersions ?? []))],
  observedCostUsd: Number(results.reduce((sum, row) => sum + (row.costUsd ?? 0), 0).toFixed(6)),
  secretPatternMatches: secretMatches,
  secretScanPassed: secretMatches.length === 0,
  rawEvidenceFiles: {
    resultJson: runIds.filter(id => results.some(row => row.runId === id)).length,
    telemetryJsonl: await countRunFile('telemetry.jsonl'),
    completedModelExchangeFiles: await countRunFile('model-exchanges.json'),
  },
}
manifest.digest = hashJson(manifest)
await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/delivery-manifest.json', JSON.stringify(manifest, null, 2) + '\n')
if (!manifest.frozenSourceFilesUnchangedAfterExecution || !manifest.parityPassed || !manifest.secretScanPassed || manifest.runSlots !== 12) {
  throw new Error('delivery manifest gate failed')
}

await copyFile('artifacts/v2-experiment-report.md', reportCopy)
await unlink(archive).catch(error => { if (error.code !== 'ENOENT') throw error })
await execFileAsync('zip', [
  '-q', '-r', archive, '.',
  '-x', 'node_modules/*', 'workspaces/*', 'tmp-l*/*', '*.zip',
], { cwd: projectRoot, timeout: 120_000, maxBuffer: 1_000_000 })
const archiveHash = await hashFile(archive)
const reportHash = await hashFile(reportCopy)
await writeFile(checksumPath, `${archiveHash}  ${archive.split('/').at(-1)}\n${reportHash}  ${reportCopy.split('/').at(-1)}\n`)
console.log(JSON.stringify({ archive, archiveHash, reportCopy, reportHash, checksumPath, manifest }, null, 2))

async function countRunFile(name) {
  let count = 0
  for (const runId of runIds) {
    try {
      if ((await stat(join('runs', runId, name))).isFile()) count += 1
    } catch (error) {
      if (error.code !== 'ENOENT') throw error
    }
  }
  return count
}

async function scanSecrets(root) {
  const matches = []
  const walk = async directory => {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name)
      const name = relative(root, path)
      if (entry.isDirectory()) {
        if (name === 'node_modules' || name.startsWith('node_modules/') || name === 'workspaces'
          || name.startsWith('workspaces/') || name.startsWith('tmp-l')) continue
        await walk(path)
      } else if (entry.isFile()) {
        const size = (await stat(path)).size
        if (size > 5_000_000) continue
        const content = await readFile(path, 'utf8').catch(() => '')
        if (/AIza[0-9A-Za-z_-]{30,}/.test(content)) matches.push(name)
      }
    }
  }
  await walk(root)
  return matches
}
