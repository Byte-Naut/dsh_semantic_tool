/** Schedule delivery work. The returned inverse must be owned by the caller's Cordis context. */
export function installDelivery(ctx, scheduler, label, payload) {
  const handle = scheduler.schedule(label, payload)
  return { handleId: handle.id }
}
