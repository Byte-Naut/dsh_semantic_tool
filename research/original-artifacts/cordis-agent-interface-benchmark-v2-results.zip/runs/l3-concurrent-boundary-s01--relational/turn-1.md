### Diagnosis

#### Incident Overview
During provider replacement of `harbor-amber-aux-v1` (`fiber:rt:l3-concurrent-boundary-s01:50`) with `harbor-amber-aux-v2` (`fiber:rt:l3-concurrent-boundary-s01:9`), the auxiliary consumer `harbor-amber-aux-consumer` (`fiber:rt:l3-concurrent-boundary-s01:8`) entered a paused `LOADING` state. Concurrently, an immutable update on Plugin `harboh-1` to `pkg-2` failed during bootstrap (`Error: amber update bootstrap failed`).

Inspection of `pkg-2` source reveals:
```javascript
return {
  apply(ctx) {
    const intended = Object.freeze({ version: "amber-repaired" })
    throw new Error("amber update bootstrap failed")
    ctx.provide("beaconEndpoint", intended)
  }
}
```
Because `pkg-2` threw before providing `beaconEndpoint`, the previous dynamic fiber hosting `pkg-1` was unloaded and disposed, causing `beaconEndpoint` to be withdrawn. This cascaded through the dependency chain:
1. Direct consumer `harbor-beacon-client` (`fiber:rt:l3-concurrent-boundary-s01:5`) lost `beaconEndpoint` and transitioned to `pending`.
2. Transitive consumer `harbor-pulse-publisher` (`fiber:rt:l3-concurrent-boundary-s01:6`) lost `pulseView` and transitioned to `pending`.
3. In `src/callback-policy.mjs`, `installDelivery` scheduled job `external-job:1` (`amber-delivery-callback`) via the scheduler without registering Cordis lifecycle cleanup via `ctx.effect()`. The callback escaped Cordis ownership into the external scheduler.

#### Distinction: Committed vs Target Binding
During an in-flight provider transition:
- **Committed / Serving Binding (`store`)**: `harbor-amber-aux-consumer` remains bound to `harbor-amber-aux-v1` (`service-impl:rt:l3-concurrent-boundary-s01:55`, version `amber-aux-stable`), which still serves currently paused work while the fiber is `loading`.
- **Target Binding (`_store`)**: Points to `harbor-amber-aux-v2` (`service-impl:rt:l3-concurrent-boundary-s01:54`, version `amber-aux-target`).
- **Adapter Defect**: `src/status-adapter.mjs` erroneously reads `_store` for both serving and target providers and reports `transitioning: false`. It must be corrected to read `consumerFiber.store` for `servingProviderId` and `consumerFiber._store` for `targetProviderId`, setting `transitioning` to true when they diverge.

#### Distinction: Known Absence vs Unavailable External Truth
- **Known Absence**: In `harboh-1`, `active_run_package_id` is an explicit known absence (`null`). The dynamic inventory has complete coverage and contains an explicit absence record confirming that `lastSuccessfulPackageId` (`pkg-1`) is not currently running after the failed attempt (`run-2`).
- **Unavailable External Truth**: Within Cordis tracked-effect metadata and snapshot records, the external scheduler exists outside Cordis tracked-effect coverage (`coverage: unavailable`, `truth: unknown`). Missing an observation from Cordis tracked effects does not prove absence. Native oracle inspection (`native_external_effects`) was required to independently discover active handle `external-job:1` (`amber-delivery-callback`).

#### Counterfactual Analysis
- **Unsafe Action**: Withdrawing the replacement target `harbor-amber-aux-v2` before the paused load settles (`withdraw_target_before_settle`).
- **Consequence**: Removes the selected target while paused work is still committed to the retiring provider; convergence assumptions fail and the consumer can end pending.
- **Minimum Safe Action**: Allow the current load to settle (`allow_current_load_to_settle`).

---

### Action Plan (Turn 2 Execution)
1. **Source Code Repairs (pre-reactivation)**:
   - Edit `src/callback-policy.mjs` to register cancellation inside `ctx.effect(() => () => handle.cancel(), label)`.
   - Edit `src/status-adapter.mjs` to differentiate `consumerFiber.store` from `consumerFiber._store` and report transition status accurately.
   - Run visible Node tests to verify both unit tests pass.
2. **First Lifecycle Mutation**:
   - Explicitly run last-known-good package `pkg-1` on plugin `harboh-1` (`mode: run`).
3. **Handle Retirement**:
   - Retire escaped external handle `external-job:1` without disturbing other jobs.
4. **Package Creation & Update**:
   - Define a corrected package `pkg-3` on plugin `harboh-1` providing `beaconEndpoint` with `{ version: "amber-repaired" }` without throwing.
   - Update plugin `harboh-1` to `pkg-3` (`mode: update`).
5. **Auxiliary Consumer Convergence**:
   - Finish the paused in-flight load on auxiliary consumer `harbor-amber-aux-consumer` (`fiber:rt:l3-concurrent-boundary-s01:8`) allowing it to settle onto `harbor-amber-aux-v2` without restarting or withdrawing the target.

```json
{
  "runtime_truth": {
    "dynamic": {
      "last_successful_package_id": "pkg-1",
      "failed_target_package_id": "pkg-2",
      "active_run_package_id": null
    },
    "impact": {
      "direct_consumers": [
        "harbor-beacon-client"
      ],
      "transitive_consumers": [
        "harbor-pulse-publisher"
      ]
    },
    "effects": {
      "tracked_effects_at_risk": [
        "ctx.provide(\"beaconEndpoint\")",
        "ctx.provide(\"pulseView\")",
        "tracked:direct:amber-stable",
        "tracked:transitive:derived:amber-stable"
      ],
      "external_effect_truth": "unknown"
    },
    "auxiliary": {
      "state": "loading",
      "committed_provider_id": "harbor-amber-aux-v1",
      "target_provider_id": "harbor-amber-aux-v2"
    }
  },
  "planned_lifecycle_actions": [
    {
      "action": "repair_future_effect_ownership",
      "target": "src/callback-policy.mjs",
      "mode": null
    },
    {
      "action": "explicit_run_of_last_successful_package",
      "target": "pkg-1",
      "mode": "run"
    },
    {
      "action": "retire_exact_escaped_handle",
      "target": "external-job:1",
      "mode": null
    },
    {
      "action": "define_new_immutable_package",
      "target": "harboh-1",
      "mode": null
    },
    {
      "action": "update_to_new_package",
      "target": "harboh-1",
      "mode": "update"
    },
    {
      "action": "finish_existing_auxiliary_load",
      "target": "fiber:rt:l3-concurrent-boundary-s01:8",
      "mode": null
    }
  ],
  "counterfactual": {
    "unsafe_action": "withdraw_target_before_settle",
    "consequence": "removes the selected target while paused work is still committed to the retiring provider; convergence assumptions fail and the consumer can end pending",
    "minimumSafeAction": "allow_current_load_to_settle"
  },
  "unknowns": [
    "external effect identity and liveness require native scheduler observation"
  ]
}
```
