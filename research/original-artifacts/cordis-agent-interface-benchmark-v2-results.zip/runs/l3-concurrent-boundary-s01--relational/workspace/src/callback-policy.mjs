export function installDelivery(ctx, scheduler, label, payload) {
  const handle = scheduler.schedule(label, payload)
  ctx.effect(() => () => handle.cancel(), label)
  return { handleId: handle.id }
}
