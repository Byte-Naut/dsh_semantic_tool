function providerId(implementation) {
  return implementation?.fiber?.name ?? null
}

export function buildStatus(consumerFiber, serviceKey) {
  const serving = consumerFiber.store?.[serviceKey]
  const target = consumerFiber._store?.[serviceKey]
  const servingId = providerId(serving)
  const targetId = providerId(target)
  return {
    servingProviderId: servingId,
    targetProviderId: targetId,
    transitioning: servingId !== targetId,
  }
}
