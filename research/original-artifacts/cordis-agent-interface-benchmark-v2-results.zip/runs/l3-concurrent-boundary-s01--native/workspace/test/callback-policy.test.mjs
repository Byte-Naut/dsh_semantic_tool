import assert from 'node:assert/strict'
import test from 'node:test'
import { installDelivery } from '../src/callback-policy.mjs'
test('delivery cancellation is Cordis-owned', () => {
  let inverse; let label; let cancelled = 0
  const ctx = { effect(factory, value) { label = value; inverse = factory() } }
  const scheduler = { schedule() { return { id: 'h-1', cancel() { cancelled += 1 } } } }
  assert.deepEqual(installDelivery(ctx, scheduler, 'amber-delivery-callback', 17), { handleId: 'h-1' })
  assert.equal(label, 'amber-delivery-callback'); assert.equal(typeof inverse, 'function')
  inverse(); assert.equal(cancelled, 1)
})
