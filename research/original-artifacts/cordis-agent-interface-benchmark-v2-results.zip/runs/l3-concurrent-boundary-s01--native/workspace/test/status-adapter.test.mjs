import assert from 'node:assert/strict'
import test from 'node:test'
import { buildStatus } from '../src/status-adapter.mjs'
const impl = name => ({ fiber: { name } })
test('paused work and reload target are separate', () => {
  const fiber = {
    store: { "amberAuxiliaryPort": impl('harbor-amber-aux-v1') },
    _store: { "amberAuxiliaryPort": impl('harbor-amber-aux-v2') },
  }
  assert.deepEqual(buildStatus(fiber, 'amberAuxiliaryPort'), {
    servingProviderId: 'harbor-amber-aux-v1', targetProviderId: 'harbor-amber-aux-v2', transitioning: true,
  })
})
