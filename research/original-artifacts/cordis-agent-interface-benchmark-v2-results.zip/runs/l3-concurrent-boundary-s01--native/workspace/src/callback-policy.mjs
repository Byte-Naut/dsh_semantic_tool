export function installDelivery(ctx, scheduler, label, payload) {
  const handle = scheduler.schedule(label, payload)
  return { handleId: handle.id }
}
