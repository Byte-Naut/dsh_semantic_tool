function providerId(implementation) {
  return implementation?.fiber?.name ?? null
}

export function buildStatus(consumerFiber, serviceKey) {
  const target = consumerFiber._store?.[serviceKey]
  return { servingProviderId: providerId(target), targetProviderId: providerId(target), transitioning: false }
}
