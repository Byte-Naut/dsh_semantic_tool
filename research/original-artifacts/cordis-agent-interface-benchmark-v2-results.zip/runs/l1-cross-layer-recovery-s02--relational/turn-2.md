### Execution & Verification Summary

The approved recovery and upgrade sequence was executed on plugin `orchae-1`:
1. **Immediate Service Restoration:** Re-started the last successful package `pkg-1` using `dynamic_run_package(mode="run")`. The service `ledgerEndpoint` was restored immediately with value `cobalt-stable`, bringing consumer `orchard-ledger-client` back into the `active` state.
2. **Package Definition:** Defined immutable package `pkg-3` (`orchae repaired package`) via `dynamic_define_package`, supplying the intended implementation (`Object.freeze({ version: "cobalt-repaired" })`) with the synthetic bootstrap failure removed.
3. **Safe Transition:** Applied package `pkg-3` to plugin `orchae-1` via `dynamic_run_package(mode="update")`. The transition completed successfully (`run-4`), providing `ledgerEndpoint` version `cobalt-repaired`.
4. **Runtime Verification:** Lifecycle events confirm `cordis-dynamic` entered `active` state (seq 47), `ledgerEndpoint` service was registered (seq 49), and `orchard-ledger-client` transitioned to `active` (seq 50). External scheduler checks show no active jobs.

```json
{
  "summary": "Restored service with last-known-good package pkg-1 in mode run, defined repaired package pkg-3 without bootstrap failure, and updated orchae-1 to pkg-3; verified consumer orchard-ledger-client is active.",
  "actions_executed": [
    {
      "action": "dynamic_run_package",
      "target": "pkg-1",
      "mode": "run"
    },
    {
      "action": "dynamic_define_package",
      "target": "orchae-1",
      "mode": null
    },
    {
      "action": "dynamic_run_package",
      "target": "pkg-3",
      "mode": "update"
    }
  ],
  "verification": {
    "primary_service": "repaired",
    "primary_consumers": "active",
    "external_effect": "not_applicable",
    "auxiliary_binding": "not_applicable"
  },
  "remaining_unknowns": []
}
```
