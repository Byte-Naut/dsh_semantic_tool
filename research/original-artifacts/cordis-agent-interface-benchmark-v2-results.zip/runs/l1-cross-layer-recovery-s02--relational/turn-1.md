### Incident Diagnosis

#### 1. Runtime State & Package Identification
- **Plugin Identifier:** `orchae-1`
- **Last Successful Package:** `pkg-1` (`"orchae stable package"`, serving `ledgerEndpoint` with version `"cobalt-stable"`)
- **Failed Target Package:** `pkg-2` (`"orchae intended repair"`, failed during `host-load` with `Error: cobalt update bootstrap failed`)
- **Actual Active Run:** `null` (None. The update attempt `run-2` failed during host bootstrap, while `pkg-1` (`run-1`) had already been unloaded/retracted, leaving a `failedUpdateGap` where no run is currently active despite `currentPackageId` pointing to `pkg-1`.)
- **Recovery Mode:** `run` (an explicit run of the last successful package `pkg-1`, rather than an update, because no active run currently exists)

#### 2. Consumer Impact & Effects
- **Direct Consumer:** `orchard-ledger-client` (`fiber:rt:l1-cross-layer-recovery-s02:5`)
  - Currently in `pending` state because its required dependency `ledgerEndpoint` was withdrawn when `fiber:rt:l1-cross-layer-recovery-s02:4` was disposed.
- **Transitive Consumers:** None (`[]`)
- **Tracked Effects at Risk:**
  - `effect:rt:l1-cross-layer-recovery-s02:31` (`ctx.provide("ledgerEndpoint")` on `cordis-dynamic`)
  - `effect:rt:l1-cross-layer-recovery-s02:33` (`tracked:direct:cobalt-stable` on `orchard-ledger-client`)
- **External Effects:** Verified via native fixture scheduler inspection (`native_external_effects` complete coverage: `activeJobs: []`). No untracked external jobs are running.
- **Auxiliary Provider State:** `not_applicable` (single-provider dynamic incident).

#### 3. Inspection of Failed Package (`pkg-2`)
Inspection reveals that `pkg-2` contains a synthetic failure injected directly prior to service provision:
```javascript
return { apply(ctx) {
  const intended = Object.freeze({ version: "cobalt-repaired" })
  throw new Error("cobalt update bootstrap failed")
  ctx.provide("ledgerEndpoint", intended)
} }
```
The intended behavior is to provide `ledgerEndpoint` as `Object.freeze({ version: "cobalt-repaired" })` without throwing.

---

### Action Plan (Turn 2 Execution)
1. **Immediate Service Restoration:** Execute `pkg-1` with mode `run` on plugin `orchae-1` to immediately return `orchard-ledger-client` to `active` state and restore `ledgerEndpoint`.
2. **Define Repaired Package:** Define a new immutable package (e.g., `pkg-3`) under plugin `orchae-1` containing the repaired host implementation without the bootstrap exception.
3. **Safe Update:** Update `orchae-1` to the new package via mode `update`.
4. **Verification:** Verify that `orchard-ledger-client` is `active` and serving `cobalt-repaired`.

```json
{
  "runtime_truth": {
    "dynamic": {
      "last_successful_package_id": "pkg-1",
      "failed_target_package_id": "pkg-2",
      "active_run_package_id": null
    },
    "impact": {
      "direct_consumers": [
        "orchard-ledger-client"
      ],
      "transitive_consumers": []
    },
    "effects": {
      "tracked_effects_at_risk": [
        "effect:rt:l1-cross-layer-recovery-s02:31",
        "effect:rt:l1-cross-layer-recovery-s02:33"
      ],
      "external_effect_truth": "known"
    },
    "auxiliary": {
      "state": "not_applicable",
      "committed_provider_id": null,
      "target_provider_id": null
    }
  },
  "planned_lifecycle_actions": [
    {
      "action": "explicit_run_of_last_successful_package",
      "target": "pkg-1",
      "mode": "run"
    },
    {
      "action": "define_new_immutable_package",
      "target": "orchae-1",
      "mode": null
    },
    {
      "action": "update_to_new_package",
      "target": "orchae-1",
      "mode": "update"
    }
  ],
  "counterfactual": {
    "unsafe_action": "update_to_new_package",
    "consequence": "Attempting to update directly without restoring the last successful package leaves the consumer offline and risks update failure because no active run is present to update from.",
    "minimum_safe_action": "explicit_run_of_last_successful_package"
  },
  "unknowns": []
}
```
