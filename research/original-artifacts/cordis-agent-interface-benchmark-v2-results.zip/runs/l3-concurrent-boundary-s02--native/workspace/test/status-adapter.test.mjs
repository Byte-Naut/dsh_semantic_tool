import assert from 'node:assert/strict'
import test from 'node:test'
import { buildStatus } from '../src/status-adapter.mjs'
const impl = name => ({ fiber: { name } })
test('paused work and reload target are separate', () => {
  const fiber = {
    store: { "cobaltAuxiliaryPort": impl('orchard-cobalt-aux-v1') },
    _store: { "cobaltAuxiliaryPort": impl('orchard-cobalt-aux-v2') },
  }
  assert.deepEqual(buildStatus(fiber, 'cobaltAuxiliaryPort'), {
    servingProviderId: 'orchard-cobalt-aux-v1', targetProviderId: 'orchard-cobalt-aux-v2', transitioning: true,
  })
})
