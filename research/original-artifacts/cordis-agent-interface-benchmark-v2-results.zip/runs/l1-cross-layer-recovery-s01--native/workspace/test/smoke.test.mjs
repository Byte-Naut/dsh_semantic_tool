import test from 'node:test'
import assert from 'node:assert/strict'
test('workspace is isolated', () => assert.equal(1 + 1, 2))
