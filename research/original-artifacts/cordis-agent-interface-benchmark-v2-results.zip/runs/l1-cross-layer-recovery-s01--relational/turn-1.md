### Diagnostic Findings

1. **Dynamic Runtime State & Failure Analysis (`harboe-1`)**:
   - **Last Successful Package**: `pkg-1` (providing `beaconEndpoint` version `"amber-stable"`).
   - **Failed Target Package**: `pkg-2` (attempted in `run-2` under mode `"update"`, failed during `host-load` phase with `Error: amber update bootstrap failed`).
   - **Actual Active Run**: `null`. While `currentPackageId` in inventory displays `pkg-1`, `pkg-1` was retracted during the update attempt and is not running (`lastSuccessfulIsCurrentlyRunning: false`, `failedUpdateGap: true`).
   - **Failed Package Source Inspection**:
     ```javascript
     return { apply(ctx) {
       const intended = Object.freeze({ version: "amber-repaired" })
       throw new Error("amber update bootstrap failed")
       ctx.provide("beaconEndpoint", intended)
     } }
     ```
     The package throws an explicit error during host bootstrap before publishing `beaconEndpoint`.

2. **Downstream Cordis Impact**:
   - **Direct Consumer**: `harbor-beacon-client` (`fiber:rt:l1-cross-layer-recovery-s01:5`), which declared injection for `beaconEndpoint`.
   - **Transitive Consumers**: None (`[]`).
   - **Current State**: Upon disposal of the provider fiber, `harbor-beacon-client` transitioned to `pending` and its tracked effect `tracked:direct:amber-stable` was disposed / put at risk.
   - **Auxiliary Runtime State**: Not applicable (`state: "not_applicable"`, no auxiliary provider or shadow service exists).
   - **External Effects**: Verified complete coverage via native scheduler oracle (`native_external_effects`), with 0 active jobs (`external_effect_truth: "known"`).

3. **Safe Recovery Plan & Counterfactual**:
   - **Recovery Mode**: Exact recovery mode is `"run"`.
   - **Minimum Safe Action**: `explicit_run_of_last_successful_package` (running `pkg-1` under mode `"run"` on plugin `harboe-1`).
   - **Counterfactual Risk**: Attempting an immediate `update_to_new_package` without first restoring service via `run` leaves `harbor-beacon-client` unavailable throughout repair authoring, and updating across an empty active-run gap is an invalid transition.
   - **Full Sequence**:
     1. Run last successful package `pkg-1` under mode `"run"` on plugin `harboe-1` to restore `beaconEndpoint` and re-activate `harbor-beacon-client`.
     2. Define a new immutable package (e.g. `pkg-3`) containing the repaired implementation (without the bootstrap error).
     3. Update plugin `harboe-1` to the new package under mode `"update"`.

```json
{
  "runtime_truth": {
    "dynamic": {
      "last_successful_package_id": "pkg-1",
      "failed_target_package_id": "pkg-2",
      "active_run_package_id": null
    },
    "impact": {
      "direct_consumers": [
        "harbor-beacon-client"
      ],
      "transitive_consumers": []
    },
    "effects": {
      "tracked_effects_at_risk": [
        "tracked:direct:amber-stable"
      ],
      "external_effect_truth": "known"
    },
    "auxiliary": {
      "state": "not_applicable",
      "committed_provider_id": null,
      "target_provider_id": null
    }
  },
  "planned_lifecycle_actions": [
    {
      "action": "explicit_run_of_last_successful_package",
      "target": "pkg-1",
      "mode": "run"
    },
    {
      "action": "define_new_immutable_package",
      "target": "harboe-1",
      "mode": null
    },
    {
      "action": "update_to_new_package",
      "target": "harboe-1",
      "mode": "update"
    }
  ],
  "counterfactual": {
    "unsafe_action": "update_to_new_package",
    "consequence": "Attempting an update during the failed-update gap without first restoring service leaves harbor-beacon-client unavailable and risks an invalid state transition because no active run is serving beaconEndpoint.",
    "minimum_safe_action": "explicit_run_of_last_successful_package"
  },
  "unknowns": []
}
```
