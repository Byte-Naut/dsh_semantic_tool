import { WorkspaceAccess } from '../src/workspace.mjs'
import { Telemetry } from '../src/telemetry.mjs'

export async function applyReferenceSolution(seed, workspace, runtime) {
  const telemetry = new Telemetry(`reference:${seed.seedId}`)
  const editableFiles = seed.level === 1
    ? []
    : seed.level === 2
      ? ['src/callback-policy.mjs']
      : ['src/callback-policy.mjs', 'src/status-adapter.mjs']
  const access = new WorkspaceAccess(workspace, { editableFiles, telemetry, turn: 2 })
  const failed = runtime.inspectPackage({
    pluginId: runtime.publicState.pluginId,
    packageId: runtime.publicState.v2PackageId,
  })
  if (seed.level >= 2) {
    await access.writeFile('src/callback-policy.mjs', callbackPolicySource())
  }
  if (seed.level >= 3) {
    await access.writeFile('src/status-adapter.mjs', statusAdapterSource())
  }
  await runtime.runPackage({
    pluginId: runtime.publicState.pluginId,
    packageId: runtime.publicState.v1PackageId,
    mode: 'run',
  })
  if (seed.level >= 2) {
    const escaped = runtime.externalEffects().allJobs.find(job => job.label === seed.externalLabel && job.cancelCount === 0)
    if (!escaped) throw new Error(`${seed.seedId}: escaped handle not found`)
    await runtime.retireEscapedHandle({ handleId: escaped.id })
  }
  const repairedSource = failed.code.host.replace(/  throw new Error\([^\n]+\)\n/, '')
  const definition = await runtime.definePackage({
    pluginId: runtime.publicState.pluginId,
    name: `${seed.pluginPrefix} repaired package`,
    purpose: 'publish the intended repaired endpoint behavior',
    hostCode: repairedSource,
  })
  await runtime.runPackage({
    pluginId: runtime.publicState.pluginId,
    packageId: String(definition.packageId),
    mode: 'update',
  })
  if (seed.level >= 3) {
    await runtime.auxiliaryTransition({ action: 'allow_current_load_to_settle' })
  }
  return { telemetry: telemetry.totals(), grade: await runtime.grade() }
}

export function callbackPolicySource() {
  return `export function installDelivery(ctx, scheduler, label, payload) {
  const handle = scheduler.schedule(label, payload)
  ctx.effect(() => () => handle.cancel(), label)
  return { handleId: handle.id }
}
`
}

export function statusAdapterSource() {
  return `function providerId(implementation) {
  return implementation?.fiber?.name ?? null
}

export function buildStatus(consumerFiber, serviceKey) {
  const servingProviderId = providerId(consumerFiber.store?.[serviceKey])
  const targetProviderId = providerId(consumerFiber._store?.[serviceKey])
  return {
    servingProviderId,
    targetProviderId,
    transitioning: servingProviderId == null || targetProviderId == null
      ? null
      : servingProviderId !== targetProviderId,
  }
}
`
}
