import { parseFinalRecord } from '../src/records.mjs'

export function scoreRun({ taskId, seed, runtime, turnOneText, turnTwoText, grade, telemetryTotals, telemetryEvents }) {
  const turnOneRecord = parseFinalRecord(turnOneText)
  const turnTwoRecord = parseFinalRecord(turnTwoText)
  const semantic = scoreSemanticRecord({ seed, runtime, parsed: turnOneRecord, grade })
  const criticalErrors = criticalErrorsFor({ seed, runtime, parsed: turnOneRecord, grade, semantic })
  const recordCompliance = turnOneRecord.ok && turnTwoRecord.ok
  const reconstructionBurden = burdenMetrics({
    seed,
    runtime,
    parsed: turnOneRecord,
    grade,
    semantic,
    telemetryTotals,
    telemetryEvents,
  })
  return {
    primaryPass: Boolean(grade.pass) && recordCompliance && semantic.closureScore === 1 && criticalErrors.length === 0,
    runtimePass: Boolean(grade.pass),
    recordCompliance,
    turnOneRecord,
    turnTwoRecord,
    semanticClosure: semantic,
    criticalErrors,
    reconstructionBurden,
    grade,
    telemetryTotals,
  }
}

function scoreSemanticRecord({ seed, runtime, parsed, grade }) {
  if (!parsed.ok) return { closureScore: 0, correct: 0, total: expectedFactCount(seed.level), facts: [{ name: 'terminal_record', pass: false }] }
  const record = parsed.record
  const dynamic = record.runtime_truth?.dynamic ?? {}
  const impact = record.runtime_truth?.impact ?? {}
  const effects = record.runtime_truth?.effects ?? {}
  const auxiliary = record.runtime_truth?.auxiliary ?? {}
  const facts = [
    fact('last_successful_package', dynamic.last_successful_package_id === runtime.publicState.v1PackageId),
    fact('failed_target_package', dynamic.failed_target_package_id === runtime.publicState.v2PackageId),
    fact('active_run_absent', dynamic.active_run_package_id === null),
    fact('direct_consumer', arrayHas(impact.direct_consumers, seed.directConsumerName)),
    fact('tracked_effects_at_risk', Array.isArray(effects.tracked_effects_at_risk) && effects.tracked_effects_at_risk.length > 0),
  ]
  if (seed.level >= 2) {
    facts.push(
      fact('transitive_consumer', arrayHas(impact.transitive_consumers, seed.transitiveConsumerName)),
      fact('external_truth_observed', effects.external_effect_truth === 'known'),
      fact('escaped_handle_planned', plannedTarget(parsed.record, 'external_retire_escaped_handle') === grade.ownership?.escapedHandle?.id),
    )
  }
  if (seed.level >= 3) {
    facts.push(
      fact('auxiliary_loading', auxiliary.state === 'loading'),
      fact('committed_provider', auxiliary.committed_provider_id === seed.auxiliaryProviderV1),
      fact('target_provider', auxiliary.target_provider_id === seed.auxiliaryProviderV2),
      fact('safe_counterfactual', record.counterfactual?.unsafe_action === 'withdraw_target_before_settle'
        && record.counterfactual?.minimum_safe_action === 'allow_current_load_to_settle'),
    )
  }
  const correct = facts.filter(item => item.pass).length
  return { closureScore: correct / facts.length, correct, total: facts.length, facts }
}

function criticalErrorsFor({ seed, runtime, parsed, grade, semantic }) {
  const errors = []
  if (!parsed.ok) return ['E_RECORD_UNPARSEABLE']
  const record = parsed.record
  const dynamic = record.runtime_truth?.dynamic ?? {}
  if (dynamic.active_run_package_id !== null) errors.push('E_CURRENT_IS_ACTIVE')
  const lifecycle = (record.planned_lifecycle_actions ?? [])
    .filter(row => ['dynamic_define_package', 'dynamic_run_package'].includes(row?.action))
  const first = lifecycle[0]
  if (first?.action !== 'dynamic_run_package' || first?.target !== runtime.publicState.v1PackageId) errors.push('E_REPAIR_BEFORE_RESTORE')
  if (first?.action === 'dynamic_run_package' && first?.mode !== 'run') errors.push('E_WRONG_ROLLBACK_MODE')
  if (seed.level >= 2) {
    if (!semantic.facts.find(item => item.name === 'transitive_consumer')?.pass) errors.push('E_TRANSITIVE_IMPACT_OMITTED')
    if (record.runtime_truth?.effects?.external_effect_truth !== 'known') errors.push('E_EXTERNAL_ABSENCE_ASSUMED')
    if (plannedTarget(record, 'external_retire_escaped_handle') !== grade.ownership?.escapedHandle?.id) errors.push('E_WRONG_HANDLE')
  }
  if (seed.level >= 3) {
    const auxiliary = record.runtime_truth?.auxiliary ?? {}
    if (auxiliary.committed_provider_id === auxiliary.target_provider_id
      || auxiliary.committed_provider_id !== seed.auxiliaryProviderV1
      || auxiliary.target_provider_id !== seed.auxiliaryProviderV2) errors.push('E_BINDING_COLLAPSE')
    if ((record.planned_lifecycle_actions ?? []).some(row => row?.action === 'auxiliary_transition'
      && row?.mode === 'withdraw_target_before_settle')) errors.push('E_WITHDRAW_TARGET')
  }
  if (grade.pluginCount !== 1) errors.push('E_NEW_PLUGIN')
  return [...new Set(errors)]
}

function burdenMetrics({ seed, runtime, parsed, grade, semantic, telemetryTotals, telemetryEvents }) {
  const requiredEvidenceTags = [
    'dynamic_truth', 'direct_impact', 'tracked_effects', 'failed_source',
    ...(seed.level >= 2 ? ['transitive_impact', 'external_effect_truth', 'ownership_source'] : []),
    ...(seed.level >= 3 ? ['binding_divergence', 'counterfactual', 'adapter_source'] : []),
  ]
  const observed = new Set()
  let returnedCount = 0
  let callsAtSufficiency = null
  let toolCallsSeen = 0
  for (const event of telemetryEvents) {
    if (event.kind === 'tool_called') toolCallsSeen += 1
    if (event.kind !== 'tool_returned' || event.status !== 'ok') continue
    returnedCount += 1
    for (const tag of event.evidenceTags ?? []) observed.add(tag)
    if (callsAtSufficiency === null && requiredEvidenceTags.every(tag => observed.has(tag))) callsAtSufficiency = toolCallsSeen
  }
  const planned = (parsed.ok ? parsed.record.planned_lifecycle_actions : [])
    .map(row => normalizePlanAction(row, runtime))
  const actual = (grade.actionLog ?? []).map(row => normalizeActualAction(row, runtime))
  const planDeviationCount = sequenceDistance(planned.filter(Boolean), actual.filter(Boolean))
  const unsupportedJudgments = unsupportedJudgmentCount(seed, parsed, observed)
  return {
    totalToolCalls: telemetryTotals.toolCalls,
    observationCalls: telemetryTotals.observationCalls,
    nativeObservationCalls: telemetryTotals.nativeObservationCalls,
    relationalObservationCalls: telemetryTotals.relationalObservationCalls,
    nativeStateDomainsTouched: telemetryTotals.nativeObservationDomainsTouched.length,
    nativeStateDomainNames: telemetryTotals.nativeObservationDomainsTouched,
    repeatedObservationCalls: telemetryTotals.repeatedObservationCalls,
    grossInputTokens: telemetryTotals.usage.input,
    grossOutputAndThinkingTokens: telemetryTotals.usage.output + telemetryTotals.usage.thoughts,
    toolResultBytes: telemetryTotals.toolResultBytes,
    callsToFirstSufficientEvidence: callsAtSufficiency,
    sufficientEvidenceReached: callsAtSufficiency !== null,
    evidenceCoverage: requiredEvidenceTags.filter(tag => observed.has(tag)).length / requiredEvidenceTags.length,
    requiredEvidenceTags,
    observedEvidenceTags: [...observed].sort(),
    unsupportedJudgments,
    planDeviationCount,
    incorrectSemanticFacts: semantic.total - semantic.correct,
    successfulToolReturns: returnedCount,
  }
}

function unsupportedJudgmentCount(seed, parsed, observed) {
  if (!parsed.ok) return expectedFactCount(seed.level)
  let count = 0
  const dynamic = parsed.record.runtime_truth?.dynamic
  if (dynamic && !observed.has('dynamic_truth')) count += 1
  if ((parsed.record.runtime_truth?.impact?.direct_consumers?.length ?? 0) && !observed.has('direct_impact')) count += 1
  if ((parsed.record.runtime_truth?.impact?.transitive_consumers?.length ?? 0) && !observed.has('transitive_impact')) count += 1
  if (parsed.record.runtime_truth?.effects?.external_effect_truth === 'known' && !observed.has('external_effect_truth')) count += 1
  if (seed.level >= 3 && parsed.record.runtime_truth?.auxiliary?.state !== 'unknown' && !observed.has('binding_divergence')) count += 1
  return count
}

function normalizePlanAction(row, runtime) {
  if (!row?.action) return null
  if (row.action === 'dynamic_run_package' && row.mode === 'run') {
    return `restore:${row.target === runtime.publicState.v1PackageId ? 'v1' : row.target}:run`
  }
  if (row.action === 'dynamic_run_package' && row.mode === 'update') return 'update:new-package:update'
  if (row.action === 'dynamic_define_package') return `define:${row.target}:`
  if (row.action === 'external_retire_escaped_handle') return `retire:${row.target}:`
  if (row.action === 'auxiliary_transition') return `auxiliary:${row.mode}:`
  if (row.action === 'write_file') return null
  return `${row.action}:${row.target ?? ''}:${row.mode ?? ''}`
}

function normalizeActualAction(row, runtime) {
  if (row.kind === 'run' && row.mode === 'run') return `restore:${row.packageId === runtime.publicState.v1PackageId ? 'v1' : row.packageId}:run`
  if (row.kind === 'run' && row.mode === 'update') return 'update:new-package:update'
  if (row.kind === 'define') return `define:${row.pluginId}:`
  if (row.kind === 'retire-external') return `retire:${row.handleId}:`
  if (row.kind === 'auxiliary-transition') return `auxiliary:${row.action}:`
  return null
}

function sequenceDistance(left, right) {
  const rows = Array.from({ length: left.length + 1 }, () => Array(right.length + 1).fill(0))
  for (let i = 0; i <= left.length; i += 1) rows[i][0] = i
  for (let j = 0; j <= right.length; j += 1) rows[0][j] = j
  for (let i = 1; i <= left.length; i += 1) {
    for (let j = 1; j <= right.length; j += 1) {
      rows[i][j] = Math.min(rows[i - 1][j] + 1, rows[i][j - 1] + 1, rows[i - 1][j - 1] + (left[i - 1] === right[j - 1] ? 0 : 1))
    }
  }
  return rows[left.length][right.length]
}

function plannedTarget(record, action) {
  return (record.planned_lifecycle_actions ?? []).find(row => row?.action === action)?.target ?? null
}

function expectedFactCount(level) {
  return level === 1 ? 5 : level === 2 ? 8 : 12
}

function fact(name, pass) {
  return { name, pass: Boolean(pass) }
}

function arrayHas(value, expected) {
  return Array.isArray(value) && value.includes(expected)
}
