import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { allSeeds } from './seed-catalog.mjs'
import { createRuntime, taskCard, taskEditableFiles, taskWorkspaceFiles } from '../src/runtime-controller.mjs'
import { materializeWorkspace, WorkspaceAccess } from '../src/workspace.mjs'
import { createToolRegistry } from '../src/tool-registry.mjs'
import { Telemetry } from '../src/telemetry.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { applyReferenceSolution } from '../evaluator-private/reference-solutions.mjs'

const validationRoot = resolve('workspaces')
const preregistration = JSON.parse(await readFile('artifacts/preregistration.json', 'utf8'))
await mkdir(validationRoot, { recursive: true })
const cases = []

for (const seed of allSeeds()) {
  const caseRoot = join(validationRoot, seed.seedId)
  const nativeWorkspace = join(caseRoot, 'native')
  const relationalWorkspace = join(caseRoot, 'relational')
  const files = taskWorkspaceFiles(seed.taskId, seed)
  await Promise.all([materializeWorkspace(nativeWorkspace, files), materializeWorkspace(relationalWorkspace, files)])
  const [nativeTree, relationalTree] = await Promise.all([hashTree(nativeWorkspace), hashTree(relationalWorkspace)])
  assert(nativeTree.hash === relationalTree.hash, `${seed.seedId}: initial workspaces differ`)

  const runtime = await createRuntime(seed.taskId, seed, nativeWorkspace)
  try {
    validateFirewall(seed, taskCard(seed.taskId, seed, runtime), files)
    const telemetry = new Telemetry(`validate:${seed.seedId}`)
    for (const turn of [1, 2]) {
      const common = { runtime, workspace: nativeWorkspace, editableFiles: taskEditableFiles(seed.taskId), telemetry, turn }
      const nativeRegistry = createToolRegistry({ ...common, arm: 'native' })
      const relationalRegistry = createToolRegistry({ ...common, arm: 'relational' })
      validateToolDelta(seed.seedId, turn, nativeRegistry.declarations, relationalRegistry.declarations)
    }
    const witness = validateSemanticWitness(seed, runtime)
    const reference = await applyReferenceSolution(seed, nativeWorkspace, runtime)
    const visible = await new WorkspaceAccess(nativeWorkspace, { editableFiles: [], telemetry, turn: 2 }).runVisibleTests()
    assert(visible.status === 'pass', `${seed.seedId}: reference solution fails visible tests`)
    assert(reference.grade.pass, `${seed.seedId}: reference solution fails private runtime grade`)
    cases.push({
      seedId: seed.seedId,
      level: seed.level,
      workspaceHash: nativeTree.hash,
      witness,
      visibleStatus: visible.status,
      referenceGradePass: true,
    })
    process.stdout.write(`validated ${seed.seedId}\n`)
  } finally {
    await runtime.dispose()
  }
}

const report = {
  schemaVersion: 2,
  generatedAt: new Date().toISOString(),
  passed: cases.length === allSeeds().length,
  caseCount: cases.length,
  sourceTreeHash: preregistration.sourceTree.hash,
  assertions: [
    'Agent-readable workspace trees are byte-identical across arms for every seed.',
    'Common tool declarations are byte-identical; Relational adds exactly one read-only query.',
    'The composed query agrees with independently read native state in every seeded fixture.',
    'The reference action sequence passes visible and private executable checks for all 36 frozen seeds.',
    'Task cards and Agent-readable files pass the information-firewall scan.',
  ],
  cases,
  digest: hashJson(cases),
}
await writeFile('artifacts/parity-validation.json', JSON.stringify(report, null, 2) + '\n')
console.log(`parity/reference closure passed for ${cases.length} seeds; digest ${report.digest}`)

function validateToolDelta(seedId, turn, nativeDeclarations, relationalDeclarations) {
  const relationalOnly = relationalDeclarations.filter(item => !nativeDeclarations.some(native => native.name === item.name))
  assert(relationalOnly.length === 1 && relationalOnly[0].name === 'software_semantic_query', `${seedId} turn ${turn}: relational-only delta is not exactly one query`)
  const common = relationalDeclarations.filter(item => item.name !== 'software_semantic_query')
  assert(hashJson(common) === hashJson(nativeDeclarations), `${seedId} turn ${turn}: common tool schema mismatch`)
}

function validateSemanticWitness(seed, runtime) {
  const query = runtime.semanticQuery({
    query: 'explain_composite_incident',
    subject: { pluginId: runtime.publicState.pluginId, failedSnapshotId: runtime.publicState.failedSnapshotId },
  })
  const inventory = runtime.dynamicInventory().find(row => String(row.pluginId) === runtime.publicState.pluginId)
  assert(String(inventory.currentPackageId) === runtime.publicState.v1PackageId, `${seed.seedId}: native last-successful mismatch`)
  assert(String(inventory.nextPackageId) === runtime.publicState.v2PackageId, `${seed.seedId}: native failed-target mismatch`)
  assert(inventory.activeRun === undefined, `${seed.seedId}: native active run should be absent`)
  assert(query.dynamic.lastSuccessfulPackageId === String(inventory.currentPackageId), `${seed.seedId}: query last-successful mismatch`)
  assert(query.dynamic.activeRun === null, `${seed.seedId}: query active run should be strongly absent`)

  const before = runtime.nativeSnapshot(runtime.publicState.beforeCheckpointId)
  const direct = before.fibers.find(row => row.name === seed.directConsumerName)
  assert(direct?.targetBindings?.[seed.serviceKey], `${seed.seedId}: direct native binding absent`)
  assert(query.impact.directConsumers.includes(seed.directConsumerName), `${seed.seedId}: query direct impact absent`)
  if (seed.level >= 2) {
    const transitive = before.fibers.find(row => row.name === seed.transitiveConsumerName)
    assert(transitive?.targetBindings?.[seed.derivedServiceKey], `${seed.seedId}: transitive native binding absent`)
    assert(query.impact.transitiveConsumers.includes(seed.transitiveConsumerName), `${seed.seedId}: query transitive impact absent`)
    assert(query.externalEffects.coverage === 'unavailable', `${seed.seedId}: external boundary collapsed`)
  }
  if (seed.level >= 3) {
    const loading = runtime.nativeSnapshot(runtime.publicState.loadingCheckpointId)
    const consumer = loading.fibers.find(row => row.name === seed.auxiliaryConsumerName)
    assert(consumer.state === 'loading', `${seed.seedId}: auxiliary consumer not loading`)
    assert(consumer.committedBindings[seed.auxiliaryServiceKey].providerName === seed.auxiliaryProviderV1, `${seed.seedId}: native committed provider mismatch`)
    assert(consumer.targetBindings[seed.auxiliaryServiceKey].providerName === seed.auxiliaryProviderV2, `${seed.seedId}: native target provider mismatch`)
    assert(query.auxiliary.committed.providerName === seed.auxiliaryProviderV1, `${seed.seedId}: query committed provider mismatch`)
    assert(query.auxiliary.target.providerName === seed.auxiliaryProviderV2, `${seed.seedId}: query target provider mismatch`)
  }
  return {
    lastSuccessful: query.dynamic.lastSuccessfulPackageId,
    failedTarget: query.dynamic.failedOrInProgressTargetPackageId,
    activeRun: query.dynamic.activeRun,
    direct: query.impact.directConsumers,
    transitive: query.impact.transitiveConsumers,
    auxiliaryDiverged: query.auxiliary?.diverged ?? false,
    externalCoverage: query.externalEffects.coverage,
  }
}

function validateFirewall(seed, card, files) {
  const corpus = [card, ...Object.entries(files).flat()].join('\n').toLowerCase()
  const forbidden = [
    'expected superiority', 'prior a/b', 'reference solution', 'private oracle',
    'hidden oracle', 'other-arm', 'other arm trajectory', 'semantic mirror rationale',
    'concurrent-horn', 'joint canonicity', 'p_0',
  ]
  for (const fragment of forbidden) assert(!corpus.includes(fragment), `${seed.seedId}: firewall phrase leaked: ${fragment}`)
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}
