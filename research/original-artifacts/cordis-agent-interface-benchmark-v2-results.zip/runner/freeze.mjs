import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { ARMS, DIFFICULTY, EXPERIMENT, TASK_IDS, TURN_TWO_APPROVAL } from '../src/config.mjs'
import { hashJson, hashTree } from '../src/hash.mjs'
import { commonSystemPrompt } from '../src/common-prompt.mjs'
import { calibrationSeeds } from './seed-catalog.mjs'
import { calibrationRunOrder } from './run-order.mjs'

const sourceTree = await hashTree('.', { exclude: excludedFromFreeze })
const packageLockHash = hashJson(JSON.parse(await readFile('package-lock.json', 'utf8')))
const preregistration = {
  schemaVersion: 2,
  frozenAt: new Date().toISOString(),
  experiment: EXPERIMENT,
  estimand: EXPERIMENT.hypothesis,
  phase: '12-run paired difficulty-calibration experiment; descriptive boundary localization, not confirmatory efficacy testing',
  tasks: TASK_IDS.map(taskId => ({ taskId, difficulty: DIFFICULTY[taskId] })),
  semanticComplexityAxes: [
    'cross-subsystem span: dynamic package/run to service, fiber, and effect',
    'temporal span: D0 stable, optional D1 in-flight replacement, D2 failed update, D3 repair',
    'branching: safe and unsafe recovery strategies',
    'constraints: preserve Plugin identity, effect ownership, exact handle, and live auxiliary consumer',
    'counterfactual: consequence of withdrawing the selected provider during paused loading',
  ],
  antiNoiseConstraints: [
    'no unrelated source files, random decoys, prompt padding, or intentionally hidden APIs',
    'difficulty increases only by executable lifecycle semantics and constraints',
  ],
  arms: ARMS,
  calibrationSeeds: calibrationSeeds().map(seed => seed.seedId),
  runCount: calibrationSeeds().length * ARMS.length,
  runOrder: calibrationRunOrder().map(({ seed, arm }) => ({ seedId: seed.seedId, arm })),
  invariantControls: [
    'same requested model and one reported model version per run',
    'same thinking level, temperature, sampling seed, tool budget, timeout, task card, workspace, and runtime semantics',
    'fresh conversation and fresh runtime for every run',
    'no fallback and one HTTP attempt per model request',
  ],
  permittedArmDifference: 'Relational adds exactly one read-only software_semantic_query; all common tools are schema-identical.',
  informationFirewall: [
    'no theory paper or companion',
    'no semantic-interface motivation, expected direction, or prior A/B result',
    'no private oracle, scorer, reference solution, other-arm trajectory, or prior trajectory',
  ],
  outcomes: {
    correctness: 'structured semantic closure AND hidden executable runtime grade AND zero critical semantic errors',
    failureBoundarySignal: 'paired correctness and closure by easy/medium/hard level; descriptive only at n=2 pairs per level',
    reconstructionBurden: [
      'calls to first sufficient evidence',
      'observation calls and native state domains touched',
      'repeated observation calls',
      'gross input and output-plus-thinking tokens',
      'tool-result bytes',
      'unsupported state judgments',
      'incorrect structured semantic facts',
      'plan-to-action sequence deviation',
    ],
  },
  parserPolicy: 'select the last fenced JSON object and require it to be terminal; earlier code/diff fences are allowed',
  stoppingRule: 'execute exactly the twelve frozen run slots once; infrastructure-invalid slots remain invalid and are not silently replaced',
  expansionGate: 'do not launch a larger study unless calibration shows non-ceiling variance or a replicated burden signal without harness defects',
  turnTwoApproval: TURN_TWO_APPROVAL,
  commonPromptHash: hashJson(commonSystemPrompt()),
  sourceTree,
  packageLockHash,
}
await mkdir('artifacts', { recursive: true })
await writeFile('artifacts/preregistration.json', JSON.stringify(preregistration, null, 2) + '\n')
console.log(`frozen ${sourceTree.entries.length} files as ${sourceTree.hash}`)

function excludedFromFreeze(name, entry) {
  return name === 'node_modules'
    || name.startsWith('node_modules/')
    || name === 'artifacts'
    || name.startsWith('artifacts/')
    || name === 'runs'
    || name.startsWith('runs/')
    || name === 'workspaces'
    || name.startsWith('workspaces/')
    || name.startsWith('tmp-l')
    || (entry.isFile() && name === 'package-lock.json')
}
