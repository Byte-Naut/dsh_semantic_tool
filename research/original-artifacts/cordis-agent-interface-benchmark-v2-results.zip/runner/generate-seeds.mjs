import { mkdir, writeFile } from 'node:fs/promises'
import { allSeeds, calibrationSeeds } from './seed-catalog.mjs'
import { hashJson } from '../src/hash.mjs'

await mkdir('artifacts', { recursive: true })
const all = allSeeds().map(seed => ({ ...seed, hash: hashJson(seed) }))
const selected = new Set(calibrationSeeds().map(seed => seed.seedId))
await writeFile('artifacts/seeds.json', JSON.stringify({
  generatedAt: new Date().toISOString(),
  all,
  calibration: all.filter(seed => selected.has(seed.seedId)),
}, null, 2) + '\n')
console.log(`generated ${all.length} fixture seeds; calibration uses ${selected.size}`)
