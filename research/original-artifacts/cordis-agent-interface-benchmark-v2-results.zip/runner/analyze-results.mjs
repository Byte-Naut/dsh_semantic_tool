import { readFile, readdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { DIFFICULTY, EXPERIMENT } from '../src/config.mjs'

const directories = (await readdir('runs', { withFileTypes: true }))
  .filter(entry => entry.isDirectory()).map(entry => entry.name).sort()
const results = []
for (const directory of directories) results.push(JSON.parse(await readFile(join('runs', directory, 'result.json'), 'utf8')))
if (results.length !== 12) throw new Error(`expected 12 run results, found ${results.length}`)

const valid = results.filter(row => row.validity === 'valid')
const invalid = results.filter(row => row.validity !== 'valid')
const pairs = pairResults(valid)
const byArm = Object.fromEntries(['native', 'relational'].map(arm => [arm, summarize(valid.filter(row => row.arm === arm))]))
const byLevel = Object.fromEntries(Object.entries(DIFFICULTY).map(([taskId, label]) => {
  const rows = valid.filter(row => row.taskId === taskId)
  return [label, {
    taskId,
    native: summarize(rows.filter(row => row.arm === 'native')),
    relational: summarize(rows.filter(row => row.arm === 'relational')),
    paired: summarizePairs(pairs.filter(pair => pair.native.taskId === taskId)),
  }]
}))
const paired = summarizePairs(pairs)
const costs = valid.map(row => row.costUsd ?? 0)
const analysis = {
  schemaVersion: 2,
  experimentId: EXPERIMENT.id,
  generatedAt: new Date().toISOString(),
  interpretation: 'preregistered 12-run paired difficulty calibration; descriptive, not confirmatory',
  hypothesis: EXPERIMENT.hypothesis,
  runCount: results.length,
  validCount: valid.length,
  invalidCount: invalid.length,
  invalidRuns: invalid.map(row => ({ runId: row.runId, validity: row.validity, error: row.error ?? null })),
  observedModelVersions: [...new Set(valid.flatMap(row => row.reportedModelVersions ?? []))],
  arms: byArm,
  levels: byLevel,
  paired,
  failureBoundarySignal: boundarySignal(byLevel),
  costProjection: {
    observedCalibrationUsd: round(sum(results.map(row => row.costUsd ?? 0))),
    meanPerValidRunUsd: round(mean(costs)),
    maxObservedRunUsd: round(Math.max(0, ...costs)),
    projected72AtObservedMeanUsd: round(mean(costs) * 72),
    projected72AtObservedMaximumUsd: round(Math.max(0, ...costs) * 72),
  },
}
await writeFile('artifacts/calibration-analysis.json', JSON.stringify(analysis, null, 2) + '\n')
await writeFile('artifacts/calibration-report.md', renderReport(analysis, results))
console.log(`analyzed ${results.length} runs (${valid.length} valid); observed cost $${analysis.costProjection.observedCalibrationUsd}`)

function summarize(rows) {
  const burden = rows.map(row => row.score?.reconstructionBurden ?? {})
  return {
    n: rows.length,
    primaryPasses: rows.filter(row => row.score?.primaryPass).length,
    runtimePasses: rows.filter(row => row.score?.runtimePass).length,
    perfectSemanticClosure: rows.filter(row => row.score?.semanticClosure?.closureScore === 1).length,
    recordCompliant: rows.filter(row => row.score?.recordCompliance).length,
    criticalErrors: sum(rows.map(row => row.score?.criticalErrors?.length ?? 0)),
    meanSemanticClosure: round(mean(rows.map(row => row.score?.semanticClosure?.closureScore ?? 0))),
    meanToolCalls: round(mean(burden.map(row => row.totalToolCalls ?? 0))),
    meanObservationCalls: round(mean(burden.map(row => row.observationCalls ?? 0))),
    meanNativeObservationCalls: round(mean(burden.map(row => row.nativeObservationCalls ?? 0))),
    meanNativeDomainsTouched: round(mean(burden.map(row => row.nativeStateDomainsTouched ?? 0))),
    meanRepeatedObservations: round(mean(burden.map(row => row.repeatedObservationCalls ?? 0))),
    meanCallsToSufficientEvidence: round(mean(burden.map(row => row.callsToFirstSufficientEvidence).filter(value => value != null))),
    sufficientEvidenceReached: burden.filter(row => row.sufficientEvidenceReached).length,
    meanEvidenceCoverage: round(mean(burden.map(row => row.evidenceCoverage ?? 0))),
    meanUnsupportedJudgments: round(mean(burden.map(row => row.unsupportedJudgments ?? 0))),
    meanIncorrectSemanticFacts: round(mean(burden.map(row => row.incorrectSemanticFacts ?? 0))),
    meanPlanDeviation: round(mean(burden.map(row => row.planDeviationCount ?? 0))),
    meanGrossInputTokens: round(mean(burden.map(row => row.grossInputTokens ?? 0))),
    meanOutputAndThinkingTokens: round(mean(burden.map(row => row.grossOutputAndThinkingTokens ?? 0))),
    meanToolResultBytes: round(mean(burden.map(row => row.toolResultBytes ?? 0))),
    totalCostUsd: round(sum(rows.map(row => row.costUsd ?? 0))),
  }
}

function pairResults(rows) {
  const grouped = Map.groupBy(rows, row => row.seedId)
  return [...grouped.entries()].map(([seedId, entries]) => ({
    seedId,
    native: entries.find(row => row.arm === 'native'),
    relational: entries.find(row => row.arm === 'relational'),
  })).filter(pair => pair.native && pair.relational)
}

function summarizePairs(pairs) {
  const metric = (selector) => pairs.map(pair => selector(pair.relational) - selector(pair.native))
  const primary = metric(row => Number(Boolean(row.score.primaryPass)))
  const runtime = metric(row => Number(Boolean(row.score.runtimePass)))
  const closure = metric(row => row.score.semanticClosure.closureScore)
  const tools = metric(row => row.score.reconstructionBurden.totalToolCalls)
  const observations = metric(row => row.score.reconstructionBurden.observationCalls)
  const nativeObservations = metric(row => row.score.reconstructionBurden.nativeObservationCalls)
  const domains = metric(row => row.score.reconstructionBurden.nativeStateDomainsTouched)
  const repeated = metric(row => row.score.reconstructionBurden.repeatedObservationCalls)
  const input = metric(row => row.score.reconstructionBurden.grossInputTokens)
  const bytes = metric(row => row.score.reconstructionBurden.toolResultBytes)
  const cost = metric(row => row.costUsd)
  return {
    completePairs: pairs.length,
    primary: deltaSummary(primary, true),
    runtime: deltaSummary(runtime, true),
    semanticClosure: deltaSummary(closure, true),
    toolCalls: deltaSummary(tools, false),
    observationCalls: deltaSummary(observations, false),
    nativeObservationCalls: deltaSummary(nativeObservations, false),
    nativeDomainsTouched: deltaSummary(domains, false),
    repeatedObservations: deltaSummary(repeated, false),
    grossInputTokens: { ...deltaSummary(input, false), relativeMeanPercent: relativeMean(pairs, row => row.score.reconstructionBurden.grossInputTokens) },
    toolResultBytes: deltaSummary(bytes, false),
    costUsd: { ...deltaSummary(cost, false), relativeMeanPercent: relativeMean(pairs, row => row.costUsd) },
  }
}

function deltaSummary(values, higherBetter) {
  return {
    meanRelationalMinusNative: round(mean(values)),
    relationalBetterPairs: values.filter(value => higherBetter ? value > 0 : value < 0).length,
    ties: values.filter(value => value === 0).length,
    nativeBetterPairs: values.filter(value => higherBetter ? value < 0 : value > 0).length,
    values: values.map(round),
  }
}

function relativeMean(pairs, selector) {
  const nativeMean = mean(pairs.map(pair => selector(pair.native)))
  const relationalMean = mean(pairs.map(pair => selector(pair.relational)))
  return nativeMean === 0 ? null : round((relationalMean - nativeMean) / nativeMean * 100)
}

function boundarySignal(levels) {
  for (const name of ['easy', 'medium', 'hard']) {
    const level = levels[name]
    if (level.native.primaryPasses < level.native.n || level.relational.primaryPasses < level.relational.n) {
      return {
        firstNonCeilingLevel: name,
        relationalAdvantageAtBoundary: level.relational.primaryPasses - level.native.primaryPasses,
        conclusion: level.relational.primaryPasses > level.native.primaryPasses
          ? 'descriptive boundary-shift signal observed; replication required'
          : 'non-ceiling variance observed without a relational correctness advantage',
      }
    }
  }
  return { firstNonCeilingLevel: null, relationalAdvantageAtBoundary: 0, conclusion: 'correctness remained at ceiling; only burden differences are identifiable' }
}

function renderReport(a, results) {
  const rows = [...results].sort((left, right) => left.runId.localeCompare(right.runId))
  return `# Agent-facing runtime truth layer：v2 难度校准报告

## 实验状态

- 假设：${a.hypothesis}
- 设计：easy / medium / hard 各 2 个配对 seed，共 ${a.runCount} runs；有效 ${a.validCount}，无效 ${a.invalidCount}
- 模型版本：${a.observedModelVersions.join(', ') || 'none'}
- 推断边界：${a.interpretation}
- failure-boundary 信号：${a.failureBoundarySignal.conclusion}

## 总体双臂

| 指标 | Native | Relational |
|---|---:|---:|
| Primary pass | ${a.arms.native.primaryPasses}/${a.arms.native.n} | ${a.arms.relational.primaryPasses}/${a.arms.relational.n} |
| Hidden runtime pass | ${a.arms.native.runtimePasses}/${a.arms.native.n} | ${a.arms.relational.runtimePasses}/${a.arms.relational.n} |
| Perfect semantic closure | ${a.arms.native.perfectSemanticClosure}/${a.arms.native.n} | ${a.arms.relational.perfectSemanticClosure}/${a.arms.relational.n} |
| Mean semantic closure | ${a.arms.native.meanSemanticClosure} | ${a.arms.relational.meanSemanticClosure} |
| Mean tool calls | ${a.arms.native.meanToolCalls} | ${a.arms.relational.meanToolCalls} |
| Mean observation calls | ${a.arms.native.meanObservationCalls} | ${a.arms.relational.meanObservationCalls} |
| Mean native observation calls | ${a.arms.native.meanNativeObservationCalls} | ${a.arms.relational.meanNativeObservationCalls} |
| Mean native domains touched | ${a.arms.native.meanNativeDomainsTouched} | ${a.arms.relational.meanNativeDomainsTouched} |
| Mean repeat observations | ${a.arms.native.meanRepeatedObservations} | ${a.arms.relational.meanRepeatedObservations} |
| Mean gross input tokens | ${a.arms.native.meanGrossInputTokens} | ${a.arms.relational.meanGrossInputTokens} |
| Mean tool-result bytes | ${a.arms.native.meanToolResultBytes} | ${a.arms.relational.meanToolResultBytes} |
| Total estimated cost (USD) | ${a.arms.native.totalCostUsd} | ${a.arms.relational.totalCostUsd} |

## 难度边界

| Level | Native primary | Relational primary | Native closure | Relational closure | Δ input tokens R−N | Δ tool calls R−N |
|---|---:|---:|---:|---:|---:|---:|
${['easy', 'medium', 'hard'].map(name => {
  const level = a.levels[name]
  return `| ${name} | ${level.native.primaryPasses}/${level.native.n} | ${level.relational.primaryPasses}/${level.relational.n} | ${level.native.meanSemanticClosure} | ${level.relational.meanSemanticClosure} | ${level.paired.grossInputTokens.meanRelationalMinusNative} | ${level.paired.toolCalls.meanRelationalMinusNative} |`
}).join('\n')}

## 配对重建负担

- Gross input token：平均 R−N = ${a.paired.grossInputTokens.meanRelationalMinusNative}（${a.paired.grossInputTokens.relativeMeanPercent}%）
- Tool calls：平均 R−N = ${a.paired.toolCalls.meanRelationalMinusNative}；Relational 更少 ${a.paired.toolCalls.relationalBetterPairs}/${a.paired.completePairs} pairs
- Native observations：平均 R−N = ${a.paired.nativeObservationCalls.meanRelationalMinusNative}
- Native domains：平均 R−N = ${a.paired.nativeDomainsTouched.meanRelationalMinusNative}
- Tool-result bytes：平均 R−N = ${a.paired.toolResultBytes.meanRelationalMinusNative}
- 成本：平均相对变化 ${a.paired.costUsd.relativeMeanPercent}%

这些是冻结后的描述性校准结果，不是显著性检验；n=2 pairs/level 不支持一般化能力结论。

## 费用

- 本轮实际：$${a.costProjection.observedCalibrationUsd}
- 72 runs 按本轮均值：$${a.costProjection.projected72AtObservedMeanUsd}
- 72 runs 按本轮最大单次：$${a.costProjection.projected72AtObservedMaximumUsd}

## Run ledger

| Run | Valid | Primary | Runtime | Closure | Tools | Native obs | Input | Cost |
|---|---|---:|---:|---:|---:|---:|---:|---:|
${rows.map(row => `| ${row.runId} | ${row.validity} | ${Number(Boolean(row.score?.primaryPass))} | ${Number(Boolean(row.score?.runtimePass))} | ${round(row.score?.semanticClosure?.closureScore ?? 0)} | ${row.score?.reconstructionBurden?.totalToolCalls ?? ''} | ${row.score?.reconstructionBurden?.nativeObservationCalls ?? ''} | ${row.score?.reconstructionBurden?.grossInputTokens ?? ''} | ${row.costUsd ?? 0} |`).join('\n')}
`
}

function mean(values) { return values.length ? sum(values) / values.length : 0 }
function sum(values) { return values.reduce((total, value) => total + value, 0) }
function round(value) { return Number(Number(value).toFixed(4)) }
