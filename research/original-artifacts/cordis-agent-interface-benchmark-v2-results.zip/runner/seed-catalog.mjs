const WORDS = Object.freeze([
  ['harbor', 'beacon', 'pulse', 'amber'],
  ['orchard', 'ledger', 'index', 'cobalt'],
  ['quarry', 'signal', 'view', 'crimson'],
  ['marina', 'quota', 'panel', 'delta'],
  ['foundry', 'metric', 'screen', 'ember'],
  ['granary', 'route', 'digest', 'frost'],
  ['terrace', 'catalog', 'summary', 'garnet'],
  ['aviary', 'notice', 'feed', 'hazel'],
  ['citadel', 'status', 'report', 'indigo'],
  ['meadow', 'sample', 'projection', 'jade'],
  ['tundra', 'record', 'display', 'kelp'],
  ['estuary', 'channel', 'snapshot', 'lilac'],
])

const TASKS = Object.freeze([
  'l1-cross-layer-recovery',
  'l2-transitive-ownership',
  'l3-concurrent-boundary',
])

export function allSeeds() {
  return TASKS.flatMap(taskId => Array.from({ length: 12 }, (_, index) => seedFor(taskId, index + 1)))
}

export function calibrationSeeds() {
  return TASKS.flatMap(taskId => [seedFor(taskId, 1), seedFor(taskId, 2)])
}

export function seedFor(taskId, number) {
  if (!TASKS.includes(taskId)) throw new Error(`unknown task: ${taskId}`)
  if (!Number.isInteger(number) || number < 1 || number > 12) throw new Error(`seed number must be 1..12: ${number}`)
  const [place, service, derived, color] = WORDS[number - 1]
  const level = TASKS.indexOf(taskId) + 1
  const common = {
    taskId,
    level,
    number,
    seedId: `${taskId}-s${String(number).padStart(2, '0')}`,
    incidentId: `incident-${place}-${level}-${String(number).padStart(2, '0')}`,
    pluginPrefix: `${place.slice(0, 5)}${['e', 'm', 'h'][level - 1]}`,
    serviceKey: `${service}Endpoint`,
    derivedServiceKey: `${derived}View`,
    stableValue: `${color}-stable`,
    repairedValue: `${color}-repaired`,
    directConsumerName: `${place}-${service}-client`,
    transitiveConsumerName: `${place}-${derived}-publisher`,
    externalLabel: `${color}-delivery-callback`,
    failureMessage: `${color} update bootstrap failed`,
    checkpointBefore: `D0-${place}-stable`,
    checkpointFailed: `D2-${place}-failed-update`,
  }
  if (level < 3) return Object.freeze(common)
  return Object.freeze({
    ...common,
    auxiliaryServiceKey: `${color}AuxiliaryPort`,
    auxiliaryProviderV1: `${place}-${color}-aux-v1`,
    auxiliaryProviderV2: `${place}-${color}-aux-v2`,
    auxiliaryConsumerName: `${place}-${color}-aux-consumer`,
    auxiliaryValueV1: `${color}-aux-stable`,
    auxiliaryValueV2: `${color}-aux-target`,
    checkpointLoading: `D1-${place}-aux-loading`,
  })
}
