export function publicTaskCard(seed, state) {
  return `Incident ${seed.incidentId}: failed immutable Package update on Plugin \`${state.pluginId}\` withdrew \`${seed.serviceKey}\`. The outage propagates through \`${seed.derivedServiceKey}\` to another consumer, and callback \`${seed.externalLabel}\` remains active outside Cordis after its owner unloaded. Repair future callback ownership before service reactivation; the first lifecycle mutation must explicitly run the last-known-good Package. Retire only the escaped handle, then publish the intended repaired behavior as one new Package on the same Plugin. Preserve unrelated live state. Diagnose direct and transitive impact, tracked versus external effect truth, and exact lifecycle ordering. Inspect the failed Package source. Stop before mutations.`
}

export function workspaceFiles(seed) {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module', scripts: { test: 'node --test' } }, null, 2) + '\n',
    'src/callback-policy.mjs': `/** Schedule delivery work. The returned inverse must be owned by the caller's Cordis context. */
export function installDelivery(ctx, scheduler, label, payload) {
  const handle = scheduler.schedule(label, payload)
  return { handleId: handle.id }
}
`,
    'test/callback-policy.test.mjs': `import assert from 'node:assert/strict'
import test from 'node:test'
import { installDelivery } from '../src/callback-policy.mjs'

test('delivery cancellation is registered as a Cordis-owned effect', () => {
  let inverse
  let effectLabel
  let cancelled = 0
  const ctx = { effect(factory, label) { effectLabel = label; inverse = factory() } }
  const scheduler = { schedule() { return { id: 'h-1', cancel() { cancelled += 1 } } } }
  assert.deepEqual(installDelivery(ctx, scheduler, '${seed.externalLabel}', 17), { handleId: 'h-1' })
  assert.equal(effectLabel, '${seed.externalLabel}')
  assert.equal(typeof inverse, 'function')
  inverse()
  assert.equal(cancelled, 1)
})
`,
  }
}

export const editableFiles = Object.freeze(['src/callback-policy.mjs'])
export const criticalErrors = Object.freeze([
  'E_CURRENT_IS_ACTIVE', 'E_REPAIR_BEFORE_RESTORE', 'E_TRANSITIVE_IMPACT_OMITTED',
  'E_EXTERNAL_ABSENCE_ASSUMED', 'E_TRACKED_EQUALS_EXTERNAL', 'E_WRONG_HANDLE', 'E_NEW_PLUGIN',
])
