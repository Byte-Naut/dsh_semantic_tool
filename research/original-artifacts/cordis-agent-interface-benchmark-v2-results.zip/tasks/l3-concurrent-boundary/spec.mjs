export function publicTaskCard(seed, state) {
  return `Incident ${seed.incidentId}: while auxiliary consumer \`${seed.auxiliaryConsumerName}\` is paused LOADING during provider replacement \`${seed.auxiliaryProviderV1}\` → \`${seed.auxiliaryProviderV2}\`, a separate immutable update on Plugin \`${state.pluginId}\` failed and withdrew \`${seed.serviceKey}\`. That outage propagates through \`${seed.derivedServiceKey}\`; callback \`${seed.externalLabel}\` escaped Cordis ownership. Repair future callback ownership and the status adapter before service reactivation; the first lifecycle mutation must explicitly run the last-known-good Package. Retire only the escaped handle, publish one new Package on the same Plugin, then resolve the already in-flight auxiliary transition without restarting or withdrawing its target. State the counterfactual consequence of withdrawing that target before the paused load settles. Distinguish committed versus target binding and known absence versus unavailable external truth. Inspect the failed Package source. Stop before mutations.`
}

export function workspaceFiles(seed) {
  return {
    ...callbackFiles(seed),
    'src/status-adapter.mjs': `function providerId(implementation) {
  return implementation?.fiber?.name ?? null
}

export function buildStatus(consumerFiber, serviceKey) {
  const target = consumerFiber._store?.[serviceKey]
  return { servingProviderId: providerId(target), targetProviderId: providerId(target), transitioning: false }
}
`,
    'test/status-adapter.test.mjs': `import assert from 'node:assert/strict'
import test from 'node:test'
import { buildStatus } from '../src/status-adapter.mjs'
const impl = name => ({ fiber: { name } })
test('paused work and reload target are separate', () => {
  const fiber = {
    store: { ${JSON.stringify(seed.auxiliaryServiceKey)}: impl('${seed.auxiliaryProviderV1}') },
    _store: { ${JSON.stringify(seed.auxiliaryServiceKey)}: impl('${seed.auxiliaryProviderV2}') },
  }
  assert.deepEqual(buildStatus(fiber, '${seed.auxiliaryServiceKey}'), {
    servingProviderId: '${seed.auxiliaryProviderV1}', targetProviderId: '${seed.auxiliaryProviderV2}', transitioning: true,
  })
})
`,
  }
}

function callbackFiles(seed) {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module', scripts: { test: 'node --test' } }, null, 2) + '\n',
    'src/callback-policy.mjs': `export function installDelivery(ctx, scheduler, label, payload) {
  const handle = scheduler.schedule(label, payload)
  return { handleId: handle.id }
}
`,
    'test/callback-policy.test.mjs': `import assert from 'node:assert/strict'
import test from 'node:test'
import { installDelivery } from '../src/callback-policy.mjs'
test('delivery cancellation is Cordis-owned', () => {
  let inverse; let label; let cancelled = 0
  const ctx = { effect(factory, value) { label = value; inverse = factory() } }
  const scheduler = { schedule() { return { id: 'h-1', cancel() { cancelled += 1 } } } }
  assert.deepEqual(installDelivery(ctx, scheduler, '${seed.externalLabel}', 17), { handleId: 'h-1' })
  assert.equal(label, '${seed.externalLabel}'); assert.equal(typeof inverse, 'function')
  inverse(); assert.equal(cancelled, 1)
})
`,
  }
}

export const editableFiles = Object.freeze(['src/callback-policy.mjs', 'src/status-adapter.mjs'])
export const criticalErrors = Object.freeze([
  'E_CURRENT_IS_ACTIVE', 'E_REPAIR_BEFORE_RESTORE', 'E_TRANSITIVE_IMPACT_OMITTED',
  'E_EXTERNAL_ABSENCE_ASSUMED', 'E_BINDING_COLLAPSE', 'E_WITHDRAW_TARGET',
  'E_WAIT_AWAY', 'E_WRONG_HANDLE', 'E_NEW_PLUGIN',
])
