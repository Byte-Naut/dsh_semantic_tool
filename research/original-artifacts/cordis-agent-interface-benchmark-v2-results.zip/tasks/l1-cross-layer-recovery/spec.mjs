export function publicTaskCard(seed, state) {
  return `Incident ${seed.incidentId}: a session-owned dynamic Plugin \`${state.pluginId}\` stopped serving \`${seed.serviceKey}\` after an immutable Package update failed. A Cordis consumer is now unavailable. Restore service with the smallest safe sequence, then publish the intended repaired behavior as one new immutable Package under the same Plugin. Preserve Plugin identity; do not overwrite a Package or create another Plugin. Before action, identify the last successful Package, failed target, actual active Run, affected consumer, and exact recovery mode. Inspect the failed Package source. Stop before mutations.`
}

export function workspaceFiles() {
  return {
    'package.json': JSON.stringify({ private: true, type: 'module', scripts: { test: 'node --test' } }, null, 2) + '\n',
    'README.md': '# Cross-layer recovery\n\nUse runtime evidence and immutable Package lifecycle operations.\n',
    'test/smoke.test.mjs': "import test from 'node:test'\nimport assert from 'node:assert/strict'\ntest('workspace is isolated', () => assert.equal(1 + 1, 2))\n",
  }
}

export const editableFiles = Object.freeze([])
export const criticalErrors = Object.freeze([
  'E_CURRENT_IS_ACTIVE', 'E_REPAIR_BEFORE_RESTORE', 'E_WRONG_ROLLBACK_MODE',
  'E_NEW_PLUGIN', 'E_OVERWRITE_VERSION', 'E_DIRECT_IMPACT_OMITTED',
])
