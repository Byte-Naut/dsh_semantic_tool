import { pathToFileURL } from 'node:url'
import { Context } from '@deepseek-ai/cordis'
import DynamicCordisRunnerService from '@deepseek-ai/dsh-cordis-host-runner'
import { FakeExternalScheduler } from '../src/fake-scheduler.mjs'
import { captureCordisNative } from '../src/native-snapshot.mjs'
import { safePath } from '../src/workspace.mjs'
import { CordisCollector, stateName } from '../vendor/semantic-mirror-v0.3/collector.mjs'
import { DynamicPackageCollector } from '../vendor/semantic-mirror-v0.3/dynamic-collector.mjs'
import { explainCompositeIncident } from '../vendor/semantic-mirror-v0.3/composite-query.mjs'

export async function createCompositeRuntime(seed, workspace, level) {
  if (seed.level !== level) throw new Error(`seed level ${seed.level} does not match task level ${level}`)
  const root = new Context()
  const scheduler = new FakeExternalScheduler()
  const fixtureEvents = []
  const dynamicEvents = []
  const actionLog = []
  const observationLog = []
  const activity = { directApplies: [], directDisposes: [], transitiveApplies: [], transitiveDisposes: [] }
  const collector = new CordisCollector(root, { runtimeId: `rt:${seed.seedId}` })
  await collector.attach()
  const disposeTools = root.provide('tools', Object.freeze({}))
  for (const eventName of ['cordis/dynamic-package', 'cordis/dynamic-retract']) {
    root.on(eventName, payload => dynamicEvents.push({ eventName, payload: sourceFree(payload) }))
  }
  const runnerFiber = root.plugin(DynamicCordisRunnerService)
  await runnerFiber
  const runner = root.dynamicCordisRunner
  const agent = Object.freeze({ id: `session:${seed.seedId}`, steer() {}, inject() {} })

  const v1 = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'new', idPrefix: seed.pluginPrefix },
    name: `${seed.pluginPrefix} stable package`,
    purpose: 'serve the primary incident endpoint',
    code: { host: validHostCode(seed.serviceKey, seed.stableValue) },
  })
  const v1Receipt = await runner.run(agent, v1.pluginId, v1.packageId, 'run')
  if (!v1Receipt.ok) throw new Error(v1Receipt.message)

  const DirectConsumer = {
    name: seed.directConsumerName,
    inject: [seed.serviceKey],
    async apply(ctx) {
      const value = ctx[seed.serviceKey].version
      activity.directApplies.push(value)
      ctx.effect(() => () => activity.directDisposes.push(value), `tracked:direct:${value}`)
      if (level >= 2) {
        const policy = await loadWorkspaceModule(workspace, 'src/callback-policy.mjs')
        const installed = policy.installDelivery(ctx, scheduler, seed.externalLabel, value)
        fixtureEvents.push({ kind: 'delivery-installed', handleId: installed?.handleId ?? null, value })
        ctx.provide(seed.derivedServiceKey, Object.freeze({ version: `derived:${value}` }))
      }
    },
  }
  const direct = root.plugin(DirectConsumer)
  await direct

  let transitive = null
  if (level >= 2) {
    transitive = root.plugin({
      name: seed.transitiveConsumerName,
      inject: [seed.derivedServiceKey],
      apply(ctx) {
        const value = ctx[seed.derivedServiceKey].version
        activity.transitiveApplies.push(value)
        ctx.effect(() => () => activity.transitiveDisposes.push(value), `tracked:transitive:${value}`)
      },
    })
    await transitive
  }

  const primaryImpl = root.reflect._getImpl(seed.serviceKey, false)
  if (!primaryImpl) throw new Error('primary dynamic service did not become visible')
  const selectedServiceImplId = collector.serviceImplId(primaryImpl)
  const cordisBefore = collector.capture(seed.checkpointBefore)
  const nativeBefore = captureCordisNative({
    label: seed.checkpointBefore,
    root,
    collector,
    fibers: [direct, ...(transitive ? [transitive] : [])],
  })
  const initialEscapedHandleId = level >= 2
    ? scheduler.activeJobs().find(job => job.label === seed.externalLabel)?.id ?? null
    : null
  if (level >= 2 && !initialEscapedHandleId) throw new Error('ownership defect did not create an escaped handle')

  let auxiliary = null
  let cordisLoading = null
  let nativeLoading = null
  if (level >= 3) {
    auxiliary = await startAuxiliaryReplacement({ root, collector, seed, fixtureEvents })
    cordisLoading = collector.capture(seed.checkpointLoading)
    nativeLoading = captureCordisNative({
      label: seed.checkpointLoading,
      root,
      collector,
      fibers: [direct, transitive, auxiliary.providerV1, auxiliary.providerV2, auxiliary.consumer],
    })
  }

  const v2 = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'existing', pluginId: v1.pluginId },
    name: `${seed.pluginPrefix} intended repair`,
    purpose: 'publish the intended repaired endpoint behavior',
    code: { host: brokenHostCode(seed) },
  })
  const failedReceipt = await runner.run(agent, v1.pluginId, v2.packageId, 'update')
  if (failedReceipt.ok || failedReceipt.reason !== 'host-half-failed') {
    throw new Error('fixture did not produce required host update failure')
  }
  await waitFor(() => stateName(direct.state) === 'pending')
  if (transitive) await waitFor(() => stateName(transitive.state) === 'pending')

  const dynamicCollector = new DynamicPackageCollector(runner, { runtimeId: `rt:${seed.seedId}:dynamic` })
  const dynamicFailed = dynamicCollector.capture(seed.checkpointFailed)
  const cordisFailed = collector.capture(seed.checkpointFailed)
  const nativeFailed = captureCordisNative({
    label: seed.checkpointFailed,
    root,
    collector,
    fibers: [direct, ...(transitive ? [transitive] : []), ...(auxiliary ? [auxiliary.providerV1, auxiliary.providerV2, auxiliary.consumer] : [])],
  })

  const snapshots = new Map()
  addSnapshot(snapshots, seed.checkpointBefore, cordisBefore, nativeBefore)
  if (cordisLoading) addSnapshot(snapshots, seed.checkpointLoading, cordisLoading, nativeLoading)
  addSnapshot(snapshots, seed.checkpointFailed, cordisFailed, nativeFailed)
  const pluginId = String(v1.pluginId)
  const v1PackageId = String(v1.packageId)
  const v2PackageId = String(v2.packageId)
  let auxiliaryResolution = null

  const runtime = {
    taskId: seed.taskId,
    seed,
    publicState: {
      pluginId,
      v1PackageId,
      v2PackageId,
      failedSnapshotId: dynamicFailed.id,
      beforeCheckpointId: cordisBefore.id,
      failedCheckpointId: cordisFailed.id,
      ...(cordisLoading ? { loadingCheckpointId: cordisLoading.id } : {}),
    },
    checkpoints() {
      return [
        { alias: seed.checkpointBefore, snapshotId: cordisBefore.id, phase: 'primary-active-before-update' },
        ...(cordisLoading ? [{ alias: seed.checkpointLoading, snapshotId: cordisLoading.id, phase: 'auxiliary-consumer-loading-provider-replacement' }] : []),
        { alias: seed.checkpointFailed, snapshotId: cordisFailed.id, dynamicSnapshotId: dynamicFailed.id, phase: 'primary-update-failed' },
      ]
    },
    nativeSnapshot(checkpointId) {
      return resolveSnapshot(snapshots, checkpointId ?? seed.checkpointFailed).native
    },
    dynamicInventory() {
      observationLog.push({ kind: 'dynamic-inventory' })
      return sourceFree(runner.inventory())
    },
    inspectPackage({ pluginId: requestedPlugin, packageId }) {
      observationLog.push({ kind: 'inspect-package', pluginId: requestedPlugin, packageId })
      return sourceFree(runner.inspectPackage(agent, requestedPlugin, packageId))
    },
    nativeEvents() {
      return {
        cordis: collector.eventLog(),
        dynamic: sourceFree(dynamicEvents),
        fixture: sourceFree(fixtureEvents),
        failedReceipt: sourceFree(failedReceipt),
      }
    },
    externalEffects() {
      observationLog.push({ kind: 'external-effects' })
      return {
        coverage: 'complete_for_fixture_scheduler',
        activeJobs: scheduler.activeJobs(),
        allJobs: scheduler.jobs(),
        warning: 'this oracle is outside Cordis tracked-effect coverage',
      }
    },
    semanticQuery(request) {
      if (request.query !== 'explain_composite_incident') throw new Error(`unsupported query: ${request.query}`)
      if (request.subject?.pluginId !== pluginId) throw new Error(`unknown selected plugin: ${request.subject?.pluginId}`)
      if (request.subject?.failedSnapshotId && request.subject.failedSnapshotId !== dynamicFailed.id) {
        throw new Error(`unknown failed snapshot: ${request.subject.failedSnapshotId}`)
      }
      observationLog.push({ kind: 'semantic-query' })
      return explainCompositeIncident({
        level,
        pluginId,
        dynamicFailed,
        cordisBefore,
        selectedServiceImplId,
        auxiliaryLoading: cordisLoading,
        auxiliaryConsumerId: auxiliary ? collector.fiberId(auxiliary.consumer) : null,
        auxiliaryServiceKey: seed.auxiliaryServiceKey,
      })
    },
    async definePackage({ pluginId: requestedPlugin, name, purpose, hostCode }) {
      if (requestedPlugin !== pluginId) throw new Error('only the existing selected Plugin may receive a Package')
      const definition = runner.define({
        sessionId: agent.id,
        plugin: { kind: 'existing', pluginId: requestedPlugin },
        name,
        purpose,
        code: { host: hostCode },
      })
      actionLog.push({ kind: 'define', pluginId: requestedPlugin, packageId: String(definition.packageId) })
      return sourceFree(definition)
    },
    async runPackage({ pluginId: requestedPlugin, packageId, mode }) {
      const receipt = await runner.run(agent, requestedPlugin, packageId, mode)
      await settleMicrotasks()
      const entry = {
        kind: 'run', pluginId: requestedPlugin, packageId, mode,
        receipt: sourceFree(receipt), visibleValue: visibleVersion(root, seed.serviceKey),
      }
      actionLog.push(entry)
      return { ...sourceFree(receipt), observedServiceValue: entry.visibleValue }
    },
    ...(level >= 2 ? {
      retireEscapedHandle({ handleId }) {
        if (handleId !== initialEscapedHandleId) throw new Error('handle is not the exact escaped incident handle')
        const cancelled = scheduler.cancel(handleId)
        actionLog.push({ kind: 'retire-external', handleId, cancelled })
        return { handleId, cancelled, remainingActive: scheduler.activeJobs() }
      },
    } : {}),
    ...(level >= 3 ? {
      async auxiliaryTransition({ action }) {
        if (auxiliaryResolution) throw new Error('auxiliary transition is already resolved')
        const adapter = await loadWorkspaceModule(workspace, 'src/status-adapter.mjs')
        const pausedStatus = adapter.buildStatus(auxiliary.consumer, seed.auxiliaryServiceKey)
        if (action === 'withdraw_target_before_settle') {
          await auxiliary.providerV2.dispose()
          auxiliary.gate.resolve()
          await Promise.allSettled([auxiliary.consumer.await(), auxiliary.providerV1Disposal])
        } else if (action === 'allow_current_load_to_settle') {
          auxiliary.gate.resolve()
          await Promise.all([auxiliary.consumer.await(), auxiliary.providerV1Disposal])
        } else {
          throw new Error(`unknown auxiliary action: ${action}`)
        }
        await settleMicrotasks()
        const convergedStatus = adapter.buildStatus(auxiliary.consumer, seed.auxiliaryServiceKey)
        auxiliaryResolution = { action, pausedStatus, convergedStatus, consumerState: stateName(auxiliary.consumer.state) }
        actionLog.push({ kind: 'auxiliary-transition', ...sourceFree(auxiliaryResolution) })
        return sourceFree(auxiliaryResolution)
      },
    } : {}),
    evidenceTagsForTool(name, args) {
      if (name === 'software_semantic_query') {
        return [
          'dynamic_truth', 'direct_impact', 'tracked_effects',
          ...(level >= 2 ? ['transitive_impact'] : []),
          ...(level >= 3 ? ['binding_divergence', 'counterfactual'] : []),
        ]
      }
      if (name === 'native_dynamic_inventory') return ['dynamic_truth']
      if (name === 'native_inspect_package' && String(args.packageId) === v2PackageId) return ['failed_source']
      if (name === 'native_inspect_fiber') {
        if (args.fiberId === seed.directConsumerName || args.fiberId === collector.fiberId(direct)) return ['direct_impact', 'tracked_effects']
        if (transitive && (args.fiberId === seed.transitiveConsumerName || args.fiberId === collector.fiberId(transitive))) return ['transitive_impact', 'tracked_effects']
        if (auxiliary && (args.fiberId === seed.auxiliaryConsumerName || args.fiberId === collector.fiberId(auxiliary.consumer))) return ['binding_divergence']
      }
      if (name === 'native_external_effects') return ['external_effect_truth']
      if (name === 'native_event_slice' && level >= 3) return ['counterfactual']
      if (name === 'read_file' && args.path === 'src/callback-policy.mjs') return ['ownership_source']
      if (name === 'read_file' && args.path === 'src/status-adapter.mjs') return ['adapter_source']
      return []
    },
    async grade() {
      const selected = sourceFree(runner.inspectPlugin(agent, pluginId))
      const packageIdsBefore = new Set([v1PackageId, v2PackageId])
      const newPackages = selected.packages.filter(pkg => !packageIdsBefore.has(String(pkg.packageId)))
      const firstLifecycle = actionLog.find(action => ['define', 'run'].includes(action.kind))
      const restoredFirst = firstLifecycle?.kind === 'run'
        && firstLifecycle.pluginId === pluginId
        && firstLifecycle.packageId === v1PackageId
        && firstLifecycle.mode === 'run'
        && firstLifecycle.receipt.ok === true
      const activePackageId = selected.activeRun?.packageId == null ? null : String(selected.activeRun.packageId)
      const packageStateCorrect = newPackages.length === 1
        && activePackageId === String(newPackages[0].packageId)
        && String(selected.currentPackageId) === activePackageId
        && selected.nextPackageId === undefined
      const inspectedFailedSource = observationLog.some(entry => entry.kind === 'inspect-package'
        && entry.pluginId === pluginId && entry.packageId === v2PackageId)
      const primaryCorrect = visibleVersion(root, seed.serviceKey) === seed.repairedValue
        && stateName(direct.state) === 'active'
        && (!transitive || stateName(transitive.state) === 'active')
      const ownership = level >= 2 ? await gradeOwnership(workspace, seed, scheduler, initialEscapedHandleId, direct) : { pass: true }
      const auxGrade = level >= 3 ? await gradeAuxiliary(workspace, seed, auxiliary, auxiliaryResolution) : { pass: true }
      const result = {
        actionLog: sourceFree(actionLog),
        selected,
        inspectedFailedSource,
        restoredFirst,
        packageStateCorrect,
        primaryCorrect,
        directState: stateName(direct.state),
        transitiveState: transitive ? stateName(transitive.state) : null,
        finalServiceValue: visibleVersion(root, seed.serviceKey),
        ownership,
        auxiliary: auxGrade,
        pluginCount: runner.listPlugins(agent).length,
      }
      return {
        ...result,
        pass: inspectedFailedSource && restoredFirst && packageStateCorrect && primaryCorrect
          && result.pluginCount === 1 && ownership.pass && auxGrade.pass,
      }
    },
    async dispose() {
      if (auxiliary && !auxiliaryResolution) {
        auxiliary.gate.resolve()
        await Promise.allSettled([auxiliary.consumer.await(), auxiliary.providerV1Disposal])
      }
      await Promise.allSettled([
        ...(auxiliary ? [auxiliary.consumer.dispose(), auxiliary.providerV1.dispose(), auxiliary.providerV2.dispose()] : []),
        ...(transitive ? [transitive.dispose()] : []),
        direct.dispose(),
      ])
      await runnerFiber.dispose()
      await collector.detach()
      await disposeTools()
    },
  }
  return runtime
}

async function startAuxiliaryReplacement({ root, collector, seed, fixtureEvents }) {
  const gate = deferred()
  const started = deferred()
  const activity = { applied: [], completed: [], disposed: [] }
  let applyCount = 0
  const provider = (name, version) => ({
    name,
    apply(ctx) {
      ctx.provide(seed.auxiliaryServiceKey, Object.freeze({ version }))
      ctx.effect(() => () => activity.disposed.push(version), `aux-provider:${version}`)
    },
  })
  const providerV1 = root.plugin(provider(seed.auxiliaryProviderV1, seed.auxiliaryValueV1))
  await providerV1
  const consumer = root.plugin({
    name: seed.auxiliaryConsumerName,
    inject: [seed.auxiliaryServiceKey],
    async apply(ctx) {
      const version = ctx[seed.auxiliaryServiceKey].version
      const call = ++applyCount
      activity.applied.push(version)
      ctx.effect(() => () => activity.disposed.push(`consumer:${version}`), `aux-consumer:${version}`)
      if (call === 1) {
        started.resolve()
        await gate.promise
      }
      activity.completed.push(version)
    },
  })
  await started.promise
  const providerV1Disposal = providerV1.dispose()
  await waitFor(() => root.reflect._getImpl(seed.auxiliaryServiceKey, false) === undefined)
  const providerV2 = root.plugin(provider(seed.auxiliaryProviderV2, seed.auxiliaryValueV2))
  await providerV2
  fixtureEvents.push({ kind: 'auxiliary-replacement-paused', consumerFiberId: collector.fiberId(consumer) })
  return { gate, activity, providerV1, providerV2, providerV1Disposal, consumer }
}

async function gradeOwnership(workspace, seed, scheduler, escapedHandleId, direct) {
  let inverse
  let effectLabel
  let cancelCount = 0
  const module = await loadWorkspaceModule(workspace, 'src/callback-policy.mjs')
  const handle = { id: 'hidden-handle', cancel() { cancelCount += 1; return true } }
  const ctx = { effect(factory, label) { effectLabel = label; inverse = factory() } }
  let returned
  try {
    returned = module.installDelivery(ctx, { schedule() { return handle } }, seed.externalLabel, 'hidden')
    if (typeof inverse === 'function') inverse()
  } catch (error) {
    return { pass: false, error: error instanceof Error ? error.message : String(error) }
  }
  const escaped = scheduler.jobs().find(job => job.id === escapedHandleId)
  const liveTracked = direct.getEffects().some(effect => effect.label === seed.externalLabel
    || effect.children?.some(child => child.label === seed.externalLabel))
  const pass = returned?.handleId === handle.id
    && effectLabel === seed.externalLabel
    && cancelCount === 1
    && escaped?.active === false
    && escaped?.cancelCount === 1
    && liveTracked
  return {
    pass,
    hiddenInverseRegistered: typeof inverse === 'function',
    hiddenCancelCount: cancelCount,
    hiddenEffectLabel: effectLabel ?? null,
    escapedHandle: escaped ?? null,
    finalActiveJobs: scheduler.activeJobs(),
    liveTracked,
  }
}

async function gradeAuxiliary(workspace, seed, auxiliary, resolution) {
  const adapter = await loadWorkspaceModule(workspace, 'src/status-adapter.mjs')
  const missingCommitted = adapter.buildStatus({ store: {}, _store: auxiliary.consumer._store }, seed.auxiliaryServiceKey)
  const pausedCorrect = resolution?.pausedStatus?.servingProviderId === seed.auxiliaryProviderV1
    && resolution?.pausedStatus?.targetProviderId === seed.auxiliaryProviderV2
    && resolution?.pausedStatus?.transitioning === true
  const convergedCorrect = resolution?.convergedStatus?.servingProviderId === seed.auxiliaryProviderV2
    && resolution?.convergedStatus?.targetProviderId === seed.auxiliaryProviderV2
    && resolution?.convergedStatus?.transitioning === false
    && resolution?.consumerState === 'active'
  const unknownPreserved = missingCommitted.servingProviderId == null
    && missingCommitted.targetProviderId === seed.auxiliaryProviderV2
    && missingCommitted.transitioning == null
  const disposedV1ExactlyOnce = auxiliary.activity.disposed.filter(value => value === seed.auxiliaryValueV1).length === 1
  const pass = resolution?.action === 'allow_current_load_to_settle'
    && pausedCorrect && convergedCorrect && unknownPreserved && disposedV1ExactlyOnce
  return {
    pass, resolution: sourceFree(resolution), missingCommitted: sourceFree(missingCommitted),
    pausedCorrect, convergedCorrect, unknownPreserved, disposedV1ExactlyOnce,
    activity: sourceFree(auxiliary.activity),
  }
}

function validHostCode(serviceKey, value) {
  return `return { apply(ctx) { ctx.provide(${JSON.stringify(serviceKey)}, Object.freeze({ version: ${JSON.stringify(value)} })) } }`
}

function brokenHostCode(seed) {
  return `return { apply(ctx) {\n  const intended = Object.freeze({ version: ${JSON.stringify(seed.repairedValue)} })\n  throw new Error(${JSON.stringify(seed.failureMessage)})\n  ctx.provide(${JSON.stringify(seed.serviceKey)}, intended)\n} }`
}

function visibleVersion(root, serviceKey) {
  return root.reflect._getImpl(serviceKey, false)?.value?.version ?? null
}

async function loadWorkspaceModule(workspace, name) {
  const path = safePath(workspace, name)
  return import(`${pathToFileURL(path).href}?load=${Date.now()}-${Math.random()}`)
}

function addSnapshot(map, alias, relational, native) {
  const value = { relational, native }
  map.set(alias, value)
  map.set(relational.id, value)
}

function resolveSnapshot(map, id) {
  const value = map.get(id)
  if (!value) throw new Error(`unknown checkpoint: ${id}`)
  return value
}

function deferred() {
  let resolve
  const promise = new Promise(settle => { resolve = settle })
  return { promise, resolve }
}

async function waitFor(predicate, attempts = 500) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (predicate()) return
    await new Promise(resolve => setTimeout(resolve, 0))
  }
  throw new Error('timed out waiting for lifecycle condition')
}

async function settleMicrotasks() {
  for (let index = 0; index < 4; index += 1) await new Promise(resolve => setTimeout(resolve, 0))
}

function sourceFree(value) {
  if (value === undefined) return undefined
  return JSON.parse(JSON.stringify(value))
}
