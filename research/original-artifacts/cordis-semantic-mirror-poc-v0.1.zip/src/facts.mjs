export class FactStore {
  #facts = []
  #index = new Map()

  add(predicate, ...args) {
    if (!/^[a-z][a-z0-9_]*$/.test(predicate)) {
      throw new TypeError(`invalid predicate: ${predicate}`)
    }
    const fact = Object.freeze({ predicate, args: Object.freeze(args) })
    this.#facts.push(fact)
    const rows = this.#index.get(predicate) ?? []
    rows.push(fact.args)
    this.#index.set(predicate, rows)
    return fact
  }

  rows(predicate) {
    return this.#index.get(predicate) ?? []
  }

  facts() {
    return [...this.#facts]
  }

  has(predicate, ...args) {
    return this.rows(predicate).some(row => (
      row.length === args.length && row.every((value, index) => value === args[index])
    ))
  }

  toJSON() {
    return this.#facts.map(({ predicate, args }) => ({ predicate, args: [...args] }))
  }

  toText() {
    return this.#facts
      .map(({ predicate, args }) => `${predicate}(${args.map(formatGround).join(', ')}).`)
      .join('\n') + '\n'
  }
}

function formatGround(value) {
  if (typeof value === 'string') return JSON.stringify(value)
  if (typeof value === 'number' && Number.isFinite(value)) return String(value)
  if (typeof value === 'boolean') return value ? 'true' : 'false'
  if (value === null || value === undefined) return 'none'
  throw new TypeError(`non-ground fact argument: ${String(value)}`)
}

export function stableUnique(values) {
  return [...new Set(values)].sort((left, right) => String(left).localeCompare(String(right)))
}
