import { FactStore } from './facts.mjs'

const STATE_NAMES = Object.freeze([
  'pending',
  'loading',
  'active',
  'failed',
  'disposed',
  'unloading',
])

export class CordisCollector {
  #root
  #runtimeId
  #sequence = 0
  #objectIds = new WeakMap()
  #symbolIds = new Map()
  #nextObject = 1
  #nextSymbol = 1
  #knownFibers = new Set()
  #knownEffects = new Map()
  #events = []
  #nextEvent = 1
  #observerFiber

  constructor(root, { runtimeId = 'rt:cordis-poc:1' } = {}) {
    this.#root = root
    this.#runtimeId = runtimeId
    this.#knownFibers.add(root.fiber)
  }

  async attach() {
    if (this.#observerFiber) return this.#observerFiber
    const collector = this
    const observerPlugin = {
      name: 'ctr-semantic-observer',
      apply(ctx) {
        ctx.on('internal/plugin', (fiber) => {
          collector.#knownFibers.add(fiber)
          collector.#recordEvent('fiber_membership', {
            fiber,
            state: stateName(fiber.state),
          })
        })
        ctx.on('internal/status', (fiber, oldState) => {
          collector.#knownFibers.add(fiber)
          collector.#recordEvent('fiber_status', {
            fiber,
            oldState: stateName(oldState),
            newState: stateName(fiber.state),
          })
        })
        ctx.on('internal/service', (name, value) => {
          collector.#recordEvent('service_registry_value', {
            service: name,
            valuePresent: value !== undefined,
          })
        })
      },
    }
    this.#observerFiber = this.#root.plugin(observerPlugin)
    await this.#observerFiber
    return this.#observerFiber
  }

  capture(label) {
    const snapshotId = `snap:${this.#runtimeId}:${++this.#sequence}`
    const facts = new FactStore()
    const liveFibers = new Set([this.#root.fiber])

    for (const [callback, runtime] of this.#root.registry.entries()) {
      const runtimeId = this.#id(runtime, 'plugin-runtime')
      const definitionId = this.#id(callback, 'plugin-definition')
      facts.add('plugin_definition', definitionId)
      facts.add('plugin_runtime', runtimeId, definitionId)
      facts.add('plugin_name', definitionId, runtime.name ?? callback.name ?? 'anonymous')
      for (const fiber of runtime.fibers) {
        liveFibers.add(fiber)
        this.#knownFibers.add(fiber)
      }
    }

    facts.add('runtime', this.#runtimeId)
    facts.add('runtime_package', this.#runtimeId, 'cordis', '4.0.0-rc.9')
    facts.add('snapshot', snapshotId, this.#runtimeId)
    facts.add('snapshot_label', snapshotId, label)
    facts.add('snapshot_observation_sequence', snapshotId, this.#sequence)
    facts.add('snapshot_phase', snapshotId, 'committed')

    const fibers = [...this.#knownFibers]
    const currentEffectIds = new Set()
    for (const fiber of fibers) {
      const fiberId = this.fiberId(fiber)
      const isLive = liveFibers.has(fiber)
      facts.add('fiber', fiberId)
      facts.add('fiber_member', snapshotId, fiberId)
      facts.add('fiber_name', fiberId, fiber.name)
      facts.add('fiber_state', snapshotId, fiberId, stateName(fiber.state))
      facts.add('fiber_liveness', snapshotId, fiberId, isLive ? 'registered' : 'retained_tombstone')
      if (fiber.uid !== null) facts.add('fiber_uid', fiberId, fiber.uid)
      if (fiber.parent?.fiber && fiber.parent.fiber !== fiber) {
        facts.add('fiber_parent', snapshotId, fiberId, this.fiberId(fiber.parent.fiber))
      }
      facts.add('fiber_context', snapshotId, fiberId, this.#id(fiber.ctx, 'context'))
      if (fiber.runtime) {
        facts.add('fiber_instance_of', snapshotId, fiberId, this.#id(fiber.runtime, 'plugin-runtime'))
      }

      const targetStore = fiber._store ?? Object.create(null)
      const committedStore = fiber.store ?? Object.create(null)
      for (const service of Object.keys(fiber.inject ?? {})) {
        facts.add('declared_injection', fiberId, service, 'required')
        const target = targetStore[service]
        const committed = committedStore[service]
        if (target) {
          facts.add('target_binding', snapshotId, fiberId, service, this.serviceImplId(target))
        } else {
          facts.add('fiber_waits_for', snapshotId, fiberId, service)
        }
        if (committed) {
          facts.add('committed_binding', snapshotId, fiberId, service, this.serviceImplId(committed))
        }
      }

      for (const effect of flattenEffects(
        fiberId,
        fiber.getEffects(),
        node => this.#id(node, 'effect'),
      )) {
        currentEffectIds.add(effect.id)
        this.#knownEffects.set(effect.id, effect)
        facts.add('effect', effect.id)
        facts.add('effect_member', snapshotId, effect.id)
        facts.add('effect_owner', effect.id, fiberId)
        facts.add('effect_label', effect.id, effect.label)
        facts.add('effect_path', effect.id, effect.path)
        facts.add('effect_status', snapshotId, effect.id, 'registered')
        if (effect.parentId) facts.add('effect_parent', effect.id, effect.parentId)
      }
    }

    for (const effect of this.#knownEffects.values()) {
      if (currentEffectIds.has(effect.id)) continue
      facts.add('effect', effect.id)
      facts.add('effect_member', snapshotId, effect.id)
      facts.add('effect_owner', effect.id, effect.fiberId)
      facts.add('effect_label', effect.id, effect.label)
      facts.add('effect_path', effect.id, effect.path)
      facts.add('effect_status', snapshotId, effect.id, 'disposed')
      if (effect.parentId) facts.add('effect_parent', effect.id, effect.parentId)
    }

    for (const key of Reflect.ownKeys(this.#root.reflect.store)) {
      const impl = this.#root.reflect.store[key]
      if (!impl) continue
      const implId = this.serviceImplId(impl)
      const providerId = this.fiberId(impl.fiber)
      const realmId = this.#symbolId(key)
      facts.add('service_key', impl.name)
      facts.add('service_impl', implId)
      facts.add('service_impl_key', implId, impl.name)
      facts.add('service_impl_provider', implId, providerId)
      facts.add('service_impl_realm', implId, realmId)
      facts.add('service_impl_registered', snapshotId, implId)
      if (stateName(impl.fiber.state) === 'active') {
        facts.add('service_impl_visible', snapshotId, implId)
      }
    }

    facts.add('snapshot_quiescence', snapshotId, isQuiescent(fibers) ? 'quiescent' : 'in_flight')
    facts.add('coverage_scope', snapshotId, 'reachable_single_process_fixture')
    facts.add('domain_coverage', snapshotId, 'registry_fibers', 'complete')
    facts.add('domain_coverage', snapshotId, 'reflect_services', 'complete')
    facts.add('domain_coverage', snapshotId, 'fiber_bindings', 'complete')
    facts.add('domain_coverage', snapshotId, 'tracked_effect_metadata', 'complete')
    facts.add('domain_coverage', snapshotId, 'all_contexts', 'partial')
    facts.add('coverage_reason', snapshotId, 'all_contexts', 'no_native_global_context_registry')
    facts.add('domain_coverage', snapshotId, 'external_effect_truth', 'unavailable')
    facts.add('coverage_reason', snapshotId, 'external_effect_truth', 'primitive_oracle_boundary')

    for (const event of this.#events) {
      facts.add('observed_event', event.id)
      facts.add('event_sequence', event.id, event.sequence)
      facts.add('event_kind', event.id, event.kind)
      if (event.fiber) facts.add('event_subject', event.id, this.fiberId(event.fiber))
      if (event.service) facts.add('event_service', event.id, event.service)
      if (event.oldState) facts.add('event_old_state', event.id, event.oldState)
      if (event.newState) facts.add('event_new_state', event.id, event.newState)
      if (event.valuePresent !== undefined) facts.add('event_value_present', event.id, event.valuePresent)
    }

    return Object.freeze({
      id: snapshotId,
      runtimeId: this.#runtimeId,
      label,
      sequence: this.#sequence,
      facts,
    })
  }

  fiberId(fiber) {
    if (fiber.uid !== null) {
      const stable = `fiber:${this.#runtimeId}:${fiber.uid}`
      if (!this.#objectIds.has(fiber)) this.#objectIds.set(fiber, stable)
    }
    return this.#id(fiber, 'fiber')
  }

  serviceImplId(impl) {
    return this.#id(impl, 'service-impl')
  }

  eventLog() {
    return this.#events.map(event => ({
      id: event.id,
      sequence: event.sequence,
      kind: event.kind,
      ...(event.fiber ? { fiberId: this.fiberId(event.fiber), fiberName: event.fiber.name } : {}),
      ...(event.service ? { service: event.service } : {}),
      ...(event.oldState ? { oldState: event.oldState } : {}),
      ...(event.newState ? { newState: event.newState } : {}),
      ...(event.valuePresent !== undefined ? { valuePresent: event.valuePresent } : {}),
    }))
  }

  async detach() {
    if (!this.#observerFiber) return
    const fiber = this.#observerFiber
    this.#observerFiber = undefined
    await fiber.dispose()
  }

  #recordEvent(kind, details) {
    const sequence = this.#nextEvent++
    this.#events.push({
      id: `event:${this.#runtimeId}:${sequence}`,
      sequence,
      kind,
      ...details,
    })
  }

  #id(object, kind) {
    let id = this.#objectIds.get(object)
    if (!id) {
      id = `${kind}:${this.#runtimeId}:${this.#nextObject++}`
      this.#objectIds.set(object, id)
    }
    return id
  }

  #symbolId(symbol) {
    let id = this.#symbolIds.get(symbol)
    if (!id) {
      id = `realm:${this.#runtimeId}:${this.#nextSymbol++}:${symbol.description ?? 'anonymous'}`
      this.#symbolIds.set(symbol, id)
    }
    return id
  }
}

export function stateName(state) {
  return STATE_NAMES[state] ?? `unknown_${String(state)}`
}

function isQuiescent(fibers) {
  return fibers.every(fiber => fiber.inertia === undefined)
}

function flattenEffects(fiberId, roots, identity) {
  const output = []
  const walk = (node, path, parentId) => {
    const id = identity(node)
    output.push({ id, fiberId, label: node.label, path, parentId })
    node.children.forEach((child, index) => walk(child, `${path}.${index}`, id))
  }
  roots.forEach((root, index) => walk(root, String(index), undefined))
  return output
}
