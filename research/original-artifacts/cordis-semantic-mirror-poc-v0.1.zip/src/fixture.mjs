import { Context } from 'cordis'

export async function createProviderRemovalFixture({ beforeMount } = {}) {
  const root = new Context()
  const activity = {
    active: new Set(),
    disposed: [],
  }

  const trackedEffect = (ctx, label) => {
    ctx.effect(() => {
      activity.active.add(label)
      return () => {
        activity.active.delete(label)
        activity.disposed.push(label)
      }
    }, label)
  }

  const ClockProvider = {
    name: 'clock-provider',
    apply(ctx) {
      ctx.provide('clock', Object.freeze({ now: () => 42 }))
      trackedEffect(ctx, 'provider-audit')
    },
  }

  const ClockUi = {
    name: 'clock-ui',
    inject: ['clock'],
    apply(ctx) {
      ctx.provide('clockView', Object.freeze({ render: () => String(ctx.clock.now()) }))
      trackedEffect(ctx, 'ui-render-loop')
    },
  }

  const ClockReporter = {
    name: 'clock-reporter',
    inject: ['clockView'],
    apply(ctx) {
      void ctx.clockView.render()
      trackedEffect(ctx, 'reporter-poll')
    },
  }

  if (beforeMount) await beforeMount(root)

  const provider = root.plugin(ClockProvider)
  await provider
  const ui = root.plugin(ClockUi)
  await ui
  const reporter = root.plugin(ClockReporter)
  await reporter

  const selectedImpl = root.reflect._getImpl('clock', false)
  if (!selectedImpl) throw new Error('fixture failed to publish clock')

  return {
    root,
    activity,
    selectedImpl,
    fibers: { provider, ui, reporter },
  }
}
