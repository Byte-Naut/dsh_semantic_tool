# Cordis semantic mirror: minimal executable loop

This project is the smallest executable continuation of the Cordis semantic ABI.
It does not modify Cordis and does not add project-specific Horn rules.

The loop is:

1. create a real Cordis 4.0.0-rc.9 runtime;
2. mount a provider, a direct consumer, and a transitive consumer;
3. capture a ground relational snapshot;
4. run one fact-only impact_remove query;
5. independently traverse native Cordis objects;
6. dispose the provider through Fiber.dispose();
7. capture the post-state;
8. compare the prediction, native inspection, and actual lifecycle;
9. write facts, trace, query, comparator, and result artifacts.

## Run

~~~sh
npm install
npm test
npm run demo
~~~

Generated evidence is written to artifacts/.

## Boundary

The collector reads Registry entries, Runtime fibers, Fiber target/committed
stores, Reflect service implementations, and Fiber effect metadata. It never
writes those structures. The only runtime mutation in the scenario uses normal
Cordis plugin/provide/dispose APIs.

The direct comparator deliberately does not call the relational query. It
traverses native Cordis objects and supplies an independent bounded oracle.

The result demonstrates interface compression: one relational call returns
direct and transitive consumers, predicted states, effects, coverage, and
provenance paths. It does not yet establish lower general Agent reasoning
complexity, complete Context observability, external-effect correctness, or
formal verification of JavaScript.
