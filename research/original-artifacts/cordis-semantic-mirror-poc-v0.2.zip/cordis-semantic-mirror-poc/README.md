# Cordis semantic mirror: three executable witnesses

This project is the executable continuation of the Cordis semantic ABI. It does
not modify Cordis or dsh and does not add project-specific Horn rules. Software
state is reified as ground facts and consumed by fixed JavaScript query
procedures at the primitive/search boundary.

## Scenarios

1. **Provider removal:** `impact_remove` predicts direct/transitive consumers,
   lifecycle states, and tracked effects, then checks real `Fiber.dispose()`.
2. **Replacement during LOADING:** `explain_binding_divergence` reads one
   in-flight snapshot where target v2 and committed v1 coexist, then checks the
   eventual unload/reload convergence on v2.
3. **Failed dsh update:** `explain_dynamic_package_state` separates the last
   successful immutable package from the absent active run after a real Host
   failure, then executes the recommended explicit v1 run.

## Run

~~~sh
npm install --legacy-peer-deps
npm test
npm run demo
~~~

Run one witness with `npm run demo:scenario-1`, `demo:scenario-2`, or
`demo:scenario-3`. Generated facts, queries, direct inspections, traces, and
reports are written to `artifacts/`.

## Boundary

The Cordis collector reads Registry entries, Runtime fibers, Fiber
target/committed stores, Reflect service implementations, and Fiber effect
metadata. The dsh collector reads the public dynamic runner inventory. Neither
collector writes native structures. Runtime mutations use normal
plugin/provide/dispose and define/run/update operations.

Each direct comparator deliberately does not call its relational query. It
reads native Cordis objects or dsh inventory and supplies an independent
bounded oracle.

The dsh fixture uses the published runner with a no-op `tools` service because
the host halves register no tools; model, browser, filesystem, network, and
external effects are outside this witness.

The three results demonstrate repeated semantic-substrate reuse across service
loss, concurrent binding change, and immutable package failure. They do not yet
establish lower general Agent reasoning complexity, complete Context
observability, external-effect correctness, or formal verification of
JavaScript.
