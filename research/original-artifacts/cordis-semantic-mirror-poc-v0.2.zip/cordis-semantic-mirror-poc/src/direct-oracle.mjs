import { stateName } from './collector.mjs'
import { stableUnique } from './facts.mjs'

export function inspectImpactDirectly(root, selectedImpl) {
  const stats = {
    registryPasses: 0,
    fiberObjectsVisited: 0,
    reflectStorePasses: 0,
    serviceImplObjectsVisited: 0,
    privateBindingReads: 0,
    effectMetadataReads: 0,
  }
  const affectedFibers = new Set()
  const directFibers = new Set()
  const transitiveFibers = new Set()
  const removedImpls = new Set()
  const queue = [{ impl: selectedImpl, depth: 0 }]

  while (queue.length) {
    const { impl, depth } = queue.shift()
    if (removedImpls.has(impl)) continue
    removedImpls.add(impl)

    stats.registryPasses++
    for (const runtime of root.registry.values()) {
      for (const fiber of runtime.fibers) {
        stats.fiberObjectsVisited++
        stats.privateBindingReads++
        if (fiber._store?.[impl.name] !== impl) continue
        if (!affectedFibers.has(fiber)) {
          affectedFibers.add(fiber)
          if (depth === 0) directFibers.add(fiber)
          else transitiveFibers.add(fiber)
        }

        stats.reflectStorePasses++
        for (const key of Reflect.ownKeys(root.reflect.store)) {
          const provided = root.reflect.store[key]
          stats.serviceImplObjectsVisited++
          if (!provided || provided.fiber !== fiber || stateName(provided.fiber.state) !== 'active') continue
          queue.push({ impl: provided, depth: depth + 1 })
        }
      }
    }
  }

  const effectLabels = []
  for (const fiber of new Set([selectedImpl.fiber, ...affectedFibers])) {
    stats.effectMetadataReads++
    for (const effect of flattenEffectLabels(fiber.getEffects())) {
      effectLabels.push(`${fiber.name}:${effect}`)
    }
  }

  return {
    selectedProvider: selectedImpl.fiber.name,
    directConsumers: stableUnique([...directFibers].map(fiber => fiber.name)),
    transitiveConsumers: stableUnique([...transitiveFibers].map(fiber => fiber.name)),
    affectedFibers: stableUnique([...affectedFibers].map(fiber => fiber.name)),
    effectsToDispose: stableUnique(effectLabels),
    removedServices: stableUnique([...removedImpls].map(impl => impl.name)),
    stats,
    domainsTouched: [
      'registry',
      'runtime.fibers',
      'fiber._store',
      'reflect.store',
      'fiber.getEffects',
    ],
  }
}

export function inspectActualAfter(root, fibers, activity) {
  return {
    visibleServices: ['clock', 'clockView'].filter(name => root.reflect._getImpl(name, false) !== undefined),
    fiberStates: Object.fromEntries(
      Object.entries(fibers).map(([name, fiber]) => [name, stateName(fiber.state)]),
    ),
    activeEffects: [...activity.active].sort(),
    disposedEffects: [...activity.disposed].sort(),
  }
}

export function inspectBindingDirectly(consumerFiber, serviceKey) {
  const target = consumerFiber._store?.[serviceKey]
  const committed = consumerFiber.store?.[serviceKey]
  return {
    consumerName: consumerFiber.name,
    consumerState: stateName(consumerFiber.state),
    serviceKey,
    target: describeNativeImpl(target),
    committed: describeNativeImpl(committed),
    diverged: target !== undefined && committed !== undefined && target !== committed,
    nativeReads: ['fiber.state', 'fiber._store', 'fiber.store', 'impl.fiber', 'impl.value'],
  }
}

export function inspectReplacementAfter(root, fibers, activity) {
  const visible = root.reflect._getImpl('clock', false)
  return {
    visibleClockProvider: visible?.fiber.name ?? null,
    visibleClockVersion: visible?.value?.version ?? null,
    fiberStates: Object.fromEntries(
      Object.entries(fibers).map(([name, fiber]) => [name, stateName(fiber.state)]),
    ),
    applyVersions: [...activity.applyVersions],
    completedVersions: [...activity.completedVersions],
    disposedVersions: [...activity.disposedVersions],
  }
}

function describeNativeImpl(impl) {
  if (!impl) return null
  return {
    serviceKey: impl.name,
    providerName: impl.fiber.name,
    version: impl.value?.version ?? null,
  }
}

function flattenEffectLabels(roots) {
  const labels = []
  const walk = (effect) => {
    labels.push(effect.label)
    effect.children.forEach(walk)
  }
  roots.forEach(walk)
  return labels
}
