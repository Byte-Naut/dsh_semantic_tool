import { Context } from 'cordis'

export async function createProviderRemovalFixture({ beforeMount } = {}) {
  const root = new Context()
  const activity = {
    active: new Set(),
    disposed: [],
  }

  const trackedEffect = (ctx, label) => {
    ctx.effect(() => {
      activity.active.add(label)
      return () => {
        activity.active.delete(label)
        activity.disposed.push(label)
      }
    }, label)
  }

  const ClockProvider = {
    name: 'clock-provider',
    apply(ctx) {
      ctx.provide('clock', Object.freeze({ now: () => 42 }))
      trackedEffect(ctx, 'provider-audit')
    },
  }

  const ClockUi = {
    name: 'clock-ui',
    inject: ['clock'],
    apply(ctx) {
      ctx.provide('clockView', Object.freeze({ render: () => String(ctx.clock.now()) }))
      trackedEffect(ctx, 'ui-render-loop')
    },
  }

  const ClockReporter = {
    name: 'clock-reporter',
    inject: ['clockView'],
    apply(ctx) {
      void ctx.clockView.render()
      trackedEffect(ctx, 'reporter-poll')
    },
  }

  if (beforeMount) await beforeMount(root)

  const provider = root.plugin(ClockProvider)
  await provider
  const ui = root.plugin(ClockUi)
  await ui
  const reporter = root.plugin(ClockReporter)
  await reporter

  const selectedImpl = root.reflect._getImpl('clock', false)
  if (!selectedImpl) throw new Error('fixture failed to publish clock')

  return {
    root,
    activity,
    selectedImpl,
    fibers: { provider, ui, reporter },
  }
}

export async function createProviderReplacementFixture({ beforeMount } = {}) {
  const root = new Context()
  const firstLoadGate = deferred()
  const firstLoadStarted = deferred()
  const activity = {
    applyVersions: [],
    completedVersions: [],
    disposedVersions: [],
  }
  let applyCount = 0

  const provider = version => ({
    name: `clock-provider-${version}`,
    apply(ctx) {
      ctx.provide('clock', Object.freeze({ version, now: () => version }))
    },
  })

  const SlowConsumer = {
    name: 'slow-clock-consumer',
    inject: ['clock'],
    async apply(ctx) {
      const version = ctx.clock.version
      const call = ++applyCount
      activity.applyVersions.push(version)
      ctx.effect(() => () => {
        activity.disposedVersions.push(version)
      }, `consumer-session:${version}`)
      if (call === 1) {
        firstLoadStarted.resolve()
        await firstLoadGate.promise
      }
      activity.completedVersions.push(version)
    },
  }

  if (beforeMount) await beforeMount(root)

  const providerV1 = root.plugin(provider('v1'))
  await providerV1
  const consumer = root.plugin(SlowConsumer)
  await firstLoadStarted.promise

  const selectedV1 = root.reflect._getImpl('clock', false)
  if (!selectedV1) throw new Error('fixture failed to publish clock v1')

  return {
    root,
    activity,
    selectedV1,
    fibers: { providerV1, consumer },
    releaseFirstLoad: () => firstLoadGate.resolve(),
    async replaceProvider() {
      const providerV1Disposal = providerV1.dispose()
      await waitFor(() => root.reflect._getImpl('clock', false) === undefined)
      const providerV2 = root.plugin(provider('v2'))
      await providerV2
      const selectedV2 = root.reflect._getImpl('clock', false)
      if (!selectedV2) throw new Error('fixture failed to publish clock v2')
      return { providerV2, providerV1Disposal, selectedV2 }
    },
  }
}

function deferred() {
  let resolve
  const promise = new Promise(settle => { resolve = settle })
  return { promise, resolve }
}

async function waitFor(predicate, { attempts = 200 } = {}) {
  for (let attempt = 0; attempt < attempts; attempt++) {
    if (predicate()) return
    await new Promise(resolve => setTimeout(resolve, 0))
  }
  throw new Error('timed out waiting for Cordis lifecycle condition')
}
