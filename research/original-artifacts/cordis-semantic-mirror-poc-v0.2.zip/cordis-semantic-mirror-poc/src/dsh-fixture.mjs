import { Context } from '@deepseek-ai/cordis'
import DynamicCordisRunnerService from '@deepseek-ai/dsh-cordis-host-runner'

export async function createFailedUpdateFixture() {
  const root = new Context()
  const nativeEvents = []
  const disposeTools = root.provide('tools', Object.freeze({}))
  for (const eventName of ['cordis/dynamic-package', 'cordis/dynamic-retract']) {
    root.on(eventName, payload => {
      nativeEvents.push({ sequence: nativeEvents.length + 1, eventName, payload })
    })
  }

  const runnerFiber = root.plugin(DynamicCordisRunnerService)
  await runnerFiber
  const runner = root.dynamicCordisRunner
  const agent = Object.freeze({
    id: 'session:semantic-mirror',
    steer() {},
    inject() {},
  })

  const first = runner.define({
    sessionId: agent.id,
    plugin: { kind: 'new', idPrefix: 'clock' },
    name: 'clock v1',
    purpose: 'failed update semantic witness',
    code: { host: 'return { apply() {} }' },
  })
  const firstRun = await runner.run(agent, first.pluginId, first.packageId, 'run')
  if (!firstRun.ok) throw new Error(firstRun.message)

  return {
    root,
    runner,
    runnerFiber,
    disposeTools,
    agent,
    first,
    firstRun,
    nativeEvents,
    defineBrokenUpdate() {
      return runner.define({
        sessionId: agent.id,
        plugin: { kind: 'existing', pluginId: first.pluginId },
        name: 'clock v2',
        purpose: 'failed update semantic witness',
        code: { host: 'throw new Error("broken update witness")' },
      })
    },
  }
}
