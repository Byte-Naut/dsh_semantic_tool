export function inspectDynamicPackageDirectly(runner, pluginId) {
  const rows = runner.inventory()
  const matches = rows.filter(row => String(row.pluginId) === pluginId)
  if (matches.length !== 1) {
    throw new Error(`expected one native inventory row for ${pluginId}; found ${matches.length}`)
  }
  const row = matches[0]
  return {
    pluginId,
    lastSuccessfulPackageId: row.currentPackageId === undefined ? null : String(row.currentPackageId),
    failedOrInProgressTargetPackageId: row.nextPackageId === undefined ? null : String(row.nextPackageId),
    activeRun: row.activeRun === undefined
      ? null
      : {
          runId: String(row.activeRun.pluginRunId),
          packageId: String(row.activeRun.packageId),
        },
    latestAttemptStatus: row.latestRun?.status ?? null,
    nativeReads: [
      'runner.inventory()',
      'row.currentPackageId',
      'row.nextPackageId',
      'row.activeRun',
      'row.latestRun.status',
    ],
  }
}
