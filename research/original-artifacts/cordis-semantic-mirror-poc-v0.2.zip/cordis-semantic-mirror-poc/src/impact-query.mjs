import { stableUnique } from './facts.mjs'

export function impactRemove(snapshot, selectedServiceImplId) {
  const { facts, id: snapshotId } = snapshot
  if (!facts.has('service_impl_visible', snapshotId, selectedServiceImplId)) {
    throw new Error(`service implementation is not visible in ${snapshotId}: ${selectedServiceImplId}`)
  }

  const selectedKey = oneValue(facts.rows('service_impl_key'), 0, selectedServiceImplId, 1)
  const providerFiberId = oneValue(facts.rows('service_impl_provider'), 0, selectedServiceImplId, 1)
  const queuedImpls = [selectedServiceImplId]
  const removedImpls = new Set()
  const impactedFibers = new Map()
  const paths = []
  const depthByImpl = new Map([[selectedServiceImplId, 0]])

  while (queuedImpls.length) {
    const implId = queuedImpls.shift()
    if (removedImpls.has(implId)) continue
    removedImpls.add(implId)
    const serviceKey = oneValue(facts.rows('service_impl_key'), 0, implId, 1)
    const currentDepth = depthByImpl.get(implId) ?? 0

    for (const [snap, consumerFiberId, dependencyKey, targetImplId] of facts.rows('target_binding')) {
      if (snap !== snapshotId || targetImplId !== implId) continue
      const nextDepth = currentDepth + 1
      if (!impactedFibers.has(consumerFiberId)) {
        impactedFibers.set(consumerFiberId, {
          fiberId: consumerFiberId,
          name: oneValue(facts.rows('fiber_name'), 0, consumerFiberId, 1),
          depth: nextDepth,
          reason: `required service ${dependencyKey} loses ${implId}`,
        })
      }
      paths.push({
        serviceImplId: implId,
        serviceKey,
        consumerFiberId,
        dependencyKey,
        depth: nextDepth,
      })

      for (const [providedImplId, providerId] of facts.rows('service_impl_provider')) {
        if (providerId !== consumerFiberId) continue
        if (!facts.has('service_impl_visible', snapshotId, providedImplId)) continue
        if (!depthByImpl.has(providedImplId)) depthByImpl.set(providedImplId, nextDepth)
        queuedImpls.push(providedImplId)
      }
    }
  }

  const affectedOwnerIds = new Set([providerFiberId, ...impactedFibers.keys()])
  const effects = []
  for (const [effectId, ownerFiberId] of facts.rows('effect_owner')) {
    if (!affectedOwnerIds.has(ownerFiberId)) continue
    if (!facts.has('effect_status', snapshotId, effectId, 'registered')) continue
    effects.push({
      effectId,
      ownerFiberId,
      ownerName: oneValue(facts.rows('fiber_name'), 0, ownerFiberId, 1),
      label: oneValue(facts.rows('effect_label'), 0, effectId, 1),
    })
  }

  const coverage = Object.fromEntries(
    facts.rows('domain_coverage')
      .filter(([snap]) => snap === snapshotId)
      .map(([, domain, status]) => [domain, status]),
  )
  const requiredDomains = ['registry_fibers', 'reflect_services', 'fiber_bindings', 'tracked_effect_metadata']
  const unknowns = requiredDomains
    .filter(domain => coverage[domain] !== 'complete')
    .map(domain => `incomplete domain: ${domain}`)

  const impacted = [...impactedFibers.values()]
    .map(item => ({ ...item, predictedFinalState: 'pending' }))
    .sort((left, right) => left.name.localeCompare(right.name))

  return {
    query: 'impact_remove',
    snapshotId,
    selected: {
      serviceImplId: selectedServiceImplId,
      serviceKey: selectedKey,
      providerFiberId,
      providerName: oneValue(facts.rows('fiber_name'), 0, providerFiberId, 1),
      removalMode: 'dispose_provider_fiber',
      predictedFinalState: 'disposed',
    },
    directConsumers: stableUnique(
      paths
        .filter(path => path.serviceImplId === selectedServiceImplId)
        .map(path => oneValue(facts.rows('fiber_name'), 0, path.consumerFiberId, 1)),
    ),
    transitiveConsumers: stableUnique(
      paths
        .filter(path => path.serviceImplId !== selectedServiceImplId)
        .map(path => oneValue(facts.rows('fiber_name'), 0, path.consumerFiberId, 1)),
    ),
    affectedFibers: impacted,
    removedServiceImpls: stableUnique([...removedImpls]),
    effectsToDispose: effects.sort(compareEffect),
    relationPaths: paths,
    coverage,
    unknowns,
    confidence: unknowns.length ? 'partial' : 'complete_within_declared_fixture_scope',
    resultFacets: [
      'direct_consumers',
      'transitive_consumers',
      'affected_fibers',
      'predicted_states',
      'effects_to_dispose',
      'coverage',
      'provenance_paths',
    ],
  }
}

function oneValue(rows, matchIndex, matchValue, resultIndex) {
  const matches = rows.filter(row => row[matchIndex] === matchValue)
  if (matches.length !== 1) {
    throw new Error(`expected one relational value for ${matchValue}; found ${matches.length}`)
  }
  return matches[0][resultIndex]
}

function compareEffect(left, right) {
  return left.ownerName.localeCompare(right.ownerName)
    || left.label.localeCompare(right.label)
    || left.effectId.localeCompare(right.effectId)
}
