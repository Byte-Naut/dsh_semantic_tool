import { FactStore } from './facts.mjs'

const IN_FLIGHT_ATTEMPT_STATES = new Set([
  'awaiting-approval',
  'starting-host',
  'client-pending',
])

export class DynamicPackageCollector {
  #runner
  #runtimeId
  #sequence = 0

  constructor(runner, { runtimeId = 'rt:dsh-dynamic:1' } = {}) {
    this.#runner = runner
    this.#runtimeId = runtimeId
  }

  capture(label) {
    const snapshotId = `snap:${this.#runtimeId}:${++this.#sequence}`
    const facts = new FactStore()
    const rows = this.#runner.inventory()

    facts.add('runtime', this.#runtimeId)
    facts.add('runtime_package', this.#runtimeId, '@deepseek-ai/cordis', '4.0.2')
    facts.add('runtime_package', this.#runtimeId, '@deepseek-ai/dsh-cordis-host-runner', '0.1.2-alpha.5')
    facts.add('snapshot', snapshotId, this.#runtimeId)
    facts.add('snapshot_label', snapshotId, label)
    facts.add('snapshot_observation_sequence', snapshotId, this.#sequence)
    facts.add('snapshot_phase', snapshotId, 'committed')
    facts.add(
      'snapshot_quiescence',
      snapshotId,
      rows.some(row => IN_FLIGHT_ATTEMPT_STATES.has(row.latestRun?.status)) ? 'in_flight' : 'quiescent',
    )
    facts.add('coverage_scope', snapshotId, 'reachable_single_process_dynamic_runner')
    facts.add('domain_coverage', snapshotId, 'dynamic_package_inventory', 'complete')
    facts.add('domain_coverage', snapshotId, 'package_source', 'unavailable')
    facts.add('coverage_reason', snapshotId, 'package_source', 'inventory_is_source_free')
    facts.add('domain_coverage', snapshotId, 'arbitrary_host_effect_truth', 'unavailable')
    facts.add('coverage_reason', snapshotId, 'arbitrary_host_effect_truth', 'primitive_oracle_boundary')

    for (const row of rows) {
      const pluginId = String(row.pluginId)
      facts.add('dynamic_plugin', pluginId)
      facts.add('dynamic_plugin_owner', pluginId, String(row.agentId))
      row.packages.forEach((pkg, index) => {
        const packageId = String(pkg.packageId)
        facts.add('dynamic_package', packageId)
        facts.add('package_of', packageId, pluginId)
        facts.add('package_define_order', packageId, index + 1)
        if (pkg.hasHostHalf) facts.add('package_half', packageId, 'host')
        if (pkg.hasClientHalf) facts.add('package_half', packageId, 'client')
      })

      if (row.currentPackageId !== undefined) {
        facts.add('last_successful_package', snapshotId, pluginId, String(row.currentPackageId))
      }
      if (row.nextPackageId !== undefined) {
        facts.add('next_package', snapshotId, pluginId, String(row.nextPackageId))
      }

      const runPackages = new Set()
      if (row.activeRun === undefined) {
        facts.add('absence_fact', snapshotId, 'active_run', pluginId)
      } else {
        const runId = String(row.activeRun.pluginRunId)
        const packageId = String(row.activeRun.packageId)
        facts.add('active_run', snapshotId, pluginId, runId)
        facts.add('run_package', runId, packageId)
        runPackages.add(runId)
      }

      if (row.latestRun !== undefined) {
        const runId = String(row.latestRun.pluginRunId)
        facts.add('latest_attempt_status', snapshotId, pluginId, row.latestRun.status)
        if (!runPackages.has(runId)) {
          facts.add('run_package', runId, String(row.latestRun.packageId))
        }
        facts.add('run_status', snapshotId, runId, row.latestRun.status)
        facts.add('run_half_status', snapshotId, runId, 'host', row.latestRun.host.status)
        facts.add('run_half_status', snapshotId, runId, 'client', row.latestRun.client.status)
        for (const service of row.latestRun.host.waitingFor) {
          facts.add('run_waits_for', snapshotId, runId, 'host', service)
        }
        for (const service of row.latestRun.client.waitingFor) {
          facts.add('run_waits_for', snapshotId, runId, 'client', service)
        }
      }
    }

    return Object.freeze({
      id: snapshotId,
      runtimeId: this.#runtimeId,
      label,
      sequence: this.#sequence,
      facts,
    })
  }
}
