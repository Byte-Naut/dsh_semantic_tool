import assert from 'node:assert/strict'
import { mkdir, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { CordisCollector } from './collector.mjs'
import { inspectActualAfter, inspectImpactDirectly } from './direct-oracle.mjs'
import { createProviderRemovalFixture } from './fixture.mjs'
import { impactRemove } from './impact-query.mjs'

export async function executeClosedLoop({ writeArtifacts = true } = {}) {
  let collector
  const fixture = await createProviderRemovalFixture({
    beforeMount: async (root) => {
      collector = new CordisCollector(root)
      await collector.attach()
    },
  })

  const before = collector.capture('before_provider_disposal')
  const selectedServiceImplId = collector.serviceImplId(fixture.selectedImpl)
  const relational = impactRemove(before, selectedServiceImplId)
  const directBefore = inspectImpactDirectly(fixture.root, fixture.selectedImpl)

  assert.deepEqual(relational.directConsumers, directBefore.directConsumers)
  assert.deepEqual(relational.transitiveConsumers, directBefore.transitiveConsumers)
  assert.deepEqual(
    relational.affectedFibers.map(item => item.name).sort(),
    directBefore.affectedFibers,
  )
  assert.deepEqual(
    relational.effectsToDispose.map(item => `${item.ownerName}:${item.label}`).sort(),
    directBefore.effectsToDispose,
  )

  await fixture.fibers.provider.dispose()
  await Promise.all([fixture.fibers.ui.await(), fixture.fibers.reporter.await()])

  const after = collector.capture('after_provider_disposal')
  const actualAfter = inspectActualAfter(fixture.root, fixture.fibers, fixture.activity)

  assert.deepEqual(actualAfter.visibleServices, [])
  assert.deepEqual(actualAfter.fiberStates, {
    provider: 'disposed',
    ui: 'pending',
    reporter: 'pending',
  })
  assert.deepEqual(actualAfter.activeEffects, [])
  assert.deepEqual(actualAfter.disposedEffects, [
    'provider-audit',
    'reporter-poll',
    'ui-render-loop',
  ])

  for (const item of relational.affectedFibers) {
    const actualName = item.name === 'clock-ui' ? 'ui' : item.name === 'clock-reporter' ? 'reporter' : item.name
    assert.equal(actualAfter.fiberStates[actualName], item.predictedFinalState)
  }
  assert.equal(actualAfter.fiberStates.provider, relational.selected.predictedFinalState)

  const comparison = {
    status: 'PASS',
    claim: 'The one-call relational query matched an independent traversal of live Cordis internals and the observed post-disposal lifecycle in the bounded fixture.',
    scope: 'single process, one provider, one direct consumer, one transitive consumer',
    sourceRuntime: {
      package: 'cordis',
      version: '4.0.0-rc.9',
    },
    snapshots: {
      before: before.id,
      after: after.id,
    },
    relational,
    directBefore,
    actualAfter,
    semanticEvidence: {
      beforeGroundFactCount: before.facts.facts().length,
      afterGroundFactCount: after.facts.facts().length,
      targetBindingCount: before.facts.rows('target_binding').length,
      committedBindingCount: before.facts.rows('committed_binding').length,
      disposedEffectFactCount: after.facts.rows('effect_status')
        .filter(([snap, , status]) => snap === after.id && status === 'disposed')
        .length,
      providerRetainedAsTombstone: after.facts.has(
        'fiber_liveness',
        after.id,
        relational.selected.providerFiberId,
        'retained_tombstone',
      ),
      providerStateAfter: after.facts.rows('fiber_state')
        .find(([snap, fiberId]) => snap === after.id && fiberId === relational.selected.providerFiberId)?.[2],
    },
    compressionEvidence: {
      relationalConsumerCalls: 1,
      relationalResultFacets: relational.resultFacets.length,
      nativeDomainsRequiredByComparator: directBefore.domainsTouched.length,
      nativeDomains: directBefore.domainsTouched,
      conclusion: 'Interface compression demonstrated; general Agent reasoning-complexity reduction remains unproven.',
    },
    eventCount: collector.eventLog().length,
  }

  if (writeArtifacts) {
    const here = dirname(fileURLToPath(import.meta.url))
    const output = join(here, '..', 'artifacts')
    await mkdir(output, { recursive: true })
    await Promise.all([
      writeFile(join(output, 'before.facts'), before.facts.toText()),
      writeFile(join(output, 'after.facts'), after.facts.toText()),
      writeFile(join(output, 'before.json'), JSON.stringify(before.facts.toJSON(), null, 2) + '\n'),
      writeFile(join(output, 'after.json'), JSON.stringify(after.facts.toJSON(), null, 2) + '\n'),
      writeFile(join(output, 'impact-remove.json'), JSON.stringify(relational, null, 2) + '\n'),
      writeFile(join(output, 'direct-inspection.json'), JSON.stringify(directBefore, null, 2) + '\n'),
      writeFile(join(output, 'event-trace.json'), JSON.stringify(collector.eventLog(), null, 2) + '\n'),
      writeFile(join(output, 'closed-loop-result.json'), JSON.stringify(comparison, null, 2) + '\n'),
      writeFile(join(output, 'closed-loop-report.md'), renderReport(comparison)),
    ])
  }

  await collector.detach()
  await Promise.all([
    fixture.fibers.ui.dispose(),
    fixture.fibers.reporter.dispose(),
  ])
  return comparison
}

function renderReport(result) {
  const impacted = result.relational.affectedFibers
    .map(item => `- ${item.name}: ${item.predictedFinalState}`)
    .join('\n')
  const effects = result.relational.effectsToDispose
    .map(item => `- ${item.ownerName}: ${item.label}`)
    .join('\n')
  return `# Cordis minimal closed-loop result

Status: **${result.status}**

${result.claim}

## Predicted impact

Direct consumers: ${result.relational.directConsumers.join(', ')}

Transitive consumers: ${result.relational.transitiveConsumers.join(', ')}

${impacted}

Effects:

${effects}

## Actual post-state

- provider: ${result.actualAfter.fiberStates.provider}
- UI: ${result.actualAfter.fiberStates.ui}
- reporter: ${result.actualAfter.fiberStates.reporter}
- visible services: ${result.actualAfter.visibleServices.length}
- active fixture effects: ${result.actualAfter.activeEffects.length}
- disposed effect facts: ${result.semanticEvidence.disposedEffectFactCount}
- provider retained as tombstone: ${result.semanticEvidence.providerRetainedAsTombstone}

## Compression evidence

The caller used one relational query returning ${result.compressionEvidence.relationalResultFacets} result facets.
The independent native comparator touched ${result.compressionEvidence.nativeDomainsRequiredByComparator} Cordis domains:
${result.compressionEvidence.nativeDomains.map(domain => `- ${domain}`).join('\n')}

This demonstrates interface compression in the bounded fixture. It does not yet prove lower general Agent reasoning complexity.
`
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const result = await executeClosedLoop()
  process.stdout.write(JSON.stringify({
    status: result.status,
    snapshots: result.snapshots,
    directConsumers: result.relational.directConsumers,
    transitiveConsumers: result.relational.transitiveConsumers,
    affectedFibers: result.relational.affectedFibers.map(item => item.name),
    effectsToDispose: result.relational.effectsToDispose.length,
    actualAfter: result.actualAfter,
    semanticEvidence: result.semanticEvidence,
    compressionEvidence: result.compressionEvidence,
    eventCount: result.eventCount,
  }, null, 2) + '\n')
}
