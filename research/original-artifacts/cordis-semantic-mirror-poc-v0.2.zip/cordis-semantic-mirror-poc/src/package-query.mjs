export function explainDynamicPackageState(snapshot, pluginId) {
  const { facts, id: snapshotId } = snapshot
  if (!facts.has('dynamic_plugin', pluginId)) {
    throw new Error(`dynamic plugin is not present in ${snapshotId}: ${pluginId}`)
  }

  const coverage = Object.fromEntries(
    facts.rows('domain_coverage')
      .filter(([snap]) => snap === snapshotId)
      .map(([, domain, status]) => [domain, status]),
  )
  const inventoryComplete = coverage.dynamic_package_inventory === 'complete'
  const lastSuccessfulPackageId = optionalValue(
    facts.rows('last_successful_package'),
    [snapshotId, pluginId],
    2,
  )
  const nextPackageId = optionalValue(facts.rows('next_package'), [snapshotId, pluginId], 2)
  const activeRunId = optionalValue(facts.rows('active_run'), [snapshotId, pluginId], 2)
  const strongActiveRunAbsence = inventoryComplete
    && facts.has('absence_fact', snapshotId, 'active_run', pluginId)
  const activePackageId = activeRunId === undefined
    ? undefined
    : oneValue(facts.rows('run_package'), [activeRunId], 1)
  const latestAttemptStatus = optionalValue(
    facts.rows('latest_attempt_status'),
    [snapshotId, pluginId],
    2,
  )

  const failedUpdateGap = lastSuccessfulPackageId !== undefined
    && nextPackageId !== undefined
    && latestAttemptStatus === 'failed'
    && strongActiveRunAbsence
  const recovery = failedUpdateGap
    ? {
        kind: 'explicit_run_of_last_successful_package',
        packageId: lastSuccessfulPackageId,
        mode: 'run',
      }
    : null

  const unknowns = inventoryComplete ? [] : ['incomplete domain: dynamic_package_inventory']
  const activeRun = activeRunId !== undefined
    ? { runId: activeRunId, packageId: activePackageId }
    : strongActiveRunAbsence
      ? null
      : { unknown: true }

  return {
    query: 'explain_dynamic_package_state',
    snapshotId,
    pluginId,
    lastSuccessfulPackageId: lastSuccessfulPackageId ?? null,
    failedOrInProgressTargetPackageId: nextPackageId ?? null,
    activeRun,
    latestAttemptStatus: latestAttemptStatus ?? null,
    failedUpdateGap,
    lastSuccessfulIsCurrentlyRunning: activePackageId !== undefined
      && activePackageId === lastSuccessfulPackageId,
    recovery,
    rejectedInference: lastSuccessfulPackageId !== undefined && activeRun === null
      ? 'last_successful_package_does_not_imply_active_run'
      : null,
    coverage,
    unknowns,
    confidence: unknowns.length ? 'partial' : 'complete_within_declared_fixture_scope',
    provenancePaths: [
      ...(lastSuccessfulPackageId === undefined ? [] : [
        ['last_successful_package', snapshotId, pluginId, lastSuccessfulPackageId],
      ]),
      ...(nextPackageId === undefined ? [] : [['next_package', snapshotId, pluginId, nextPackageId]]),
      ...(activeRunId === undefined ? [] : [['active_run', snapshotId, pluginId, activeRunId]]),
      ...(strongActiveRunAbsence ? [['absence_fact', snapshotId, 'active_run', pluginId]] : []),
      ...(latestAttemptStatus === undefined ? [] : [
        ['latest_attempt_status', snapshotId, pluginId, latestAttemptStatus],
      ]),
    ],
    resultFacets: [
      'last_successful_package',
      'failed_or_in_progress_target',
      'active_run',
      'latest_attempt_status',
      'failed_update_gap',
      'recovery_action',
      'coverage',
      'provenance_paths',
    ],
  }
}

function optionalValue(rows, prefix, resultIndex) {
  const matches = rows.filter(row => prefix.every((value, index) => row[index] === value))
  if (matches.length > 1) {
    throw new Error(`expected at most one relational value for ${prefix.join('/')}; found ${matches.length}`)
  }
  return matches[0]?.[resultIndex]
}

function oneValue(rows, prefix, resultIndex) {
  const value = optionalValue(rows, prefix, resultIndex)
  if (value === undefined) {
    throw new Error(`expected one relational value for ${prefix.join('/')}; found 0`)
  }
  return value
}
