import assert from 'node:assert/strict'
import { mkdir, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { explainBindingDivergence } from './binding-query.mjs'
import { CordisCollector } from './collector.mjs'
import { inspectBindingDirectly, inspectReplacementAfter } from './direct-oracle.mjs'
import { createProviderReplacementFixture } from './fixture.mjs'

export async function executeProviderReplacement({ writeArtifacts = true } = {}) {
  let collector
  const fixture = await createProviderReplacementFixture({
    beforeMount: async (root) => {
      collector = new CordisCollector(root, { runtimeId: 'rt:cordis-replacement:1' })
      await collector.attach()
    },
  })

  const consumerId = collector.fiberId(fixture.fibers.consumer)
  const before = collector.capture('consumer_loading_with_v1')
  const replacement = await fixture.replaceProvider()
  const during = collector.capture('provider_v2_target_while_v1_committed')
  const relationalDuring = explainBindingDivergence(during, consumerId, 'clock')
  const directDuring = inspectBindingDirectly(fixture.fibers.consumer, 'clock')

  assert.equal(relationalDuring.consumer.state, 'loading')
  assert.equal(relationalDuring.diverged, true)
  assert.equal(relationalDuring.target.providerName, 'clock-provider-v2')
  assert.equal(relationalDuring.committed.providerName, 'clock-provider-v1')
  assert.equal(directDuring.consumerState, relationalDuring.consumer.state)
  assert.equal(directDuring.diverged, relationalDuring.diverged)
  assert.equal(directDuring.target.providerName, relationalDuring.target.providerName)
  assert.equal(directDuring.committed.providerName, relationalDuring.committed.providerName)

  fixture.releaseFirstLoad()
  await Promise.all([
    fixture.fibers.consumer.await(),
    replacement.providerV1Disposal,
  ])

  const after = collector.capture('consumer_reloaded_with_v2')
  const relationalAfter = explainBindingDivergence(after, consumerId, 'clock')
  const directAfter = inspectBindingDirectly(fixture.fibers.consumer, 'clock')
  const actualAfter = inspectReplacementAfter(fixture.root, {
    providerV1: fixture.fibers.providerV1,
    providerV2: replacement.providerV2,
    consumer: fixture.fibers.consumer,
  }, fixture.activity)

  assert.equal(relationalAfter.consumer.state, 'active')
  assert.equal(relationalAfter.diverged, false)
  assert.equal(relationalAfter.target.providerName, 'clock-provider-v2')
  assert.equal(relationalAfter.committed.providerName, 'clock-provider-v2')
  assert.equal(directAfter.consumerState, relationalAfter.consumer.state)
  assert.equal(directAfter.diverged, relationalAfter.diverged)
  assert.equal(directAfter.target.providerName, relationalAfter.target.providerName)
  assert.equal(directAfter.committed.providerName, relationalAfter.committed.providerName)
  assert.deepEqual(actualAfter.fiberStates, {
    providerV1: 'disposed',
    providerV2: 'active',
    consumer: 'active',
  })
  assert.equal(actualAfter.visibleClockProvider, 'clock-provider-v2')
  assert.equal(actualAfter.visibleClockVersion, 'v2')
  assert.deepEqual(actualAfter.applyVersions, ['v1', 'v2'])
  assert.deepEqual(actualAfter.completedVersions, ['v1', 'v2'])
  assert.deepEqual(actualAfter.disposedVersions, ['v1'])

  const result = {
    status: 'PASS',
    scenario: 'provider replacement while consumer LOADING',
    claim: 'The relational snapshot preserved distinct target and committed service bindings during an in-flight load, matched direct Fiber inspection, and predicted convergence on provider v2.',
    scope: 'single process, one replaceable service, one deliberately blocked consumer load',
    sourceRuntime: { package: 'cordis', version: '4.0.0-rc.9' },
    snapshots: { before: before.id, during: during.id, after: after.id },
    relationalDuring,
    directDuring,
    relationalAfter,
    directAfter,
    actualAfter,
    semanticEvidence: {
      beforeFactCount: before.facts.facts().length,
      duringFactCount: during.facts.facts().length,
      afterFactCount: after.facts.facts().length,
      duringSnapshotInFlight: during.facts.has('snapshot_quiescence', during.id, 'in_flight'),
      targetServiceImplId: relationalDuring.target.serviceImplId,
      committedServiceImplId: relationalDuring.committed.serviceImplId,
      identitiesDistinct: relationalDuring.target.serviceImplId !== relationalDuring.committed.serviceImplId,
      finalBindingsConverged: relationalAfter.target.serviceImplId === relationalAfter.committed.serviceImplId,
    },
    differentialEvidence: {
      relationalConsumerCalls: 1,
      nativeFieldsRead: directDuring.nativeReads,
      observationAgreement: true,
      runtimeConvergenceAgreement: true,
    },
    eventCount: collector.eventLog().length,
  }

  if (writeArtifacts) await writeScenarioArtifacts({ before, during, after, result, collector })

  await collector.detach()
  await Promise.all([
    fixture.fibers.consumer.dispose(),
    replacement.providerV2.dispose(),
  ])
  return result
}

async function writeScenarioArtifacts({ before, during, after, result, collector }) {
  const here = dirname(fileURLToPath(import.meta.url))
  const output = join(here, '..', 'artifacts', 'scenario-2')
  await mkdir(output, { recursive: true })
  await Promise.all([
    writeFile(join(output, 'before.facts'), before.facts.toText()),
    writeFile(join(output, 'during.facts'), during.facts.toText()),
    writeFile(join(output, 'after.facts'), after.facts.toText()),
    writeFile(join(output, 'before.json'), JSON.stringify(before.facts.toJSON(), null, 2) + '\n'),
    writeFile(join(output, 'during.json'), JSON.stringify(during.facts.toJSON(), null, 2) + '\n'),
    writeFile(join(output, 'after.json'), JSON.stringify(after.facts.toJSON(), null, 2) + '\n'),
    writeFile(join(output, 'binding-query.json'), JSON.stringify(result.relationalDuring, null, 2) + '\n'),
    writeFile(join(output, 'direct-inspection.json'), JSON.stringify(result.directDuring, null, 2) + '\n'),
    writeFile(join(output, 'event-trace.json'), JSON.stringify(collector.eventLog(), null, 2) + '\n'),
    writeFile(join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n'),
    writeFile(join(output, 'report.md'), renderReport(result)),
  ])
}

function renderReport(result) {
  return `# Scenario 2: provider replacement while consumer LOADING

Status: **${result.status}**

At the in-flight snapshot, \`${result.relationalDuring.consumer.name}\` was **${result.relationalDuring.consumer.state}**.

- target binding: ${result.relationalDuring.target.providerName} / ${result.relationalDuring.target.serviceImplId}
- committed binding: ${result.relationalDuring.committed.providerName} / ${result.relationalDuring.committed.serviceImplId}
- identities distinct: ${result.semanticEvidence.identitiesDistinct}
- direct native inspection agreed: ${result.differentialEvidence.observationAgreement}

After the first load settled, Cordis unloaded the v1-owned effects and reloaded the same consumer against v2.

- final consumer state: ${result.actualAfter.fiberStates.consumer}
- final visible provider: ${result.actualAfter.visibleClockProvider}
- apply versions: ${result.actualAfter.applyVersions.join(' -> ')}
- disposed consumer sessions: ${result.actualAfter.disposedVersions.join(', ')}
- target/committed converged: ${result.semanticEvidence.finalBindingsConverged}
`
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const result = await executeProviderReplacement()
  process.stdout.write(JSON.stringify({
    status: result.status,
    scenario: result.scenario,
    snapshots: result.snapshots,
    during: {
      state: result.relationalDuring.consumer.state,
      target: result.relationalDuring.target.providerName,
      committed: result.relationalDuring.committed.providerName,
      diverged: result.relationalDuring.diverged,
    },
    after: result.actualAfter,
    semanticEvidence: result.semanticEvidence,
    eventCount: result.eventCount,
  }, null, 2) + '\n')
}
