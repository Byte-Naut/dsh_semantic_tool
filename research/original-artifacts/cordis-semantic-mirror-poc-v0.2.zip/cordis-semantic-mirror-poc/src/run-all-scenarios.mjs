import { fileURLToPath } from 'node:url'
import { mkdir, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { executeClosedLoop } from './run-closed-loop.mjs'
import { executeFailedUpdate } from './run-failed-update.mjs'
import { executeProviderReplacement } from './run-provider-replacement.mjs'

export async function executeAllScenarios({ writeArtifacts = true } = {}) {
  const scenario1 = await executeClosedLoop({ writeArtifacts })
  const scenario2 = await executeProviderReplacement({ writeArtifacts })
  const scenario3 = await executeFailedUpdate({ writeArtifacts })
  const result = {
    status: [scenario1, scenario2, scenario3].every(result => result.status === 'PASS') ? 'PASS' : 'FAIL',
    scenarios: [
      { id: 1, name: 'provider removal', status: scenario1.status },
      { id: 2, name: scenario2.scenario, status: scenario2.status },
      { id: 3, name: scenario3.scenario, status: scenario3.status },
    ],
    semanticSubstrateReuse: [
      'FactStore ground facts',
      'snapshot identity and coverage',
      'fact-only queries',
      'independent native comparators',
      'actual lifecycle post-state validation',
      'provenance paths and explicit absence',
    ],
  }
  if (writeArtifacts) {
    const here = dirname(fileURLToPath(import.meta.url))
    const output = join(here, '..', 'artifacts')
    await mkdir(output, { recursive: true })
    await Promise.all([
      writeFile(join(output, 'all-scenarios-result.json'), JSON.stringify(result, null, 2) + '\n'),
      writeFile(join(output, 'all-scenarios-report.md'), renderReport(result)),
    ])
  }
  return result
}

function renderReport(result) {
  return `# Cordis semantic-mirror executable witnesses

Status: **${result.status}**

${result.scenarios.map(item => `- Scenario ${item.id}: ${item.name} — ${item.status}`).join('\n')}

## Reused semantic substrate

${result.semanticSubstrateReuse.map(item => `- ${item}`).join('\n')}
`
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const result = await executeAllScenarios()
  process.stdout.write(JSON.stringify(result, null, 2) + '\n')
}
