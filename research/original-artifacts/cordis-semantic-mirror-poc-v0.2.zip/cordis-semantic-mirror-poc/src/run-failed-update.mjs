import assert from 'node:assert/strict'
import { mkdir, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createFailedUpdateFixture } from './dsh-fixture.mjs'
import { inspectDynamicPackageDirectly } from './dynamic-direct-oracle.mjs'
import { DynamicPackageCollector } from './dynamic-collector.mjs'
import { FactStore } from './facts.mjs'
import { explainDynamicPackageState } from './package-query.mjs'

export async function executeFailedUpdate({ writeArtifacts = true } = {}) {
  const fixture = await createFailedUpdateFixture()
  const collector = new DynamicPackageCollector(fixture.runner)
  const pluginId = String(fixture.first.pluginId)
  const firstPackageId = String(fixture.first.packageId)
  const before = collector.capture('v1_running_before_update')
  const beforeQuery = explainDynamicPackageState(before, pluginId)

  const second = fixture.defineBrokenUpdate()
  const secondPackageId = String(second.packageId)
  const failedReceipt = await fixture.runner.run(
    fixture.agent,
    fixture.first.pluginId,
    second.packageId,
    'update',
  )
  assert.equal(failedReceipt.ok, false)
  assert.equal(failedReceipt.reason, 'host-half-failed')

  const failed = collector.capture('v2_update_failed')
  const relationalFailed = explainDynamicPackageState(failed, pluginId)
  const directFailed = inspectDynamicPackageDirectly(fixture.runner, pluginId)

  assert.equal(relationalFailed.lastSuccessfulPackageId, firstPackageId)
  assert.equal(relationalFailed.failedOrInProgressTargetPackageId, secondPackageId)
  assert.equal(relationalFailed.activeRun, null)
  assert.equal(relationalFailed.latestAttemptStatus, 'failed')
  assert.equal(relationalFailed.failedUpdateGap, true)
  assert.equal(relationalFailed.lastSuccessfulIsCurrentlyRunning, false)
  assert.deepEqual(relationalFailed.recovery, {
    kind: 'explicit_run_of_last_successful_package',
    packageId: firstPackageId,
    mode: 'run',
  })
  assert.equal(relationalFailed.rejectedInference, 'last_successful_package_does_not_imply_active_run')
  assert.equal(directFailed.lastSuccessfulPackageId, relationalFailed.lastSuccessfulPackageId)
  assert.equal(
    directFailed.failedOrInProgressTargetPackageId,
    relationalFailed.failedOrInProgressTargetPackageId,
  )
  assert.deepEqual(directFailed.activeRun, relationalFailed.activeRun)
  assert.equal(directFailed.latestAttemptStatus, relationalFailed.latestAttemptStatus)

  const recoveryReceipt = await fixture.runner.run(
    fixture.agent,
    fixture.first.pluginId,
    fixture.first.packageId,
    'run',
  )
  assert.equal(recoveryReceipt.ok, true)

  const recovered = collector.capture('v1_explicitly_restarted')
  const relationalRecovered = explainDynamicPackageState(recovered, pluginId)
  const directRecovered = inspectDynamicPackageDirectly(fixture.runner, pluginId)

  assert.equal(relationalRecovered.lastSuccessfulPackageId, firstPackageId)
  assert.equal(relationalRecovered.failedOrInProgressTargetPackageId, null)
  assert.equal(relationalRecovered.activeRun.packageId, firstPackageId)
  assert.equal(relationalRecovered.latestAttemptStatus, 'running')
  assert.equal(relationalRecovered.lastSuccessfulIsCurrentlyRunning, true)
  assert.equal(relationalRecovered.recovery, null)
  assert.deepEqual(directRecovered.activeRun, relationalRecovered.activeRun)
  assert.equal(
    directRecovered.failedOrInProgressTargetPackageId,
    relationalRecovered.failedOrInProgressTargetPackageId,
  )

  const transitionFacts = buildTransitionFacts({
    before,
    failed,
    recovered,
    firstPackageId,
    secondPackageId,
  })
  const result = {
    status: 'PASS',
    scenario: 'failed dsh update',
    claim: 'One relational query distinguished the last successful immutable package from the absent active run after a real Host-half update failure, matched native inventory, and prescribed the explicit v1 run that restored service.',
    scope: 'single process, one dynamic plugin, two immutable host-only packages',
    sourceRuntime: {
      packages: [
        { name: '@deepseek-ai/cordis', version: '4.0.2' },
        { name: '@deepseek-ai/dsh-cordis-host-runner', version: '0.1.2-alpha.5' },
      ],
    },
    identities: { pluginId, firstPackageId, secondPackageId },
    snapshots: { before: before.id, failed: failed.id, recovered: recovered.id },
    beforeQuery,
    failedReceipt,
    relationalFailed,
    directFailed,
    recoveryReceipt,
    relationalRecovered,
    directRecovered,
    nativeEvents: fixture.nativeEvents,
    semanticEvidence: {
      beforeFactCount: before.facts.facts().length,
      failedFactCount: failed.facts.facts().length,
      recoveredFactCount: recovered.facts.facts().length,
      lastSuccessfulRetainedAfterFailure: relationalFailed.lastSuccessfulPackageId === firstPackageId,
      activeRunStronglyAbsentAfterFailure: failed.facts.has(
        'absence_fact', failed.id, 'active_run', pluginId,
      ),
      failedTargetRetained: relationalFailed.failedOrInProgressTargetPackageId === secondPackageId,
      explicitRecoveryExecuted: recoveryReceipt.ok,
      activeRunRestoredToLastSuccessful: relationalRecovered.activeRun.packageId === firstPackageId,
    },
    differentialEvidence: {
      relationalConsumerCalls: 1,
      nativeFieldsRead: directFailed.nativeReads,
      failureStateAgreement: true,
      recoveryStateAgreement: true,
    },
  }

  if (writeArtifacts) {
    await writeScenarioArtifacts({ before, failed, recovered, transitionFacts, result })
  }

  await fixture.runnerFiber.dispose()
  await fixture.disposeTools()
  return result
}

function buildTransitionFacts({
  before,
  failed,
  recovered,
  firstPackageId,
  secondPackageId,
}) {
  const facts = new FactStore()
  facts.add('transition_event', 'event:dsh-dynamic:failed-update')
  facts.add('event_sequence', 'event:dsh-dynamic:failed-update', 1)
  facts.add('event_kind', 'event:dsh-dynamic:failed-update', 'request_update')
  facts.add('event_subject', 'event:dsh-dynamic:failed-update', secondPackageId)
  facts.add('event_from', 'event:dsh-dynamic:failed-update', before.id)
  facts.add('event_to', 'event:dsh-dynamic:failed-update', failed.id)
  facts.add('event_outcome', 'event:dsh-dynamic:failed-update', 'host_half_failed')
  facts.add('transition_event', 'event:dsh-dynamic:explicit-recovery')
  facts.add('event_sequence', 'event:dsh-dynamic:explicit-recovery', 2)
  facts.add('event_kind', 'event:dsh-dynamic:explicit-recovery', 'explicit_run')
  facts.add('event_subject', 'event:dsh-dynamic:explicit-recovery', firstPackageId)
  facts.add('event_from', 'event:dsh-dynamic:explicit-recovery', failed.id)
  facts.add('event_to', 'event:dsh-dynamic:explicit-recovery', recovered.id)
  facts.add('event_outcome', 'event:dsh-dynamic:explicit-recovery', 'succeeded')
  facts.add('event_cause', 'event:dsh-dynamic:explicit-recovery', 'event:dsh-dynamic:failed-update')
  facts.add('recovery_required', failed.id, 'explicit_run_of_last_successful_package')
  return facts
}

async function writeScenarioArtifacts({ before, failed, recovered, transitionFacts, result }) {
  const here = dirname(fileURLToPath(import.meta.url))
  const output = join(here, '..', 'artifacts', 'scenario-3')
  await mkdir(output, { recursive: true })
  await Promise.all([
    writeFile(join(output, 'before.facts'), before.facts.toText()),
    writeFile(join(output, 'failed.facts'), failed.facts.toText()),
    writeFile(join(output, 'recovered.facts'), recovered.facts.toText()),
    writeFile(join(output, 'transitions.facts'), transitionFacts.toText()),
    writeFile(join(output, 'before.json'), JSON.stringify(before.facts.toJSON(), null, 2) + '\n'),
    writeFile(join(output, 'failed.json'), JSON.stringify(failed.facts.toJSON(), null, 2) + '\n'),
    writeFile(join(output, 'recovered.json'), JSON.stringify(recovered.facts.toJSON(), null, 2) + '\n'),
    writeFile(join(output, 'package-query.json'), JSON.stringify(result.relationalFailed, null, 2) + '\n'),
    writeFile(join(output, 'direct-inspection.json'), JSON.stringify(result.directFailed, null, 2) + '\n'),
    writeFile(join(output, 'native-events.json'), JSON.stringify(result.nativeEvents, null, 2) + '\n'),
    writeFile(join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n'),
    writeFile(join(output, 'report.md'), renderReport(result)),
  ])
}

function renderReport(result) {
  return `# Scenario 3: failed dsh update

Status: **${result.status}**

The live runner attempted ${result.identities.secondPackageId} and returned \`${result.failedReceipt.reason}\`.

## State after failure

- last successful package: ${result.relationalFailed.lastSuccessfulPackageId}
- failed target package: ${result.relationalFailed.failedOrInProgressTargetPackageId}
- active run: none (strong absence fact)
- latest attempt: ${result.relationalFailed.latestAttemptStatus}
- rejected inference: ${result.relationalFailed.rejectedInference}
- recovery: \`run(${result.relationalFailed.recovery.packageId}, mode=${result.relationalFailed.recovery.mode})\`
- native inventory agreed: ${result.differentialEvidence.failureStateAgreement}

## State after explicit recovery

- last successful package: ${result.relationalRecovered.lastSuccessfulPackageId}
- active package: ${result.relationalRecovered.activeRun.packageId}
- next package: none
- latest attempt: ${result.relationalRecovered.latestAttemptStatus}
- native inventory agreed: ${result.differentialEvidence.recoveryStateAgreement}
`
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const result = await executeFailedUpdate()
  process.stdout.write(JSON.stringify({
    status: result.status,
    scenario: result.scenario,
    identities: result.identities,
    snapshots: result.snapshots,
    failure: {
      reason: result.failedReceipt.reason,
      lastSuccessfulPackageId: result.relationalFailed.lastSuccessfulPackageId,
      failedTargetPackageId: result.relationalFailed.failedOrInProgressTargetPackageId,
      activeRun: result.relationalFailed.activeRun,
      latestAttemptStatus: result.relationalFailed.latestAttemptStatus,
      recovery: result.relationalFailed.recovery,
    },
    recovered: result.relationalRecovered,
    semanticEvidence: result.semanticEvidence,
  }, null, 2) + '\n')
}
