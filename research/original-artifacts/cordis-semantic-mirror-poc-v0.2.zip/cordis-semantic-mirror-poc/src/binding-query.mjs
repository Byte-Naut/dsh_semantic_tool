export function explainBindingDivergence(snapshot, consumerFiberId, serviceKey) {
  const { facts, id: snapshotId } = snapshot
  if (!facts.has('fiber_member', snapshotId, consumerFiberId)) {
    throw new Error(`fiber is not present in ${snapshotId}: ${consumerFiberId}`)
  }
  if (!facts.has('declared_injection', consumerFiberId, serviceKey, 'required')) {
    throw new Error(`fiber does not declare required injection ${serviceKey}: ${consumerFiberId}`)
  }

  const state = oneValue(facts.rows('fiber_state'), [snapshotId, consumerFiberId], 2)
  const targetImplId = optionalValue(
    facts.rows('target_binding'),
    [snapshotId, consumerFiberId, serviceKey],
    3,
  )
  const committedImplId = optionalValue(
    facts.rows('committed_binding'),
    [snapshotId, consumerFiberId, serviceKey],
    3,
  )
  const target = describeImpl(facts, targetImplId)
  const committed = describeImpl(facts, committedImplId)
  const diverged = targetImplId !== undefined
    && committedImplId !== undefined
    && targetImplId !== committedImplId

  const coverage = Object.fromEntries(
    facts.rows('domain_coverage')
      .filter(([snap]) => snap === snapshotId)
      .map(([, domain, status]) => [domain, status]),
  )
  const requiredDomains = ['registry_fibers', 'reflect_services', 'fiber_bindings']
  const unknowns = requiredDomains
    .filter(domain => coverage[domain] !== 'complete')
    .map(domain => `incomplete domain: ${domain}`)

  const stableReplacement = state === 'loading' && diverged
    ? {
        kind: 'finish_then_reload_target_binding',
        expectedFinalState: 'active',
        expectedFinalServiceImplId: targetImplId,
        assumptions: [
          'target binding remains visible',
          'current load and cleanup settle',
          'target apply succeeds',
        ],
      }
    : undefined

  return {
    query: 'explain_binding_divergence',
    snapshotId,
    consumer: {
      fiberId: consumerFiberId,
      name: oneValue(facts.rows('fiber_name'), [consumerFiberId], 1),
      state,
      serviceKey,
    },
    target,
    committed,
    diverged,
    witness: diverged ? 'target_binding_not_equal_committed_binding' : 'bindings_equal_or_incomplete',
    lifecycleInterpretation: stableReplacement,
    coverage,
    unknowns,
    confidence: unknowns.length ? 'partial' : 'complete_within_declared_fixture_scope',
    provenancePaths: [
      ['fiber_state', snapshotId, consumerFiberId, state],
      ...(targetImplId === undefined ? [] : [['target_binding', snapshotId, consumerFiberId, serviceKey, targetImplId]]),
      ...(committedImplId === undefined ? [] : [['committed_binding', snapshotId, consumerFiberId, serviceKey, committedImplId]]),
    ],
    resultFacets: [
      'consumer_state',
      'target_provider',
      'committed_provider',
      'binding_divergence',
      'lifecycle_interpretation',
      'coverage',
      'provenance_paths',
    ],
  }
}

function describeImpl(facts, implId) {
  if (implId === undefined) return null
  const providerFiberId = oneValue(facts.rows('service_impl_provider'), [implId], 1)
  return {
    serviceImplId: implId,
    serviceKey: oneValue(facts.rows('service_impl_key'), [implId], 1),
    providerFiberId,
    providerName: oneValue(facts.rows('fiber_name'), [providerFiberId], 1),
  }
}

function optionalValue(rows, prefix, resultIndex) {
  const matches = rows.filter(row => prefix.every((value, index) => row[index] === value))
  if (matches.length > 1) {
    throw new Error(`expected at most one relational value for ${prefix.join('/')}; found ${matches.length}`)
  }
  return matches[0]?.[resultIndex]
}

function oneValue(rows, prefix, resultIndex) {
  const value = optionalValue(rows, prefix, resultIndex)
  if (value === undefined) {
    throw new Error(`expected one relational value for ${prefix.join('/')}; found 0`)
  }
  return value
}
