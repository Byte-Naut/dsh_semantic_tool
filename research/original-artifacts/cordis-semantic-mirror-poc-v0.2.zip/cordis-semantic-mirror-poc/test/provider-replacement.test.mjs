import assert from 'node:assert/strict'
import test from 'node:test'
import { executeProviderReplacement } from '../src/run-provider-replacement.mjs'

test('target and committed bindings remain distinct during LOADING replacement', async () => {
  const result = await executeProviderReplacement({ writeArtifacts: false })
  assert.equal(result.status, 'PASS')
  assert.equal(result.relationalDuring.consumer.state, 'loading')
  assert.equal(result.relationalDuring.target.providerName, 'clock-provider-v2')
  assert.equal(result.relationalDuring.committed.providerName, 'clock-provider-v1')
  assert.equal(result.semanticEvidence.identitiesDistinct, true)
  assert.equal(result.actualAfter.fiberStates.consumer, 'active')
  assert.equal(result.actualAfter.visibleClockProvider, 'clock-provider-v2')
  assert.equal(result.semanticEvidence.finalBindingsConverged, true)
})
