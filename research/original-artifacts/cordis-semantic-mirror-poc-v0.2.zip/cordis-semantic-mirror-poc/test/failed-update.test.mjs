import assert from 'node:assert/strict'
import test from 'node:test'
import { executeFailedUpdate } from '../src/run-failed-update.mjs'

test('failed dsh update separates last successful package from active run', async () => {
  const result = await executeFailedUpdate({ writeArtifacts: false })
  assert.equal(result.status, 'PASS')
  assert.equal(result.failedReceipt.reason, 'host-half-failed')
  assert.equal(result.relationalFailed.lastSuccessfulPackageId, result.identities.firstPackageId)
  assert.equal(result.relationalFailed.failedOrInProgressTargetPackageId, result.identities.secondPackageId)
  assert.equal(result.relationalFailed.activeRun, null)
  assert.equal(result.relationalFailed.lastSuccessfulIsCurrentlyRunning, false)
  assert.deepEqual(result.relationalFailed.recovery, {
    kind: 'explicit_run_of_last_successful_package',
    packageId: result.identities.firstPackageId,
    mode: 'run',
  })
  assert.equal(result.relationalRecovered.activeRun.packageId, result.identities.firstPackageId)
  assert.equal(result.relationalRecovered.lastSuccessfulIsCurrentlyRunning, true)
})
