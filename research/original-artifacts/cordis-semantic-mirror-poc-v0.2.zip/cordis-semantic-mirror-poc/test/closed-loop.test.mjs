import assert from 'node:assert/strict'
import test from 'node:test'
import { executeClosedLoop } from '../src/run-closed-loop.mjs'

test('impact_remove matches direct Cordis inspection and actual lifecycle', async () => {
  const result = await executeClosedLoop({ writeArtifacts: false })
  assert.equal(result.status, 'PASS')
  assert.deepEqual(result.relational.directConsumers, ['clock-ui'])
  assert.deepEqual(result.relational.transitiveConsumers, ['clock-reporter'])
  assert.equal(result.actualAfter.fiberStates.provider, 'disposed')
  assert.equal(result.actualAfter.fiberStates.ui, 'pending')
  assert.equal(result.actualAfter.fiberStates.reporter, 'pending')
  assert.deepEqual(result.actualAfter.visibleServices, [])
  assert.deepEqual(result.actualAfter.activeEffects, [])
  assert.equal(result.semanticEvidence.targetBindingCount, 2)
  assert.equal(result.semanticEvidence.committedBindingCount, 2)
  assert.equal(result.semanticEvidence.disposedEffectFactCount, 6)
  assert.equal(result.semanticEvidence.providerRetainedAsTombstone, true)
  assert.equal(result.semanticEvidence.providerStateAfter, 'disposed')
})
