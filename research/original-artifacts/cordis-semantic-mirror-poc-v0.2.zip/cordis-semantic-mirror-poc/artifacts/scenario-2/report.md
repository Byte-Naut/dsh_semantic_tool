# Scenario 2: provider replacement while consumer LOADING

Status: **PASS**

At the in-flight snapshot, `slow-clock-consumer` was **loading**.

- target binding: clock-provider-v2 / service-impl:rt:cordis-replacement:1:23
- committed binding: clock-provider-v1 / service-impl:rt:cordis-replacement:1:18
- identities distinct: true
- direct native inspection agreed: true

After the first load settled, Cordis unloaded the v1-owned effects and reloaded the same consumer against v2.

- final consumer state: active
- final visible provider: clock-provider-v2
- apply versions: v1 -> v2
- disposed consumer sessions: v1
- target/committed converged: true
