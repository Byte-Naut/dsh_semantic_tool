# Scenario 3: failed dsh update

Status: **PASS**

The live runner attempted pkg-2 and returned `host-half-failed`.

## State after failure

- last successful package: pkg-1
- failed target package: pkg-2
- active run: none (strong absence fact)
- latest attempt: failed
- rejected inference: last_successful_package_does_not_imply_active_run
- recovery: `run(pkg-1, mode=run)`
- native inventory agreed: true

## State after explicit recovery

- last successful package: pkg-1
- active package: pkg-1
- next package: none
- latest attempt: running
- native inventory agreed: true
