# Cordis minimal closed-loop result

Status: **PASS**

The one-call relational query matched an independent traversal of live Cordis internals and the observed post-disposal lifecycle in the bounded fixture.

## Predicted impact

Direct consumers: clock-ui

Transitive consumers: clock-reporter

- clock-reporter: pending
- clock-ui: pending

Effects:

- clock-provider: ctx.provide("clock")
- clock-provider: provider-audit
- clock-reporter: reporter-poll
- clock-ui: ctx.provide("clockView")
- clock-ui: ui-render-loop

## Actual post-state

- provider: disposed
- UI: pending
- reporter: pending
- visible services: 0
- active fixture effects: 0
- disposed effect facts: 6
- provider retained as tombstone: true

## Compression evidence

The caller used one relational query returning 7 result facets.
The independent native comparator touched 5 Cordis domains:
- registry
- runtime.fibers
- fiber._store
- reflect.store
- fiber.getEffects

This demonstrates interface compression in the bounded fixture. It does not yet prove lower general Agent reasoning complexity.
